<?php
/**
 * Opzioni dei moduli e di DS Core (dalla 0.13.0). Caricato sempre, anche sul sito pubblico: poche funzioni, nessun
 * disegno. Il disegno e il salvataggio dei campi stanno in includes/impostazioni.php (solo amministrazione).
 *
 * Un modulo dichiara le sue scelte nel registro (includes/registro.php) con 'opzione' (nome dell'opzione nel
 * database) e 'campi' (elenco dei campi: tipo, predefinito, limiti, valori ammessi). DS Core le mostra e le salva
 * anche a modulo spento, senza eseguire codice del modulo; il modulo acceso le legge con:
 *
 *   $valori = ds_core_opzioni_modulo( 'my-module' );   // valori salvati, puliti, con i predefiniti
 *
 * Le scelte di DS Core stesso (l'indirizzo degli avvisi; il canale dell'aggiornatore, nascosto) sono il gruppo
 * riservato 'ds-core', opzione ds_core_generali: ds_core_opzioni_modulo( 'ds-core' ); l'indirizzo degli avvisi si
 * legge con ds_core_indirizzo_avvisi() (includes/avvisi.php, dalla 0.15.0 con la conferma del cambio).
 *
 * Tipi di campo (ds_core_tipi_campo()) e chiavi di ogni campo:
 * - tipo         text, email, url (solo https, dalla 0.16.0), number, checkbox, radio, select, checkboxes, plugins, color
 * - predefinito  valore quando il campo non è mai stato salvato (o il valore salvato non è valido)
 * - predefinito_da  facoltativo: funzione (nome o closure) che calcola il predefinito. Deve esistere anche a modulo
 *                spento, quindi sta nel file principale del plugin, non nel file del modulo
 * - min, max     number: limiti (i valori fuori si riconducono al limite); passo: 1 = numeri interi (predefinito)
 * - scelte       radio, select, checkboxes: valori ammessi (array di chiavi); i nomi visibili stanno nei testi
 * - lunghezza    text: lunghezza massima (predefinita 200)
 * - gruppo       facoltativo: chiave del gruppo, per un titolo sopra i campi dello stesso gruppo (testi 'gruppi')
 * - mostra_se    facoltativo: array( chiave di un altro campo, valore ): il campo si mostra solo con quel valore
 *                (JavaScript); senza JavaScript resta visibile e conta il modulo, che lo ignora con l'altro valore
 * - nascosto     facoltativo (dalla 0.16.1): true = il campo non si mostra e non si cambia dal pannello; il valore
 *                salvato resta com'è a ogni salvataggio (si legge come gli altri con ds_core_opzioni_modulo())
 * - contrasto    facoltativo, solo color (dalla 0.18.0): true = sotto il campo l'anteprima del colore con il testo
 *                scelto per il contrasto (ds_core_colore_leggibile())
 *
 * I testi (etichetta, aiuto, unità, nomi delle scelte, titoli dei gruppi) stanno nella funzione 'testi' del modulo,
 * come titolo e descrizione, perché si traducono solo dopo init:
 *
 *   'campi'  => array( 'chiave' => array( 'etichetta' => …, 'aiuto' => …, 'unita' => …, 'scelte' => array( valore => nome ),
 *                                        'testo' => frase accanto a una casella (checkbox),
 *                                        'breve' => testo corto per il riepilogo della riga (0.18.0, includes/impostazioni.php),
 *                                        'vuoto' => colore usato quando un campo color è vuoto (anteprima),
 *                                        'anteprima' => righe e frasi in più dell'anteprima (0.18.1, ds_core_anteprima_colore_html()) ) ),
 *   'gruppi' => array( 'gruppo' => titolo ),
 *
 * Salvare non applica niente da solo: DS Core lancia l'azione 'ds_core_impostazioni_salvate' ( $id, $prima, $dopo )
 * e il modulo, se è acceso, la ascolta e applica.
 */

defined( 'ABSPATH' ) || exit;

/** Tipi di campo che DS Core sa disegnare, controllare e salvare. */
function ds_core_tipi_campo() {
	return array( 'text', 'email', 'url', 'number', 'checkbox', 'radio', 'select', 'checkboxes', 'plugins', 'color' );
}

/** Opzioni di DS Core che nessun modulo può usare per le sue scelte. */
function ds_core_opzioni_riservate() {
	return array( 'ds_core_stati', 'ds_core_errori', 'ds_core_storia', 'ds_core_generali', 'ds_core_db', 'ds_core_accesso_fino', 'ds_core_accesso_nonce', 'ds_core_ra_db', 'ds_core_avvisi_attesa', 'ds_core_emergenza_vista', 'ds_core_rilasci_offerta', 'ds_core_rilasci_stato' );
}

/** Campi delle impostazioni generali di DS Core (gruppo 'ds-core'). */
function ds_core_campi_generali() {
	return array(
		// Indirizzo confermato: si cambia solo con la conferma dal nuovo indirizzo (includes/avvisi.php).
		'avvisi'      => array(
			'tipo'        => 'email',
			'predefinito' => '',
		),
		'anche_admin' => array(
			'tipo'        => 'checkbox',
			'predefinito' => false,
		),
		/*
		 * Canale dell'aggiornatore firmato (includes/aggiornatore.php). Dalla 0.16.1 non si mostra e non si cambia dal
		 * pannello ('nascosto'): resta nello schema solo perché il valore 'test' salvato con la 0.16.0 continui a
		 * valere e non si perda quando si salvano le impostazioni generali. Il canale si sceglie con DS_CORE_CANALE in
		 * wp-config.php. L'indirizzo dei rilasci ('rilasci' della 0.16.0) non è più un'impostazione: solo la costante
		 * DS_CORE_RILASCI_URL; il valore rimasto nel database si ignora e si toglie al primo salvataggio.
		 */
		'canale'      => array(
			'tipo'        => 'radio',
			'scelte'      => array( 'stabile', 'test' ),
			'predefinito' => 'stabile',
			'nascosto'    => true,
		),
	);
}

/** Testi delle impostazioni generali, tradotti. Solo dopo init (pannello). */
function ds_core_testi_generali() {
	return array(
		'campi' => array(
			'avvisi' => array(
				'etichetta' => __( 'Notification address', 'ds-core' ),
				'aiuto'     => __( 'All DS Core emails go here: update notices, Claude Code access openings, the weekly activity log summary and security notices. Empty = the site administrator email. A new address takes effect only after it is confirmed from the link sent to it; until then the emails keep going to the current one.', 'ds-core' ),
			),
			'anche_admin' => array(
				'etichetta' => __( 'Site administrator', 'ds-core' ),
				/* translators: %s: site administrator email address. */
				'testo'     => sprintf( __( 'Also send every DS Core email to the site administrator email (%s)', 'ds-core' ), (string) get_option( 'admin_email' ) ),
				'aiuto'     => __( 'Security notices always go there too, whatever you choose here: Claude Code access openings and closings before time is up, requests and confirmations of a new notification address, the emergency switch, a refused DS Core update, a new administrator account. Each address gets its own email, WordPress update emails included: nobody sees the other address.', 'ds-core' ),
			),
		),
	);
}

/**
 * Controlla un elenco di campi dichiarato nel registro e lo restituisce pulito: chiave => campo con tutte le chiavi.
 * I campi sbagliati si saltano e finiscono in $problemi (testi brevi, per la riga del modulo): un errore nello schema
 * non ferma né il pannello né il sito.
 */
function ds_core_schema( $campi, &$problemi = array() ) {
	$problemi = array();
	$schema   = array();
	if ( ! is_array( $campi ) ) {
		return $schema;
	}
	$tipi = ds_core_tipi_campo();
	foreach ( $campi as $chiave => $campo ) {
		$chiave = (string) $chiave;
		if ( '' === $chiave || sanitize_key( $chiave ) !== $chiave || ! is_array( $campo ) ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: invalid name or definition.';
			continue;
		}
		$tipo = isset( $campo['tipo'] ) ? (string) $campo['tipo'] : '';
		if ( ! in_array( $tipo, $tipi, true ) ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: unknown type "' . $tipo . '".';
			continue;
		}
		$pulito = array(
			'tipo'           => $tipo,
			'predefinito'    => $campo['predefinito'] ?? null,
			'predefinito_da' => isset( $campo['predefinito_da'] ) && is_callable( $campo['predefinito_da'] ) ? $campo['predefinito_da'] : null,
			'min'            => isset( $campo['min'] ) && is_numeric( $campo['min'] ) ? 0 + $campo['min'] : null,
			'max'            => isset( $campo['max'] ) && is_numeric( $campo['max'] ) ? 0 + $campo['max'] : null,
			'passo'          => isset( $campo['passo'] ) && is_numeric( $campo['passo'] ) && $campo['passo'] > 0 ? 0 + $campo['passo'] : 1,
			'scelte'         => array(),
			'lunghezza'      => isset( $campo['lunghezza'] ) ? max( 1, (int) $campo['lunghezza'] ) : 200,
			'gruppo'         => isset( $campo['gruppo'] ) ? sanitize_key( (string) $campo['gruppo'] ) : '',
			'nascosto'       => ! empty( $campo['nascosto'] ),
			'contrasto'      => 'color' === $tipo && ! empty( $campo['contrasto'] ),
			'mostra_se'      => isset( $campo['mostra_se'] ) && is_array( $campo['mostra_se'] ) && 2 === count( $campo['mostra_se'] ) ? array( sanitize_key( (string) reset( $campo['mostra_se'] ) ), (string) end( $campo['mostra_se'] ) ) : array(),
		);
		if ( in_array( $tipo, array( 'radio', 'select', 'checkboxes' ), true ) ) {
			$scelte = isset( $campo['scelte'] ) && is_array( $campo['scelte'] ) ? array_values( array_unique( array_map( 'strval', array_filter( $campo['scelte'], 'is_scalar' ) ) ) ) : array();
			if ( ! $scelte ) {
				$problemi[] = 'Field "' . $chiave . '" skipped: no choices.';
				continue;
			}
			$pulito['scelte'] = $scelte;
		}
		if ( null !== $pulito['min'] && null !== $pulito['max'] && $pulito['min'] > $pulito['max'] ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: min is greater than max.';
			continue;
		}
		// Il predefinito dichiarato passa dalla stessa pulizia dei valori salvati: se non è valido diventa neutro.
		$errore                = '';
		$valore                = ds_core_valore_campo( $pulito, $pulito['predefinito'], false, $errore );
		$pulito['predefinito'] = '' === $errore ? $valore : ds_core_valore_neutro( $pulito );
		$schema[ $chiave ]     = $pulito;
	}
	return $schema;
}

/** Valore «vuoto» di un tipo di campo. */
function ds_core_valore_neutro( $campo ) {
	switch ( $campo['tipo'] ) {
		case 'number':
			return null !== $campo['min'] ? $campo['min'] : 0;
		case 'checkbox':
			return false;
		case 'checkboxes':
		case 'plugins':
			return array();
		case 'radio':
		case 'select':
			return $campo['scelte'][0] ?? '';
	}
	return '';
}

/** Predefinito di un campo, calcolato se il campo ha 'predefinito_da'. Un errore nella funzione dà il predefinito fisso. */
function ds_core_predefinito( $campo ) {
	if ( $campo['predefinito_da'] ) {
		try {
			$errore = '';
			$valore = ds_core_valore_campo( $campo, call_user_func( $campo['predefinito_da'] ), false, $errore );
			if ( '' === $errore ) {
				return $valore;
			}
		} catch ( \Throwable $e ) {
			error_log( '[DS Core] default value not computed: ' . $e->getMessage() );
		}
	}
	return $campo['predefinito'];
}

/**
 * Pulisce un valore secondo il tipo del campo. Restituisce il valore pulito; se il valore non si può accettare,
 * $errore contiene il motivo (tradotto se le traduzioni sono già caricate) e il valore restituito non va usato.
 * $severo = true nel salvataggio dal pannello: i plugin si confrontano con quelli installati (lettura dei file, solo
 * in amministrazione). I numeri fuori dai limiti si riconducono al limite, senza errore.
 */
function ds_core_valore_campo( $campo, $grezzo, $severo, &$errore ) {
	$errore = '';
	switch ( $campo['tipo'] ) {
		case 'text':
			if ( ! is_scalar( $grezzo ) && null !== $grezzo ) {
				$errore = ds_core_testo_errore( 'testo' );
				return '';
			}
			$valore = sanitize_text_field( (string) $grezzo );
			return function_exists( 'mb_substr' ) ? mb_substr( $valore, 0, $campo['lunghezza'] ) : substr( $valore, 0, $campo['lunghezza'] );

		case 'email':
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = sanitize_email( $valore );
			if ( ! is_email( $valore ) ) {
				$errore = ds_core_testo_errore( 'email' );
				return '';
			}
			return $valore;

		case 'url':
			// Solo https, con host, senza utente e password (dalla 0.16.0).
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = esc_url_raw( $valore, array( 'https' ) );
			$parti  = '' !== $valore ? wp_parse_url( $valore ) : false;
			if ( ! is_array( $parti ) || 'https' !== strtolower( (string) ( $parti['scheme'] ?? '' ) ) || empty( $parti['host'] ) || isset( $parti['user'] ) || isset( $parti['pass'] ) ) {
				$errore = ds_core_testo_errore( 'url' );
				return '';
			}
			return function_exists( 'mb_substr' ) ? mb_substr( $valore, 0, $campo['lunghezza'] ) : substr( $valore, 0, $campo['lunghezza'] );

		case 'number':
			if ( ! is_scalar( $grezzo ) || '' === trim( (string) $grezzo ) || ! is_numeric( trim( (string) $grezzo ) ) ) {
				$errore = ds_core_testo_errore( 'numero' );
				return 0;
			}
			$valore = 0 + trim( (string) $grezzo );
			if ( floor( $campo['passo'] ) == $campo['passo'] ) { // phpcs:ignore Universal.Operators.StrictComparisons -- 1 e 1.0 sono lo stesso passo.
				$valore = (int) round( $valore );
			}
			if ( null !== $campo['min'] && $valore < $campo['min'] ) {
				$valore = $campo['min'];
			}
			if ( null !== $campo['max'] && $valore > $campo['max'] ) {
				$valore = $campo['max'];
			}
			return $valore;

		case 'checkbox':
			return true === $grezzo || 1 === $grezzo || ( is_string( $grezzo ) && in_array( strtolower( $grezzo ), array( '1', 'on', 'yes', 'true' ), true ) );

		case 'radio':
		case 'select':
			$valore = is_scalar( $grezzo ) ? (string) $grezzo : '';
			if ( ! in_array( $valore, $campo['scelte'], true ) ) {
				$errore = ds_core_testo_errore( 'scelta' );
				return '';
			}
			return $valore;

		case 'checkboxes':
			$valori = is_array( $grezzo ) ? array_map( 'strval', array_filter( $grezzo, 'is_scalar' ) ) : array();
			return array_values( array_intersect( $campo['scelte'], $valori ) );

		case 'plugins':
			$valori = is_array( $grezzo ) ? array_values( array_unique( array_map( 'sanitize_text_field', array_map( 'strval', array_filter( $grezzo, 'is_scalar' ) ) ) ) ) : array();
			if ( $severo ) {
				if ( ! function_exists( 'get_plugins' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}
				$valori = array_values( array_intersect( $valori, array_keys( get_plugins() ) ) );
			}
			return $valori;

		case 'color':
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = sanitize_hex_color( $valore );
			if ( ! $valore ) {
				$errore = ds_core_testo_errore( 'colore' );
				return '';
			}
			return strtolower( $valore );
	}
	$errore = ds_core_testo_errore( 'testo' );
	return '';
}

/** Motivi per cui un valore non si accetta. Tradotti solo dopo init; prima (sito pubblico, cron) servono solo da segnale. */
function ds_core_testo_errore( $codice ) {
	if ( ! did_action( 'init' ) ) {
		return $codice;
	}
	$testi = array(
		'email'  => __( 'Enter a valid email address, or leave the field empty.', 'ds-core' ),
		'url'    => __( 'Enter an address that starts with https://, or leave the field empty.', 'ds-core' ),
		'numero' => __( 'Enter a number.', 'ds-core' ),
		'scelta' => __( 'Choose one of the options.', 'ds-core' ),
		'colore' => __( 'Enter a color as #rrggbb, or leave the field empty.', 'ds-core' ),
		'testo'  => __( 'This value cannot be saved.', 'ds-core' ),
	);
	return $testi[ $codice ] ?? $testi['testo'];
}

/**
 * Gruppo di impostazioni: array( 'opzione' => nome, 'schema' => campi puliti, 'problemi' => errori dello schema ),
 * oppure null se l'ID non ha scelte. 'ds-core' è il gruppo riservato alle impostazioni generali.
 */
function ds_core_gruppo_impostazioni( $id ) {
	$problemi = array();
	if ( 'ds-core' === $id ) {
		$schema = ds_core_schema( ds_core_campi_generali(), $problemi );
		return array( 'opzione' => 'ds_core_generali', 'schema' => $schema, 'problemi' => $problemi );
	}
	$id       = ds_core_id_attuale( $id ); // vecchi ID (prima della 0.17.0) accettati
	$registro = ds_core_registro();
	if ( ! isset( $registro[ $id ] ) || '' === $registro[ $id ]['opzione'] || ! $registro[ $id ]['campi'] ) {
		return null;
	}
	// Anche con lo schema tutto sbagliato il gruppo esiste: il pannello mostra i problemi nella riga del modulo.
	$schema = ds_core_schema( $registro[ $id ]['campi'], $problemi );
	return array( 'opzione' => $registro[ $id ]['opzione'], 'schema' => $schema, 'problemi' => $problemi );
}

/**
 * Valori puliti di un elenco di campi a partire da quelli salvati. $severo come in ds_core_valore_campo(). Un campo
 * mai salvato o con un valore non valido prende il predefinito.
 */
function ds_core_valori_da_salvati( $schema, $salvati, $severo = false ) {
	$salvati = is_array( $salvati ) ? $salvati : array();
	$valori  = array();
	foreach ( $schema as $chiave => $campo ) {
		if ( array_key_exists( $chiave, $salvati ) ) {
			$errore = '';
			$valore = ds_core_valore_campo( $campo, $salvati[ $chiave ], $severo, $errore );
			if ( '' === $errore ) {
				$valori[ $chiave ] = $valore;
				continue;
			}
		}
		$valori[ $chiave ] = ds_core_predefinito( $campo );
	}
	return $valori;
}

/**
 * Scelte di un modulo (o di DS Core con 'ds-core'): valori salvati, puliti, con i predefiniti per quelli mai
 * salvati. Una volta per richiesta; ds_core_opzioni_svuota() dopo un salvataggio. Array vuoto se il modulo non ha
 * scelte.
 */
function ds_core_opzioni_modulo( $id, $svuota = false ) {
	static $cache = array();
	if ( $svuota ) {
		$cache = array();
		return array();
	}
	$id = ds_core_id_attuale( (string) $id ); // vecchi ID (prima della 0.17.0) accettati
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	$gruppo = ds_core_gruppo_impostazioni( $id );
	if ( ! $gruppo || ! $gruppo['schema'] ) {
		return array();
	}
	$valori = ds_core_valori_da_salvati( $gruppo['schema'], get_option( $gruppo['opzione'], array() ) );
	if ( did_action( 'plugins_loaded' ) ) {
		$cache[ $id ] = $valori;
	}
	return $valori;
}

/** Dimentica i valori letti in questa richiesta (dopo un salvataggio). */
function ds_core_opzioni_svuota() {
	ds_core_opzioni_modulo( '', true );
}

/*
 * Colori e contrasto (dalla 0.18.0): servono al modulo admin-branding e all'anteprima del pannello (campo 'color' con
 * 'contrasto'), anche a modulo spento, quindi stanno qui. Formula del contrasto di WCAG 2.x (luminanza relativa);
 * soglia AA per il testo normale: 4,5:1. La stessa formula è in assets/pannello.js per l'anteprima dal vivo.
 */

/** Colore #rrggbb → array( r, g, b ) da 0 a 255; null se non è un colore valido. */
function ds_core_colore_rgb( $hex ) {
	$hex = sanitize_hex_color( (string) $hex );
	if ( ! $hex ) {
		return null;
	}
	$hex = ltrim( $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
}

/** array( r, g, b ) → #rrggbb. */
function ds_core_colore_hex( $rgb ) {
	return sprintf( '#%02x%02x%02x', max( 0, min( 255, (int) round( $rgb[0] ) ) ), max( 0, min( 255, (int) round( $rgb[1] ) ) ), max( 0, min( 255, (int) round( $rgb[2] ) ) ) );
}

/** Luminanza relativa (WCAG) di un colore #rrggbb, da 0 a 1. */
function ds_core_colore_luminanza( $hex ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return 0.0;
	}
	$canali = array_map(
		function ( $v ) {
			$v = $v / 255;
			return $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
		},
		$rgb
	);
	return 0.2126 * $canali[0] + 0.7152 * $canali[1] + 0.0722 * $canali[2];
}

/** Rapporto di contrasto fra due colori, da 1 a 21. */
function ds_core_colore_contrasto( $a, $b ) {
	$x = ds_core_colore_luminanza( $a );
	$y = ds_core_colore_luminanza( $b );
	return ( max( $x, $y ) + 0.05 ) / ( min( $x, $y ) + 0.05 );
}

/** Mescola un colore con il nero ($verso = 'scuro') o il bianco ('chiaro'); $quota da 0 a 1. */
function ds_core_colore_mescola( $hex, $verso, $quota ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return (string) $hex;
	}
	$meta = 'scuro' === $verso ? 0 : 255;
	foreach ( $rgb as $i => $v ) {
		$rgb[ $i ] = $v + ( $meta - $v ) * $quota;
	}
	return ds_core_colore_hex( $rgb );
}

/**
 * Colore di fondo leggibile con un testo sopra (pulsanti, voce di menu scelta): il testo è bianco o scuro (#1d2327),
 * quello con il contrasto maggiore; se nemmeno quello arriva a $minimo, il fondo si scurisce (testo bianco) o si
 * schiarisce (testo scuro) a piccoli passi finché ci arriva. Restituisce array( 'fondo', 'testo', 'rapporto',
 * 'cambiato' ).
 */
function ds_core_colore_leggibile( $hex, $minimo = 4.5 ) {
	$fondo = sanitize_hex_color( (string) $hex );
	$fondo = $fondo ? ds_core_colore_hex( ds_core_colore_rgb( $fondo ) ) : '#2271b1';
	$bianco = ds_core_colore_contrasto( $fondo, '#ffffff' );
	$scuro  = ds_core_colore_contrasto( $fondo, '#1d2327' );
	$testo  = $bianco >= $scuro ? '#ffffff' : '#1d2327';
	$verso  = '#ffffff' === $testo ? 'scuro' : 'chiaro';
	$base   = $fondo;
	for ( $passo = 0; $passo <= 20 && ds_core_colore_contrasto( $fondo, $testo ) < $minimo; $passo++ ) {
		$fondo = ds_core_colore_mescola( $base, $verso, ( $passo + 1 ) * 0.05 );
	}
	return array(
		'fondo'    => $fondo,
		'testo'    => $testo,
		'rapporto' => round( ds_core_colore_contrasto( $fondo, $testo ), 1 ),
		'cambiato' => $fondo !== $base,
	);
}

/**
 * Colore da usare come testo (link, icone) su uno sfondo dato: il colore stesso se il contrasto arriva a $minimo,
 * altrimenti più scuro (sfondo chiaro) o più chiaro (sfondo scuro) a piccoli passi.
 */
function ds_core_colore_su( $hex, $sfondo, $minimo = 4.5 ) {
	$colore = sanitize_hex_color( (string) $hex );
	$colore = $colore ? ds_core_colore_hex( ds_core_colore_rgb( $colore ) ) : '#2271b1';
	$verso  = ds_core_colore_luminanza( $sfondo ) > 0.18 ? 'scuro' : 'chiaro';
	$base   = $colore;
	for ( $passo = 0; $passo <= 20 && ds_core_colore_contrasto( $colore, $sfondo ) < $minimo; $passo++ ) {
		$colore = ds_core_colore_mescola( $base, $verso, ( $passo + 1 ) * 0.05 );
	}
	return $colore;
}

/*
 * Colori globali di Breakdance (dalla 0.18.1, formato verificato su un sito il 27/11/2026). Facoltativo: DS Core non
 * dipende da Breakdance, legge solo l'opzione «breakdance_global_settings_json_string» (o la funzione di Breakdance
 * che la restituisce). Il formato non è documentato da Breakdance, quindi la lettura è difensiva:
 * - l'opzione è JSON codificato due volte (una stringa JSON che contiene JSON): si decodifica finché il risultato è
 *   una stringa, al massimo tre volte;
 * - in settings.colors ci sono brand, text, headings, links, background e palette; ognuno può essere un colore diretto
 *   (#rgb, #rrggbb, #rrggbbaa, rgb(), rgba()) o un riferimento alla palette come var(--bde-palette-color-2);
 * - palette.colors è un elenco di oggetti con «value». Il numero N di --bde-palette-color-N si cerca prima in un
 *   identificativo dell'elemento (cssVariableName, id, variable, name, slug, key: «palette-color-2», «color-2»,
 *   «--bde-palette-color-2» o «2» valgono tutti N = 2); se nessun elemento ne ha, vale la posizione (1 = il primo);
 * - un colore con trasparenza (alfa sotto 1) non si usa come colore del brand: si legge ma si scarta.
 */

/**
 * Colore CSS → array( 'hex' => '#rrggbb', 'alfa' => 0..1 ); null se non è un colore che DS Core sa leggere
 * (#rgb, #rgba, #rrggbb, #rrggbbaa, rgb() e rgba() con virgole o spazi, alfa in numero o percentuale).
 */
function ds_core_colore_css( $valore ) {
	if ( ! is_string( $valore ) ) {
		return null;
	}
	$valore = strtolower( trim( $valore ) );
	if ( preg_match( '/^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/', $valore, $m ) ) {
		$h = $m[1];
		if ( strlen( $h ) <= 4 ) {
			$lungo = '';
			foreach ( str_split( $h ) as $c ) {
				$lungo .= $c . $c;
			}
			$h = $lungo;
		}
		$alfa = 8 === strlen( $h ) ? hexdec( substr( $h, 6, 2 ) ) / 255 : 1.0;
		return array( 'hex' => '#' . substr( $h, 0, 6 ), 'alfa' => round( $alfa, 3 ) );
	}
	if ( preg_match( '/^rgba?\(\s*([0-9.]+%?)\s*[,\s]\s*([0-9.]+%?)\s*[,\s]\s*([0-9.]+%?)\s*(?:[,\/]\s*([0-9.]+%?)\s*)?\)$/', $valore, $m ) ) {
		$canali = array();
		foreach ( array( $m[1], $m[2], $m[3] ) as $c ) {
			$n = '%' === substr( $c, -1 ) ? (float) $c * 2.55 : (float) $c;
			if ( $n > 255.5 ) {
				return null;
			}
			$canali[] = $n;
		}
		$alfa = 1.0;
		if ( isset( $m[4] ) && '' !== $m[4] ) {
			$alfa = '%' === substr( $m[4], -1 ) ? (float) $m[4] / 100 : (float) $m[4];
		}
		return array( 'hex' => ds_core_colore_hex( $canali ), 'alfa' => round( max( 0.0, min( 1.0, $alfa ) ), 3 ) );
	}
	return null;
}

/** Testo grezzo dei colori globali di Breakdance (JSON, anche codificato due volte); '' se non c'è. */
function ds_core_breakdance_grezzo() {
	$grezzo = null;
	if ( function_exists( 'Breakdance\Data\get_global_option' ) ) {
		try {
			$grezzo = call_user_func( 'Breakdance\Data\get_global_option', 'global_settings_json_string' );
		} catch ( \Throwable $e ) {
			$grezzo = null;
		}
	}
	if ( ! ( is_string( $grezzo ) && '' !== trim( $grezzo ) ) && ! is_array( $grezzo ) ) {
		$grezzo = get_option( 'breakdance_global_settings_json_string', '' );
	}
	return is_string( $grezzo ) || is_array( $grezzo ) ? $grezzo : '';
}

/** Decodifica il JSON dei colori di Breakdance, anche codificato due (o tre) volte; null se non è leggibile. */
function ds_core_breakdance_decodifica( $grezzo ) {
	$dati = $grezzo;
	for ( $giro = 0; $giro < 3 && is_string( $dati ); $giro++ ) {
		$dati = '' !== trim( $dati ) ? json_decode( $dati, true ) : null;
	}
	return is_array( $dati ) ? $dati : null;
}

/** Identificativo della palette normalizzato: «--bde-palette-color-2», «palette-color-2», «color-2», «2» → «color-2». */
function ds_core_breakdance_chiave( $nome ) {
	$nome = strtolower( trim( (string) $nome ) );
	$nome = (string) preg_replace( '/^(--)?(bde-)?(palette-)?/', '', $nome );
	if ( preg_match( '/^\d+$/', $nome ) ) {
		$nome = 'color-' . $nome;
	}
	return $nome;
}

/**
 * Palette di Breakdance → array( 'color-N' => array( 'valore' => testo, 'numero' => N ) ). Chiavi dagli identificativi
 * degli elementi; se nessun elemento ne ha uno riconoscibile, dalla posizione (color-1 = il primo).
 */
function ds_core_breakdance_palette( $colori ) {
	$elenco = $colori['palette']['colors'] ?? ( $colori['palette'] ?? array() );
	if ( ! is_array( $elenco ) ) {
		return array();
	}
	$per_nome  = array();
	$per_posto = array();
	$posto     = 0;
	foreach ( array_values( $elenco ) as $elemento ) {
		$posto++;
		$valore = is_array( $elemento ) ? ( $elemento['value'] ?? ( $elemento['color'] ?? '' ) ) : $elemento;
		if ( ! is_string( $valore ) ) {
			continue;
		}
		$per_posto[ 'color-' . $posto ] = array( 'valore' => $valore, 'numero' => $posto );
		if ( ! is_array( $elemento ) ) {
			continue;
		}
		foreach ( array( 'cssVariableName', 'id', 'variable', 'name', 'slug', 'key' ) as $campo ) {
			if ( ! isset( $elemento[ $campo ] ) || ! is_scalar( $elemento[ $campo ] ) ) {
				continue;
			}
			$chiave = ds_core_breakdance_chiave( $elemento[ $campo ] );
			// Breakdance dà nomi liberi (bde-palette-color-2, bde-palette-yellow-brand-identity-13…): ogni nome vale.
			if ( '' !== $chiave && ! isset( $per_nome[ $chiave ] ) ) {
				$numero              = preg_match( '/(\d+)$/', $chiave, $m ) ? (int) $m[1] : $posto;
				$per_nome[ $chiave ] = array( 'valore' => $valore, 'numero' => $numero );
			}
		}
	}
	return $per_nome ? $per_nome : $per_posto;
}

/**
 * Valore dei colori di Breakdance risolto: colore diretto o var(--bde-palette-color-N[, ripiego]).
 * Restituisce array( 'hex', 'alfa', 'palette' => N, 0 se diretto ) oppure null.
 */
function ds_core_breakdance_risolvi( $valore, $palette, $profondita = 0 ) {
	if ( is_array( $valore ) ) {
		$valore = $valore['value'] ?? '';
	}
	if ( ! is_string( $valore ) || $profondita > 3 ) {
		return null;
	}
	$valore = trim( $valore );
	if ( preg_match( '/^var\(\s*(--[a-z0-9_-]+)\s*(?:,\s*(.+))?\)$/i', $valore, $m ) ) {
		$chiave = ds_core_breakdance_chiave( $m[1] );
		if ( isset( $palette[ $chiave ] ) ) {
			$trovato = ds_core_breakdance_risolvi( $palette[ $chiave ]['valore'], $palette, $profondita + 1 );
			if ( $trovato ) {
				$trovato['palette'] = $palette[ $chiave ]['numero'];
				return $trovato;
			}
		}
		return isset( $m[2] ) ? ds_core_breakdance_risolvi( $m[2], $palette, $profondita + 1 ) : null;
	}
	$colore = ds_core_colore_css( $valore );
	if ( ! $colore ) {
		return null;
	}
	$colore['palette'] = 0;
	return $colore;
}

/**
 * Colori globali di Breakdance risolti: array( 'brand'|'links'|'text'|'headings'|'background' => array( 'hex', 'alfa',
 * 'palette', 'usabile' ) ), solo quelli leggibili; 'usabile' = colore pieno (alfa 1). Array vuoto senza Breakdance o
 * con l'opzione illeggibile. $grezzo serve alle prove (senza: l'opzione del sito, letta una volta per richiesta).
 */
function ds_core_colori_breakdance( $grezzo = null ) {
	static $cache = null;
	if ( null === $grezzo && null !== $cache ) {
		return $cache;
	}
	$dati    = ds_core_breakdance_decodifica( null === $grezzo ? ds_core_breakdance_grezzo() : $grezzo );
	$colori  = is_array( $dati ) ? ( $dati['settings']['colors'] ?? ( $dati['colors'] ?? null ) ) : null;
	$risolti = array();
	if ( is_array( $colori ) ) {
		$palette = ds_core_breakdance_palette( $colori );
		foreach ( array( 'brand', 'links', 'text', 'headings', 'background' ) as $nome ) {
			$colore = isset( $colori[ $nome ] ) ? ds_core_breakdance_risolvi( $colori[ $nome ], $palette ) : null;
			if ( $colore ) {
				$colore['usabile'] = $colore['alfa'] >= 0.999;
				$risolti[ $nome ]  = $colore;
			}
		}
	}
	if ( null === $grezzo ) {
		$cache = $risolti;
	}
	return $risolti;
}

/** Colore del brand dal design del sito: «Brand» di Breakdance se è un colore pieno (anche dalla palette); altrimenti ''. */
function ds_core_colore_dal_sito() {
	$colori = ds_core_colori_breakdance();
	return ! empty( $colori['brand']['usabile'] ) ? $colori['brand']['hex'] : '';
}

/** Saturazione (HSL, 0..1) di un colore #rrggbb: sotto 0,2 è un grigio, quasi bianco o quasi nero. */
function ds_core_colore_saturazione( $hex ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return 0.0;
	}
	$max = max( $rgb ) / 255;
	$min = min( $rgb ) / 255;
	if ( $max === $min ) {
		return 0.0;
	}
	return ( $max - $min ) / ( 1 - abs( $max + $min - 1 ) );
}

/**
 * Colori dell'amministrazione per admin-branding (servono anche a modulo spento, per l'anteprima del pannello):
 * - principale: il colore scelto nel pannello, altrimenti «Brand» di Breakdance (colore pieno); '' = nessuno, e allora
 *   nessuno schema: ogni utente tiene lo schema di WordPress che ha (decisione di Daniele del 27/11/2026);
 * - link: «Links» di Breakdance come secondo accento solo se il principale viene da Breakdance e Links è un colore
 *   pieno, diverso dal principale, non un grigio (saturazione almeno 0,2) e già quasi leggibile sullo sfondo della
 *   Bacheca (almeno 3:1 su #f0f0f1, così la tonalità portata a 4,5:1 resta riconoscibile); altrimenti il principale.
 *   Con un colore scelto nel pannello vale quello ovunque;
 * - Text, Headings e Background di Breakdance si leggono ma non si usano: sono pensati per le pagine pubbliche, il
 *   menu resta scuro come quello di WordPress (decisione 0.18.0) e i contrasti sono calcolati sui suoi grigi fissi.
 * Restituisce array( 'principale', 'origine', 'palette', 'link', 'link_origine', 'link_palette', 'breakdance' );
 * 'origine' e 'link_origine' valgono 'scelto', 'brand', 'links' o ''.
 */
function ds_core_colori_admin( $scelto = '', $breakdance = null ) {
	$breakdance = null === $breakdance ? ds_core_colori_breakdance() : $breakdance;
	$esito      = array(
		'principale'   => '',
		'origine'      => '',
		'palette'      => 0,
		'link'         => '',
		'link_origine' => '',
		'link_palette' => 0,
		'breakdance'   => $breakdance,
	);
	$scelto = ds_core_colore_css( (string) $scelto );
	if ( $scelto && $scelto['alfa'] >= 0.999 ) {
		$esito['principale'] = $scelto['hex'];
		$esito['origine']    = 'scelto';
	} elseif ( ! empty( $breakdance['brand']['usabile'] ) ) {
		$esito['principale'] = $breakdance['brand']['hex'];
		$esito['origine']    = 'brand';
		$esito['palette']    = (int) $breakdance['brand']['palette'];
	}
	if ( '' === $esito['principale'] ) {
		return $esito;
	}
	$esito['link']         = $esito['principale'];
	$esito['link_origine'] = $esito['origine'];
	$esito['link_palette'] = $esito['palette'];
	$links                 = $breakdance['links'] ?? null;
	if ( 'brand' === $esito['origine'] && ! empty( $links['usabile'] ) && $links['hex'] !== $esito['principale']
		&& ds_core_colore_saturazione( $links['hex'] ) >= 0.2 && ds_core_colore_contrasto( $links['hex'], '#f0f0f1' ) >= 3 ) {
		$esito['link']         = $links['hex'];
		$esito['link_origine'] = 'links';
		$esito['link_palette'] = (int) $links['palette'];
	}
	return $esito;
}

/*
 * Predefiniti calcolati dei moduli di DS Core: stanno qui e non nel file del modulo, perché servono anche a modulo
 * spento (il pannello mostra le scelte prima dell'accensione).
 */

/** aggiornamenti: plugin da aggiornare a mano finché non si sceglie diversamente, quelli che toccano le vendite. */
function ds_core_agg_manuali_predefiniti() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$manuali = array();
	foreach ( array_keys( get_plugins() ) as $file ) {
		$cartella = strtolower( dirname( $file ) );
		if ( 'woocommerce' === $cartella || 'ds-woo' === $cartella || preg_match( '/-site$/', $cartella )
			|| preg_match( '/(gateway|payment|pagament|stripe|paypal|satispay|klarna|scalapay|nexi|braintree|mollie|square)/', $cartella ) ) {
			$manuali[] = $file;
		}
	}
	return $manuali;
}

/*
 * Migrazioni dei dati salvati: una volta per versione, alla prima richiesta dopo l'aggiornamento dei file (i siti
 * ricevono i file senza riattivare il plugin, quindi niente register_activation_hook). Non cancellano nulla: le
 * vecchie chiavi restano finché il pannello non salva di nuovo quel gruppo, così si può tornare indietro.
 */
add_action( 'plugins_loaded', 'ds_core_migra', 1 );
function ds_core_migra() {
	$db = (string) get_option( 'ds_core_db', '' );
	if ( '' !== $db && version_compare( $db, DS_CORE_VERSIONE, '>=' ) ) {
		return;
	}

	// 0.13.0: l'indirizzo degli avvisi del modulo updates-safety-net diventa l'indirizzo unico di DS Core.
	if ( '' === $db || version_compare( $db, '0.13.0', '<' ) ) {
		$generali = get_option( 'ds_core_generali', array() );
		$generali = is_array( $generali ) ? $generali : array();
		$agg      = get_option( 'ds_core_agg', array() );
		if ( empty( $generali['avvisi'] ) && is_array( $agg ) && ! empty( $agg['avvisi'] ) && is_email( $agg['avvisi'] ) ) {
			// Indirizzo già scelto da un amministratore: vale come confermato (dalla 0.15.0 passa dalla guardia).
			ds_core_avvisi_scrivi_confermato( $agg['avvisi'] );
		}
	}

	/*
	 * 0.15.0: l'indirizzo degli avvisi salvato con la 0.13/0.14 resta valido senza conferma (è già in
	 * ds_core_generali['avvisi'], niente da copiare). Registro delle attività: la conservazione passa da numero libero
	 * a scelta 30 / 90 / 365 / personalizzato; un numero salvato diverso dai tre diventa «personalizzato» (7-730).
	 */
	if ( '' === $db || version_compare( $db, '0.15.0', '<' ) ) {
		$ra = get_option( 'ds_core_ra', false );
		if ( is_array( $ra ) && isset( $ra['giorni'] ) && ! isset( $ra['conserva'] ) ) {
			$ra = array_merge( $ra, ds_core_eventi_conserva_da_giorni( $ra['giorni'] ) );
			update_option( 'ds_core_ra', $ra, false );
		}
	}

	// 0.17.0: ID dei moduli in inglese (decisione di Daniele del 27/11/2026).
	if ( '' === $db || version_compare( $db, '0.17.0', '<' ) ) {
		ds_core_migra_id();
	}

	update_option( 'ds_core_db', DS_CORE_VERSIONE, true );
}

/**
 * Migrazione della 0.17.0: i dati salvati con i vecchi ID italiani dei moduli passano agli ID inglesi
 * (ds_core_id_rinominati(), includes/registro.php). Si può rifare quante volte si vuole con lo stesso risultato
 * (idempotente): copia o rinomina solo ciò che ha ancora il vecchio ID e non ha già il nuovo.
 *
 * - ds_core_stati (scelte del pannello): lo stato si COPIA sotto l'ID nuovo e quello vecchio resta. Se WordPress
 *   rimette la versione precedente (ritorno automatico dopo un aggiornamento fallito) la 0.16.x ritrova i suoi stati:
 *   nessun modulo si spegne. Le chiavi vecchie non le legge più nessuno; si toglieranno in una versione successiva.
 *   Se l'ID nuovo ha già uno stato, vince quello (scelta fatta dopo l'aggiornamento).
 * - ds_core_errori (errori di caricamento): la chiave si rinomina.
 * - ds_core_storia (ultime modifiche del pannello): l'ID della riga si rinomina.
 * - Registro delle attività (tabella ds_core_eventi, se esiste): origine e oggetto delle righe con un vecchio ID.
 * - Opzioni dei moduli (ds_core_accesso, ds_core_agg, ds_core_ra…): il nome non contiene l'ID, restano come sono.
 * - Eventi pianificati (ds_core_agg_riepilogo, ds_core_ra_pulizia…): non contengono ID, restano come sono.
 * - .htaccess: il blocco «DS Core header-dati» resta leggibile e si rinomina alla prima scrittura del modulo
 *   security-headers da una pagina di amministrazione (includes/htaccess.php): la migrazione gira anche sul sito
 *   pubblico, dove DS Core non scrive mai il .htaccess.
 * - DS_CORE_SPENTI in wp-config.php: non si tocca, accetta vecchi e nuovi ID (includes/caricatore.php).
 */
function ds_core_migra_id() {
	global $wpdb;
	$mappa = ds_core_id_rinominati();

	$stati = get_option( 'ds_core_stati', array() );
	if ( is_array( $stati ) ) {
		$dopo = $stati;
		foreach ( $mappa as $vecchio => $nuovo ) {
			if ( isset( $stati[ $vecchio ] ) && ! isset( $stati[ $nuovo ] ) ) {
				$dopo[ $nuovo ] = $stati[ $vecchio ];
			}
		}
		if ( $dopo !== $stati ) {
			update_option( 'ds_core_stati', $dopo, true );
		}
	}

	$errori = get_option( 'ds_core_errori', array() );
	if ( is_array( $errori ) && $errori ) {
		$dopo = array();
		foreach ( $errori as $id => $errore ) {
			$nuovo = ds_core_id_attuale( $id );
			if ( ! isset( $dopo[ $nuovo ] ) || $nuovo === $id ) {
				$dopo[ $nuovo ] = $errore;
			}
		}
		if ( $dopo !== $errori ) {
			update_option( 'ds_core_errori', $dopo, true );
		}
	}

	$storia = get_option( 'ds_core_storia', array() );
	if ( is_array( $storia ) && $storia ) {
		$dopo = $storia;
		foreach ( $dopo as $n => $riga ) {
			if ( is_array( $riga ) && isset( $riga['id'] ) && isset( $mappa[ (string) $riga['id'] ] ) ) {
				$dopo[ $n ]['id'] = $mappa[ (string) $riga['id'] ];
			}
		}
		if ( $dopo !== $storia ) {
			update_option( 'ds_core_storia', $dopo, false );
		}
	}

	// Registro delle attività: una query sola, solo se la tabella esiste (anche a modulo spento, finché ha righe).
	if ( function_exists( 'ds_core_eventi_pronta' ) && ds_core_eventi_pronta() ) {
		$tabella  = ds_core_eventi_tabella();
		$casi     = '';
		$valori   = array();
		foreach ( $mappa as $vecchio => $nuovo ) {
			$casi    .= ' WHEN %s THEN %s';
			$valori[] = $vecchio;
			$valori[] = $nuovo;
		}
		$segnaposti = implode( ',', array_fill( 0, count( $mappa ), '%s' ) );
		$vecchi     = array_keys( $mappa );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders -- tabella propria, segnaposti costruiti dall'elenco fisso.
		$sql = $wpdb->prepare(
			"UPDATE {$tabella} SET origine = CASE origine{$casi} ELSE origine END, oggetto = CASE oggetto{$casi} ELSE oggetto END WHERE origine IN ({$segnaposti}) OR oggetto IN ({$segnaposti})",
			array_merge( $valori, $valori, $vecchi, $vecchi )
		);
		$errori_db = $wpdb->suppress_errors( true );
		$wpdb->query( $sql );
		$wpdb->suppress_errors( $errori_db );
		// phpcs:enable
	}
}

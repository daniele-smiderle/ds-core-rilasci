<?php
/**
 * Impostazioni dichiarate nel registro (dalla 0.13.0, decisione di Daniele del 27/11/2026): disegno dei campi nella
 * riga del modulo, salvataggio, stato del modulo dopo l'accensione. Solo amministrazione (caricato con il pannello).
 *
 * - Le scelte si mostrano e si salvano sempre, anche a modulo spento, senza eseguire codice del modulo: lo schema sta
 *   nel registro, i predefiniti calcolati in includes/opzioni.php. Con l'interruttore d'emergenza (DS_CORE_SPENTI) le
 *   scelte di quel modulo non si mostrano e non si salvano.
 * - Un pulsante «Save settings» per modulo. Salvataggio via AJAX (wp_ajax_ds_core_impostazioni) o, senza
 *   JavaScript, con il modulo HTML verso admin-post.php (stessa funzione, stessa azione, stesso nonce per modulo).
 * - Sicurezza: manage_options, nonce 'ds_core_impostazioni_<id>', pulizia secondo il tipo del campo, escape
 *   all'uscita. Opzioni registrate con register_setting(), così WordPress applica la stessa pulizia a ogni
 *   update_option().
 * - Salvare non applica niente: DS Core lancia 'ds_core_impostazioni_salvate' ( $id, $prima, $dopo ) e il modulo
 *   acceso, se serve, applica.
 * - Stato e azioni del modulo (campo 'stato' del registro) solo a modulo acceso. Dopo un cambio di stato il
 *   pannello li chiede con una seconda richiesta (wp_ajax_ds_core_riga): in quella il modulo è già caricato.
 *
 * Tipo di campo non previsto: per ora nessuno. Un'immagine dalla libreria media richiede wp_enqueue_media() e il
 * selettore di WordPress: rimandata (docs/ds-core-moduli.md); admin-branding (0.18.0) usa il logo o l'icona del sito.
 *
 * Riepilogo della riga (0.18.0, ds_core_riepilogo_html()): una riga breve sotto la descrizione del modulo con lo stato
 * e le scelte, senza conoscere i singoli moduli. Le scelte entrano se il modulo dà, nei testi del campo, la chiave
 * facoltativa 'breve': una stringa con %s (il valore), un array valore => testo corto (scelte a elenco; caselle con
 * le chiavi '1' e '0'; testo vuoto = niente) o una funzione ( $valore, $valori ) che restituisce il testo. Lo stato a
 * parole viene dalla chiave facoltativa 'riepilogo' del registro (funzione del modulo acceso, come 'problemi').
 *
 * Anteprima del contrasto (0.18.0): un campo 'color' con 'contrasto' => true nello schema mostra sotto il campo un
 * pezzo di menu e un pulsante nel colore, con il testo bianco o scuro scelto per il contrasto (WCAG AA 4,5:1) e, se
 * serve, la tonalità più scura o più chiara che DS Core usa al suo posto (ds_core_colore_leggibile(), opzioni.php).
 * Nei testi del campo, 'vuoto' è il colore usato quando il campo è vuoto.
 */

defined( 'ABSPATH' ) || exit;

/* ---------- Registrazione delle opzioni (regole di WordPress) ---------- */

add_action( 'admin_init', 'ds_core_registra_opzioni' );
function ds_core_registra_opzioni() {
	$gruppi = array( 'ds-core' );
	foreach ( ds_core_registro() as $id => $modulo ) {
		if ( '' !== $modulo['opzione'] && $modulo['campi'] ) {
			$gruppi[] = $id;
		}
	}
	foreach ( $gruppi as $id ) {
		$gruppo = ds_core_gruppo_impostazioni( $id );
		if ( ! $gruppo || ! $gruppo['schema'] ) {
			continue;
		}
		$schema  = $gruppo['schema'];
		$opzione = $gruppo['opzione'];
		register_setting(
			'ds_core',
			$opzione,
			array(
				'type'              => 'array',
				'show_in_rest'      => false,
				// Pulizia «morbida» (un valore non valido torna al predefinito): i messaggi d'errore li dà il pannello.
				// I campi nascosti tengono il valore già salvato, chiunque scriva l'opzione da qui (0.16.1).
				'sanitize_callback' => function ( $valori ) use ( $schema, $opzione ) {
					$valori  = is_array( $valori ) ? $valori : array();
					$attuali = get_option( $opzione, array() );
					$attuali = is_array( $attuali ) ? $attuali : array();
					foreach ( $schema as $chiave => $campo ) {
						if ( $campo['nascosto'] ) {
							unset( $valori[ $chiave ] );
							if ( array_key_exists( $chiave, $attuali ) ) {
								$valori[ $chiave ] = $attuali[ $chiave ];
							}
						}
					}
					return ds_core_valori_da_salvati( $schema, $valori, true );
				},
			)
		);
	}
}

/* ---------- Disegno ---------- */

/** True se il modulo ha qualcosa da mostrare nella riga sotto: scelte dichiarate o stato. */
function ds_core_ha_impostazioni( $modulo ) {
	$campi = '' !== $modulo['opzione'] && ! empty( $modulo['campi'] );
	$stato = ! empty( $modulo['stato'] ) && ( is_string( $modulo['stato'] ) || is_callable( $modulo['stato'] ) );
	return $campi || $stato;
}

/** Esito del salvataggio senza JavaScript, conservato per un minuto per l'utente che ha salvato. */
function ds_core_esito_ripiego( $id ) {
	$esito = get_transient( 'ds_core_imp_' . get_current_user_id() );
	if ( ! is_array( $esito ) || ( $esito['id'] ?? '' ) !== $id ) {
		return null;
	}
	delete_transient( 'ds_core_imp_' . get_current_user_id() );
	return $esito;
}

/**
 * Modulo HTML delle scelte di un gruppo ('ds-core' o l'ID di un modulo). $testi: array( 'campi' => …, 'gruppi' => … ).
 * $spento: true se il modulo è spento (la riga del pulsante lo ricorda: le scelte si tengono per l'accensione).
 * Restituisce HTML già escapato.
 */
function ds_core_impostazioni_form( $id, $testi, $spento = false, $con_avvisi = false ) {
	$gruppo = ds_core_gruppo_impostazioni( $id );
	if ( ! $gruppo ) {
		return '';
	}
	$html = '';
	if ( $gruppo['problemi'] ) {
		// Errori di chi ha scritto il modulo: tecnici, in inglese come quelli del caricatore.
		$html .= '<p class="ds-errore">' . esc_html__( 'Some settings of this module could not be shown:', 'ds-core' ) . ' ' . esc_html( implode( ' ', $gruppo['problemi'] ) ) . '</p>';
	}
	if ( ! $gruppo['schema'] ) {
		return $html;
	}

	$valori      = ds_core_valori_da_salvati( $gruppo['schema'], get_option( $gruppo['opzione'], array() ) );
	$testi_campi = isset( $testi['campi'] ) && is_array( $testi['campi'] ) ? $testi['campi'] : array();
	$titoli      = isset( $testi['gruppi'] ) && is_array( $testi['gruppi'] ) ? $testi['gruppi'] : array();
	$ripiego     = ds_core_esito_ripiego( $id );
	$errori      = $ripiego && ! empty( $ripiego['errori'] ) && is_array( $ripiego['errori'] ) ? $ripiego['errori'] : array();

	ob_start();
	?>
	<form class="ds-impostazioni" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-ds-impostazioni="<?php echo esc_attr( $id ); ?>" novalidate>
		<input type="hidden" name="action" value="ds_core_impostazioni">
		<input type="hidden" name="ds_id" value="<?php echo esc_attr( $id ); ?>">
		<?php // Nonce per modulo, senza l'id fisso di wp_nonce_field() (in pagina ci sono più moduli HTML). ?>
		<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'ds_core_impostazioni_' . $id ) ); ?>">
		<div class="ds-campi">
			<?php
			$gruppo_corrente = '';
			foreach ( $gruppo['schema'] as $chiave => $campo ) {
				if ( $campo['nascosto'] ) {
					continue;
				}
				if ( '' !== $campo['gruppo'] && $campo['gruppo'] !== $gruppo_corrente && ! empty( $titoli[ $campo['gruppo'] ] ) ) {
					echo '<h3 class="ds-campi-gruppo">' . esc_html( (string) $titoli[ $campo['gruppo'] ] ) . '</h3>';
				}
				$gruppo_corrente = $campo['gruppo'];
				ds_core_campo_html( $id, $chiave, $campo, $valori[ $chiave ], isset( $testi_campi[ $chiave ] ) && is_array( $testi_campi[ $chiave ] ) ? $testi_campi[ $chiave ] : array(), $errori[ $chiave ] ?? '' );
			}
			?>
		</div>
		<?php if ( $con_avvisi ) : ?>
			<p class="ds-impostazioni-nota">
				<?php echo ds_core_icona( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?>
				<span>
					<?php
					printf(
						/* translators: %s: email address, or a list of addresses. */
						esc_html__( 'Emails from this module go to %s.', 'ds-core' ),
						ds_core_avvisi_destinatari_html() // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato.
					);
					?>
					<a href="<?php echo esc_url( ds_core_url_pannello( 'settings', 'ds-generali' ) ); ?>" data-ds-vai="settings"><?php esc_html_e( 'Change it in the Settings tab', 'ds-core' ); ?></a>
				</span>
			</p>
		<?php endif; ?>
		<div class="ds-salva">
			<button type="submit" class="button button-primary ds-salva-pulsante"><?php esc_html_e( 'Save settings', 'ds-core' ); ?></button>
			<span class="ds-salva-esito<?php echo $ripiego ? ( empty( $ripiego['ok'] ) ? ' ds-salva-esito--errore' : ' ds-salva-esito--ok' ) : ''; ?>" role="status" aria-live="polite"><?php
			if ( $ripiego ) {
				echo esc_html( (string) ( $ripiego['messaggio'] ?? '' ) );
			}
			?></span>
			<?php if ( 'ds-core' !== $id ) : ?>
				<span class="ds-salva-spento"<?php echo $spento ? '' : ' hidden'; ?>><?php esc_html_e( 'The module is off: the settings are kept and used when you turn it on.', 'ds-core' ); ?></span>
			<?php endif; ?>
		</div>
	</form>
	<?php
	return $html . (string) ob_get_clean();
}

/** Stampa un campo: etichetta a sinistra, controllo, unità, aiuto ed errore a destra. */
function ds_core_campo_html( $id, $chiave, $campo, $valore, $testi, $errore ) {
	$base      = 'ds-campo-' . $id . '-' . $chiave;
	$nome      = 'ds_campi[' . $chiave . ']';
	$valore    = array_key_exists( 'valore', $testi ) ? $testi['valore'] : $valore;
	$etichetta = isset( $testi['etichetta'] ) && '' !== (string) $testi['etichetta'] ? (string) $testi['etichetta'] : $chiave;
	$aiuto     = isset( $testi['aiuto'] ) ? (string) $testi['aiuto'] : '';
	$unita     = isset( $testi['unita'] ) ? (string) $testi['unita'] : '';
	$nomi      = isset( $testi['scelte'] ) && is_array( $testi['scelte'] ) ? $testi['scelte'] : array();
	$descritto = trim( ( '' !== $aiuto ? $base . '-aiuto ' : '' ) . $base . '-errore' );
	$gruppo    = in_array( $campo['tipo'], array( 'radio', 'checkboxes', 'plugins' ), true );
	$invalido  = '' !== $errore ? ' aria-invalid="true"' : '';
	$sola      = ! empty( $testi['sola_lettura'] );
	$attributi = ' aria-describedby="' . esc_attr( $descritto ) . '"' . $invalido . ( $sola ? ' readonly' : '' );
	$mostra_se = ! empty( $campo['mostra_se'] ) ? ' data-ds-mostra-se="' . esc_attr( $campo['mostra_se'][0] ) . '" data-ds-mostra-valore="' . esc_attr( $campo['mostra_se'][1] ) . '"' : '';

	echo '<div class="ds-campo ds-campo--' . esc_attr( $campo['tipo'] ) . ( '' !== $errore ? ' is-invalido' : '' ) . '" data-ds-campo="' . esc_attr( $chiave ) . '"' . $mostra_se . ( $gruppo ? ' role="group" aria-labelledby="' . esc_attr( $base ) . '-etichetta" aria-describedby="' . esc_attr( $descritto ) . '"' : '' ) . '>';
	if ( $gruppo ) {
		echo '<span class="ds-campo-etichetta" id="' . esc_attr( $base ) . '-etichetta">' . esc_html( $etichetta ) . '</span>';
	} else {
		echo '<label class="ds-campo-etichetta" for="' . esc_attr( $base ) . '">' . esc_html( $etichetta ) . '</label>';
	}
	echo '<div class="ds-campo-controllo">';

	switch ( $campo['tipo'] ) {
		case 'text':
			printf( '<input type="text" id="%1$s" name="%2$s" value="%3$s" maxlength="%4$d" class="regular-text"%5$s>', esc_attr( $base ), esc_attr( $nome ), esc_attr( (string) $valore ), (int) $campo['lunghezza'], $attributi ); // phpcs:ignore WordPress.Security.EscapeOutput -- attributi già escapati.
			break;

		case 'url':
			printf( '<input type="url" id="%1$s" name="%2$s" value="%3$s" maxlength="%4$d" class="large-text code" placeholder="https://" spellcheck="false"%5$s>', esc_attr( $base ), esc_attr( $nome ), esc_attr( (string) $valore ), (int) $campo['lunghezza'], $attributi ); // phpcs:ignore WordPress.Security.EscapeOutput -- attributi già escapati.
			break;

		case 'email':
			printf( '<input type="email" id="%1$s" name="%2$s" value="%3$s" class="regular-text" autocomplete="email" placeholder="%4$s"%5$s>', esc_attr( $base ), esc_attr( $nome ), esc_attr( (string) $valore ), esc_attr( (string) get_option( 'admin_email' ) ), $attributi ); // phpcs:ignore WordPress.Security.EscapeOutput -- attributi già escapati.
			break;

		case 'number':
			printf(
				'<span class="ds-campo-numero"><input type="number" id="%1$s" name="%2$s" value="%3$s" step="%4$s"%5$s%6$s class="small-text" inputmode="numeric"%7$s>%8$s</span>',
				esc_attr( $base ),
				esc_attr( $nome ),
				esc_attr( (string) $valore ),
				esc_attr( (string) $campo['passo'] ),
				null !== $campo['min'] ? ' min="' . esc_attr( (string) $campo['min'] ) . '"' : '',
				null !== $campo['max'] ? ' max="' . esc_attr( (string) $campo['max'] ) . '"' : '',
				$attributi, // phpcs:ignore WordPress.Security.EscapeOutput -- già escapati.
				'' !== $unita ? ' <span class="ds-campo-unita">' . esc_html( $unita ) . '</span>' : ''
			);
			if ( null !== $campo['min'] && null !== $campo['max'] ) {
				/* translators: 1: minimum value, 2: maximum value. */
				echo '<span class="ds-campo-limiti">' . esc_html( sprintf( __( 'from %1$s to %2$s', 'ds-core' ), number_format_i18n( $campo['min'] ), number_format_i18n( $campo['max'] ) ) ) . '</span>';
			}
			break;

		case 'checkbox':
			// Etichetta a sinistra (label for); a destra la casella e, se c'è, la frase 'testo' che dice cosa fa.
			$frase = isset( $testi['testo'] ) ? (string) $testi['testo'] : '';
			printf(
				'<span class="ds-campo-casella"><input type="checkbox" id="%1$s" name="%2$s" value="1"%3$s%4$s>%5$s</span>',
				esc_attr( $base ),
				esc_attr( $nome ),
				checked( (bool) $valore, true, false ),
				$attributi, // phpcs:ignore WordPress.Security.EscapeOutput -- già escapati.
				'' !== $frase ? ' <label for="' . esc_attr( $base ) . '">' . esc_html( $frase ) . '</label>' : ''
			);
			break;

		case 'radio':
			foreach ( $campo['scelte'] as $i => $scelta ) {
				printf(
					'<label class="ds-campo-scelta"><input type="radio" name="%1$s" value="%2$s"%3$s%4$s> %5$s</label>',
					esc_attr( $nome ),
					esc_attr( $scelta ),
					checked( (string) $valore, $scelta, false ),
					0 === $i ? ' id="' . esc_attr( $base ) . '"' : '',
					esc_html( isset( $nomi[ $scelta ] ) ? (string) $nomi[ $scelta ] : $scelta )
				);
			}
			break;

		case 'select':
			printf( '<select id="%1$s" name="%2$s"%3$s>', esc_attr( $base ), esc_attr( $nome ), $attributi ); // phpcs:ignore WordPress.Security.EscapeOutput -- attributi già escapati.
			foreach ( $campo['scelte'] as $scelta ) {
				printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $scelta ), selected( (string) $valore, $scelta, false ), esc_html( isset( $nomi[ $scelta ] ) ? (string) $nomi[ $scelta ] : $scelta ) );
			}
			echo '</select>';
			break;

		case 'checkboxes':
		case 'plugins':
			$scelte = $campo['scelte'];
			if ( 'plugins' === $campo['tipo'] ) {
				if ( ! function_exists( 'get_plugins' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}
				$nomi   = array();
				$scelte = array();
				foreach ( get_plugins() as $file => $dati ) {
					if ( plugin_basename( DS_CORE_FILE ) === $file ) {
						continue; // DS Core ha il suo aggiornamento firmato.
					}
					$scelte[]      = $file;
					$nomi[ $file ] = $dati['Name'];
				}
			}
			echo '<span class="ds-campo-griglia">';
			foreach ( $scelte as $scelta ) {
				printf(
					'<label class="ds-campo-scelta"><input type="checkbox" name="%1$s[]" value="%2$s"%3$s> %4$s</label>',
					esc_attr( $nome ),
					esc_attr( $scelta ),
					checked( in_array( $scelta, (array) $valore, true ), true, false ),
					esc_html( isset( $nomi[ $scelta ] ) ? (string) $nomi[ $scelta ] : $scelta )
				);
			}
			echo '</span>';
			if ( ! $scelte ) {
				echo '<span class="ds-campo-aiuto">' . esc_html__( 'Nothing to choose from.', 'ds-core' ) . '</span>';
			}
			break;

		case 'color':
			// Selettore del browser + testo #rrggbb (il testo è il campo vero: funziona anche senza JavaScript e può restare vuoto).
			printf(
				'<span class="ds-campo-colore"><input type="color" class="ds-campo-colore-scelta" value="%1$s" aria-label="%2$s" tabindex="-1"><input type="text" id="%3$s" name="%4$s" value="%5$s" class="code" size="8" maxlength="7" pattern="#[0-9a-fA-F]{6}" placeholder="#rrggbb" spellcheck="false"%6$s></span>',
				esc_attr( '' !== (string) $valore ? (string) $valore : '#000000' ),
				/* translators: %s: field label. */
				esc_attr( sprintf( __( 'Pick a color for %s', 'ds-core' ), $etichetta ) ),
				esc_attr( $base ),
				esc_attr( $nome ),
				esc_attr( (string) $valore ),
				$attributi // phpcs:ignore WordPress.Security.EscapeOutput -- già escapati.
			);
			if ( ! empty( $campo['contrasto'] ) ) {
				$vuoto = isset( $testi['vuoto'] ) ? (string) sanitize_hex_color( (string) $testi['vuoto'] ) : '';
				$pieno = '' !== (string) $valore;
				echo ds_core_anteprima_colore_html( $pieno ? (string) $valore : $vuoto, $vuoto, isset( $testi['anteprima'] ) && is_array( $testi['anteprima'] ) ? $testi['anteprima'] : array(), $pieno ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato.
			}
			break;
	}

	if ( '' !== $aiuto ) {
		echo '<p class="ds-campo-aiuto" id="' . esc_attr( $base ) . '-aiuto">' . esc_html( $aiuto ) . '</p>';
	}
	if ( isset( $testi['dopo_html'] ) ) {
		// HTML preparato e già escapato da DS Core (stato dell'indirizzo degli avvisi), mai dai moduli esterni.
		echo $testi['dopo_html']; // phpcs:ignore WordPress.Security.EscapeOutput -- già escapato.
	}
	echo '<p class="ds-campo-errore" id="' . esc_attr( $base ) . '-errore"' . ( '' === $errore ? ' hidden' : '' ) . '>' . ds_core_icona( 'attenzione' ) . '<span>' . esc_html( $errore ) . '</span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso.
	echo '</div></div>';
}

/**
 * Parte «stato» della riga di un modulo: problemi, poi lo stato e le azioni del modulo (solo acceso). Da spento, una
 * riga che lo dice. Un errore nella funzione del modulo diventa un messaggio. Restituisce HTML già escapato.
 */
function ds_core_stato_html( $id, $modulo, $visto, $problemi ) {
	$html = '';
	if ( $problemi ) {
		$html .= '<ul class="ds-dettagli-problemi">';
		foreach ( $problemi as $problema ) {
			$html .= '<li>' . ds_core_icona( 'attenzione' ) . esc_html( $problema ) . '</li>';
		}
		$html .= '</ul>';
	}
	if ( 'spento-config' === $visto ) {
		return $html . '<p class="ds-dettagli-vuoto">' . esc_html__( 'The module is turned off by the emergency switch in wp-config.php: its settings are not available.', 'ds-core' ) . '</p>';
	}
	if ( empty( $modulo['stato'] ) ) {
		return $html;
	}
	if ( ! in_array( $visto, array( 'attivo', 'prova' ), true ) ) {
		return $html . '<p class="ds-dettagli-vuoto">' . esc_html__( 'What the module is doing and its actions show here while it is on.', 'ds-core' ) . '</p>';
	}
	if ( ! is_callable( $modulo['stato'] ) ) {
		return $html . '<p class="ds-dettagli-vuoto">' . esc_html__( 'The module is on but its state is not available: reload the page.', 'ds-core' ) . '</p>';
	}
	ob_start();
	try {
		call_user_func( $modulo['stato'], $id );
	} catch ( \Throwable $e ) {
		ob_end_clean();
		/* translators: %s: error message. */
		return $html . '<p class="ds-errore">' . esc_html( sprintf( __( 'The state of this module could not be shown: %s', 'ds-core' ), $e->getMessage() ) ) . '</p>';
	}
	return $html . (string) ob_get_clean();
}

/* ---------- Salvataggio ---------- */

/**
 * Salva le scelte di un gruppo dai dati inviati. Restituisce array( 'ok' => bool, 'messaggio' => …, 'errori' =>
 * chiave => motivo, 'valori' => valori salvati, per il modulo HTML ). Con un errore non si salva nulla: o tutto o
 * niente, così un modulo non riceve mezza configurazione.
 */
function ds_core_salva_impostazioni( $id, $inviati ) {
	$risposta = array( 'ok' => false, 'messaggio' => '', 'errori' => array(), 'valori' => array() );
	$gruppo   = ds_core_gruppo_impostazioni( $id );
	if ( ! $gruppo || ! $gruppo['schema'] ) {
		$risposta['messaggio'] = __( 'This module has no settings.', 'ds-core' );
		return $risposta;
	}
	if ( 'ds-core' !== $id && in_array( $id, ds_core_spenti_da_config(), true ) ) {
		$risposta['messaggio'] = __( 'The module is turned off by the emergency switch in wp-config.php.', 'ds-core' );
		return $risposta;
	}
	$prima = get_option( $gruppo['opzione'], array() );
	if ( false !== $prima && ! is_array( $prima ) ) {
		// L'opzione esiste già e non è di DS Core (un valore semplice): non si sovrascrive.
		$risposta['messaggio'] = __( 'The settings cannot be saved: the option name is already used by something else.', 'ds-core' );
		return $risposta;
	}
	$prima   = is_array( $prima ) ? $prima : array();
	$inviati = is_array( $inviati ) ? $inviati : array();
	$dopo    = array();
	foreach ( $gruppo['schema'] as $chiave => $campo ) {
		// Campo nascosto (0.16.1): non si cambia dal pannello, nemmeno con dati inviati a mano; resta il valore salvato.
		if ( $campo['nascosto'] ) {
			$dopo[ $chiave ] = array_key_exists( $chiave, $prima ) ? $prima[ $chiave ] : ds_core_predefinito( $campo );
			continue;
		}
		// Caselle non spuntate: il browser non le manda.
		$grezzo = $inviati[ $chiave ] ?? ( in_array( $campo['tipo'], array( 'checkboxes', 'plugins' ), true ) ? array() : ( 'checkbox' === $campo['tipo'] ? '' : null ) );
		if ( null === $grezzo ) {
			$dopo[ $chiave ] = array_key_exists( $chiave, $prima ) ? $prima[ $chiave ] : ds_core_predefinito( $campo );
			continue;
		}
		$errore = '';
		$valore = ds_core_valore_campo( $campo, $grezzo, true, $errore );
		if ( '' !== $errore ) {
			$risposta['errori'][ $chiave ] = $errore;
			continue;
		}
		$dopo[ $chiave ] = $valore;
	}
	if ( $risposta['errori'] ) {
		$risposta['messaggio'] = _n( 'Not saved: check the highlighted field.', 'Not saved: check the highlighted fields.', count( $risposta['errori'] ), 'ds-core' );
		return $risposta;
	}

	/*
	 * Indirizzo degli avvisi (0.15.0): non si salva qui. Un indirizzo diverso da quello confermato (anche il campo
	 * vuoto) diventa una richiesta da confermare dal nuovo indirizzo (includes/avvisi.php); con la costante in
	 * wp-config.php il campo non conta.
	 */
	$richiesta = '';
	if ( 'ds-core' === $id ) {
		$chiesto        = trim( (string) ( $dopo['avvisi'] ?? '' ) );
		$dopo['avvisi'] = ds_core_avvisi_confermato();
		if ( '' === ds_core_avvisi_bloccato() && strtolower( $chiesto ) !== strtolower( $dopo['avvisi'] ) ) {
			$esito = ds_core_avvisi_richiedi( $chiesto );
			if ( true !== $esito ) {
				$risposta['errori']['avvisi'] = (string) $esito;
				$risposta['messaggio']        = __( 'Not saved: check the highlighted field.', 'ds-core' );
				return $risposta;
			}
			$richiesta = ds_core_avvisi_maschera( '' !== $chiesto ? $chiesto : ds_core_avvisi_admin() );
		}
	}

	// Un modulo (anche spento: il filtro sta nei file sempre caricati) può mettere d'accordo campi che dipendono
	// l'uno dall'altro, per esempio una scelta fissa e il numero personalizzato.
	$dopo = apply_filters( 'ds_core_impostazioni_da_salvare', $dopo, $id, $prima );

	// Le chiavi non dichiarate (per esempio 'avvisi' di aggiornamenti prima della 0.13.0) si tolgono qui.
	update_option( $gruppo['opzione'], $dopo, false );
	ds_core_opzioni_svuota();
	if ( $prima !== $dopo ) {
		ds_core_storia_aggiungi( $id, 'impostazioni', 'impostazioni:salvate' );
		do_action( 'ds_core_impostazioni_salvate', $id, $prima, $dopo );
	}
	$risposta['ok']        = true;
	$risposta['valori']    = $dopo;
	$risposta['messaggio'] = $prima !== $dopo ? __( 'Settings saved.', 'ds-core' ) : __( 'Nothing changed.', 'ds-core' );
	if ( '' !== $richiesta ) {
		$risposta['messaggio'] = sprintf(
			/* translators: 1: masked new email address, 2: current email address. */
			__( 'Confirmation link sent to %1$s. The new address takes effect when it is confirmed; until then the emails keep going to %2$s.', 'ds-core' ),
			$richiesta,
			ds_core_indirizzo_avvisi()
		);
		// Il pannello si ricarica per mostrare la richiesta in attesa.
		$risposta['ricarica'] = true;
	}
	return $risposta;
}

/** Salvataggio dal pannello: via AJAX (risposta JSON) o dal modulo HTML (ritorno alla riga). */
add_action( 'wp_ajax_ds_core_impostazioni', 'ds_core_richiesta_impostazioni' );
add_action( 'admin_post_ds_core_impostazioni', 'ds_core_richiesta_impostazioni' );
function ds_core_richiesta_impostazioni() {
	$ajax = wp_doing_ajax();
	if ( ! current_user_can( 'manage_options' ) ) {
		if ( $ajax ) {
			wp_send_json_error( array( 'messaggio' => __( 'You do not have permission to do this.', 'ds-core' ) ), 403 );
		}
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	$id = isset( $_POST['ds_id'] ) ? sanitize_key( wp_unslash( $_POST['ds_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- il nonce dipende dall'ID e si controlla subito sotto.
	if ( $ajax ) {
		check_ajax_referer( 'ds_core_impostazioni_' . $id );
	} else {
		check_admin_referer( 'ds_core_impostazioni_' . $id );
	}
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- ogni valore si pulisce secondo il tipo del campo.
	$inviati  = isset( $_POST['ds_campi'] ) && is_array( $_POST['ds_campi'] ) ? wp_unslash( $_POST['ds_campi'] ) : array();
	$risposta = ds_core_salva_impostazioni( $id, $inviati );
	if ( 'ds-core' !== $id && $risposta['ok'] ) {
		// Riepilogo nuovo della riga (0.18.0), con le scelte appena salvate.
		$errori_car             = get_option( 'ds_core_errori', array() );
		$risposta['riepilogo'] = ds_core_riepilogo_html( $id, ds_core_stato_visibile( $id, is_array( $errori_car ) ? $errori_car : array() ) );
	}

	if ( $ajax ) {
		if ( $risposta['ok'] ) {
			if ( ! empty( $risposta['ricarica'] ) ) {
				// Il messaggio resta per la pagina ricaricata (stesso meccanismo del salvataggio senza JavaScript).
				set_transient( 'ds_core_imp_' . get_current_user_id(), array( 'id' => $id, 'ok' => true, 'messaggio' => $risposta['messaggio'], 'errori' => array() ), MINUTE_IN_SECONDS );
			}
			wp_send_json_success( $risposta );
		}
		wp_send_json_error( $risposta, 400 );
	}
	set_transient(
		'ds_core_imp_' . get_current_user_id(),
		array( 'id' => $id, 'ok' => $risposta['ok'], 'messaggio' => $risposta['messaggio'], 'errori' => $risposta['errori'] ),
		MINUTE_IN_SECONDS
	);
	// Si torna alla stessa scheda (0.18.0): Settings per le impostazioni generali, quella di partenza per i moduli.
	if ( 'ds-core' === $id ) {
		wp_safe_redirect( ds_core_url_pannello( 'settings', 'ds-generali' ) );
	} else {
		wp_safe_redirect( ds_core_url_pannello( ds_core_scheda_dal_referer(), 'ds-impostazioni-' . $id ) );
	}
	exit;
}

/**
 * Stato di un modulo dopo un cambio (accensione, spegnimento): in questa richiesta il modulo acceso è già caricato,
 * quindi la sua funzione 'stato' esiste. Risponde con l'HTML della parte «stato» e i problemi.
 */
add_action( 'wp_ajax_ds_core_riga', 'ds_core_ajax_riga' );
function ds_core_ajax_riga() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'messaggio' => __( 'You do not have permission to do this.', 'ds-core' ) ), 403 );
	}
	check_ajax_referer( 'ds_core_imposta', 'nonce' );
	$id       = isset( $_POST['id'] ) ? sanitize_key( wp_unslash( $_POST['id'] ) ) : '';
	$registro = ds_core_registro_con_testi();
	if ( ! isset( $registro[ $id ] ) ) {
		wp_send_json_error( array( 'messaggio' => __( 'Unknown module.', 'ds-core' ) ), 400 );
	}
	$errori   = get_option( 'ds_core_errori', array() );
	$visto    = ds_core_stato_visibile( $id, is_array( $errori ) ? $errori : array() );
	$problemi = ds_core_problemi_modulo( $id, $registro[ $id ], $visto );
	wp_send_json_success(
		array(
			'html'      => ds_core_stato_html( $id, $registro[ $id ], $visto, $problemi ),
			'problemi'  => count( $problemi ),
			'acceso'    => in_array( $visto, array( 'attivo', 'prova' ), true ),
			'riepilogo' => ds_core_riepilogo_html( $id, $visto, $registro[ $id ] ),
		)
	);
}

/* ---------- Indirizzo degli avvisi nel pannello (0.15.0) ---------- */

/**
 * Testi delle impostazioni generali per il pannello: quelli di ds_core_testi_generali() più lo stato dell'indirizzo
 * (a chi vanno ora le mail, richiesta in attesa) e, con la costante in wp-config.php, il campo in sola lettura.
 */
function ds_core_avvisi_testi_pannello() {
	$testi    = ds_core_testi_generali();
	$bloccato = ds_core_avvisi_bloccato();
	if ( '' !== $bloccato ) {
		$testi['campi']['avvisi']['sola_lettura'] = true;
		$testi['campi']['avvisi']['valore']       = $bloccato;
		$testi['campi']['avvisi']['aiuto']        = __( 'Set in wp-config.php with DS_CORE_INDIRIZZO_AVVISI, so it cannot be changed from this panel. To change it, edit that line in wp-config.php; to unlock it, remove the line.', 'ds-core' );
	}
	$testi['campi']['avvisi']['dopo_html'] = ds_core_avvisi_stato_html();
	return $testi;
}

/** Sotto il campo dell'indirizzo: blocco, costante sbagliata, a chi vanno ora le mail, richiesta in attesa. */
function ds_core_avvisi_stato_html() {
	$html = '';
	if ( '' !== ds_core_avvisi_bloccato() ) {
		$html .= '<p class="ds-avvisi-bloccato">' . ds_core_icona( 'chiuso' ) . '<span>' . esc_html__( 'Set in wp-config.php', 'ds-core' ) . '</span></p>';
	} elseif ( ds_core_avvisi_costante_errata() ) {
		$html .= '<p class="ds-avvisi-errata">' . ds_core_icona( 'attenzione' ) . '<span>' . esc_html__( 'DS_CORE_INDIRIZZO_AVVISI in wp-config.php is not a valid email address, so it is ignored: fix or remove that line.', 'ds-core' ) . '</span></p>';
	}

	$tutte     = ds_core_avvisi_destinatari( '' );
	$sicurezza = ds_core_avvisi_destinatari( 'avvisi.richiesta' );
	$html     .= '<p class="ds-avvisi-rotta">' . ds_core_icona( 'mail' ) . '<span>';
	if ( $tutte === $sicurezza ) {
		$html .= sprintf(
			/* translators: %s: email address, or a list of addresses. */
			esc_html__( 'Now every DS Core email, security notices included, goes to %s.', 'ds-core' ),
			ds_core_avvisi_destinatari_html( 'avvisi.richiesta' )
		);
	} else {
		$html .= sprintf(
			/* translators: 1: email address, 2: site administrator email address. */
			esc_html__( 'Now DS Core emails go to %1$s; security notices also go to %2$s.', 'ds-core' ),
			ds_core_avvisi_destinatari_html( '' ),
			'<strong>' . esc_html( ds_core_avvisi_admin() ) . '</strong>'
		);
	}
	$html .= '</span></p>';

	$attesa = ds_core_avvisi_attesa();
	if ( $attesa ) {
		$nuovo = '' !== (string) $attesa['indirizzo'] ? (string) $attesa['indirizzo'] : ds_core_avvisi_admin();
		$html .= '<div class="ds-avvisi-attesa" role="status">';
		$html .= '<p class="ds-avvisi-attesa-titolo">' . ds_core_icona( 'attesa' ) . '<span>' . sprintf(
			/* translators: %s: email address waiting for confirmation. */
			esc_html__( 'Waiting for confirmation from %s', 'ds-core' ),
			'<strong>' . esc_html( $nuovo ) . '</strong>'
		) . '</span></p>';
		$html .= '<p>' . esc_html(
			sprintf(
				/* translators: 1: username, 2: date and time of the request, 3: date and time when the link expires. */
				__( 'Requested by %1$s on %2$s. The link in the email works until %3$s; until it is used the emails keep going to the current address.', 'ds-core' ),
				'' !== (string) $attesa['utente'] ? $attesa['utente'] : __( 'unknown', 'ds-core' ),
				ds_core_avvisi_data( $attesa['quando'] ),
				ds_core_avvisi_data( $attesa['scade'] )
			)
		) . '</p>';
		$html .= '<p class="ds-avvisi-attesa-azioni"><button type="submit" form="ds-avvisi-annulla" class="button ds-con-icona">' . ds_core_icona( 'x' ) . esc_html__( 'Cancel the request', 'ds-core' ) . '</button>';
		$html .= '<span class="ds-grigio">' . esc_html__( 'Email not arrived? Save the address again to send a new link.', 'ds-core' ) . '</span></p>';
		$html .= '</div>';
	}
	return $html;
}

/**
 * Dopo il modulo delle impostazioni generali: il modulo HTML dell'annullamento (il pulsante sta nella richiesta in
 * attesa, collegato con l'attributo form) e, se l'indirizzo non è bloccato, la riga da copiare in wp-config.php.
 */
function ds_core_avvisi_dopo_form_html() {
	$html = '<form id="ds-avvisi-annulla" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" hidden>'
		. '<input type="hidden" name="action" value="ds_core_avvisi_annulla">'
		. '<input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( 'ds_core_avvisi_annulla' ) ) . '">'
		. '</form>';
	if ( '' !== ds_core_avvisi_bloccato() ) {
		return $html;
	}
	$riga  = "define( 'DS_CORE_INDIRIZZO_AVVISI', '" . ds_core_indirizzo_avvisi() . "' );";
	$html .= '<details class="ds-avvisi-blocco">';
	$html .= '<summary>' . ds_core_icona( 'chiuso' ) . '<span>' . esc_html__( 'Lock the address in wp-config.php (optional)', 'ds-core' ) . '</span></summary>';
	$html .= '<p>' . esc_html__( 'With this line the notification address can no longer be changed from the panel, not even by an administrator: only someone with access to the site files can change it. Add it to wp-config.php above the line that says to stop editing, with the address you want.', 'ds-core' ) . '</p>';
	$html .= '<div class="ds-copia"><code id="ds-avvisi-riga">' . esc_html( $riga ) . '</code>';
	$html .= '<button type="button" class="button button-small ds-copia-pulsante" data-ds-copia="ds-avvisi-riga" hidden>' . esc_html__( 'Copy', 'ds-core' ) . '</button>';
	$html .= '<span class="ds-copia-esito" role="status" aria-live="polite"></span></div>';
	$html .= '</details>';
	return $html;
}

/* ---------- Riepilogo della riga e anteprima del colore (0.18.0) ---------- */

/**
 * Testo breve di una scelta per il riepilogo, dalla chiave 'breve' dei testi del campo. '' = la scelta non entra.
 */
function ds_core_riepilogo_breve( $breve, $campo, $valore, $valori ) {
	if ( is_callable( $breve ) && ! is_string( $breve ) ) {
		try {
			$testo = call_user_func( $breve, $valore, $valori );
		} catch ( \Throwable $e ) {
			return '';
		}
		return is_scalar( $testo ) ? (string) $testo : '';
	}
	if ( is_array( $breve ) ) {
		$chiave = 'checkbox' === $campo['tipo'] ? ( $valore ? '1' : '0' ) : ( is_scalar( $valore ) ? (string) $valore : '' );
		return isset( $breve[ $chiave ] ) && is_scalar( $breve[ $chiave ] ) ? (string) $breve[ $chiave ] : '';
	}
	if ( ! is_string( $breve ) || '' === $breve ) {
		return '';
	}
	if ( is_array( $valore ) ) {
		$valore = number_format_i18n( count( $valore ) );
	} elseif ( 'number' === $campo['tipo'] ) {
		$valore = number_format_i18n( $valore );
	} elseif ( is_bool( $valore ) || '' === (string) $valore ) {
		return '';
	}
	return sprintf( $breve, (string) $valore );
}

/**
 * Pezzi del riepilogo di un modulo: array di array( 'testo' => …, 'classe' => … ). Stato (spento, errore, dipendenza
 * mancante, in prova; a modulo acceso lo stato a parole della funzione 'riepilogo' del modulo), poi le scelte con
 * 'breve'. Si scrive anche a modulo spento, senza eseguire codice del modulo (le scelte stanno nel registro).
 */
function ds_core_riepilogo_pezzi( $id, $visto, $modulo ) {
	$pezzi = array();
	switch ( $visto ) {
		case 'spento-config':
			$pezzi[] = array( 'testo' => __( 'Off from wp-config.php', 'ds-core' ), 'classe' => 'spento' );
			return $pezzi;
		case 'errore':
			$pezzi[] = array( 'testo' => __( 'Not loaded because of an error', 'ds-core' ), 'classe' => 'errore' );
			break;
		case 'dipendenze':
			$pezzi[] = array( 'testo' => __( 'Waiting for a missing dependency', 'ds-core' ), 'classe' => 'errore' );
			break;
		case 'spento':
			$pezzi[] = array( 'testo' => _x( 'Off', 'module summary', 'ds-core' ), 'classe' => 'spento' );
			break;
		case 'prova':
		case 'attivo':
			if ( 'prova' === $visto ) {
				$pezzi[] = array( 'testo' => __( 'In test: only for administrators', 'ds-core' ), 'classe' => '' );
			}
			if ( ! empty( $modulo['riepilogo'] ) && is_callable( $modulo['riepilogo'] ) ) {
				try {
					$testo = call_user_func( $modulo['riepilogo'], $id );
				} catch ( \Throwable $e ) {
					$testo = '';
				}
				if ( is_scalar( $testo ) && '' !== (string) $testo ) {
					$pezzi[] = array( 'testo' => (string) $testo, 'classe' => '' );
				}
			}
			break;
	}
	$gruppo = '' !== $modulo['opzione'] && $modulo['campi'] ? ds_core_gruppo_impostazioni( $id ) : null;
	if ( $gruppo && $gruppo['schema'] ) {
		$valori = ds_core_opzioni_modulo( $id );
		$testi  = isset( $modulo['testi_campi'] ) && is_array( $modulo['testi_campi'] ) ? $modulo['testi_campi'] : array();
		foreach ( $gruppo['schema'] as $chiave => $campo ) {
			if ( $campo['nascosto'] || ! isset( $testi[ $chiave ]['breve'] ) || ! array_key_exists( $chiave, $valori ) ) {
				continue;
			}
			// Un campo che dipende da un altro conta solo con il valore giusto dell'altro (es. «Custom»).
			if ( $campo['mostra_se'] ) {
				$altro = $valori[ $campo['mostra_se'][0] ] ?? null;
				$altro = is_bool( $altro ) ? ( $altro ? '1' : '' ) : ( is_scalar( $altro ) ? (string) $altro : '' );
				if ( $altro !== $campo['mostra_se'][1] ) {
					continue;
				}
			}
			$testo = ds_core_riepilogo_breve( $testi[ $chiave ]['breve'], $campo, $valori[ $chiave ], $valori );
			if ( '' !== $testo ) {
				$pezzi[] = array( 'testo' => $testo, 'classe' => '' );
			}
		}
	}
	return $pezzi;
}

/**
 * Riga di riepilogo sotto la descrizione del modulo (riga chiusa), con il segnale «Unsaved changes» nascosto che lo
 * script mostra quando la riga ha scelte modificate e non salvate. Restituisce HTML già escapato.
 */
function ds_core_riepilogo_html( $id, $visto, $modulo = null ) {
	if ( null === $modulo ) {
		$registro = ds_core_registro_con_testi();
		if ( ! isset( $registro[ $id ] ) ) {
			return '';
		}
		$modulo = $registro[ $id ];
	}
	$html = '<p class="ds-riepilogo" data-ds-riepilogo="' . esc_attr( $id ) . '">';
	foreach ( ds_core_riepilogo_pezzi( $id, $visto, $modulo ) as $pezzo ) {
		$html .= '<span class="ds-pezzo' . ( '' !== $pezzo['classe'] ? ' ds-pezzo--' . esc_attr( $pezzo['classe'] ) : '' ) . '">' . esc_html( $pezzo['testo'] ) . '</span>';
	}
	$html .= '<span class="ds-pezzo ds-pezzo--modificato" hidden>' . esc_html__( 'Unsaved changes', 'ds-core' ) . '</span>';
	return $html . '</p>';
}

/**
 * Anteprima di un colore di brand sotto il campo 'color' con 'contrasto': un pezzo di menu e un pulsante nel colore,
 * testo bianco o scuro scelto per il contrasto e il rapporto a parole; sotto 4,5:1 la tonalità che DS Core usa al suo
 * posto. Lo script la ricalcola mentre si sceglie il colore (stessa formula, pannello.js). HTML già escapato.
 * $extra (dalla 0.18.1, facoltativo, dai testi del campo): 'nota_vuoto' (frase quando il campo è vuoto e non c'è un
 * colore di ripiego), 'link_vuoto' (colore dei link con il campo vuoto: compare un campione di link), 'origini' e
 * 'origini_scelto' (righe «da dove viene ogni colore» con il campo vuoto e con un colore scelto). $pieno: il campo ha
 * un valore (null = si deduce dal colore).
 */
function ds_core_anteprima_colore_html( $colore, $vuoto = '', $extra = array(), $pieno = null ) {
	$colore     = sanitize_hex_color( (string) $colore );
	$pieno      = null === $pieno ? ( $colore && $colore !== $vuoto ) : (bool) $pieno;
	$nota_vuoto = isset( $extra['nota_vuoto'] ) ? (string) $extra['nota_vuoto'] : '';
	$link_vuoto = isset( $extra['link_vuoto'] ) ? (string) sanitize_hex_color( (string) $extra['link_vuoto'] ) : '';
	$con_link   = '' !== $link_vuoto || ! empty( $extra['origini'] );
	$html       = '<div class="ds-anteprima-colore" data-ds-anteprima="1" data-ds-vuoto="' . esc_attr( (string) $vuoto ) . '"'
		. ( '' !== $nota_vuoto ? ' data-ds-nota-vuoto="' . esc_attr( $nota_vuoto ) . '"' : '' )
		. ( $con_link ? ' data-ds-link-vuoto="' . esc_attr( $link_vuoto ) . '"' : '' ) . '>';
	$stile      = '';
	$nota       = '' !== $nota_vuoto && ! $pieno ? $nota_vuoto : __( 'Choose a color to see the preview.', 'ds-core' );
	$link       = '';
	if ( $colore ) {
		$leggibile = ds_core_colore_leggibile( $colore );
		$stile     = 'background:' . $leggibile['fondo'] . ';color:' . $leggibile['testo'];
		$nota      = ds_core_anteprima_colore_testo( $colore, $leggibile );
		$link      = $pieno || '' === $link_vuoto ? ds_core_colore_su( $colore, '#f0f0f1' ) : $link_vuoto;
	}
	$html .= '<span class="ds-anteprima-campioni" aria-hidden="true"' . ( $colore ? '' : ' hidden' ) . '>';
	$html .= '<span class="ds-anteprima-menu"><span>' . esc_html__( 'Posts', 'ds-core' ) . '</span><span class="ds-anteprima-corrente" style="' . esc_attr( $stile ) . '">DS Core</span><span>' . esc_html__( 'Pages', 'ds-core' ) . '</span></span>';
	$html .= '<span class="ds-anteprima-pulsante" style="' . esc_attr( $stile ) . '">' . esc_html__( 'Save', 'ds-core' ) . '</span>';
	if ( $con_link ) {
		$html .= '<span class="ds-anteprima-link" style="' . esc_attr( $link ? 'color:' . $link : '' ) . '">' . esc_html__( 'A link on the dashboard', 'ds-core' ) . '</span>';
	}
	$html .= '</span>';
	$html .= '<p class="ds-campo-aiuto ds-anteprima-nota" aria-live="polite">' . esc_html( $nota ) . '</p>';
	foreach ( array( 'origini' => 'vuoto', 'origini_scelto' => 'scelto' ) as $chiave => $stato ) {
		if ( empty( $extra[ $chiave ] ) || ! is_array( $extra[ $chiave ] ) ) {
			continue;
		}
		$html .= '<ul class="ds-anteprima-origini" data-ds-se="' . $stato . '"' . ( ( 'scelto' === $stato ) !== $pieno ? ' hidden' : '' ) . '>';
		foreach ( $extra[ $chiave ] as $riga ) {
			$html .= '<li>' . esc_html( (string) $riga ) . '</li>';
		}
		$html .= '</ul>';
	}
	return $html . '</div>';
}

/** Frase dell'anteprima: colore del testo, contrasto e, se serve, la tonalità usata al posto del colore scelto. */
function ds_core_anteprima_colore_testo( $colore, $leggibile ) {
	$testo = '#ffffff' === $leggibile['testo'] ? __( 'white', 'ds-core' ) : __( 'dark', 'ds-core' );
	if ( $leggibile['cambiato'] ) {
		/* translators: 1: color chosen, 2: "white" or "dark", 3: contrast ratio, 4: color used instead. */
		return sprintf( __( 'With %1$s no text color is readable enough, so DS Core uses the shade %4$s with %2$s text: contrast %3$s:1 (readable).', 'ds-core' ), $colore, $testo, number_format_i18n( $leggibile['rapporto'], 1 ), $leggibile['fondo'] );
	}
	/* translators: 1: "white" or "dark", 2: contrast ratio. */
	return sprintf( __( 'Text on this color: %1$s, contrast %2$s:1 (readable).', 'ds-core' ), $testo, number_format_i18n( $leggibile['rapporto'], 1 ) );
}

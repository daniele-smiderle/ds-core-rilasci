/*
 * Pannello DS Core, scritto a mano senza dipendenze (solo wp.i18n per i testi).
 * - Levetta (role="switch") per i moduli a due stati, pulsanti Spento | Prova | Attivo per quelli a tre stati:
 *   un clic salva subito (azione AJAX ds_core_imposta); in caso d'errore il controllo torna com'era.
 * - Schede (0.18.0, modello «Tabs» di WAI-ARIA, attivazione automatica): All · categorie │ Settings · Help. Il server
 *   ha già disegnato tutto: lo script mostra e nasconde, aggiorna l'indirizzo (?tab=) con history.replaceState (il
 *   tasto Indietro torna alla pagina precedente di WordPress) e sposta la voce evidenziata del sottomenu. Frecce ← →,
 *   Home e Fine fra le schede. Cambiando scheda la selezione delle azioni in blocco si azzera.
 * - Filtri lato client: stato (contato nella scheda scelta), origine e tag sotto «More filters», ricerca. La ricerca
 *   vale sempre per tutti i moduli: scrivendo la vista passa a «All» con una riga che dice quanti moduli
 *   corrispondono; svuotando il campo torna la scheda di prima.
 * - Azioni su un'intera categoria (nella testata della categoria), con conferma; nascoste durante una ricerca.
 * - Azioni in blocco via AJAX (ds_core_blocco) sui moduli scelti e visibili; la barra compare solo con una selezione.
 *   Senza JavaScript il modulo HTML fa lo stesso con la ricarica della pagina.
 * - Righe compatte: «Settings»/«Details» (link con role="button", aria-expanded, aria-controls) apre e chiude la riga
 *   sotto. Righe aperte ricordate solo per la sessione del browser (sessionStorage, 0.18.0: prima localStorage, che le
 *   riapriva per sempre). «Collapse all» le chiude tutte. L'indirizzo #ds-impostazioni-<id> apre quella riga.
 * - Riepilogo sotto la descrizione: si aggiorna dopo un cambio di stato e dopo «Save settings» (HTML dal server);
 *   con scelte modificate e non salvate dice «Unsaved changes» anche a riga chiusa.
 * - Scelte dichiarate nel registro (0.13.0): «Save settings» via AJAX (ds_core_impostazioni, nonce del modulo già
 *   nel modulo HTML), errori campo per campo, valori puliti dal server rimessi nei campi.
 * - Dopo un cambio di stato la parte «stato» della riga si chiede di nuovo (ds_core_riga).
 * - Campi che dipendono da un altro (data-ds-mostra-se); colore con anteprima del contrasto (stessa formula di
 *   ds_core_colore_leggibile() in includes/opzioni.php).
 * - Scheda Settings: «Change» apre la riga delle impostazioni generali; indirizzo degli avvisi con ricarica se nasce
 *   una richiesta di cambio. «Copy» per le righe da mettere in wp-config.php e per il nome tecnico dei moduli.
 * - Aspetto Automatico | Chiaro | Scuro (azione ds_core_tema).
 * - 0.18.2: barra fissa in basso con le modifiche non salvate («Save changes», «Discard», «Show»), per tutti i moduli e
 *   le impostazioni generali; avviso cambiando scheda e uscendo dalla pagina (beforeunload). «Discard» torna all'ultimo
 *   salvataggio (valori fissati come predefiniti del modulo HTML dopo ogni «Save»).
 * - 0.18.2: admin-branding, schemi proposti e colori personalizzati con anteprima dal vivo (calcolaSchema(), stessa
 *   logica di ds_core_ab_calcola() in includes/opzioni.php).
 */
( function () {
	'use strict';

	var pagina = document.querySelector( '.ds-core' );
	if ( ! pagina || typeof dsCore === 'undefined' || ! window.wp || ! wp.i18n ) {
		return;
	}

	pagina.classList.add( 'ds-js' );

	var __ = wp.i18n.__;
	var _n = wp.i18n._n;
	var sprintf = wp.i18n.sprintf;

	function tutti( selettore, base ) {
		return Array.prototype.slice.call( ( base || pagina ).querySelectorAll( selettore ) );
	}

	var messaggio = pagina.querySelector( '.ds-messaggio' );
	var righe = tutti( 'tr[data-ds-id]' );
	var sezioni = tutti( '.ds-categoria' );
	var perId = {};
	righe.forEach( function ( riga ) {
		perId[ riga.getAttribute( 'data-ds-id' ) ] = riga;
	} );

	var campoOrigine = pagina.querySelector( '#ds-origine' );
	var campoTag = pagina.querySelector( '#ds-tag' );
	var campoCerca = pagina.querySelector( '#ds-cerca' );
	var azzera = pagina.querySelector( '.ds-azzera' );
	var nessuno = pagina.querySelector( '.ds-nessuno' );
	var notaRicerca = pagina.querySelector( '.ds-nota-ricerca' );
	var tuttiVisibili = pagina.querySelector( '#ds-seleziona-visibili' );
	var contaScelti = pagina.querySelector( '.ds-blocco-conta' );
	var barra = pagina.querySelector( '.ds-blocco' );
	var annullaScelta = pagina.querySelector( '.ds-blocco-annulla' );
	var schede = tutti( '.ds-schede [role="tab"]' );
	var pannelloModuli = pagina.querySelector( '#ds-pannello-moduli' );

	// Vista: scheda scelta ('all', una categoria, 'settings', 'help') e filtri.
	var vista = { scheda: pagina.getAttribute( 'data-ds-scheda' ) || 'all', prima: '' };
	var filtri = { stato: 'tutti', origine: '', tag: '', testo: '' };

	/* ---------- Messaggi ---------- */

	function mostra( testo, errore ) {
		if ( ! messaggio ) {
			return;
		}
		messaggio.textContent = testo;
		messaggio.className = 'ds-messaggio notice ' + ( errore ? 'notice-error' : 'notice-success' );
	}

	function messaggioRiga( riga, testo, tipo ) {
		var spazio = riga.querySelector( '.ds-riga-messaggio' );
		if ( ! spazio ) {
			return;
		}
		spazio.textContent = testo || '';
		spazio.className = 'ds-riga-messaggio' + ( tipo ? ' ds-riga-messaggio--' + tipo : '' );
	}

	function titolo( riga ) {
		var t = riga.querySelector( '.ds-titolo' );
		return t ? t.textContent : riga.getAttribute( 'data-ds-id' );
	}

	/* ---------- Richieste ---------- */

	function richiesta( campi ) {
		var dati = new FormData();
		dati.append( 'nonce', dsCore.nonce );
		Object.keys( campi ).forEach( function ( chiave ) {
			var valore = campi[ chiave ];
			if ( Array.isArray( valore ) ) {
				valore.forEach( function ( v ) {
					dati.append( chiave + '[]', v );
				} );
			} else {
				dati.append( chiave, valore );
			}
		} );
		return fetch( dsCore.ajax, { method: 'POST', credentials: 'same-origin', body: dati } ).then( function ( risposta ) {
			return risposta.json().catch( function () {
				return null;
			} );
		} );
	}

	// WordPress risponde -1 o 0 (non un oggetto) se il nonce è scaduto o l'azione non esiste.
	function testoErrore( esito ) {
		if ( esito && typeof esito === 'object' && esito.data && esito.data.messaggio ) {
			return esito.data.messaggio;
		}
		if ( esito === -1 || esito === 0 ) {
			return __( 'Session expired: reload the page and try again.', 'ds-core' );
		}
		return __( 'Not saved.', 'ds-core' );
	}

	/* ---------- Riepilogo della riga ---------- */

	function formDi( id ) {
		return pagina.querySelector( 'form.ds-impostazioni[data-ds-impostazioni="' + id + '"]' );
	}

	// Mostra o nasconde «Unsaved changes» nel riepilogo del modulo.
	function segnaNonSalvato( id ) {
		var form = formDi( id );
		var segno = pagina.querySelector( '[data-ds-riepilogo="' + id + '"] .ds-pezzo--modificato' );
		if ( segno ) {
			segno.hidden = ! ( form && form.classList.contains( 'is-modificato' ) );
		}
	}

	// HTML del riepilogo preparato dal server (escape fatto in PHP).
	function sostituisciRiepilogo( id, html ) {
		var vecchio = pagina.querySelector( '[data-ds-riepilogo="' + id + '"]' );
		if ( ! vecchio || typeof html !== 'string' || ! html ) {
			return;
		}
		var contenitore = document.createElement( 'div' );
		contenitore.innerHTML = html;
		var nuovo = contenitore.firstElementChild;
		if ( nuovo ) {
			vecchio.parentNode.replaceChild( nuovo, vecchio );
			segnaNonSalvato( id );
		}
	}

	/* ---------- Stato delle righe ---------- */

	function impostaControllo( riga, scelto ) {
		var levetta = riga.querySelector( '.ds-levetta' );
		if ( levetta ) {
			levetta.setAttribute( 'aria-checked', scelto !== 'spento' ? 'true' : 'false' );
		}
		tutti( '.ds-segmento', riga ).forEach( function ( pulsante ) {
			pulsante.setAttribute( 'aria-pressed', pulsante.getAttribute( 'data-ds-valore' ) === scelto ? 'true' : 'false' );
		} );
	}

	function applicaRiga( riga, dati ) {
		riga.setAttribute( 'data-ds-stato', dati.stato );
		riga.setAttribute( 'data-ds-scelto', dati.scelto );
		impostaControllo( riga, dati.scelto );
		var badge = riga.querySelector( '.ds-stato' );
		if ( badge ) {
			badge.textContent = dati.etichetta;
			badge.className = 'ds-stato ds-stato--' + dati.stato;
		}
		sostituisciRiepilogo( riga.getAttribute( 'data-ds-id' ), dati.riepilogo );
	}

	// Durante il salvataggio i controlli restano focalizzabili (aria-disabled, non disabled): chi usa la tastiera
	// non perde la posizione.
	function inSalvataggio( riga, si ) {
		riga.classList.toggle( 'is-salvataggio', si );
		tutti( '.ds-levetta, .ds-segmento', riga ).forEach( function ( c ) {
			if ( si ) {
				c.setAttribute( 'aria-disabled', 'true' );
			} else {
				c.removeAttribute( 'aria-disabled' );
			}
		} );
		var cella = riga.querySelector( '.ds-col-stato' );
		if ( cella ) {
			cella.setAttribute( 'aria-busy', si ? 'true' : 'false' );
		}
		if ( si ) {
			riga.classList.remove( 'is-errore' );
			messaggioRiga( riga, __( 'saving…', 'ds-core' ), 'attesa' );
		}
	}

	function segnaErrore( riga, testo ) {
		riga.classList.add( 'is-errore' );
		messaggioRiga( riga, testo, 'errore' );
	}

	function cambia( riga, nuovo ) {
		if ( riga.classList.contains( 'is-salvataggio' ) ) {
			return;
		}
		var prima = riga.getAttribute( 'data-ds-scelto' );
		if ( nuovo === prima ) {
			return;
		}
		impostaControllo( riga, nuovo );
		inSalvataggio( riga, true );

		richiesta( { action: 'ds_core_imposta', id: riga.getAttribute( 'data-ds-id' ), stato: nuovo } )
			.then( function ( esito ) {
				inSalvataggio( riga, false );
				if ( esito && esito.success ) {
					applicaRiga( riga, esito.data );
					aggiornaDettagli( riga.getAttribute( 'data-ds-id' ) );
					messaggioRiga( riga, esito.data.stato === 'dipendenze' ? esito.data.messaggio : '', esito.data.stato === 'dipendenze' ? 'avviso' : '' );
					/* translators: 1: module title, 2: message. */
					mostra( sprintf( __( '%1$s: %2$s', 'ds-core' ), titolo( riga ), esito.data.messaggio ), false );
				} else {
					impostaControllo( riga, prima );
					segnaErrore( riga, testoErrore( esito ) );
					/* translators: 1: module title, 2: message. */
					mostra( sprintf( __( '%1$s: %2$s', 'ds-core' ), titolo( riga ), testoErrore( esito ) ), true );
				}
				aggiornaConteggi();
			} )
			.catch( function () {
				inSalvataggio( riga, false );
				impostaControllo( riga, prima );
				segnaErrore( riga, __( 'Not saved: network error.', 'ds-core' ) );
				/* translators: %s: module title. */
				mostra( sprintf( __( '%s: not saved, network error. Reload the page and try again.', 'ds-core' ), titolo( riga ) ), true );
			} );
	}

	righe.forEach( function ( riga ) {
		var levetta = riga.querySelector( '.ds-levetta' );
		if ( levetta ) {
			// Un <button> si attiva già con spazio e invio.
			levetta.addEventListener( 'click', function () {
				if ( levetta.disabled || levetta.getAttribute( 'aria-disabled' ) === 'true' ) {
					return;
				}
				cambia( riga, levetta.getAttribute( 'aria-checked' ) === 'true' ? 'spento' : 'attivo' );
			} );
		}
		tutti( '.ds-segmento', riga ).forEach( function ( pulsante ) {
			pulsante.addEventListener( 'click', function () {
				if ( pulsante.disabled || pulsante.getAttribute( 'aria-disabled' ) === 'true' ) {
					return;
				}
				cambia( riga, pulsante.getAttribute( 'data-ds-valore' ) );
			} );
		} );
	} );

	/* ---------- Conteggi e filtri ---------- */

	function gruppo( stato ) {
		return ( stato === 'attivo' || stato === 'prova' || stato === 'errore' ) ? stato : 'spento';
	}

	// Categoria mostrata: '' = tutte (scheda All, Settings/Help, oppure ricerca in corso).
	function categoriaVista() {
		if ( filtri.testo ) {
			return '';
		}
		return ( vista.scheda === 'all' || vista.scheda === 'settings' || vista.scheda === 'help' ) ? '' : vista.scheda;
	}

	function nellaVista( riga ) {
		var categoria = categoriaVista();
		return ! categoria || riga.getAttribute( 'data-ds-categoria-riga' ) === categoria;
	}

	function aggiornaConteggi() {
		var conta = { tutti: 0, attivo: 0, prova: 0, spento: 0, errore: 0 };
		righe.forEach( function ( riga ) {
			if ( nellaVista( riga ) ) {
				conta.tutti++;
				conta[ gruppo( riga.getAttribute( 'data-ds-stato' ) ) ]++;
			}
		} );
		Object.keys( conta ).forEach( function ( chiave ) {
			var posto = pagina.querySelector( '[data-ds-conta="' + chiave + '"]' );
			if ( posto ) {
				posto.textContent = conta[ chiave ];
			}
		} );
		sezioni.forEach( function ( sezione ) {
			var tutte = sezione.querySelectorAll( 'tr[data-ds-id]' );
			var accese = 0;
			tutte.forEach( function ( riga ) {
				if ( riga.getAttribute( 'data-ds-scelto' ) !== 'spento' ) {
					accese++;
				}
			} );
			var posto = sezione.querySelector( '[data-ds-categoria-conta]' );
			if ( posto ) {
				/* translators: 1: number of modules on, 2: number of modules in the category. */
				posto.textContent = sprintf( __( '%1$d of %2$d on', 'ds-core' ), accese, tutte.length );
			}
			tutti( '.ds-categoria-azione', sezione ).forEach( function ( pulsante ) {
				var accendi = pulsante.getAttribute( 'data-ds-categoria-azione' ) === 'attivo';
				var inutile = accendi ? accese === tutte.length : accese === 0;
				pulsante.disabled = inutile;
				pulsante.title = inutile ? ( accendi ? __( 'They are all on already', 'ds-core' ) : __( 'They are all off already', 'ds-core' ) ) : '';
			} );
		} );
	}

	function tagDi( riga ) {
		var valore = riga.getAttribute( 'data-ds-tag' ) || '';
		return valore ? valore.split( '|' ) : [];
	}

	// Dopo un cambio di stato la riga resta dov'è anche se non corrisponde più al filtro: sparirebbe sotto il
	// cursore. Il filtro si riapplica alla prossima scelta di filtro.
	function filtra() {
		var vuoto = true;
		var trovati = 0;
		var categoria = categoriaVista();
		sezioni.forEach( function ( sezione ) {
			var visibili = 0;
			var categoriaOk = ! categoria || sezione.getAttribute( 'data-ds-categoria' ) === categoria;
			tutti( 'tr[data-ds-id]', sezione ).forEach( function ( riga ) {
				var ok = categoriaOk && ( filtri.stato === 'tutti' || filtri.stato === gruppo( riga.getAttribute( 'data-ds-stato' ) ) ) &&
					( ! filtri.origine || riga.getAttribute( 'data-ds-origine' ) === filtri.origine ) &&
					( ! filtri.tag || tagDi( riga ).indexOf( filtri.tag ) !== -1 ) &&
					( ! filtri.testo || ( riga.getAttribute( 'data-ds-testo' ) || '' ).indexOf( filtri.testo ) !== -1 );
				riga.hidden = ! ok;
				// La riga aperta sta nello stesso <tbody> e sparisce con il suo modulo.
				var corpo = riga.parentNode;
				if ( corpo && corpo.classList && corpo.classList.contains( 'ds-modulo' ) ) {
					corpo.hidden = ! ok;
				}
				if ( ok ) {
					visibili++;
				}
			} );
			sezione.hidden = visibili === 0;
			trovati += visibili;
			if ( visibili ) {
				vuoto = false;
			}
		} );
		if ( nessuno ) {
			nessuno.hidden = ! vuoto;
		}
		if ( notaRicerca ) {
			notaRicerca.hidden = ! filtri.testo;
			if ( filtri.testo ) {
				/* translators: 1: number of modules, 2: text searched. */
				notaRicerca.textContent = sprintf( _n( '%1$d module matches “%2$s” in all categories.', '%1$d modules match “%2$s” in all categories.', trovati, 'ds-core' ), trovati, campoCerca ? campoCerca.value.trim() : filtri.testo );
			}
		}
		pagina.classList.toggle( 'is-ricerca', !! filtri.testo );
		if ( azzera ) {
			azzera.hidden = filtri.stato === 'tutti' && ! filtri.origine && ! filtri.tag && ! filtri.testo;
		}
		tutti( '.ds-tag' ).forEach( function ( pulsante ) {
			pulsante.setAttribute( 'aria-pressed', filtri.tag && pulsante.getAttribute( 'data-ds-tag' ) === filtri.tag ? 'true' : 'false' );
		} );
		aggiornaConteggi();
		aggiornaSelezione();
	}

	function scegliStato( chiave ) {
		filtri.stato = chiave;
		tutti( '[data-ds-filtro]' ).forEach( function ( link ) {
			var attivo = link.getAttribute( 'data-ds-filtro' ) === chiave;
			link.classList.toggle( 'current', attivo );
			if ( attivo ) {
				link.setAttribute( 'aria-current', 'true' );
			} else {
				link.removeAttribute( 'aria-current' );
			}
		} );
	}

	tutti( '[data-ds-filtro]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function ( evento ) {
			evento.preventDefault();
			scegliStato( link.getAttribute( 'data-ds-filtro' ) );
			filtra();
		} );
	} );

	// «More filters»: origine (solo con più origini) e tag.
	var mostraFiltri = pagina.querySelector( '.ds-mostra-filtri' );
	var piuFiltri = pagina.querySelector( '#ds-piu-filtri' );
	if ( mostraFiltri && piuFiltri ) {
		mostraFiltri.hidden = false;
		mostraFiltri.addEventListener( 'click', function () {
			var apri = piuFiltri.hidden;
			piuFiltri.hidden = ! apri;
			mostraFiltri.setAttribute( 'aria-expanded', apri ? 'true' : 'false' );
			mostraFiltri.textContent = apri ? __( 'Fewer filters', 'ds-core' ) : __( 'More filters', 'ds-core' );
		} );
	}

	if ( campoOrigine ) {
		campoOrigine.addEventListener( 'change', function () {
			filtri.origine = campoOrigine.value;
			filtra();
		} );
	}

	function scegliTag( tag ) {
		filtri.tag = tag;
		if ( campoTag ) {
			campoTag.value = tag;
		}
		if ( tag && piuFiltri && piuFiltri.hidden && mostraFiltri ) {
			mostraFiltri.click();
		}
		filtra();
	}

	if ( campoTag ) {
		campoTag.addEventListener( 'change', function () {
			scegliTag( campoTag.value );
		} );
	}

	// Un tag nei dettagli tecnici filtra; cliccato di nuovo toglie il filtro.
	tutti( '.ds-tag' ).forEach( function ( pulsante ) {
		pulsante.addEventListener( 'click', function () {
			var tag = pulsante.getAttribute( 'data-ds-tag' );
			scegliTag( filtri.tag === tag ? '' : tag );
		} );
	} );

	// Ricerca su tutti i moduli: la vista passa a «All»; svuotando il campo torna la scheda di prima.
	if ( campoCerca ) {
		campoCerca.addEventListener( 'input', function () {
			var testo = campoCerca.value.trim().toLowerCase();
			if ( testo && ! filtri.testo ) {
				vista.prima = vista.scheda;
				segnaScheda( 'all' );
			} else if ( ! testo && filtri.testo ) {
				segnaScheda( vista.prima || 'all' );
			}
			filtri.testo = testo;
			azzeraSelezione();
			filtra();
		} );
	}

	function togliFiltri() {
		scegliStato( 'tutti' );
		filtri.origine = '';
		if ( campoOrigine ) {
			campoOrigine.value = '';
		}
		if ( filtri.testo ) {
			segnaScheda( vista.prima || 'all' );
		}
		filtri.testo = '';
		if ( campoCerca ) {
			campoCerca.value = '';
		}
		scegliTag( '' );
	}

	if ( azzera ) {
		azzera.addEventListener( 'click', togliFiltri );
	}

	/* ---------- Schede ---------- */

	function slugSottomenu( scheda ) {
		return scheda === 'settings' || scheda === 'help' ? 'tab=' + scheda : '';
	}

	// Voce evidenziata nel sottomenu di «DS Core»: Settings e Help per le loro schede, Modules per le altre.
	function aggiornaSottomenu( scheda ) {
		var menu = document.querySelector( '#toplevel_page_ds-core .wp-submenu' );
		if ( ! menu ) {
			return;
		}
		var cerca = slugSottomenu( scheda );
		var voci = Array.prototype.slice.call( menu.querySelectorAll( 'li' ) ).filter( function ( li ) {
			return li.querySelector( 'a' );
		} );
		var scelta = null;
		voci.forEach( function ( li ) {
			var href = li.querySelector( 'a' ).getAttribute( 'href' ) || '';
			var giusta = cerca ? href.indexOf( 'page=ds-core' ) !== -1 && href.indexOf( cerca ) !== -1 : /page=ds-core$/.test( href ) || /^admin\.php\?page=ds-core$/.test( href );
			if ( giusta && ! scelta ) {
				scelta = li;
			}
		} );
		if ( ! scelta ) {
			return;
		}
		voci.forEach( function ( li ) {
			var a = li.querySelector( 'a' );
			var si = li === scelta;
			li.classList.toggle( 'current', si );
			a.classList.toggle( 'current', si );
			if ( si ) {
				a.setAttribute( 'aria-current', 'page' );
			} else {
				a.removeAttribute( 'aria-current' );
			}
		} );
	}

	function urlScheda( scheda ) {
		var url = new URL( window.location.href );
		url.searchParams.set( 'page', 'ds-core' );
		if ( scheda === 'all' ) {
			url.searchParams.delete( 'tab' );
		} else {
			url.searchParams.set( 'tab', scheda );
		}
		// Messaggi di un'azione già mostrata: non si ripetono ricaricando.
		[ 'ds_fatti', 'ds_saltati', 'ds_errori', 'ds_accesso' ].forEach( function ( chiave ) {
			url.searchParams.delete( chiave );
		} );
		url.hash = '';
		return url;
	}

	// Solo l'aspetto delle schede (aria-selected, tabindex), senza cambiare l'indirizzo: serve alla ricerca.
	function segnaScheda( scheda ) {
		vista.scheda = scheda;
		pagina.setAttribute( 'data-ds-scheda', scheda );
		schede.forEach( function ( tab ) {
			var si = tab.getAttribute( 'data-ds-scheda' ) === scheda;
			tab.setAttribute( 'aria-selected', si ? 'true' : 'false' );
			tab.setAttribute( 'tabindex', si ? '0' : '-1' );
			tab.classList.toggle( 'nav-tab-active', si );
		} );
		var modulo = scheda !== 'settings' && scheda !== 'help';
		tutti( '.ds-pannello' ).forEach( function ( parte ) {
			parte.hidden = modulo ? parte !== pannelloModuli : parte.id !== 'ds-pannello-' + scheda;
		} );
		if ( modulo && pannelloModuli ) {
			pannelloModuli.setAttribute( 'aria-labelledby', 'ds-scheda-' + scheda );
		}
	}

	function azzeraSelezione() {
		righe.forEach( function ( riga ) {
			var c = casella( riga );
			if ( c ) {
				c.checked = false;
			}
		} );
	}

	// Cambio di scheda: aspetto, indirizzo, sottomenu, selezione azzerata (nessuno spegne moduli che non vede).
	function vaiScheda( scheda, opzioni ) {
		opzioni = opzioni || {};
		if ( ! schede.some( function ( tab ) {
			return tab.getAttribute( 'data-ds-scheda' ) === scheda;
		} ) ) {
			return;
		}
		if ( filtri.testo && campoCerca ) {
			filtri.testo = '';
			campoCerca.value = '';
		}
		segnaScheda( scheda );
		avvisaNonSalvati();
		azzeraSelezione();
		filtra();
		if ( window.history && window.history.replaceState && ! opzioni.senzaIndirizzo ) {
			try {
				window.history.replaceState( null, '', urlScheda( scheda ).toString() );
			} catch ( e ) {
				// Indirizzo non aggiornato: la scheda resta comunque quella scelta.
			}
		}
		aggiornaSottomenu( scheda );
		if ( opzioni.fuoco ) {
			var tab = document.getElementById( 'ds-scheda-' + scheda );
			if ( tab ) {
				tab.focus();
			}
		}
	}

	schede.forEach( function ( tab, indice ) {
		tab.addEventListener( 'click', function ( evento ) {
			// Ctrl/⌘/Maiusc + clic: scheda nuova del browser, come un link normale.
			if ( evento.ctrlKey || evento.metaKey || evento.shiftKey || evento.button !== 0 ) {
				return;
			}
			evento.preventDefault();
			vaiScheda( tab.getAttribute( 'data-ds-scheda' ) );
		} );
		tab.addEventListener( 'keydown', function ( evento ) {
			var nuovo = -1;
			if ( evento.key === 'ArrowRight' ) {
				nuovo = ( indice + 1 ) % schede.length;
			} else if ( evento.key === 'ArrowLeft' ) {
				nuovo = ( indice - 1 + schede.length ) % schede.length;
			} else if ( evento.key === 'Home' ) {
				nuovo = 0;
			} else if ( evento.key === 'End' ) {
				nuovo = schede.length - 1;
			} else if ( evento.key === ' ' ) {
				evento.preventDefault();
				vaiScheda( tab.getAttribute( 'data-ds-scheda' ) );
				return;
			}
			if ( nuovo !== -1 ) {
				evento.preventDefault();
				vaiScheda( schede[ nuovo ].getAttribute( 'data-ds-scheda' ), { fuoco: true } );
			}
		} );
	} );

	// Le voci Settings e Help del sottomenu cambiano scheda senza ricaricare quando si è già sulla pagina.
	tutti( '#toplevel_page_ds-core .wp-submenu a', document ).forEach( function ( a ) {
		var href = a.getAttribute( 'href' ) || '';
		var trovato = /[?&]page=ds-core(?:&tab=([a-z]+))?$/.exec( href );
		if ( ! trovato ) {
			return;
		}
		a.addEventListener( 'click', function ( evento ) {
			if ( evento.ctrlKey || evento.metaKey || evento.shiftKey || evento.button !== 0 ) {
				return;
			}
			evento.preventDefault();
			vaiScheda( trovato[ 1 ] || 'all', { fuoco: true } );
		} );
	} );

	// Link interni verso un'altra scheda (data-ds-vai), per esempio da Settings a Help.
	tutti( '[data-ds-vai]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function ( evento ) {
			evento.preventDefault();
			vaiScheda( link.getAttribute( 'data-ds-vai' ), { fuoco: true } );
			var ancora = ( link.getAttribute( 'href' ) || '' ).split( '#' )[ 1 ];
			var bersaglio = ancora ? document.getElementById( ancora ) : null;
			if ( bersaglio ) {
				scorriA( bersaglio );
			}
		} );
	} );

	/* ---------- Selezione e azioni in blocco ---------- */

	function visibile( riga ) {
		var sezione = riga.closest( '.ds-categoria' );
		return ! riga.hidden && ! ( sezione && sezione.hidden ) && ! ( pannelloModuli && pannelloModuli.hidden );
	}

	function casella( riga ) {
		return riga.querySelector( 'input[name="ds_scelti[]"]' );
	}

	function sceltiVisibili() {
		return righe.filter( function ( riga ) {
			var c = casella( riga );
			return c && c.checked && visibile( riga );
		} );
	}

	function statoCasella( casellaTutti, elenco ) {
		var scelte = elenco.filter( function ( riga ) {
			return casella( riga ) && casella( riga ).checked;
		} ).length;
		casellaTutti.checked = elenco.length > 0 && scelte === elenco.length;
		casellaTutti.indeterminate = scelte > 0 && scelte < elenco.length;
	}

	function aggiornaSelezione() {
		var visibiliTutte = righe.filter( visibile );
		var scelte = sceltiVisibili().length;
		if ( contaScelti ) {
			/* translators: %d: number of selected modules. */
			contaScelti.textContent = scelte === 0 ? __( 'No modules selected', 'ds-core' ) : sprintf( _n( '%d module selected', '%d modules selected', scelte, 'ds-core' ), scelte );
		}
		if ( tuttiVisibili ) {
			statoCasella( tuttiVisibili, visibiliTutte );
		}
		sezioni.forEach( function ( sezione ) {
			var c = sezione.querySelector( '.ds-seleziona-tutti' );
			if ( c ) {
				statoCasella( c, visibiliTutte.filter( function ( riga ) {
					return sezione.contains( riga );
				} ) );
			}
		} );
		tutti( '.ds-blocco-azioni button' ).forEach( function ( pulsante ) {
			pulsante.disabled = scelte === 0;
		} );
		if ( barra ) {
			barra.classList.toggle( 'ds-blocco--attivo', scelte > 0 );
		}
		if ( annullaScelta ) {
			annullaScelta.hidden = scelte === 0;
		}
	}

	if ( tuttiVisibili ) {
		tuttiVisibili.addEventListener( 'change', function () {
			righe.filter( visibile ).forEach( function ( riga ) {
				casella( riga ).checked = tuttiVisibili.checked;
			} );
			aggiornaSelezione();
		} );
	}

	if ( annullaScelta ) {
		annullaScelta.addEventListener( 'click', function () {
			azzeraSelezione();
			aggiornaSelezione();
		} );
	}

	tutti( '.ds-seleziona-tutti' ).forEach( function ( c ) {
		c.addEventListener( 'change', function () {
			var sezione = c.closest( '.ds-categoria' );
			righe.filter( function ( riga ) {
				return sezione.contains( riga ) && visibile( riga );
			} ).forEach( function ( riga ) {
				casella( riga ).checked = c.checked;
			} );
			aggiornaSelezione();
		} );
	} );

	righe.forEach( function ( riga ) {
		var c = casella( riga );
		if ( c ) {
			c.addEventListener( 'change', aggiornaSelezione );
		}
	} );

	// Applica uno stato a più righe insieme (azioni in blocco e azioni di categoria): una richiesta, esito riga per riga.
	function eseguiBlocco( scelte, stato ) {
		var ids = scelte.map( function ( riga ) {
			return riga.getAttribute( 'data-ds-id' );
		} );
		scelte.forEach( function ( riga ) {
			inSalvataggio( riga, true );
		} );

		richiesta( { action: 'ds_core_blocco', stato: stato, ids: ids } )
			.then( function ( esito ) {
				scelte.forEach( function ( riga ) {
					inSalvataggio( riga, false );
					messaggioRiga( riga, '', '' );
				} );
				if ( ! esito || ! esito.success ) {
					mostra( testoErrore( esito ), true );
					return;
				}
				Object.keys( esito.data.righe ).forEach( function ( id ) {
					var riga = perId[ id ];
					var dati = esito.data.righe[ id ];
					if ( ! riga ) {
						return;
					}
					applicaRiga( riga, dati );
					aggiornaDettagli( id );
					if ( dati.errore ) {
						segnaErrore( riga, dati.errore );
					} else if ( dati.stato === 'dipendenze' ) {
						messaggioRiga( riga, dati.messaggio, 'avviso' );
					} else {
						casella( riga ).checked = false;
					}
				} );
				mostra( esito.data.messaggio, false );
				aggiornaConteggi();
				aggiornaSelezione();
			} )
			.catch( function () {
				scelte.forEach( function ( riga ) {
					inSalvataggio( riga, false );
					messaggioRiga( riga, '', '' );
				} );
				mostra( __( 'Not saved: network error. Reload the page and try again.', 'ds-core' ), true );
			} );
	}

	tutti( '.ds-blocco-azioni button' ).forEach( function ( pulsante ) {
		pulsante.addEventListener( 'click', function ( evento ) {
			evento.preventDefault();
			var scelte = sceltiVisibili();
			if ( ! scelte.length ) {
				mostra( __( 'Select at least one module.', 'ds-core' ), true );
				return;
			}
			eseguiBlocco( scelte, pulsante.value );
		} );
	} );

	/* ---------- Azioni su tutta la categoria ---------- */

	// Primo clic: al posto dei due pulsanti compare la domanda con il numero di moduli; secondo clic su «Conferma».
	// Esc o «Annulla» tornano indietro. Valgono per tutti i moduli della categoria, anche quelli nascosti dai filtri.
	sezioni.forEach( function ( sezione ) {
		var azioni = sezione.querySelector( '.ds-categoria-azioni' );
		var conferma = sezione.querySelector( '.ds-categoria-conferma' );
		if ( ! azioni || ! conferma ) {
			return;
		}
		var domanda = conferma.querySelector( '.ds-categoria-domanda' );
		var si = conferma.querySelector( '.ds-categoria-si' );
		var no = conferma.querySelector( '.ds-categoria-no' );
		var scelto = '';
		var origine = null;

		function chiudi( rimettiFuoco ) {
			conferma.hidden = true;
			azioni.hidden = false;
			scelto = '';
			if ( rimettiFuoco && origine ) {
				origine.focus();
			}
		}

		tutti( '.ds-categoria-azione', azioni ).forEach( function ( pulsante ) {
			pulsante.addEventListener( 'click', function () {
				scelto = pulsante.getAttribute( 'data-ds-categoria-azione' );
				origine = pulsante;
				domanda.textContent = pulsante.getAttribute( 'data-ds-domanda' );
				si.textContent = scelto === 'spento' ? __( 'Yes, turn off', 'ds-core' ) : __( 'Yes, turn on', 'ds-core' );
				azioni.hidden = true;
				conferma.hidden = false;
				si.focus();
			} );
		} );
		no.addEventListener( 'click', function () {
			chiudi( true );
		} );
		conferma.addEventListener( 'keydown', function ( evento ) {
			if ( evento.key === 'Escape' ) {
				chiudi( true );
			}
		} );
		si.addEventListener( 'click', function () {
			var stato = scelto;
			var righeCategoria = tutti( 'tr[data-ds-id]', sezione ).filter( function ( riga ) {
				return riga.getAttribute( 'data-ds-scelto' ) !== stato;
			} );
			chiudi( true );
			if ( righeCategoria.length ) {
				eseguiBlocco( righeCategoria, stato );
			}
		} );
	} );

	/* ---------- Aspetto ---------- */

	// La classe sul <body> cambia subito; se il salvataggio fallisce torna quella di prima.
	function applicaTema( tema ) {
		document.body.classList.remove( 'ds-tema-auto', 'ds-tema-chiaro', 'ds-tema-scuro' );
		document.body.classList.add( 'ds-tema-' + tema );
		tutti( '.ds-tema-scelta' ).forEach( function ( pulsante ) {
			pulsante.setAttribute( 'aria-pressed', pulsante.getAttribute( 'data-ds-tema' ) === tema ? 'true' : 'false' );
		} );
	}

	tutti( '.ds-tema-scelta' ).forEach( function ( pulsante ) {
		pulsante.addEventListener( 'click', function () {
			var corrente = pagina.querySelector( '.ds-tema-scelta[aria-pressed="true"]' );
			var prima = corrente ? corrente.getAttribute( 'data-ds-tema' ) : 'auto';
			var tema = pulsante.getAttribute( 'data-ds-tema' );
			if ( tema === prima ) {
				return;
			}
			applicaTema( tema );
			richiesta( { action: 'ds_core_tema', tema: tema } )
				.then( function ( esito ) {
					if ( ! esito || ! esito.success ) {
						applicaTema( prima );
						/* translators: %s: error message. */
						mostra( sprintf( __( 'Appearance not saved: %s', 'ds-core' ), testoErrore( esito ) ), true );
					}
				} )
				.catch( function () {
					applicaTema( prima );
					mostra( __( 'Appearance not saved: network error.', 'ds-core' ), true );
				} );
		} );
	} );

	/* ---------- Stato del modulo nella riga aperta, dopo un cambio ---------- */

	// La richiesta parte dopo il salvataggio dello stato: in quella richiesta il modulo appena acceso è già caricato e
	// le sue funzioni 'stato' e 'riepilogo' esistono.
	function aggiornaDettagli( id ) {
		var area = pagina.querySelector( '[data-ds-stato-area="' + id + '"]' );
		if ( ! area ) {
			return;
		}
		area.setAttribute( 'aria-busy', 'true' );
		richiesta( { action: 'ds_core_riga', id: id } )
			.then( function ( esito ) {
				area.removeAttribute( 'aria-busy' );
				if ( ! esito || ! esito.success ) {
					return;
				}
				// HTML preparato dal server (escape fatto in PHP), come al caricamento della pagina.
				area.innerHTML = esito.data.html;
				attivaCopia( area );
				sostituisciRiepilogo( id, esito.data.riepilogo );
				var conProblemi = esito.data.problemi > 0;
				var riga = perId[ id ];
				if ( riga ) {
					riga.classList.toggle( 'ds-riga--problema', conProblemi );
					var segno = riga.querySelector( '.ds-titolo-riga .ds-attenzione' );
					if ( segno ) {
						segno.hidden = ! conProblemi;
					}
				}
				var dettagli = document.getElementById( 'ds-impostazioni-' + id );
				if ( dettagli ) {
					dettagli.classList.toggle( 'ds-dettagli--problema', conProblemi );
					var spento = dettagli.querySelector( '.ds-salva-spento' );
					if ( spento ) {
						spento.hidden = esito.data.acceso;
					}
				}
			} )
			.catch( function () {
				area.removeAttribute( 'aria-busy' );
			} );
	}

	/* ---------- Scelte dei moduli e impostazioni generali ---------- */

	// Spunta come ds_core_icona( 'spunta' ): markup fisso, nessun dato esterno.
	var SPUNTA = '<svg class="ds-icona" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false"><path d="M3 8.5 6.5 12 13 4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

	function esitoForm( form, testo, tipo ) {
		var posto = form.querySelector( '.ds-salva-esito' );
		if ( ! posto ) {
			return;
		}
		posto.className = 'ds-salva-esito' + ( tipo ? ' ds-salva-esito--' + tipo : '' );
		posto.textContent = '';
		if ( ! testo ) {
			return;
		}
		if ( tipo === 'ok' ) {
			posto.innerHTML = SPUNTA;
		}
		var span = document.createElement( 'span' );
		span.textContent = testo;
		posto.appendChild( span );
	}

	function campiDi( form, chiave ) {
		return tutti( '[name="ds_campi[' + chiave + ']"], [name="ds_campi[' + chiave + '][]"]', form );
	}

	function mostraErrori( form, errori ) {
		var primo = null;
		tutti( '.ds-campo[data-ds-campo]', form ).forEach( function ( blocco ) {
			var chiave = blocco.getAttribute( 'data-ds-campo' );
			var testo = errori && errori[ chiave ] ? errori[ chiave ] : '';
			var posto = blocco.querySelector( '.ds-campo-errore' );
			blocco.classList.toggle( 'is-invalido', !! testo );
			if ( posto ) {
				posto.hidden = ! testo;
				var span = posto.querySelector( 'span' );
				if ( span ) {
					span.textContent = testo;
				}
			}
			campiDi( form, chiave ).forEach( function ( campo ) {
				if ( testo ) {
					campo.setAttribute( 'aria-invalid', 'true' );
				} else {
					campo.removeAttribute( 'aria-invalid' );
				}
			} );
			if ( testo && ! primo ) {
				primo = campiDi( form, chiave )[ 0 ] || null;
			}
		} );
		if ( primo ) {
			primo.focus();
		}
	}

	/* Colore e anteprima del contrasto (WCAG 2.x, soglia AA 4,5:1): stessa formula di includes/opzioni.php. */

	function rgb( hex ) {
		var n = parseInt( hex.slice( 1 ), 16 );
		return [ ( n >> 16 ) & 255, ( n >> 8 ) & 255, n & 255 ];
	}

	function hex( c ) {
		return '#' + c.map( function ( v ) {
			var s = Math.max( 0, Math.min( 255, Math.round( v ) ) ).toString( 16 );
			return s.length === 1 ? '0' + s : s;
		} ).join( '' );
	}

	function luminanza( colore ) {
		var c = rgb( colore ).map( function ( v ) {
			v /= 255;
			return v <= 0.03928 ? v / 12.92 : Math.pow( ( v + 0.055 ) / 1.055, 2.4 );
		} );
		return 0.2126 * c[ 0 ] + 0.7152 * c[ 1 ] + 0.0722 * c[ 2 ];
	}

	function contrasto( a, b ) {
		var x = luminanza( a );
		var y = luminanza( b );
		return ( Math.max( x, y ) + 0.05 ) / ( Math.min( x, y ) + 0.05 );
	}

	function mescola( colore, scuro, quota ) {
		var meta = scuro ? 0 : 255;
		return hex( rgb( colore ).map( function ( v ) {
			return v + ( meta - v ) * quota;
		} ) );
	}

	function leggibile( colore ) {
		var base = colore.toLowerCase();
		var testo = contrasto( base, '#ffffff' ) >= contrasto( base, '#1d2327' ) ? '#ffffff' : '#1d2327';
		var fondo = base;
		for ( var passo = 0; passo <= 20 && contrasto( fondo, testo ) < 4.5; passo++ ) {
			fondo = mescola( base, testo === '#ffffff', ( passo + 1 ) * 0.05 );
		}
		return { fondo: fondo, testo: testo, rapporto: Math.round( contrasto( fondo, testo ) * 10 ) / 10, cambiato: fondo !== base };
	}

	// Colore come testo su uno sfondo (link): più scuro o più chiaro finché arriva a 4,5:1 o a minimo (ds_core_colore_su()).
	function su( colore, sfondo, minimo ) {
		var base = colore.toLowerCase();
		var scuro = luminanza( sfondo ) > 0.18;
		var c = base;
		minimo = minimo || 4.5;
		for ( var passo = 0; passo <= 20 && contrasto( c, sfondo ) < minimo; passo++ ) {
			c = mescola( base, scuro, ( passo + 1 ) * 0.05 );
		}
		return c;
	}

	function numero( n ) {
		try {
			return n.toLocaleString( document.documentElement.lang || undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 } );
		} catch ( e ) {
			return n.toFixed( 1 );
		}
	}

	function aggiornaAnteprima( testo ) {
		var gruppoCampo = testo.closest( '.ds-campo-controllo' );
		var box = gruppoCampo ? gruppoCampo.querySelector( '[data-ds-anteprima]' ) : null;
		if ( ! box ) {
			return;
		}
		var pieno = /^#[0-9a-f]{6}$/i.test( testo.value );
		var valore = pieno ? testo.value : ( testo.value === '' ? box.getAttribute( 'data-ds-vuoto' ) || '' : '' );
		var campioni = box.querySelector( '.ds-anteprima-campioni' );
		var nota = box.querySelector( '.ds-anteprima-nota' );
		// Righe «da dove viene ogni colore» (0.18.1): quelle del design del sito con il campo vuoto, «scelto qui» con un colore.
		tutti( '[data-ds-se]', box ).forEach( function ( el ) {
			el.hidden = ( el.getAttribute( 'data-ds-se' ) === 'scelto' ) !== pieno;
		} );
		if ( ! /^#[0-9a-f]{6}$/i.test( valore ) ) {
			if ( campioni ) {
				campioni.hidden = true;
			}
			if ( nota ) {
				nota.textContent = testo.value === '' && box.getAttribute( 'data-ds-nota-vuoto' ) ? box.getAttribute( 'data-ds-nota-vuoto' ) : __( 'Choose a color to see the preview.', 'ds-core' );
			}
			return;
		}
		var l = leggibile( valore );
		if ( campioni ) {
			campioni.hidden = false;
			tutti( '.ds-anteprima-corrente, .ds-anteprima-pulsante', campioni ).forEach( function ( el ) {
				el.style.background = l.fondo;
				el.style.color = l.testo;
			} );
			var campioneLink = campioni.querySelector( '.ds-anteprima-link' );
			if ( campioneLink ) {
				var linkVuoto = box.getAttribute( 'data-ds-link-vuoto' ) || '';
				campioneLink.style.color = ! pieno && /^#[0-9a-f]{6}$/i.test( linkVuoto ) ? linkVuoto : su( valore, '#f0f0f1' );
			}
		}
		if ( nota ) {
			var nome = l.testo === '#ffffff' ? __( 'white', 'ds-core' ) : __( 'dark', 'ds-core' );
			nota.textContent = l.cambiato
				/* translators: 1: color chosen, 2: "white" or "dark", 3: contrast ratio, 4: color used instead. */
				? sprintf( __( 'With %1$s no text color is readable enough, so DS Core uses the shade %4$s with %2$s text: contrast %3$s:1 (readable).', 'ds-core' ), valore.toLowerCase(), nome, numero( l.rapporto ), l.fondo )
				/* translators: 1: "white" or "dark", 2: contrast ratio. */
				: sprintf( __( 'Text on this color: %1$s, contrast %2$s:1 (readable).', 'ds-core' ), nome, numero( l.rapporto ) );
		}
	}

	// Colore: il selettore del browser e il testo #rrggbb si seguono; il testo è il valore che si salva.
	function sincronizzaColore( testo ) {
		var gruppoColore = testo.closest ? testo.closest( '.ds-campo-colore' ) : null;
		var scelta = gruppoColore ? gruppoColore.querySelector( '.ds-campo-colore-scelta' ) : null;
		if ( scelta && /^#[0-9a-f]{6}$/i.test( testo.value ) ) {
			scelta.value = testo.value.toLowerCase();
		}
		aggiornaAnteprima( testo );
	}

	// Rimette nei campi i valori salvati e puliti dal server.
	function applicaValori( form, valori ) {
		Object.keys( valori || {} ).forEach( function ( chiave ) {
			var valore = valori[ chiave ];
			campiDi( form, chiave ).forEach( function ( campo ) {
				if ( campo.type === 'radio' ) {
					campo.checked = String( valore ) === campo.value;
				} else if ( campo.type === 'checkbox' ) {
					campo.checked = Array.isArray( valore ) ? valore.indexOf( campo.value ) !== -1 : !! valore;
				} else {
					campo.value = valore === null || valore === undefined ? '' : String( valore );
					if ( campo.closest( '.ds-campo-colore' ) ) {
						sincronizzaColore( campo );
					}
				}
			} );
		} );
	}

	tutti( '.ds-campo-colore' ).forEach( function ( gruppoColore ) {
		var scelta = gruppoColore.querySelector( '.ds-campo-colore-scelta' );
		var testo = gruppoColore.querySelector( 'input[type="text"]' );
		if ( ! scelta || ! testo ) {
			return;
		}
		// 0.18.2: anche 'change' (alcuni browser lo mandano solo alla chiusura del selettore): la modifica si vede subito.
		function daSelettore() {
			if ( testo.value.toLowerCase() === scelta.value.toLowerCase() ) {
				return;
			}
			testo.value = scelta.value;
			testo.dispatchEvent( new Event( 'input', { bubbles: true } ) );
		}
		scelta.addEventListener( 'input', daSelettore );
		scelta.addEventListener( 'change', daSelettore );
		testo.addEventListener( 'input', function () {
			sincronizzaColore( testo );
		} );
	} );

	tutti( 'form.ds-impostazioni' ).forEach( function ( form ) {
		var pulsante = form.querySelector( '.ds-salva-pulsante' );
		var id = form.getAttribute( 'data-ds-impostazioni' );

		function modificato() {
			if ( form.classList.contains( 'is-salvataggio' ) || form.classList.contains( 'is-ripristino' ) ) {
				return;
			}
			form.classList.add( 'is-modificato' );
			esitoForm( form, __( 'Unsaved changes', 'ds-core' ), 'modificato' );
			segnaNonSalvato( id );
			registraModifica( id );
		}
		form.addEventListener( 'input', modificato );
		form.addEventListener( 'change', modificato );

		function fine() {
			form.classList.remove( 'is-salvataggio' );
			if ( pulsante ) {
				pulsante.removeAttribute( 'aria-disabled' );
			}
		}

		form.addEventListener( 'submit', function ( evento ) {
			evento.preventDefault();
			if ( form.classList.contains( 'is-salvataggio' ) ) {
				return;
			}
			form.classList.add( 'is-salvataggio' );
			if ( pulsante ) {
				pulsante.setAttribute( 'aria-disabled', 'true' );
			}
			esitoForm( form, __( 'saving…', 'ds-core' ), 'attesa' );

			// FormData del modulo HTML: contiene già action=ds_core_impostazioni, l'ID e il nonce del modulo.
			fetch( dsCore.ajax, { method: 'POST', credentials: 'same-origin', body: new FormData( form ) } )
				.then( function ( risposta ) {
					return risposta.json().catch( function () {
						return null;
					} );
				} )
				.then( function ( esito ) {
					fine();
					if ( esito && esito.success && esito.data.ricarica ) {
						// Richiesta di cambio dell'indirizzo creata: la pagina nuova la mostra con il messaggio.
						form.classList.remove( 'is-modificato' );
						togliModifica( id );
						esitoForm( form, esito.data.messaggio, 'ok' );
						window.location.reload();
						return;
					}
					if ( esito && esito.success ) {
						form.classList.remove( 'is-modificato' );
						mostraErrori( form, {} );
						applicaValori( form, esito.data.valori );
						esitoForm( form, esito.data.messaggio, 'ok' );
						sostituisciRiepilogo( id, esito.data.riepilogo );
						segnaNonSalvato( id );
						fissaPredefiniti( form );
						/* translators: 1: module title, 2: message (e.g. "Settings saved."). */
						togliModifica( id, sprintf( __( '%1$s: %2$s', 'ds-core' ), nomeForm( id ), esito.data.messaggio ) );
						return;
					}
					var dati = esito && esito.data ? esito.data : null;
					mostraErrori( form, dati && dati.errori ? dati.errori : {} );
					esitoForm( form, testoErrore( esito ), 'errore' );
					/* translators: 1: module title, 2: error message. */
					aggiornaBarra( sprintf( __( '%1$s: %2$s', 'ds-core' ), nomeForm( id ), testoErrore( esito ) ) );
				} )
				.catch( function () {
					fine();
					esitoForm( form, __( 'Not saved: network error.', 'ds-core' ), 'errore' );
					/* translators: %s: module title. */
					aggiornaBarra( sprintf( __( '%s: not saved, network error.', 'ds-core' ), nomeForm( id ) ) );
				} );
		} );
	} );

	/* ---------- Modifiche non salvate: barra fissa in basso (0.18.2) ---------- */

	// Moduli HTML con modifiche non salvate, il più recente per ultimo.
	var nonSalvati = [];
	var barraSalva = null;
	var barraTesto = null;
	var barraTimer = null;

	function nomeForm( id ) {
		if ( id === 'ds-core' ) {
			return __( 'General settings', 'ds-core' );
		}
		return perId[ id ] ? titolo( perId[ id ] ) : id;
	}

	function creaBarra() {
		if ( barraSalva ) {
			return;
		}
		barraSalva = document.createElement( 'div' );
		barraSalva.className = 'ds-barra-salva';
		barraSalva.setAttribute( 'role', 'region' );
		barraSalva.setAttribute( 'aria-label', __( 'Unsaved changes', 'ds-core' ) );
		barraSalva.hidden = true;
		barraTesto = document.createElement( 'p' );
		barraTesto.className = 'ds-barra-salva-testo';
		barraTesto.setAttribute( 'role', 'status' );
		barraTesto.setAttribute( 'aria-live', 'polite' );
		var azioni = document.createElement( 'span' );
		azioni.className = 'ds-barra-salva-azioni';
		var vai = document.createElement( 'button' );
		vai.type = 'button';
		vai.className = 'button-link ds-barra-salva-vai';
		vai.textContent = __( 'Show', 'ds-core' );
		var annulla = document.createElement( 'button' );
		annulla.type = 'button';
		annulla.className = 'button ds-barra-salva-annulla';
		annulla.textContent = __( 'Discard', 'ds-core' );
		var salva = document.createElement( 'button' );
		salva.type = 'button';
		salva.className = 'button button-primary ds-barra-salva-salva';
		salva.textContent = __( 'Save changes', 'ds-core' );
		azioni.appendChild( vai );
		azioni.appendChild( annulla );
		azioni.appendChild( salva );
		barraSalva.appendChild( barraTesto );
		barraSalva.appendChild( azioni );
		pagina.appendChild( barraSalva );

		salva.addEventListener( 'click', function () {
			var id = nonSalvati[ nonSalvati.length - 1 ];
			var form = id ? formDi( id ) : null;
			if ( form ) {
				inviaForm( form );
			}
		} );
		annulla.addEventListener( 'click', function () {
			var id = nonSalvati[ nonSalvati.length - 1 ];
			var form = id ? formDi( id ) : null;
			if ( form ) {
				ripristinaForm( form );
				esitoForm( form, __( 'Changes discarded.', 'ds-core' ), '' );
				annunciaBarra( sprintf( /* translators: %s: module title. */ __( 'Changes in %s discarded.', 'ds-core' ), nomeForm( id ) ) );
			}
		} );
		vai.addEventListener( 'click', function () {
			var id = nonSalvati[ nonSalvati.length - 1 ];
			if ( id ) {
				vaiAlForm( id );
			}
		} );
	}

	// Porta in vista il modulo HTML (apre la riga o la scheda Settings) e mette il fuoco sul primo campo.
	function vaiAlForm( id ) {
		var form = formDi( id );
		if ( ! form ) {
			return;
		}
		if ( id === 'ds-core' ) {
			if ( vista.scheda !== 'settings' ) {
				vaiScheda( 'settings' );
			}
			var cambia = pagina.querySelector( '.ds-generale-aperto' );
			var pulsanteCambia = cambia ? pagina.querySelector( '.ds-cambia[aria-controls="' + cambia.id + '"]' ) : null;
			if ( cambia && cambia.hidden && pulsanteCambia ) {
				pulsanteCambia.click();
			}
		} else {
			mostraModulo( id );
		}
		var primo = form.querySelector( '.is-invalido input, .is-invalido select' ) || form.querySelector( '.ds-salva-pulsante' );
		scorriA( form );
		if ( primo ) {
			primo.focus( { preventScroll: true } );
		}
	}

	function aggiornaBarra( testo ) {
		creaBarra();
		window.clearTimeout( barraTimer );
		if ( ! nonSalvati.length ) {
			if ( testo ) {
				annunciaBarra( testo );
			} else {
				barraSalva.hidden = true;
				pagina.classList.remove( 'ds-con-barra-salva' );
			}
			return;
		}
		var ultimo = nonSalvati[ nonSalvati.length - 1 ];
		var altri = nonSalvati.length - 1;
		barraSalva.classList.remove( 'is-fatto' );
		tutti( '.ds-barra-salva-azioni button', barraSalva ).forEach( function ( b ) {
			b.hidden = false;
		} );
		barraTesto.textContent = testo || ( altri
			? sprintf( /* translators: 1: module title, 2: number of other modules. */ _n( 'Unsaved changes in %1$s and %2$d other module', 'Unsaved changes in %1$s and %2$d other modules', altri, 'ds-core' ), nomeForm( ultimo ), altri )
			: sprintf( /* translators: %s: module title. */ __( 'Unsaved changes in %s', 'ds-core' ), nomeForm( ultimo ) ) );
		barraSalva.hidden = false;
		pagina.classList.add( 'ds-con-barra-salva' );
	}

	// Messaggio breve nella barra senza modifiche in sospeso (dopo un salvataggio): sparisce da solo.
	function annunciaBarra( testo ) {
		creaBarra();
		if ( nonSalvati.length ) {
			aggiornaBarra();
			return;
		}
		barraTesto.textContent = testo;
		barraSalva.classList.add( 'is-fatto' );
		tutti( '.ds-barra-salva-azioni button', barraSalva ).forEach( function ( b ) {
			b.hidden = true;
		} );
		barraSalva.hidden = false;
		window.clearTimeout( barraTimer );
		barraTimer = window.setTimeout( function () {
			if ( ! nonSalvati.length ) {
				barraSalva.hidden = true;
				pagina.classList.remove( 'ds-con-barra-salva' );
			}
		}, 4000 );
	}

	function registraModifica( id ) {
		var posto = nonSalvati.indexOf( id );
		if ( posto !== -1 ) {
			nonSalvati.splice( posto, 1 );
		}
		nonSalvati.push( id );
		aggiornaBarra();
	}

	function togliModifica( id, testo ) {
		var posto = nonSalvati.indexOf( id );
		if ( posto !== -1 ) {
			nonSalvati.splice( posto, 1 );
		}
		aggiornaBarra( testo );
	}

	// Cambiando scheda le modifiche restano nei campi (la pagina non si ricarica): la barra lo ricorda.
	function avvisaNonSalvati() {
		if ( ! nonSalvati || ! nonSalvati.length || ! barraTesto ) {
			return;
		}
		var ultimo = nonSalvati[ nonSalvati.length - 1 ];
		aggiornaBarra( sprintf( /* translators: %s: module title. */ __( 'Changes in %s are not saved yet: they stay here until you save or discard them.', 'ds-core' ), nomeForm( ultimo ) ) );
		barraSalva.classList.remove( 'is-richiamo' );
		void barraSalva.offsetWidth; // riavvia l'animazione
		barraSalva.classList.add( 'is-richiamo' );
	}

	// Uscendo dalla pagina con modifiche non salvate il browser chiede conferma (testo del browser).
	window.addEventListener( 'beforeunload', function ( evento ) {
		if ( nonSalvati.length ) {
			evento.preventDefault();
			evento.returnValue = '';
		}
	} );

	// Valori attuali come «predefiniti» del modulo HTML: «Discard» (form.reset()) torna all'ultimo salvataggio.
	function fissaPredefiniti( form ) {
		tutti( 'input, select, textarea', form ).forEach( function ( campo ) {
			if ( campo.type === 'checkbox' || campo.type === 'radio' ) {
				campo.defaultChecked = campo.checked;
			} else if ( campo.tagName === 'SELECT' ) {
				Array.prototype.forEach.call( campo.options, function ( o ) {
					o.defaultSelected = o.selected;
				} );
			} else if ( campo.type !== 'hidden' && campo.type !== 'submit' ) {
				campo.defaultValue = campo.value;
			}
		} );
	}

	// «Discard»: valori dell'ultimo salvataggio, anteprime e campi dipendenti ridisegnati, nessuna modifica in sospeso.
	function ripristinaForm( form ) {
		var id = form.getAttribute( 'data-ds-impostazioni' );
		form.classList.add( 'is-ripristino' );
		form.reset();
		tutti( 'input[name], select[name]', form ).forEach( function ( campo ) {
			campo.dispatchEvent( new Event( campo.type === 'text' ? 'input' : 'change', { bubbles: true } ) );
		} );
		form.classList.remove( 'is-ripristino', 'is-modificato' );
		mostraErrori( form, {} );
		segnaNonSalvato( id );
		togliModifica( id );
	}

	// Invia il modulo come il pulsante «Save settings» (stesso gestore, stessi controlli del browser saltati: novalidate).
	function inviaForm( form ) {
		if ( typeof form.requestSubmit === 'function' ) {
			form.requestSubmit();
		} else {
			form.dispatchEvent( new Event( 'submit', { bubbles: true, cancelable: true } ) );
		}
	}

	/* ---------- admin-branding: schemi proposti, colori personalizzati, anteprima dal vivo (0.18.2) ---------- */

	var abBox = pagina.querySelector( '[data-ds-ab]' );
	var abForm = abBox ? abBox.closest( 'form' ) : null;
	var abDati = null;
	if ( abBox && abForm ) {
		try {
			abDati = JSON.parse( abBox.getAttribute( 'data-ds-ab' ) );
		} catch ( e ) {
			abDati = null;
		}
	}
	var AB_RUOLI = [ 'menu', 'menu_testo', 'accento', 'notifiche', 'link', 'sottomenu', 'barra' ];
	var AB_WP = { menu: '#1d2327', menu_testo: '#f0f0f1', accento: '#2271b1', notifiche: '#d63638', link: '#2271b1', sottomenu: '#2c3338', barra: '#1d2327' };
	var ATTENZIONE = '<svg class="ds-icona" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false"><path d="M8 1.9 14.6 13.6H1.4z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 6.2v3.4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="8" cy="11.6" r=".8" fill="currentColor"/></svg>';

	// #rgb o #rrggbb → #rrggbb minuscolo; '' se non è un colore.
	function hexPieno( v ) {
		v = String( v || '' ).trim().toLowerCase();
		if ( /^#[0-9a-f]{3}$/.test( v ) ) {
			return '#' + v[ 1 ] + v[ 1 ] + v[ 2 ] + v[ 2 ] + v[ 3 ] + v[ 3 ];
		}
		return /^#[0-9a-f]{6}$/.test( v ) ? v : '';
	}

	// Mescola due colori: quota 0 = a, 1 = b (ds_core_colore_verso()).
	function verso( a, b, quota ) {
		var x = rgb( a );
		var y = rgb( b );
		return hex( x.map( function ( v, i ) {
			return v + ( y[ i ] - v ) * quota;
		} ) );
	}

	// Stessa logica di ds_core_ab_calcola() in includes/opzioni.php.
	function calcolaSchema( base, scelti ) {
		function v( ruolo ) {
			return scelti[ ruolo ] || hexPieno( base[ ruolo ] );
		}
		function migliore( fondo ) {
			return contrasto( fondo, '#f0f0f1' ) >= contrasto( fondo, '#1d2327' ) ? '#f0f0f1' : '#1d2327';
		}
		var menu = v( 'menu' ) || AB_WP.menu;
		var scuro = luminanza( menu ) < 0.18;
		var sottomenu = v( 'sottomenu' ) || mescola( menu, ! scuro, scuro ? 0.07 : 0.05 );
		var barra = v( 'barra' ) || menu;
		var testoVol = v( 'menu_testo' ) || migliore( menu );
		var menuTesto = su( testoVol, menu );
		var sottoTesto = su( menuTesto, sottomenu );
		var barraTesto = su( v( 'menu_testo' ) ? testoVol : migliore( barra ), barra );
		var icona = su( verso( menuTesto, menu, 0.3 ), menu, 3 );
		var iconaBarra = su( verso( barraTesto, barra, 0.3 ), barra, 3 );
		var accVol = v( 'accento' );
		var accBase = accVol || AB_WP.accento;
		var acc = leggibile( su( accBase, menu, 3 ) );
		var suSotto = su( accBase, sottomenu );
		var notVol = v( 'notifiche' ) || accBase;
		var not = leggibile( su( notVol, menu, 3 ) );
		var linkVol = v( 'link' ) || accBase;
		var link = su( linkVol, '#f0f0f1' );
		var puls = leggibile( su( linkVol, '#f0f0f1', 3 ) );
		function ruolo( h, voluto, chiave ) {
			return { hex: h, voluto: voluto, scelto: scelti[ chiave ] || '', corretto: voluto !== '' && h !== voluto };
		}
		function tondo( x ) {
			return Math.round( x * 10 ) / 10;
		}
		var bianco = function ( t ) {
			return t === '#ffffff';
		};
		return {
			ruoli: {
				menu: ruolo( menu, menu, 'menu' ),
				menu_testo: ruolo( menuTesto, testoVol, 'menu_testo' ),
				accento: ruolo( acc.fondo, accVol, 'accento' ),
				notifiche: ruolo( not.fondo, notVol, 'notifiche' ),
				link: ruolo( link, linkVol, 'link' ),
				sottomenu: ruolo( sottomenu, sottomenu, 'sottomenu' ),
				barra: ruolo( barra, barra, 'barra' )
			},
			css: {
				menu: menu, 'menu-testo': menuTesto, 'menu-icona': icona, sotto: sottomenu, 'sotto-testo': sottoTesto,
				barra: barra, 'barra-testo': barraTesto, 'barra-icona': iconaBarra, fondo: acc.fondo, testo: acc.testo,
				'fondo-10': mescola( acc.fondo, bianco( acc.testo ), 0.1 ), 'su-sotto': suSotto, 'su-barra': suSotto,
				badge: not.fondo, 'badge-testo': not.testo, link: link, 'link-10': mescola( link, true, 0.15 ),
				pulsante: puls.fondo, 'pulsante-testo': puls.testo,
				'pulsante-10': mescola( puls.fondo, bianco( puls.testo ), 0.1 ), 'pulsante-20': mescola( puls.fondo, bianco( puls.testo ), 0.2 )
			},
			contrasti: {
				menu: tondo( contrasto( menuTesto, menu ) ), sottomenu: tondo( contrasto( sottoTesto, sottomenu ) ),
				barra: tondo( contrasto( barraTesto, barra ) ), accento: acc.rapporto, accento_menu: tondo( contrasto( acc.fondo, menu ) ),
				notifiche: not.rapporto, link: tondo( contrasto( link, '#f0f0f1' ) ), pulsante: puls.rapporto
			}
		};
	}

	function abSchemaScelto() {
		var scelto = abForm.querySelector( 'input[name="ds_campi[schema]"]:checked' );
		var codice = scelto ? scelto.value : 'sito';
		return abDati.schemi[ codice ] ? codice : 'sito';
	}

	function abTesto( ruolo ) {
		return abForm.querySelector( 'input[type="text"][name="ds_campi[' + ruolo + ']"]' );
	}

	// Come ds_core_ab_risolvi(): schema scelto, colori personalizzati, origine di ogni colore.
	function risolviSchema() {
		var codice = abSchemaScelto();
		var schema = abDati.schemi[ codice ];
		var scelti = {};
		if ( codice !== 'wordpress' ) {
			AB_RUOLI.forEach( function ( r ) {
				var campo = abTesto( r );
				scelti[ r ] = campo ? hexPieno( campo.value ) : '';
			} );
		}
		var calc = calcolaSchema( schema.colori, scelti );
		calc.schema = codice;
		calc.attivo = codice !== 'wordpress' && calc.ruoli.accento.voluto !== '';
		AB_RUOLI.forEach( function ( r ) {
			var dato = calc.ruoli[ r ];
			if ( dato.scelto ) {
				dato.origine = __( 'chosen here', 'ds-core' );
			} else if ( hexPieno( schema.colori[ r ] ) ) {
				dato.origine = schema.origini[ r ] || '';
			} else {
				dato.origine = r === 'notifiche' || r === 'link' ? __( 'derived from the highlight', 'ds-core' ) : __( 'derived from the menu background', 'ds-core' );
			}
		} );
		return calc;
	}

	// Testo del contrasto di un colore: stessi testi e soglie di ds_core_ab_contrasto_testo().
	function contrastoRuolo( r, c ) {
		var n = numero;
		switch ( r ) {
			case 'menu':
				/* translators: %s: contrast ratio. */
				return [ sprintf( __( 'menu text on it %s:1', 'ds-core' ), n( c.menu ) ), c.menu >= 4.5 ];
			case 'menu_testo':
				/* translators: %s: contrast ratio. */
				return [ sprintf( __( 'on the menu %s:1', 'ds-core' ), n( c.menu ) ), c.menu >= 4.5 ];
			case 'sottomenu':
				/* translators: %s: contrast ratio. */
				return [ sprintf( __( 'submenu text on it %s:1', 'ds-core' ), n( c.sottomenu ) ), c.sottomenu >= 4.5 ];
			case 'barra':
				/* translators: %s: contrast ratio. */
				return [ sprintf( __( 'top bar text on it %s:1', 'ds-core' ), n( c.barra ) ), c.barra >= 4.5 ];
			case 'accento':
				/* translators: 1: contrast ratio of the text, 2: contrast ratio against the menu. */
				return [ sprintf( __( 'text on it %1$s:1, against the menu %2$s:1', 'ds-core' ), n( c.accento ), n( c.accento_menu ) ), c.accento >= 4.5 && c.accento_menu >= 3 ];
			case 'notifiche':
				/* translators: %s: contrast ratio. */
				return [ sprintf( __( 'text on it %s:1', 'ds-core' ), n( c.notifiche ) ), c.notifiche >= 4.5 ];
			case 'link':
				/* translators: 1: contrast ratio of links, 2: contrast ratio of the button text. */
				return [ sprintf( __( 'on the dashboard background %1$s:1, button text %2$s:1', 'ds-core' ), n( c.link ), n( c.pulsante ) ), c.link >= 4.5 && c.pulsante >= 4.5 ];
		}
		return [ '', true ];
	}

	function span( classe, testo ) {
		var el = document.createElement( 'span' );
		el.className = classe;
		if ( testo !== undefined ) {
			el.textContent = testo;
		}
		return el;
	}

	// Riga sotto il campo di un colore (come ds_core_ab_info_html()).
	function abInfo( r, calc ) {
		var riga = abForm.querySelector( '[data-ds-ab-info="' + r + '"]' );
		if ( ! riga ) {
			return;
		}
		var dato = calc.ruoli[ r ];
		var senza = r === 'accento' && dato.voluto === '';
		riga.textContent = '';
		var campione = span( 'ds-ab-campione' );
		campione.setAttribute( 'aria-hidden', 'true' );
		campione.style.background = senza ? 'transparent' : dato.hex;
		riga.appendChild( campione );
		var datoEl = span( 'ds-ab-dato' );
		datoEl.appendChild( span( 'ds-ab-valore', senza ? '—' : dato.hex ) );
		datoEl.appendChild( document.createTextNode( ' ' ) );
		datoEl.appendChild( span( 'ds-ab-origine', senza ? __( 'no colored highlight found in Breakdance', 'ds-core' ) : dato.origine ) );
		riga.appendChild( datoEl );
		if ( senza ) {
			return;
		}
		var esito = contrastoRuolo( r, calc.contrasti );
		var c = span( 'ds-ab-contrasto ' + ( esito[ 1 ] ? 'is-ok' : 'is-basso' ) );
		c.innerHTML = esito[ 1 ] ? SPUNTA : ATTENZIONE;
		c.appendChild( span( '', esito[ 0 ] + ' · ' + ( esito[ 1 ] ? __( 'readable (AA)', 'ds-core' ) : __( 'low contrast', 'ds-core' ) ) ) );
		riga.appendChild( c );
		if ( dato.corretto ) {
			/* translators: 1: color chosen, 2: color used instead. */
			riga.appendChild( span( 'ds-ab-corretto', sprintf( __( 'Adjusted from %1$s to %2$s to stay readable.', 'ds-core' ), dato.voluto, dato.hex ) ) );
		}
	}

	function abStato( calc ) {
		if ( calc.schema === 'wordpress' ) {
			return __( 'WordPress default: no colors applied, each user keeps their own scheme.', 'ds-core' );
		}
		if ( ! calc.attivo ) {
			return __( 'No highlight color yet: no scheme is applied. Choose a highlight color below.', 'ds-core' );
		}
		var nome = abDati.schemi[ calc.schema ].nome;
		var propri = abForm.querySelector( 'input[name="ds_campi[propri]"]' );
		return propri && propri.checked
			/* translators: %s: name of the color scheme. */
			? sprintf( __( '“%s” applies to users who did not choose another scheme in their profile.', 'ds-core' ), nome )
			/* translators: %s: name of the color scheme. */
			: sprintf( __( '“%s” applies to the whole dashboard for every user.', 'ds-core' ), nome );
	}

	// Ridisegna anteprima, righe dei colori, segnaposti e selettori secondo lo schema e i colori scelti.
	function abAggiorna() {
		if ( ! abDati ) {
			return;
		}
		var calc = risolviSchema();
		var finto = abBox.querySelector( '.ds-ab-finto' );
		var css = calc.attivo ? calc.css : calcolaSchema( AB_WP, {} ).css;
		if ( finto ) {
			Object.keys( css ).forEach( function ( k ) {
				finto.style.setProperty( '--ab-' + k, css[ k ] );
			} );
			finto.classList.toggle( 'is-wordpress', ! calc.attivo );
		}
		var stato = abBox.querySelector( '.ds-ab-stato' );
		var frase = abStato( calc );
		if ( stato && stato.textContent !== frase ) {
			stato.textContent = frase;
		}
		var base = abDati.schemi[ calc.schema ].colori;
		AB_RUOLI.forEach( function ( r ) {
			abInfo( r, calc );
			var campo = abTesto( r );
			if ( ! campo ) {
				return;
			}
			var vuoto = hexPieno( base[ r ] ) || ( r === 'accento' ? '' : calc.ruoli[ r ].hex );
			campo.placeholder = vuoto || '#rrggbb';
			var gruppo = campo.closest( '.ds-campo-colore' );
			var scelta = gruppo ? gruppo.querySelector( '.ds-campo-colore-scelta' ) : null;
			if ( scelta && vuoto && ! hexPieno( campo.value ) ) {
				scelta.value = vuoto;
			}
			var svuota = gruppo ? gruppo.querySelector( '[data-ds-svuota]' ) : null;
			if ( svuota ) {
				svuota.hidden = campo.value === '';
			}
			var blocco = campo.closest( '.ds-campo' );
			if ( blocco ) {
				blocco.classList.toggle( 'is-inattivo', calc.schema === 'wordpress' );
			}
		} );
	}

	if ( abDati ) {
		abForm.addEventListener( 'input', abAggiorna );
		abForm.addEventListener( 'change', abAggiorna );
	}

	// «Use the scheme color»: svuota il campo (vale il colore dello schema) e lo segna come modifica.
	tutti( '[data-ds-svuota]' ).forEach( function ( pulsante ) {
		pulsante.addEventListener( 'click', function () {
			var campo = document.getElementById( pulsante.getAttribute( 'data-ds-svuota' ) );
			if ( ! campo ) {
				return;
			}
			campo.value = '';
			campo.dispatchEvent( new Event( 'input', { bubbles: true } ) );
			campo.focus();
		} );
	} );

	/* ---------- Campi che dipendono da un altro campo ---------- */

	tutti( '.ds-campo[data-ds-mostra-se]' ).forEach( function ( blocco ) {
		var form = blocco.closest( 'form' );
		var chiave = blocco.getAttribute( 'data-ds-mostra-se' );
		var valore = blocco.getAttribute( 'data-ds-mostra-valore' );
		if ( ! form ) {
			return;
		}
		function aggiorna() {
			var scelto = campiDi( form, chiave ).filter( function ( campo ) {
				return ( campo.type !== 'radio' && campo.type !== 'checkbox' ) || campo.checked;
			} )[ 0 ];
			var visto = !! scelto && scelto.value === valore;
			blocco.hidden = ! visto;
			// Nascosto = non si manda: il server tiene il numero effettivo.
			tutti( 'input, select, textarea', blocco ).forEach( function ( campo ) {
				campo.disabled = ! visto;
			} );
		}
		campiDi( form, chiave ).forEach( function ( campo ) {
			campo.addEventListener( 'change', aggiorna );
		} );
		aggiorna();
	} );

	/* ---------- Copia (righe per wp-config.php, nome tecnico dei moduli) ---------- */

	function attivaCopia( base ) {
		tutti( '[data-ds-copia]', base ).forEach( function ( pulsante ) {
			if ( pulsante.getAttribute( 'data-ds-copia-pronto' ) ) {
				return;
			}
			var sorgente = document.getElementById( pulsante.getAttribute( 'data-ds-copia' ) );
			var esito = pulsante.parentNode.querySelector( '.ds-copia-esito' );
			if ( ! sorgente ) {
				return;
			}
			pulsante.setAttribute( 'data-ds-copia-pronto', '1' );
			pulsante.hidden = false;
			function scrivi( testo, errore ) {
				if ( esito ) {
					esito.textContent = testo;
					esito.classList.toggle( 'is-errore', !! errore );
				}
			}
			function seleziona() {
				var intervallo = document.createRange();
				intervallo.selectNodeContents( sorgente );
				var selezione = window.getSelection();
				selezione.removeAllRanges();
				selezione.addRange( intervallo );
			}
			pulsante.addEventListener( 'click', function () {
				var testo = sorgente.textContent;
				if ( navigator.clipboard && window.isSecureContext ) {
					navigator.clipboard.writeText( testo ).then( function () {
						scrivi( __( 'Copied.', 'ds-core' ) );
					}, function () {
						seleziona();
						scrivi( __( 'Selected: press Ctrl+C to copy.', 'ds-core' ), true );
					} );
					return;
				}
				seleziona();
				scrivi( __( 'Selected: press Ctrl+C to copy.', 'ds-core' ), true );
			} );
		} );
	}
	attivaCopia( pagina );

	/* ---------- Righe aperte ---------- */

	// Solo per la sessione del browser (0.18.0): una visita nuova parte compatta. sessionStorage può mancare o dare
	// errore (navigazione privata, dati bloccati): allora non si ricorda nulla.
	var CHIAVE_APERTI = 'ds-core-aperti-sessione';
	try {
		window.localStorage.removeItem( 'ds-core-aperti' ); // ricordo per sempre delle versioni fino alla 0.17.x
	} catch ( e ) {
		// Niente da togliere.
	}

	function apertiSalvati() {
		try {
			var valore = JSON.parse( window.sessionStorage.getItem( CHIAVE_APERTI ) || '[]' );
			return Array.isArray( valore ) ? valore : [];
		} catch ( e ) {
			return [];
		}
	}

	function ricordaAperto( id, aperto ) {
		var elenco = apertiSalvati().filter( function ( voce ) {
			return voce !== id;
		} );
		if ( aperto ) {
			elenco.push( id );
		}
		try {
			window.sessionStorage.setItem( CHIAVE_APERTI, JSON.stringify( elenco ) );
		} catch ( e ) {
			// Niente da fare: la riga resta aperta solo fino alla ricarica.
		}
	}

	function pulsanteDi( id ) {
		return document.getElementById( 'ds-apri-' + id );
	}

	var chiudiTutti = pagina.querySelector( '.ds-chiudi-tutti' );

	function aggiornaChiudiTutti() {
		if ( chiudiTutti ) {
			chiudiTutti.hidden = ! pagina.querySelector( 'tr.ds-dettagli:not([hidden])' );
		}
	}

	function impostaAperto( id, aperto, ricorda ) {
		var pulsante = pulsanteDi( id );
		var dettagli = document.getElementById( 'ds-impostazioni-' + id );
		if ( ! pulsante || ! dettagli ) {
			return false;
		}
		pulsante.setAttribute( 'aria-expanded', aperto ? 'true' : 'false' );
		dettagli.hidden = ! aperto;
		if ( perId[ id ] ) {
			perId[ id ].classList.toggle( 'is-aperto', aperto );
		}
		if ( ricorda ) {
			ricordaAperto( id, aperto );
		}
		aggiornaChiudiTutti();
		return true;
	}

	function scorriA( elemento ) {
		var calmo = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		elemento.scrollIntoView( { behavior: calmo ? 'auto' : 'smooth', block: 'start' } );
	}

	// Apre la riga di un modulo (avviso in cima, indirizzo): sceglie la scheda che lo mostra, toglie i filtri se lo
	// nascondono, lo porta in vista e mette il fuoco sul suo pulsante, così chi usa la tastiera continua da lì.
	function mostraModulo( id ) {
		var riga = perId[ id ];
		if ( ! riga || ! pulsanteDi( id ) ) {
			return false;
		}
		var categoria = riga.getAttribute( 'data-ds-categoria-riga' );
		if ( vista.scheda !== 'all' && vista.scheda !== categoria ) {
			vaiScheda( vista.scheda === 'settings' || vista.scheda === 'help' ? 'all' : categoria );
		}
		if ( ! visibile( riga ) ) {
			togliFiltri();
		}
		impostaAperto( id, true, true );
		scorriA( riga );
		pulsanteDi( id ).focus( { preventScroll: true } );
		return true;
	}

	tutti( '.ds-apri' ).forEach( function ( pulsante ) {
		var id = pulsante.id.replace( /^ds-apri-/, '' );
		function cambiaRiga( evento ) {
			evento.preventDefault();
			impostaAperto( id, pulsante.getAttribute( 'aria-expanded' ) !== 'true', true );
		}
		pulsante.addEventListener( 'click', cambiaRiga );
		// È un link con role="button": anche la barra spaziatrice.
		pulsante.addEventListener( 'keydown', function ( evento ) {
			if ( evento.key === ' ' ) {
				cambiaRiga( evento );
			}
		} );
	} );

	if ( chiudiTutti ) {
		chiudiTutti.addEventListener( 'click', function () {
			righe.forEach( function ( riga ) {
				impostaAperto( riga.getAttribute( 'data-ds-id' ), false, true );
			} );
		} );
	}

	tutti( '[data-ds-apri]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function ( evento ) {
			if ( mostraModulo( link.getAttribute( 'data-ds-apri' ) ) ) {
				evento.preventDefault();
			}
		} );
	} );

	/* ---------- Impostazioni generali: «Change» ---------- */

	tutti( '.ds-cambia' ).forEach( function ( pulsante ) {
		var parte = document.getElementById( pulsante.getAttribute( 'aria-controls' ) );
		if ( ! parte ) {
			return;
		}
		function cambiaParte( evento ) {
			evento.preventDefault();
			var apri = parte.hidden;
			parte.hidden = ! apri;
			pulsante.setAttribute( 'aria-expanded', apri ? 'true' : 'false' );
			var gruppoRiga = pulsante.closest( '.ds-generale' );
			if ( gruppoRiga ) {
				gruppoRiga.classList.toggle( 'is-aperto', apri );
			}
			if ( apri ) {
				var primo = parte.querySelector( 'input:not([type="hidden"]):not([readonly]), select, textarea' );
				if ( primo ) {
					primo.focus();
				}
			}
		}
		pulsante.addEventListener( 'click', cambiaParte );
		pulsante.addEventListener( 'keydown', function ( evento ) {
			if ( evento.key === ' ' ) {
				cambiaParte( evento );
			}
		} );
	} );

	/* ---------- Avvio ---------- */

	apertiSalvati().forEach( function ( id ) {
		impostaAperto( id, true, false );
	} );
	tutti( 'tr.ds-dettagli:not([hidden])' ).forEach( function ( dettagli ) {
		var id = dettagli.getAttribute( 'data-ds-dettagli' );
		impostaAperto( id, true, false );
	} );

	// Indirizzo con il cancelletto: riga di un modulo, impostazioni generali, emergenza nell'aiuto.
	var cancelletto = window.location.hash;
	var dallIndirizzo = /^#ds-impostazioni-([a-z0-9_-]+)$/.exec( cancelletto );
	if ( dallIndirizzo ) {
		mostraModulo( dallIndirizzo[ 1 ] );
	} else if ( cancelletto === '#ds-generali' && vista.scheda !== 'settings' ) {
		vaiScheda( 'settings' );
	} else if ( cancelletto === '#ds-emergenza' && vista.scheda !== 'help' ) {
		vaiScheda( 'help' );
	}

	aggiornaSottomenu( vista.scheda );
	tutti( '.ds-campo-colore input[type="text"]' ).forEach( aggiornaAnteprima );
	abAggiorna();
	tutti( 'form.ds-impostazioni' ).forEach( fissaPredefiniti );
	filtra();
	aggiornaChiudiTutti();
}() );

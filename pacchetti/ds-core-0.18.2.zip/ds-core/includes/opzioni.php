<?php
/**
 * Opzioni dei moduli e di DS Core (dalla 0.13.0). Caricato sempre, anche sul sito pubblico: poche funzioni, nessun
 * disegno. Il disegno e il salvataggio dei campi stanno in includes/impostazioni.php (solo amministrazione).
 *
 * Un modulo dichiara le sue scelte nel registro (includes/registro.php) con 'opzione' (nome dell'opzione nel
 * database) e 'campi' (elenco dei campi: tipo, predefinito, limiti, valori ammessi). DS Core le mostra e le salva
 * anche a modulo spento, senza eseguire codice del modulo; il modulo acceso le legge con:
 *
 *   $valori = ds_core_opzioni_modulo( 'my-module' );   // valori salvati, puliti, con i predefiniti
 *
 * Le scelte di DS Core stesso (l'indirizzo degli avvisi; il canale dell'aggiornatore, nascosto) sono il gruppo
 * riservato 'ds-core', opzione ds_core_generali: ds_core_opzioni_modulo( 'ds-core' ); l'indirizzo degli avvisi si
 * legge con ds_core_indirizzo_avvisi() (includes/avvisi.php, dalla 0.15.0 con la conferma del cambio).
 *
 * Tipi di campo (ds_core_tipi_campo()) e chiavi di ogni campo:
 * - tipo         text, email, url (solo https, dalla 0.16.0), number, checkbox, radio, select, checkboxes, plugins, color,
 *                schemi (dalla 0.18.2: scelta a griglia di riquadri con nome e strisce di colore; si controlla come radio)
 * - predefinito  valore quando il campo non è mai stato salvato (o il valore salvato non è valido)
 * - predefinito_da  facoltativo: funzione (nome o closure) che calcola il predefinito. Deve esistere anche a modulo
 *                spento, quindi sta nel file principale del plugin, non nel file del modulo
 * - min, max     number: limiti (i valori fuori si riconducono al limite); passo: 1 = numeri interi (predefinito)
 * - scelte       radio, select, checkboxes, schemi: valori ammessi (array di chiavi); i nomi visibili stanno nei testi
 * - lunghezza    text: lunghezza massima (predefinita 200)
 * - gruppo       facoltativo: chiave del gruppo, per un titolo sopra i campi dello stesso gruppo (testi 'gruppi')
 * - mostra_se    facoltativo: array( chiave di un altro campo, valore ): il campo si mostra solo con quel valore
 *                (JavaScript); senza JavaScript resta visibile e conta il modulo, che lo ignora con l'altro valore
 * - nascosto     facoltativo (dalla 0.16.1): true = il campo non si mostra e non si cambia dal pannello; il valore
 *                salvato resta com'è a ogni salvataggio (si legge come gli altri con ds_core_opzioni_modulo())
 * - contrasto    facoltativo, solo color (dalla 0.18.0): true = sotto il campo l'anteprima del colore con il testo
 *                scelto per il contrasto (ds_core_colore_leggibile())
 *
 * I testi (etichetta, aiuto, unità, nomi delle scelte, titoli dei gruppi) stanno nella funzione 'testi' del modulo,
 * come titolo e descrizione, perché si traducono solo dopo init:
 *
 *   'campi'  => array( 'chiave' => array( 'etichetta' => …, 'aiuto' => …, 'unita' => …, 'scelte' => array( valore => nome ),
 *                                        'testo' => frase accanto a una casella (checkbox),
 *                                        'breve' => testo corto per il riepilogo della riga (0.18.0, includes/impostazioni.php),
 *                                        'vuoto' => colore usato quando un campo color è vuoto (anteprima),
 *                                        'anteprima' => righe e frasi in più dell'anteprima (0.18.1, ds_core_anteprima_colore_html()),
 *                                        'schede' => riquadri del tipo schemi (0.18.2): valore => array( 'nome', 'sotto',
 *                                                    'strisce' => colori #rrggbb, 'nascosto' => true se non disponibile ),
 *                                        'dopo_html' => HTML già escapato sotto il campo, solo da DS Core ) ),
 *   'accanto_html' => HTML già escapato accanto ai campi (0.18.2, colonna a destra; anteprima di admin-branding), solo da DS Core,
 *   'gruppi' => array( 'gruppo' => titolo ),
 *
 * Salvare non applica niente da solo: DS Core lancia l'azione 'ds_core_impostazioni_salvate' ( $id, $prima, $dopo )
 * e il modulo, se è acceso, la ascolta e applica.
 */

defined( 'ABSPATH' ) || exit;

/** Tipi di campo che DS Core sa disegnare, controllare e salvare. */
function ds_core_tipi_campo() {
	return array( 'text', 'email', 'url', 'number', 'checkbox', 'radio', 'select', 'checkboxes', 'plugins', 'color', 'schemi' );
}

/** Opzioni di DS Core che nessun modulo può usare per le sue scelte. */
function ds_core_opzioni_riservate() {
	return array( 'ds_core_stati', 'ds_core_errori', 'ds_core_storia', 'ds_core_generali', 'ds_core_db', 'ds_core_accesso_fino', 'ds_core_accesso_nonce', 'ds_core_ra_db', 'ds_core_avvisi_attesa', 'ds_core_emergenza_vista', 'ds_core_rilasci_offerta', 'ds_core_rilasci_stato' );
}

/** Campi delle impostazioni generali di DS Core (gruppo 'ds-core'). */
function ds_core_campi_generali() {
	return array(
		// Indirizzo confermato: si cambia solo con la conferma dal nuovo indirizzo (includes/avvisi.php).
		'avvisi'      => array(
			'tipo'        => 'email',
			'predefinito' => '',
		),
		'anche_admin' => array(
			'tipo'        => 'checkbox',
			'predefinito' => false,
		),
		/*
		 * Canale dell'aggiornatore firmato (includes/aggiornatore.php). Dalla 0.16.1 non si mostra e non si cambia dal
		 * pannello ('nascosto'): resta nello schema solo perché il valore 'test' salvato con la 0.16.0 continui a
		 * valere e non si perda quando si salvano le impostazioni generali. Il canale si sceglie con DS_CORE_CANALE in
		 * wp-config.php. L'indirizzo dei rilasci ('rilasci' della 0.16.0) non è più un'impostazione: solo la costante
		 * DS_CORE_RILASCI_URL; il valore rimasto nel database si ignora e si toglie al primo salvataggio.
		 */
		'canale'      => array(
			'tipo'        => 'radio',
			'scelte'      => array( 'stabile', 'test' ),
			'predefinito' => 'stabile',
			'nascosto'    => true,
		),
	);
}

/** Testi delle impostazioni generali, tradotti. Solo dopo init (pannello). */
function ds_core_testi_generali() {
	return array(
		'campi' => array(
			'avvisi' => array(
				'etichetta' => __( 'Notification address', 'ds-core' ),
				'aiuto'     => __( 'All DS Core emails go here: update notices, Claude Code access openings, the weekly activity log summary and security notices. Empty = the site administrator email. A new address takes effect only after it is confirmed from the link sent to it; until then the emails keep going to the current one.', 'ds-core' ),
			),
			'anche_admin' => array(
				'etichetta' => __( 'Site administrator', 'ds-core' ),
				/* translators: %s: site administrator email address. */
				'testo'     => sprintf( __( 'Also send every DS Core email to the site administrator email (%s)', 'ds-core' ), (string) get_option( 'admin_email' ) ),
				'aiuto'     => __( 'Security notices always go there too, whatever you choose here: Claude Code access openings and closings before time is up, requests and confirmations of a new notification address, the emergency switch, a refused DS Core update, a new administrator account. Each address gets its own email, WordPress update emails included: nobody sees the other address.', 'ds-core' ),
			),
		),
	);
}

/**
 * Controlla un elenco di campi dichiarato nel registro e lo restituisce pulito: chiave => campo con tutte le chiavi.
 * I campi sbagliati si saltano e finiscono in $problemi (testi brevi, per la riga del modulo): un errore nello schema
 * non ferma né il pannello né il sito.
 */
function ds_core_schema( $campi, &$problemi = array() ) {
	$problemi = array();
	$schema   = array();
	if ( ! is_array( $campi ) ) {
		return $schema;
	}
	$tipi = ds_core_tipi_campo();
	foreach ( $campi as $chiave => $campo ) {
		$chiave = (string) $chiave;
		if ( '' === $chiave || sanitize_key( $chiave ) !== $chiave || ! is_array( $campo ) ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: invalid name or definition.';
			continue;
		}
		$tipo = isset( $campo['tipo'] ) ? (string) $campo['tipo'] : '';
		if ( ! in_array( $tipo, $tipi, true ) ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: unknown type "' . $tipo . '".';
			continue;
		}
		$pulito = array(
			'tipo'           => $tipo,
			'predefinito'    => $campo['predefinito'] ?? null,
			'predefinito_da' => isset( $campo['predefinito_da'] ) && is_callable( $campo['predefinito_da'] ) ? $campo['predefinito_da'] : null,
			'min'            => isset( $campo['min'] ) && is_numeric( $campo['min'] ) ? 0 + $campo['min'] : null,
			'max'            => isset( $campo['max'] ) && is_numeric( $campo['max'] ) ? 0 + $campo['max'] : null,
			'passo'          => isset( $campo['passo'] ) && is_numeric( $campo['passo'] ) && $campo['passo'] > 0 ? 0 + $campo['passo'] : 1,
			'scelte'         => array(),
			'lunghezza'      => isset( $campo['lunghezza'] ) ? max( 1, (int) $campo['lunghezza'] ) : 200,
			'gruppo'         => isset( $campo['gruppo'] ) ? sanitize_key( (string) $campo['gruppo'] ) : '',
			'nascosto'       => ! empty( $campo['nascosto'] ),
			'contrasto'      => 'color' === $tipo && ! empty( $campo['contrasto'] ),
			'mostra_se'      => isset( $campo['mostra_se'] ) && is_array( $campo['mostra_se'] ) && 2 === count( $campo['mostra_se'] ) ? array( sanitize_key( (string) reset( $campo['mostra_se'] ) ), (string) end( $campo['mostra_se'] ) ) : array(),
		);
		if ( in_array( $tipo, array( 'radio', 'select', 'checkboxes', 'schemi' ), true ) ) {
			$scelte = isset( $campo['scelte'] ) && is_array( $campo['scelte'] ) ? array_values( array_unique( array_map( 'strval', array_filter( $campo['scelte'], 'is_scalar' ) ) ) ) : array();
			if ( ! $scelte ) {
				$problemi[] = 'Field "' . $chiave . '" skipped: no choices.';
				continue;
			}
			$pulito['scelte'] = $scelte;
		}
		if ( null !== $pulito['min'] && null !== $pulito['max'] && $pulito['min'] > $pulito['max'] ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: min is greater than max.';
			continue;
		}
		// Il predefinito dichiarato passa dalla stessa pulizia dei valori salvati: se non è valido diventa neutro.
		$errore                = '';
		$valore                = ds_core_valore_campo( $pulito, $pulito['predefinito'], false, $errore );
		$pulito['predefinito'] = '' === $errore ? $valore : ds_core_valore_neutro( $pulito );
		$schema[ $chiave ]     = $pulito;
	}
	return $schema;
}

/** Valore «vuoto» di un tipo di campo. */
function ds_core_valore_neutro( $campo ) {
	switch ( $campo['tipo'] ) {
		case 'number':
			return null !== $campo['min'] ? $campo['min'] : 0;
		case 'checkbox':
			return false;
		case 'checkboxes':
		case 'plugins':
			return array();
		case 'radio':
		case 'select':
		case 'schemi':
			return $campo['scelte'][0] ?? '';
	}
	return '';
}

/** Predefinito di un campo, calcolato se il campo ha 'predefinito_da'. Un errore nella funzione dà il predefinito fisso. */
function ds_core_predefinito( $campo ) {
	if ( $campo['predefinito_da'] ) {
		try {
			$errore = '';
			$valore = ds_core_valore_campo( $campo, call_user_func( $campo['predefinito_da'] ), false, $errore );
			if ( '' === $errore ) {
				return $valore;
			}
		} catch ( \Throwable $e ) {
			error_log( '[DS Core] default value not computed: ' . $e->getMessage() );
		}
	}
	return $campo['predefinito'];
}

/**
 * Pulisce un valore secondo il tipo del campo. Restituisce il valore pulito; se il valore non si può accettare,
 * $errore contiene il motivo (tradotto se le traduzioni sono già caricate) e il valore restituito non va usato.
 * $severo = true nel salvataggio dal pannello: i plugin si confrontano con quelli installati (lettura dei file, solo
 * in amministrazione). I numeri fuori dai limiti si riconducono al limite, senza errore.
 */
function ds_core_valore_campo( $campo, $grezzo, $severo, &$errore ) {
	$errore = '';
	switch ( $campo['tipo'] ) {
		case 'text':
			if ( ! is_scalar( $grezzo ) && null !== $grezzo ) {
				$errore = ds_core_testo_errore( 'testo' );
				return '';
			}
			$valore = sanitize_text_field( (string) $grezzo );
			return function_exists( 'mb_substr' ) ? mb_substr( $valore, 0, $campo['lunghezza'] ) : substr( $valore, 0, $campo['lunghezza'] );

		case 'email':
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = sanitize_email( $valore );
			if ( ! is_email( $valore ) ) {
				$errore = ds_core_testo_errore( 'email' );
				return '';
			}
			return $valore;

		case 'url':
			// Solo https, con host, senza utente e password (dalla 0.16.0).
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = esc_url_raw( $valore, array( 'https' ) );
			$parti  = '' !== $valore ? wp_parse_url( $valore ) : false;
			if ( ! is_array( $parti ) || 'https' !== strtolower( (string) ( $parti['scheme'] ?? '' ) ) || empty( $parti['host'] ) || isset( $parti['user'] ) || isset( $parti['pass'] ) ) {
				$errore = ds_core_testo_errore( 'url' );
				return '';
			}
			return function_exists( 'mb_substr' ) ? mb_substr( $valore, 0, $campo['lunghezza'] ) : substr( $valore, 0, $campo['lunghezza'] );

		case 'number':
			if ( ! is_scalar( $grezzo ) || '' === trim( (string) $grezzo ) || ! is_numeric( trim( (string) $grezzo ) ) ) {
				$errore = ds_core_testo_errore( 'numero' );
				return 0;
			}
			$valore = 0 + trim( (string) $grezzo );
			if ( floor( $campo['passo'] ) == $campo['passo'] ) { // phpcs:ignore Universal.Operators.StrictComparisons -- 1 e 1.0 sono lo stesso passo.
				$valore = (int) round( $valore );
			}
			if ( null !== $campo['min'] && $valore < $campo['min'] ) {
				$valore = $campo['min'];
			}
			if ( null !== $campo['max'] && $valore > $campo['max'] ) {
				$valore = $campo['max'];
			}
			return $valore;

		case 'checkbox':
			return true === $grezzo || 1 === $grezzo || ( is_string( $grezzo ) && in_array( strtolower( $grezzo ), array( '1', 'on', 'yes', 'true' ), true ) );

		case 'radio':
		case 'select':
		case 'schemi':
			$valore = is_scalar( $grezzo ) ? (string) $grezzo : '';
			if ( ! in_array( $valore, $campo['scelte'], true ) ) {
				$errore = ds_core_testo_errore( 'scelta' );
				return '';
			}
			return $valore;

		case 'checkboxes':
			$valori = is_array( $grezzo ) ? array_map( 'strval', array_filter( $grezzo, 'is_scalar' ) ) : array();
			return array_values( array_intersect( $campo['scelte'], $valori ) );

		case 'plugins':
			$valori = is_array( $grezzo ) ? array_values( array_unique( array_map( 'sanitize_text_field', array_map( 'strval', array_filter( $grezzo, 'is_scalar' ) ) ) ) ) : array();
			if ( $severo ) {
				if ( ! function_exists( 'get_plugins' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}
				$valori = array_values( array_intersect( $valori, array_keys( get_plugins() ) ) );
			}
			return $valori;

		case 'color':
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = sanitize_hex_color( $valore );
			if ( ! $valore ) {
				$errore = ds_core_testo_errore( 'colore' );
				return '';
			}
			return strtolower( $valore );
	}
	$errore = ds_core_testo_errore( 'testo' );
	return '';
}

/** Motivi per cui un valore non si accetta. Tradotti solo dopo init; prima (sito pubblico, cron) servono solo da segnale. */
function ds_core_testo_errore( $codice ) {
	if ( ! did_action( 'init' ) ) {
		return $codice;
	}
	$testi = array(
		'email'  => __( 'Enter a valid email address, or leave the field empty.', 'ds-core' ),
		'url'    => __( 'Enter an address that starts with https://, or leave the field empty.', 'ds-core' ),
		'numero' => __( 'Enter a number.', 'ds-core' ),
		'scelta' => __( 'Choose one of the options.', 'ds-core' ),
		'colore' => __( 'Enter a color as #rrggbb, or leave the field empty.', 'ds-core' ),
		'testo'  => __( 'This value cannot be saved.', 'ds-core' ),
	);
	return $testi[ $codice ] ?? $testi['testo'];
}

/**
 * Gruppo di impostazioni: array( 'opzione' => nome, 'schema' => campi puliti, 'problemi' => errori dello schema ),
 * oppure null se l'ID non ha scelte. 'ds-core' è il gruppo riservato alle impostazioni generali.
 */
function ds_core_gruppo_impostazioni( $id ) {
	$problemi = array();
	if ( 'ds-core' === $id ) {
		$schema = ds_core_schema( ds_core_campi_generali(), $problemi );
		return array( 'opzione' => 'ds_core_generali', 'schema' => $schema, 'problemi' => $problemi );
	}
	$id       = ds_core_id_attuale( $id ); // vecchi ID (prima della 0.17.0) accettati
	$registro = ds_core_registro();
	if ( ! isset( $registro[ $id ] ) || '' === $registro[ $id ]['opzione'] || ! $registro[ $id ]['campi'] ) {
		return null;
	}
	// Anche con lo schema tutto sbagliato il gruppo esiste: il pannello mostra i problemi nella riga del modulo.
	$schema = ds_core_schema( $registro[ $id ]['campi'], $problemi );
	return array( 'opzione' => $registro[ $id ]['opzione'], 'schema' => $schema, 'problemi' => $problemi );
}

/**
 * Valori puliti di un elenco di campi a partire da quelli salvati. $severo come in ds_core_valore_campo(). Un campo
 * mai salvato o con un valore non valido prende il predefinito.
 */
function ds_core_valori_da_salvati( $schema, $salvati, $severo = false ) {
	$salvati = is_array( $salvati ) ? $salvati : array();
	$valori  = array();
	foreach ( $schema as $chiave => $campo ) {
		if ( array_key_exists( $chiave, $salvati ) ) {
			$errore = '';
			$valore = ds_core_valore_campo( $campo, $salvati[ $chiave ], $severo, $errore );
			if ( '' === $errore ) {
				$valori[ $chiave ] = $valore;
				continue;
			}
		}
		$valori[ $chiave ] = ds_core_predefinito( $campo );
	}
	return $valori;
}

/**
 * Scelte di un modulo (o di DS Core con 'ds-core'): valori salvati, puliti, con i predefiniti per quelli mai
 * salvati. Una volta per richiesta; ds_core_opzioni_svuota() dopo un salvataggio. Array vuoto se il modulo non ha
 * scelte.
 */
function ds_core_opzioni_modulo( $id, $svuota = false ) {
	static $cache = array();
	if ( $svuota ) {
		$cache = array();
		return array();
	}
	$id = ds_core_id_attuale( (string) $id ); // vecchi ID (prima della 0.17.0) accettati
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	$gruppo = ds_core_gruppo_impostazioni( $id );
	if ( ! $gruppo || ! $gruppo['schema'] ) {
		return array();
	}
	$valori = ds_core_valori_da_salvati( $gruppo['schema'], get_option( $gruppo['opzione'], array() ) );
	if ( did_action( 'plugins_loaded' ) ) {
		$cache[ $id ] = $valori;
	}
	return $valori;
}

/** Dimentica i valori letti in questa richiesta (dopo un salvataggio). */
function ds_core_opzioni_svuota() {
	ds_core_opzioni_modulo( '', true );
}

/*
 * Colori e contrasto (dalla 0.18.0): servono al modulo admin-branding e all'anteprima del pannello (campo 'color' con
 * 'contrasto'), anche a modulo spento, quindi stanno qui. Formula del contrasto di WCAG 2.x (luminanza relativa);
 * soglia AA per il testo normale: 4,5:1. La stessa formula è in assets/pannello.js per l'anteprima dal vivo.
 */

/** Colore #rrggbb → array( r, g, b ) da 0 a 255; null se non è un colore valido. */
function ds_core_colore_rgb( $hex ) {
	$hex = sanitize_hex_color( (string) $hex );
	if ( ! $hex ) {
		return null;
	}
	$hex = ltrim( $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
}

/** array( r, g, b ) → #rrggbb. */
function ds_core_colore_hex( $rgb ) {
	return sprintf( '#%02x%02x%02x', max( 0, min( 255, (int) round( $rgb[0] ) ) ), max( 0, min( 255, (int) round( $rgb[1] ) ) ), max( 0, min( 255, (int) round( $rgb[2] ) ) ) );
}

/** Luminanza relativa (WCAG) di un colore #rrggbb, da 0 a 1. */
function ds_core_colore_luminanza( $hex ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return 0.0;
	}
	$canali = array_map(
		function ( $v ) {
			$v = $v / 255;
			return $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
		},
		$rgb
	);
	return 0.2126 * $canali[0] + 0.7152 * $canali[1] + 0.0722 * $canali[2];
}

/** Rapporto di contrasto fra due colori, da 1 a 21. */
function ds_core_colore_contrasto( $a, $b ) {
	$x = ds_core_colore_luminanza( $a );
	$y = ds_core_colore_luminanza( $b );
	return ( max( $x, $y ) + 0.05 ) / ( min( $x, $y ) + 0.05 );
}

/** Mescola un colore con il nero ($verso = 'scuro') o il bianco ('chiaro'); $quota da 0 a 1. */
function ds_core_colore_mescola( $hex, $verso, $quota ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return (string) $hex;
	}
	$meta = 'scuro' === $verso ? 0 : 255;
	foreach ( $rgb as $i => $v ) {
		$rgb[ $i ] = $v + ( $meta - $v ) * $quota;
	}
	return ds_core_colore_hex( $rgb );
}

/**
 * Colore di fondo leggibile con un testo sopra (pulsanti, voce di menu scelta): il testo è bianco o scuro (#1d2327),
 * quello con il contrasto maggiore; se nemmeno quello arriva a $minimo, il fondo si scurisce (testo bianco) o si
 * schiarisce (testo scuro) a piccoli passi finché ci arriva. Restituisce array( 'fondo', 'testo', 'rapporto',
 * 'cambiato' ).
 */
function ds_core_colore_leggibile( $hex, $minimo = 4.5 ) {
	$fondo = sanitize_hex_color( (string) $hex );
	$fondo = $fondo ? ds_core_colore_hex( ds_core_colore_rgb( $fondo ) ) : '#2271b1';
	$bianco = ds_core_colore_contrasto( $fondo, '#ffffff' );
	$scuro  = ds_core_colore_contrasto( $fondo, '#1d2327' );
	$testo  = $bianco >= $scuro ? '#ffffff' : '#1d2327';
	$verso  = '#ffffff' === $testo ? 'scuro' : 'chiaro';
	$base   = $fondo;
	for ( $passo = 0; $passo <= 20 && ds_core_colore_contrasto( $fondo, $testo ) < $minimo; $passo++ ) {
		$fondo = ds_core_colore_mescola( $base, $verso, ( $passo + 1 ) * 0.05 );
	}
	return array(
		'fondo'    => $fondo,
		'testo'    => $testo,
		'rapporto' => round( ds_core_colore_contrasto( $fondo, $testo ), 1 ),
		'cambiato' => $fondo !== $base,
	);
}

/**
 * Colore da usare come testo (link, icone) su uno sfondo dato: il colore stesso se il contrasto arriva a $minimo,
 * altrimenti più scuro (sfondo chiaro) o più chiaro (sfondo scuro) a piccoli passi.
 */
function ds_core_colore_su( $hex, $sfondo, $minimo = 4.5 ) {
	$colore = sanitize_hex_color( (string) $hex );
	$colore = $colore ? ds_core_colore_hex( ds_core_colore_rgb( $colore ) ) : '#2271b1';
	$verso  = ds_core_colore_luminanza( $sfondo ) > 0.18 ? 'scuro' : 'chiaro';
	$base   = $colore;
	for ( $passo = 0; $passo <= 20 && ds_core_colore_contrasto( $colore, $sfondo ) < $minimo; $passo++ ) {
		$colore = ds_core_colore_mescola( $base, $verso, ( $passo + 1 ) * 0.05 );
	}
	return $colore;
}

/*
 * Colori globali di Breakdance (dalla 0.18.1, formato verificato su un sito il 27/11/2026). Facoltativo: DS Core non
 * dipende da Breakdance, legge solo l'opzione «breakdance_global_settings_json_string» (o la funzione di Breakdance
 * che la restituisce). Il formato non è documentato da Breakdance, quindi la lettura è difensiva:
 * - l'opzione è JSON codificato due volte (una stringa JSON che contiene JSON): si decodifica finché il risultato è
 *   una stringa, al massimo tre volte;
 * - in settings.colors ci sono brand, text, headings, links, background e palette; ognuno può essere un colore diretto
 *   (#rgb, #rrggbb, #rrggbbaa, rgb(), rgba()) o un riferimento alla palette come var(--bde-palette-color-2);
 * - palette.colors è un elenco di oggetti con «value». Il numero N di --bde-palette-color-N si cerca prima in un
 *   identificativo dell'elemento (cssVariableName, id, variable, name, slug, key: «palette-color-2», «color-2»,
 *   «--bde-palette-color-2» o «2» valgono tutti N = 2); se nessun elemento ne ha, vale la posizione (1 = il primo);
 * - un colore con trasparenza (alfa sotto 1) non si usa come colore del brand: si legge ma si scarta.
 */

/**
 * Colore CSS → array( 'hex' => '#rrggbb', 'alfa' => 0..1 ); null se non è un colore che DS Core sa leggere
 * (#rgb, #rgba, #rrggbb, #rrggbbaa, rgb() e rgba() con virgole o spazi, alfa in numero o percentuale).
 */
function ds_core_colore_css( $valore ) {
	if ( ! is_string( $valore ) ) {
		return null;
	}
	$valore = strtolower( trim( $valore ) );
	if ( preg_match( '/^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/', $valore, $m ) ) {
		$h = $m[1];
		if ( strlen( $h ) <= 4 ) {
			$lungo = '';
			foreach ( str_split( $h ) as $c ) {
				$lungo .= $c . $c;
			}
			$h = $lungo;
		}
		$alfa = 8 === strlen( $h ) ? hexdec( substr( $h, 6, 2 ) ) / 255 : 1.0;
		return array( 'hex' => '#' . substr( $h, 0, 6 ), 'alfa' => round( $alfa, 3 ) );
	}
	if ( preg_match( '/^rgba?\(\s*([0-9.]+%?)\s*[,\s]\s*([0-9.]+%?)\s*[,\s]\s*([0-9.]+%?)\s*(?:[,\/]\s*([0-9.]+%?)\s*)?\)$/', $valore, $m ) ) {
		$canali = array();
		foreach ( array( $m[1], $m[2], $m[3] ) as $c ) {
			$n = '%' === substr( $c, -1 ) ? (float) $c * 2.55 : (float) $c;
			if ( $n > 255.5 ) {
				return null;
			}
			$canali[] = $n;
		}
		$alfa = 1.0;
		if ( isset( $m[4] ) && '' !== $m[4] ) {
			$alfa = '%' === substr( $m[4], -1 ) ? (float) $m[4] / 100 : (float) $m[4];
		}
		return array( 'hex' => ds_core_colore_hex( $canali ), 'alfa' => round( max( 0.0, min( 1.0, $alfa ) ), 3 ) );
	}
	return null;
}

/** Testo grezzo dei colori globali di Breakdance (JSON, anche codificato due volte); '' se non c'è. */
function ds_core_breakdance_grezzo() {
	$grezzo = null;
	if ( function_exists( 'Breakdance\Data\get_global_option' ) ) {
		try {
			$grezzo = call_user_func( 'Breakdance\Data\get_global_option', 'global_settings_json_string' );
		} catch ( \Throwable $e ) {
			$grezzo = null;
		}
	}
	if ( ! ( is_string( $grezzo ) && '' !== trim( $grezzo ) ) && ! is_array( $grezzo ) ) {
		$grezzo = get_option( 'breakdance_global_settings_json_string', '' );
	}
	return is_string( $grezzo ) || is_array( $grezzo ) ? $grezzo : '';
}

/** Decodifica il JSON dei colori di Breakdance, anche codificato due (o tre) volte; null se non è leggibile. */
function ds_core_breakdance_decodifica( $grezzo ) {
	$dati = $grezzo;
	for ( $giro = 0; $giro < 3 && is_string( $dati ); $giro++ ) {
		$dati = '' !== trim( $dati ) ? json_decode( $dati, true ) : null;
	}
	return is_array( $dati ) ? $dati : null;
}

/** Identificativo della palette normalizzato: «--bde-palette-color-2», «palette-color-2», «color-2», «2» → «color-2». */
function ds_core_breakdance_chiave( $nome ) {
	$nome = strtolower( trim( (string) $nome ) );
	$nome = (string) preg_replace( '/^(--)?(bde-)?(palette-)?/', '', $nome );
	if ( preg_match( '/^\d+$/', $nome ) ) {
		$nome = 'color-' . $nome;
	}
	return $nome;
}

/**
 * Palette di Breakdance → array( 'color-N' => array( 'valore' => testo, 'numero' => N ) ). Chiavi dagli identificativi
 * degli elementi; se nessun elemento ne ha uno riconoscibile, dalla posizione (color-1 = il primo).
 */
function ds_core_breakdance_palette( $colori ) {
	$elenco = $colori['palette']['colors'] ?? ( $colori['palette'] ?? array() );
	if ( ! is_array( $elenco ) ) {
		return array();
	}
	$per_nome  = array();
	$per_posto = array();
	$posto     = 0;
	foreach ( array_values( $elenco ) as $elemento ) {
		$posto++;
		$valore = is_array( $elemento ) ? ( $elemento['value'] ?? ( $elemento['color'] ?? '' ) ) : $elemento;
		if ( ! is_string( $valore ) ) {
			continue;
		}
		$per_posto[ 'color-' . $posto ] = array( 'valore' => $valore, 'numero' => $posto );
		if ( ! is_array( $elemento ) ) {
			continue;
		}
		foreach ( array( 'cssVariableName', 'id', 'variable', 'name', 'slug', 'key' ) as $campo ) {
			if ( ! isset( $elemento[ $campo ] ) || ! is_scalar( $elemento[ $campo ] ) ) {
				continue;
			}
			$chiave = ds_core_breakdance_chiave( $elemento[ $campo ] );
			// Breakdance dà nomi liberi (bde-palette-color-2, bde-palette-yellow-brand-identity-13…): ogni nome vale.
			if ( '' !== $chiave && ! isset( $per_nome[ $chiave ] ) ) {
				$numero              = preg_match( '/(\d+)$/', $chiave, $m ) ? (int) $m[1] : $posto;
				$per_nome[ $chiave ] = array( 'valore' => $valore, 'numero' => $numero );
			}
		}
	}
	return $per_nome ? $per_nome : $per_posto;
}

/**
 * Valore dei colori di Breakdance risolto: colore diretto o var(--bde-palette-color-N[, ripiego]).
 * Restituisce array( 'hex', 'alfa', 'palette' => N, 0 se diretto ) oppure null.
 */
function ds_core_breakdance_risolvi( $valore, $palette, $profondita = 0 ) {
	if ( is_array( $valore ) ) {
		$valore = $valore['value'] ?? '';
	}
	if ( ! is_string( $valore ) || $profondita > 3 ) {
		return null;
	}
	$valore = trim( $valore );
	if ( preg_match( '/^var\(\s*(--[a-z0-9_-]+)\s*(?:,\s*(.+))?\)$/i', $valore, $m ) ) {
		$chiave = ds_core_breakdance_chiave( $m[1] );
		if ( isset( $palette[ $chiave ] ) ) {
			$trovato = ds_core_breakdance_risolvi( $palette[ $chiave ]['valore'], $palette, $profondita + 1 );
			if ( $trovato ) {
				$trovato['palette'] = $palette[ $chiave ]['numero'];
				return $trovato;
			}
		}
		return isset( $m[2] ) ? ds_core_breakdance_risolvi( $m[2], $palette, $profondita + 1 ) : null;
	}
	$colore = ds_core_colore_css( $valore );
	if ( ! $colore ) {
		return null;
	}
	$colore['palette'] = 0;
	return $colore;
}

/**
 * Colori globali di Breakdance risolti: array( 'brand'|'links'|'text'|'headings'|'background' => array( 'hex', 'alfa',
 * 'palette', 'usabile' ) ), solo quelli leggibili; 'usabile' = colore pieno (alfa 1). Array vuoto senza Breakdance o
 * con l'opzione illeggibile. $grezzo serve alle prove (senza: l'opzione del sito, letta una volta per richiesta).
 */
function ds_core_colori_breakdance( $grezzo = null ) {
	static $cache = null;
	if ( null === $grezzo && null !== $cache ) {
		return $cache;
	}
	$dati    = ds_core_breakdance_decodifica( null === $grezzo ? ds_core_breakdance_grezzo() : $grezzo );
	$colori  = is_array( $dati ) ? ( $dati['settings']['colors'] ?? ( $dati['colors'] ?? null ) ) : null;
	$risolti = array();
	if ( is_array( $colori ) ) {
		$palette = ds_core_breakdance_palette( $colori );
		foreach ( array( 'brand', 'links', 'text', 'headings', 'background' ) as $nome ) {
			$colore = isset( $colori[ $nome ] ) ? ds_core_breakdance_risolvi( $colori[ $nome ], $palette ) : null;
			if ( $colore ) {
				$colore['usabile'] = $colore['alfa'] >= 0.999;
				$risolti[ $nome ]  = $colore;
			}
		}
	}
	if ( null === $grezzo ) {
		$cache = $risolti;
	}
	return $risolti;
}

/**
 * Palette di Breakdance nell'ordine in cui la mostra Breakdance (dalla 0.18.2): elenco di array( 'hex', 'alfa',
 * 'etichetta' (nome visibile, es. «Yellow - Brand Identity»), 'nome' (cssVariableName o id, es.
 * «yellow-brand-identity-13»), 'numero', 'usabile' (colore pieno, alfa 1) ). Solo i colori leggibili. $grezzo serve alle
 * prove (senza: l'opzione del sito, letta una volta per richiesta).
 */
function ds_core_palette_breakdance( $grezzo = null ) {
	static $cache = null;
	if ( null === $grezzo && null !== $cache ) {
		return $cache;
	}
	$dati   = ds_core_breakdance_decodifica( null === $grezzo ? ds_core_breakdance_grezzo() : $grezzo );
	$colori = is_array( $dati ) ? ( $dati['settings']['colors'] ?? ( $dati['colors'] ?? null ) ) : null;
	$elenco = array();
	if ( is_array( $colori ) ) {
		$mappa  = ds_core_breakdance_palette( $colori );
		$grezze = $colori['palette']['colors'] ?? ( $colori['palette'] ?? array() );
		$posto  = 0;
		foreach ( is_array( $grezze ) ? array_values( $grezze ) : array() as $elemento ) {
			$posto++;
			$risolto = ds_core_breakdance_risolvi( $elemento, $mappa );
			if ( ! $risolto ) {
				continue;
			}
			$etichetta = '';
			$nome      = '';
			if ( is_array( $elemento ) ) {
				foreach ( array( 'label', 'name', 'title' ) as $campo ) {
					if ( isset( $elemento[ $campo ] ) && is_scalar( $elemento[ $campo ] ) && '' !== trim( (string) $elemento[ $campo ] ) ) {
						$etichetta = sanitize_text_field( (string) $elemento[ $campo ] );
						break;
					}
				}
				foreach ( array( 'cssVariableName', 'id', 'variable', 'slug', 'key' ) as $campo ) {
					if ( isset( $elemento[ $campo ] ) && is_scalar( $elemento[ $campo ] ) && '' !== trim( (string) $elemento[ $campo ] ) ) {
						$nome = sanitize_text_field( (string) $elemento[ $campo ] );
						break;
					}
				}
			}
			$numero   = preg_match( '/(\d+)$/', $nome, $m ) ? (int) $m[1] : $posto;
			$elenco[] = array(
				'hex'       => $risolto['hex'],
				'alfa'      => $risolto['alfa'],
				'etichetta' => function_exists( 'mb_substr' ) ? mb_substr( $etichetta, 0, 60 ) : substr( $etichetta, 0, 60 ),
				'nome'      => substr( $nome, 0, 80 ),
				'numero'    => $numero,
				'usabile'   => $risolto['alfa'] >= 0.999,
			);
		}
	}
	if ( null === $grezzo ) {
		$cache = $elenco;
	}
	return $elenco;
}

/**
 * Colore neutro: nero, bianco o grigio (anche appena tinto, come #00000f o #f3eff5). Si misura la croma (differenza fra
 * il canale più alto e il più basso, da 0 a 1): sotto 0,15 il colore non fa da accento. La saturazione HSL non serve
 * qui: dà valori alti anche ai quasi neri.
 */
function ds_core_colore_neutro( $hex ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return true;
	}
	return ( max( $rgb ) - min( $rgb ) ) / 255 < 0.15;
}

/** Saturazione (HSL, 0..1) di un colore #rrggbb (0.18.1; dalla 0.18.2 per i neutri si usa ds_core_colore_neutro()). */
function ds_core_colore_saturazione( $hex ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return 0.0;
	}
	$max = max( $rgb ) / 255;
	$min = min( $rgb ) / 255;
	if ( $max === $min ) {
		return 0.0;
	}
	return ( $max - $min ) / ( 1 - abs( $max + $min - 1 ) );
}

/** Tinta (HSL) di un colore #rrggbb, da 0 a 360 gradi. */
function ds_core_colore_tinta( $hex ) {
	$rgb = ds_core_colore_rgb( $hex );
	if ( ! $rgb ) {
		return 0.0;
	}
	list( $r, $g, $b ) = array( $rgb[0] / 255, $rgb[1] / 255, $rgb[2] / 255 );
	$max = max( $r, $g, $b );
	$min = min( $r, $g, $b );
	$d   = $max - $min;
	if ( $d <= 0 ) {
		return 0.0;
	}
	if ( $max === $r ) {
		$h = fmod( ( $g - $b ) / $d, 6 );
	} elseif ( $max === $g ) {
		$h = ( $b - $r ) / $d + 2;
	} else {
		$h = ( $r - $g ) / $d + 4;
	}
	$h *= 60;
	return $h < 0 ? $h + 360 : $h;
}

/** Distanza fra due tinte, da 0 a 180 gradi. */
function ds_core_colore_distanza_tinta( $a, $b ) {
	$d = abs( ds_core_colore_tinta( $a ) - ds_core_colore_tinta( $b ) );
	return $d > 180 ? 360 - $d : $d;
}

/** Mescola due colori #rrggbb: $quota 0 = $a, 1 = $b. */
function ds_core_colore_verso( $a, $b, $quota ) {
	$x = ds_core_colore_rgb( $a );
	$y = ds_core_colore_rgb( $b );
	if ( ! $x || ! $y ) {
		return (string) $a;
	}
	return ds_core_colore_hex( array( $x[0] + ( $y[0] - $x[0] ) * $quota, $x[1] + ( $y[1] - $x[1] ) * $quota, $x[2] + ( $y[2] - $x[2] ) * $quota ) );
}

/*
 * Schemi colori dell'amministrazione (admin-branding, dalla 0.18.2; decisioni di Daniele del 27/11/2026). Servono anche a
 * modulo spento (schemi proposti e anteprima del pannello), quindi stanno qui. Ruoli, come negli schemi di WordPress:
 * menu (sfondo del menu laterale), menu_testo, accento (voce attiva ed evidenza), notifiche (pallini e badge), link
 * (link e pulsanti), sottomenu e barra (barra in alto), facoltativi: vuoti si ricavano dal menu.
 * La stessa risoluzione è in assets/pannello.js (anteprima dal vivo): le due versioni vanno tenute uguali.
 */

/** Colori dello schema predefinito di WordPress («Default», fresh). */
function ds_core_ab_wordpress() {
	return array(
		'menu'       => '#1d2327',
		'menu_testo' => '#f0f0f1',
		'accento'    => '#2271b1',
		'notifiche'  => '#d63638',
		'link'       => '#2271b1',
		'sottomenu'  => '#2c3338',
		'barra'      => '#1d2327',
	);
}

/** Ruoli personalizzabili, nell'ordine dei campi. */
function ds_core_ab_ruoli() {
	return array( 'menu', 'menu_testo', 'accento', 'notifiche', 'link', 'sottomenu', 'barra' );
}

/**
 * Accento automatico (decisione di Daniele del 27/11/2026). «Brand» di Breakdance spesso è il colore dei testi (nero),
 * non l'accento del marchio. Si usa Brand solo se è un colore pieno, non neutro e distinguibile dal menu scuro
 * ($menu, contrasto almeno 3:1). Altrimenti, in ordine: Links se è un colore pieno non neutro; il primo colore della
 * palette con «brand» nell'etichetta o nel nome (pieno, non neutro); il primo colore pieno non neutro della palette
 * nell'ordine di Breakdance; altrimenti nessuno (resta lo schema di WordPress).
 * Restituisce array( 'hex', 'origine' => array( 'tipo' => brand|links|palette, 'etichetta', 'nome', 'numero' ),
 * 'perche' => brand-palette|palette|brand|links|'' , 'scarti' => array( codice => hex ) ). 'hex' '' = nessuno.
 */
function ds_core_ab_accento_auto( $bd, $palette, $menu = '#1d2327' ) {
	$esito = array( 'hex' => '', 'origine' => array(), 'perche' => '', 'scarti' => array() );
	$brand = $bd['brand'] ?? null;
	if ( $brand ) {
		if ( empty( $brand['usabile'] ) ) {
			$esito['scarti']['brand-trasparente'] = $brand['hex'];
		} elseif ( ds_core_colore_neutro( $brand['hex'] ) ) {
			$esito['scarti']['brand-neutro'] = $brand['hex'];
		} elseif ( ds_core_colore_contrasto( $brand['hex'], $menu ) < 3 ) {
			$esito['scarti']['brand-menu'] = $brand['hex'];
		} else {
			$esito['hex']     = $brand['hex'];
			$esito['origine'] = array( 'tipo' => 'brand', 'numero' => (int) $brand['palette'] );
			$esito['perche']  = 'brand';
			return $esito;
		}
	}
	$links = $bd['links'] ?? null;
	if ( $links ) {
		if ( ! empty( $links['usabile'] ) && ! ds_core_colore_neutro( $links['hex'] ) ) {
			$esito['hex']     = $links['hex'];
			$esito['origine'] = array( 'tipo' => 'links', 'numero' => (int) $links['palette'] );
			$esito['perche']  = 'links';
			return $esito;
		}
		$esito['scarti']['links-neutro'] = $links['hex'];
	}
	foreach ( $palette as $colore ) {
		if ( $colore['usabile'] && ! ds_core_colore_neutro( $colore['hex'] ) && ( false !== stripos( $colore['etichetta'], 'brand' ) || false !== stripos( $colore['nome'], 'brand' ) ) ) {
			$esito['hex']     = $colore['hex'];
			$esito['origine'] = ds_core_ab_origine_palette( $colore );
			$esito['perche']  = 'brand-palette';
			return $esito;
		}
	}
	foreach ( $palette as $colore ) {
		if ( $colore['usabile'] && ! ds_core_colore_neutro( $colore['hex'] ) ) {
			$esito['hex']     = $colore['hex'];
			$esito['origine'] = ds_core_ab_origine_palette( $colore );
			$esito['perche']  = 'palette';
			return $esito;
		}
	}
	return $esito;
}

/** Origine «colore della palette» per i testi del pannello. */
function ds_core_ab_origine_palette( $colore ) {
	return array( 'tipo' => 'palette', 'etichetta' => $colore['etichetta'], 'nome' => $colore['nome'], 'numero' => $colore['numero'] );
}

/** Origine «schema di WordPress». */
function ds_core_ab_origine_wp() {
	return array( 'tipo' => 'wordpress' );
}

/**
 * Colore dei link e dei pulsanti proposto: Links di Breakdance (pieno, non neutro), l'accento, poi i colori saturi della
 * palette, il primo già quasi leggibile sullo sfondo della Bacheca (3:1 su #f0f0f1: la tonalità portata a 4,5:1 resta
 * riconoscibile; il giallo, per esempio, diventerebbe un verde oliva). Se nessuno, l'accento. array( hex, origine ).
 */
function ds_core_ab_link_auto( $bd, $saturi, $accento ) {
	$candidati = array();
	if ( ! empty( $bd['links']['usabile'] ) && ! ds_core_colore_neutro( $bd['links']['hex'] ) ) {
		$candidati[] = array( $bd['links']['hex'], array( 'tipo' => 'links', 'numero' => (int) $bd['links']['palette'] ) );
	}
	if ( '' !== $accento['hex'] ) {
		$candidati[] = array( $accento['hex'], $accento['origine'] );
	}
	foreach ( $saturi as $colore ) {
		$candidati[] = array( $colore['hex'], ds_core_ab_origine_palette( $colore ) );
	}
	foreach ( $candidati as $candidato ) {
		if ( ds_core_colore_contrasto( $candidato[0], '#f0f0f1' ) >= 3 ) {
			return $candidato;
		}
	}
	return $candidati ? $candidati[0] : array( '', array() );
}

/**
 * Schemi proposti (dalla 0.18.2), costruiti dai colori di Breakdance. id => array( 'disponibile', 'colori' => ruolo =>
 * #rrggbb o '' (si ricava), 'origini' => ruolo => array( 'tipo' => wordpress|brand|links|palette|derivato, … ),
 * 'nomi' => array( 'menu' => origine del menu, 'accento' => origine dell'accento ) ).
 * - sito: «Dal sito (Breakdance)»: menu scuro di WordPress, accento automatico (ds_core_ab_accento_auto()), link dal
 *   sito; disponibile anche senza accento (allora non applica niente finché non si sceglie un colore qui);
 * - marchio: menu nel primo colore saturo scuro della palette (testo chiaro), accento distinguibile da quel menu;
 * - scuro: menu nel colore neutro più scuro della palette (es. il nero del sito), accento automatico;
 * - chiaro: menu chiaro (colore neutro chiaro della palette o grigio di WordPress), testo scuro, accento leggibile sul
 *   chiaro;
 * - secondo: menu scuro di WordPress, accento alternativo (colore saturo con tinta lontana dall'accento automatico);
 * - wordpress: lo schema predefinito di WordPress, nessun colore applicato (per tornare indietro).
 * Uno schema senza i colori che servono non è disponibile; due schemi uguali: resta il primo. Notifiche: il rosso di
 * WordPress, o un rosso della palette se c'è.
 */
function ds_core_ab_schemi( $bd = null, $palette = null ) {
	$bd      = null === $bd ? ds_core_colori_breakdance() : $bd;
	$palette = null === $palette ? ds_core_palette_breakdance() : $palette;
	$wp      = ds_core_ab_wordpress();
	$pieni   = array_values( array_filter( $palette, function ( $c ) { return $c['usabile']; } ) );
	$saturi  = array_values( array_filter( $pieni, function ( $c ) { return ! ds_core_colore_neutro( $c['hex'] ); } ) );
	$accento = ds_core_ab_accento_auto( $bd, $palette, $wp['menu'] );
	$link    = ds_core_ab_link_auto( $bd, $saturi, $accento );

	$notifica = array( $wp['notifiche'], ds_core_ab_origine_wp() );
	foreach ( $saturi as $c ) {
		$tinta = ds_core_colore_tinta( $c['hex'] );
		if ( ( $tinta < 15 || $tinta > 345 ) && ds_core_colore_luminanza( $c['hex'] ) < 0.4 ) {
			$notifica = array( $c['hex'], ds_core_ab_origine_palette( $c ) );
			break;
		}
	}

	$base = function ( $menu, $menu_origine, $acc, $acc_origine ) use ( $link, $notifica ) {
		return array(
			'disponibile' => true,
			'colori'      => array(
				'menu'       => $menu,
				'menu_testo' => '',
				'accento'    => $acc,
				'notifiche'  => $notifica[0],
				'link'       => '' !== $link[0] ? $link[0] : '',
				'sottomenu'  => '',
				'barra'      => '',
			),
			'origini'     => array(
				'menu'       => $menu_origine,
				'menu_testo' => array( 'tipo' => 'derivato', 'da' => 'menu' ),
				'accento'    => $acc_origine,
				'notifiche'  => $notifica[1],
				'link'       => '' !== $link[0] ? $link[1] : array( 'tipo' => 'derivato', 'da' => 'accento' ),
				'sottomenu'  => array( 'tipo' => 'derivato', 'da' => 'menu' ),
				'barra'      => array( 'tipo' => 'derivato', 'da' => 'menu' ),
			),
			'nomi'        => array( 'menu' => $menu_origine, 'accento' => $acc_origine ),
		);
	};

	$schemi = array();

	// Dal sito: menu e testo di WordPress, accento automatico.
	$schemi['sito']                         = $base( $wp['menu'], ds_core_ab_origine_wp(), $accento['hex'], $accento['origine'] );
	$schemi['sito']['colori']['sottomenu']  = $wp['sottomenu'];
	$schemi['sito']['colori']['menu_testo'] = $wp['menu_testo'];
	$schemi['sito']['origini']['sottomenu'] = ds_core_ab_origine_wp();
	$schemi['sito']['origini']['menu_testo'] = ds_core_ab_origine_wp();
	$schemi['sito']['accento_auto']         = $accento;

	// Menu nel colore saturo scuro del marchio.
	$schemi['marchio'] = array( 'disponibile' => false );
	foreach ( $saturi as $c ) {
		if ( ds_core_colore_luminanza( $c['hex'] ) > 0.12 ) {
			continue;
		}
		$acc = null;
		if ( '' !== $accento['hex'] && $accento['hex'] !== $c['hex'] && ds_core_colore_contrasto( $accento['hex'], $c['hex'] ) >= 3 ) {
			$acc = array( $accento['hex'], $accento['origine'] );
		} else {
			foreach ( $saturi as $altro ) {
				if ( $altro['hex'] !== $c['hex'] && ds_core_colore_contrasto( $altro['hex'], $c['hex'] ) >= 3 ) {
					$acc = array( $altro['hex'], ds_core_ab_origine_palette( $altro ) );
					break;
				}
			}
		}
		if ( $acc ) {
			$schemi['marchio'] = $base( $c['hex'], ds_core_ab_origine_palette( $c ), $acc[0], $acc[1] );
		}
		break;
	}

	// Menu nel neutro più scuro della palette (il nero del sito).
	$schemi['scuro'] = array( 'disponibile' => false );
	if ( '' !== $accento['hex'] ) {
		$scuro = null;
		foreach ( $pieni as $c ) {
			if ( ds_core_colore_neutro( $c['hex'] ) && ds_core_colore_luminanza( $c['hex'] ) < 0.03 && ( ! $scuro || ds_core_colore_luminanza( $c['hex'] ) < ds_core_colore_luminanza( $scuro['hex'] ) ) ) {
				$scuro = $c;
			}
		}
		if ( $scuro && $scuro['hex'] !== $wp['menu'] ) {
			$schemi['scuro'] = $base( $scuro['hex'], ds_core_ab_origine_palette( $scuro ), $accento['hex'], $accento['origine'] );
		}
	}

	// Menu chiaro con testo scuro.
	$schemi['chiaro'] = array( 'disponibile' => false );
	$chiaro           = array( '#f6f7f7', ds_core_ab_origine_wp() );
	foreach ( $pieni as $c ) {
		$l = ds_core_colore_luminanza( $c['hex'] );
		if ( ds_core_colore_neutro( $c['hex'] ) && $l >= 0.75 && $l < 0.99 ) {
			$chiaro = array( $c['hex'], ds_core_ab_origine_palette( $c ) );
			break;
		}
	}
	$candidati = array();
	if ( '' !== $accento['hex'] ) {
		$candidati[] = array( $accento['hex'], $accento['origine'] );
	}
	foreach ( $saturi as $c ) {
		$candidati[] = array( $c['hex'], ds_core_ab_origine_palette( $c ) );
	}
	foreach ( $candidati as $candidato ) {
		if ( ds_core_colore_contrasto( $candidato[0], $chiaro[0] ) >= 3 ) {
			$schemi['chiaro'] = $base( $chiaro[0], $chiaro[1], $candidato[0], $candidato[1] );
			break;
		}
	}

	// Menu scuro di WordPress con un accento alternativo.
	$schemi['secondo'] = array( 'disponibile' => false );
	if ( '' !== $accento['hex'] ) {
		foreach ( $saturi as $c ) {
			if ( $c['hex'] !== $accento['hex'] && ds_core_colore_contrasto( $c['hex'], $wp['menu'] ) >= 3 && ds_core_colore_distanza_tinta( $c['hex'], $accento['hex'] ) >= 40 ) {
				$schemi['secondo']                          = $base( $wp['menu'], ds_core_ab_origine_wp(), $c['hex'], ds_core_ab_origine_palette( $c ) );
				$schemi['secondo']['colori']['sottomenu']   = $wp['sottomenu'];
				$schemi['secondo']['colori']['menu_testo']  = $wp['menu_testo'];
				$schemi['secondo']['origini']['sottomenu']  = ds_core_ab_origine_wp();
				$schemi['secondo']['origini']['menu_testo'] = ds_core_ab_origine_wp();
				break;
			}
		}
	}

	// Predefinito di WordPress: nessun colore applicato.
	$origini_wp = array();
	foreach ( ds_core_ab_ruoli() as $ruolo ) {
		$origini_wp[ $ruolo ] = ds_core_ab_origine_wp();
	}
	$schemi['wordpress'] = array(
		'disponibile' => true,
		'colori'      => $wp,
		'origini'     => $origini_wp,
		'nomi'        => array(),
	);

	// Due schemi con gli stessi colori: resta il primo.
	$visti = array();
	foreach ( $schemi as $id => $schema ) {
		if ( empty( $schema['disponibile'] ) || 'wordpress' === $id ) {
			continue;
		}
		$firma = implode( ',', $schema['colori'] );
		if ( isset( $visti[ $firma ] ) ) {
			$schemi[ $id ] = array( 'disponibile' => false );
			continue;
		}
		$visti[ $firma ] = true;
	}
	return $schemi;
}

/** Codici degli schemi proposti, nell'ordine della griglia (sono anche le scelte del campo «schema» nel registro). */
function ds_core_ab_codici_schemi() {
	return array( 'sito', 'marchio', 'scuro', 'chiaro', 'secondo', 'wordpress' );
}

/**
 * Schema applicato: parte dallo schema proposto scelto, sostituisce i colori personalizzati e ricava quelli vuoti, poi
 * corregge per il contrasto. Stessa logica di risolviSchema() in assets/pannello.js. $valori: scelte del modulo
 * (schema e colori personalizzati); $schemi: ds_core_ab_schemi() (per le prove).
 * Restituisce array( 'attivo', 'schema' (codice usato), 'ruoli' => ruolo => array( 'hex' usato, 'voluto', 'scelto'
 * (personalizzato qui), 'origine', 'corretto' ), 'css' => colori calcolati per il foglio, 'contrasti' => numeri ).
 * 'attivo' false: nessuno schema (predefinito di WordPress scelto, o nessun accento).
 */
function ds_core_ab_risolvi( $valori, $schemi = null ) {
	$schemi = null === $schemi ? ds_core_ab_schemi() : $schemi;
	$codice = (string) ( $valori['schema'] ?? 'sito' );
	if ( empty( $schemi[ $codice ]['disponibile'] ) ) {
		$codice = 'sito'; // Schema salvato che con i colori di oggi non si può costruire.
	}
	$schema = $schemi[ $codice ];
	$scelti = array();
	foreach ( ds_core_ab_ruoli() as $ruolo ) {
		$v                = sanitize_hex_color( (string) ( $valori[ $ruolo ] ?? '' ) );
		$scelti[ $ruolo ] = $v ? strtolower( ds_core_colore_hex( ds_core_colore_rgb( $v ) ) ) : '';
	}
	$calcolo           = ds_core_ab_calcola( $schema['colori'], 'wordpress' === $codice ? array() : $scelti );
	$calcolo['schema'] = $codice;
	$calcolo['attivo'] = 'wordpress' !== $codice && '' !== $calcolo['ruoli']['accento']['voluto'];
	foreach ( ds_core_ab_ruoli() as $ruolo ) {
		$calcolo['ruoli'][ $ruolo ]['origine'] = '' !== $calcolo['ruoli'][ $ruolo ]['scelto'] ? array( 'tipo' => 'scelto' ) : ( '' !== (string) ( $schema['colori'][ $ruolo ] ?? '' ) ? $schema['origini'][ $ruolo ] : array( 'tipo' => 'derivato', 'da' => in_array( $ruolo, array( 'notifiche', 'link' ), true ) ? 'accento' : 'menu' ) );
	}
	return $calcolo;
}

/**
 * Calcolo dei colori da base e scelte (cuore di ds_core_ab_risolvi(), uguale a calcolaSchema() in pannello.js).
 * - menu: scelto o base (WordPress se vuoto); sottomenu e barra: scelti o base, altrimenti dal menu (sottomenu un po'
 *   più chiaro su un menu scuro, un po' più scuro su uno chiaro);
 * - testo del menu: scelto o base, altrimenti chiaro o scuro, quello più leggibile; portato a 4,5:1 sul menu (AA);
 *   testo del sottomenu e della barra portati a 4,5:1 sui loro fondi; icone a 3:1;
 * - accento: portato a 3:1 sul menu (si distingue dal menu, WCAG 1.4.11), poi testo bianco o scuro a 4,5:1 sopra
 *   (ds_core_colore_leggibile()); al passaggio del mouse sul sottomenu il colore portato a 4,5:1;
 * - notifiche: scelte o base, altrimenti l'accento; a 3:1 sul menu, testo a 4,5:1;
 * - link e pulsanti: scelti o base, altrimenti l'accento; link a 4,5:1 sullo sfondo della Bacheca (#f0f0f1),
 *   pulsante principale a 3:1 sullo sfondo con il testo a 4,5:1.
 */
function ds_core_ab_calcola( $base, $scelti ) {
	$wp = ds_core_ab_wordpress();
	$v  = function ( $ruolo ) use ( $base, $scelti ) {
		if ( ! empty( $scelti[ $ruolo ] ) ) {
			return $scelti[ $ruolo ];
		}
		$b = sanitize_hex_color( (string) ( $base[ $ruolo ] ?? '' ) );
		return $b ? strtolower( ds_core_colore_hex( ds_core_colore_rgb( $b ) ) ) : '';
	};
	$migliore = function ( $fondo ) {
		return ds_core_colore_contrasto( $fondo, '#f0f0f1' ) >= ds_core_colore_contrasto( $fondo, '#1d2327' ) ? '#f0f0f1' : '#1d2327';
	};

	$menu        = '' !== $v( 'menu' ) ? $v( 'menu' ) : $wp['menu'];
	$scuro       = ds_core_colore_luminanza( $menu ) < 0.18;
	$sottomenu   = '' !== $v( 'sottomenu' ) ? $v( 'sottomenu' ) : ds_core_colore_mescola( $menu, $scuro ? 'chiaro' : 'scuro', $scuro ? 0.07 : 0.05 );
	$barra       = '' !== $v( 'barra' ) ? $v( 'barra' ) : $menu;
	$testo_vol   = '' !== $v( 'menu_testo' ) ? $v( 'menu_testo' ) : $migliore( $menu );
	$menu_testo  = ds_core_colore_su( $testo_vol, $menu );
	$sotto_testo = ds_core_colore_su( $menu_testo, $sottomenu );
	$barra_testo = ds_core_colore_su( '' !== $v( 'menu_testo' ) ? $testo_vol : $migliore( $barra ), $barra );
	$icona       = ds_core_colore_su( ds_core_colore_verso( $menu_testo, $menu, 0.3 ), $menu, 3 );
	$icona_barra = ds_core_colore_su( ds_core_colore_verso( $barra_testo, $barra, 0.3 ), $barra, 3 );

	$acc_vol   = $v( 'accento' );
	$acc_base  = '' !== $acc_vol ? $acc_vol : $wp['accento'];
	$acc_menu  = ds_core_colore_su( $acc_base, $menu, 3 );
	$acc       = ds_core_colore_leggibile( $acc_menu );
	$su_sotto  = ds_core_colore_su( $acc_base, $sottomenu );
	$su_barra  = ds_core_colore_su( $acc_base, $sottomenu );

	$not_vol = '' !== $v( 'notifiche' ) ? $v( 'notifiche' ) : $acc_base;
	$not     = ds_core_colore_leggibile( ds_core_colore_su( $not_vol, $menu, 3 ) );

	$link_vol = '' !== $v( 'link' ) ? $v( 'link' ) : $acc_base;
	$link     = ds_core_colore_su( $link_vol, '#f0f0f1' );
	$puls     = ds_core_colore_leggibile( ds_core_colore_su( $link_vol, '#f0f0f1', 3 ) );

	$ruolo = function ( $hex, $voluto, $chiave ) use ( $scelti ) {
		return array(
			'hex'      => $hex,
			'voluto'   => $voluto,
			'scelto'   => (string) ( $scelti[ $chiave ] ?? '' ),
			'corretto' => '' !== $voluto && $hex !== $voluto,
		);
	};
	return array(
		'ruoli'     => array(
			'menu'       => $ruolo( $menu, $menu, 'menu' ),
			'menu_testo' => $ruolo( $menu_testo, $testo_vol, 'menu_testo' ),
			'accento'    => $ruolo( $acc['fondo'], $acc_vol, 'accento' ),
			'notifiche'  => $ruolo( $not['fondo'], $not_vol, 'notifiche' ),
			'link'       => $ruolo( $link, $link_vol, 'link' ),
			'sottomenu'  => $ruolo( $sottomenu, $sottomenu, 'sottomenu' ),
			'barra'      => $ruolo( $barra, $barra, 'barra' ),
		),
		'css'       => array(
			'menu'          => $menu,
			'menu-testo'    => $menu_testo,
			'menu-icona'    => $icona,
			'sotto'         => $sottomenu,
			'sotto-testo'   => $sotto_testo,
			'barra'         => $barra,
			'barra-testo'   => $barra_testo,
			'barra-icona'   => $icona_barra,
			'fondo'         => $acc['fondo'],
			'testo'         => $acc['testo'],
			'fondo-10'      => ds_core_colore_mescola( $acc['fondo'], '#ffffff' === $acc['testo'] ? 'scuro' : 'chiaro', 0.1 ),
			'su-sotto'      => $su_sotto,
			'su-barra'      => $su_barra,
			'badge'         => $not['fondo'],
			'badge-testo'   => $not['testo'],
			'link'          => $link,
			'link-10'       => ds_core_colore_mescola( $link, 'scuro', 0.15 ),
			'pulsante'      => $puls['fondo'],
			'pulsante-testo' => $puls['testo'],
			'pulsante-10'   => ds_core_colore_mescola( $puls['fondo'], '#ffffff' === $puls['testo'] ? 'scuro' : 'chiaro', 0.1 ),
			'pulsante-20'   => ds_core_colore_mescola( $puls['fondo'], '#ffffff' === $puls['testo'] ? 'scuro' : 'chiaro', 0.2 ),
		),
		'contrasti' => array(
			'menu'       => round( ds_core_colore_contrasto( $menu_testo, $menu ), 1 ),
			'sottomenu'  => round( ds_core_colore_contrasto( $sotto_testo, $sottomenu ), 1 ),
			'barra'      => round( ds_core_colore_contrasto( $barra_testo, $barra ), 1 ),
			'accento'    => $acc['rapporto'],
			'accento_menu' => round( ds_core_colore_contrasto( $acc['fondo'], $menu ), 1 ),
			'notifiche'  => $not['rapporto'],
			'link'       => round( ds_core_colore_contrasto( $link, '#f0f0f1' ), 1 ),
			'pulsante'   => $puls['rapporto'],
		),
	);
}

/*
 * Predefiniti calcolati dei moduli di DS Core: stanno qui e non nel file del modulo, perché servono anche a modulo
 * spento (il pannello mostra le scelte prima dell'accensione).
 */

/** aggiornamenti: plugin da aggiornare a mano finché non si sceglie diversamente, quelli che toccano le vendite. */
function ds_core_agg_manuali_predefiniti() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$manuali = array();
	foreach ( array_keys( get_plugins() ) as $file ) {
		$cartella = strtolower( dirname( $file ) );
		if ( 'woocommerce' === $cartella || 'ds-woo' === $cartella || preg_match( '/-site$/', $cartella )
			|| preg_match( '/(gateway|payment|pagament|stripe|paypal|satispay|klarna|scalapay|nexi|braintree|mollie|square)/', $cartella ) ) {
			$manuali[] = $file;
		}
	}
	return $manuali;
}

/*
 * Migrazioni dei dati salvati: una volta per versione, alla prima richiesta dopo l'aggiornamento dei file (i siti
 * ricevono i file senza riattivare il plugin, quindi niente register_activation_hook). Non cancellano nulla: le
 * vecchie chiavi restano finché il pannello non salva di nuovo quel gruppo, così si può tornare indietro.
 */
add_action( 'plugins_loaded', 'ds_core_migra', 1 );
function ds_core_migra() {
	$db = (string) get_option( 'ds_core_db', '' );
	if ( '' !== $db && version_compare( $db, DS_CORE_VERSIONE, '>=' ) ) {
		return;
	}

	// 0.13.0: l'indirizzo degli avvisi del modulo updates-safety-net diventa l'indirizzo unico di DS Core.
	if ( '' === $db || version_compare( $db, '0.13.0', '<' ) ) {
		$generali = get_option( 'ds_core_generali', array() );
		$generali = is_array( $generali ) ? $generali : array();
		$agg      = get_option( 'ds_core_agg', array() );
		if ( empty( $generali['avvisi'] ) && is_array( $agg ) && ! empty( $agg['avvisi'] ) && is_email( $agg['avvisi'] ) ) {
			// Indirizzo già scelto da un amministratore: vale come confermato (dalla 0.15.0 passa dalla guardia).
			ds_core_avvisi_scrivi_confermato( $agg['avvisi'] );
		}
	}

	/*
	 * 0.15.0: l'indirizzo degli avvisi salvato con la 0.13/0.14 resta valido senza conferma (è già in
	 * ds_core_generali['avvisi'], niente da copiare). Registro delle attività: la conservazione passa da numero libero
	 * a scelta 30 / 90 / 365 / personalizzato; un numero salvato diverso dai tre diventa «personalizzato» (7-730).
	 */
	if ( '' === $db || version_compare( $db, '0.15.0', '<' ) ) {
		$ra = get_option( 'ds_core_ra', false );
		if ( is_array( $ra ) && isset( $ra['giorni'] ) && ! isset( $ra['conserva'] ) ) {
			$ra = array_merge( $ra, ds_core_eventi_conserva_da_giorni( $ra['giorni'] ) );
			update_option( 'ds_core_ra', $ra, false );
		}
	}

	// 0.17.0: ID dei moduli in inglese (decisione di Daniele del 27/11/2026).
	if ( '' === $db || version_compare( $db, '0.17.0', '<' ) ) {
		ds_core_migra_id();
	}

	/*
	 * 0.18.2: admin-branding con gli schemi colori. Il colore scelto nella 0.18.0/0.18.1 (campo «colore», sostituiva il
	 * Brand di Breakdance) diventa l'accento personalizzato dello schema «Dal sito»; il resto delle scelte resta.
	 */
	if ( '' === $db || version_compare( $db, '0.18.2', '<' ) ) {
		$ab = get_option( 'ds_core_ab', false );
		if ( is_array( $ab ) && array_key_exists( 'colore', $ab ) ) {
			$colore = sanitize_hex_color( (string) $ab['colore'] );
			if ( $colore && empty( $ab['accento'] ) ) {
				$ab['accento'] = strtolower( $colore );
			}
			if ( empty( $ab['schema'] ) ) {
				$ab['schema'] = 'sito';
			}
			unset( $ab['colore'] );
			update_option( 'ds_core_ab', $ab, false );
		}
	}

	update_option( 'ds_core_db', DS_CORE_VERSIONE, true );
}

/**
 * Migrazione della 0.17.0: i dati salvati con i vecchi ID italiani dei moduli passano agli ID inglesi
 * (ds_core_id_rinominati(), includes/registro.php). Si può rifare quante volte si vuole con lo stesso risultato
 * (idempotente): copia o rinomina solo ciò che ha ancora il vecchio ID e non ha già il nuovo.
 *
 * - ds_core_stati (scelte del pannello): lo stato si COPIA sotto l'ID nuovo e quello vecchio resta. Se WordPress
 *   rimette la versione precedente (ritorno automatico dopo un aggiornamento fallito) la 0.16.x ritrova i suoi stati:
 *   nessun modulo si spegne. Le chiavi vecchie non le legge più nessuno; si toglieranno in una versione successiva.
 *   Se l'ID nuovo ha già uno stato, vince quello (scelta fatta dopo l'aggiornamento).
 * - ds_core_errori (errori di caricamento): la chiave si rinomina.
 * - ds_core_storia (ultime modifiche del pannello): l'ID della riga si rinomina.
 * - Registro delle attività (tabella ds_core_eventi, se esiste): origine e oggetto delle righe con un vecchio ID.
 * - Opzioni dei moduli (ds_core_accesso, ds_core_agg, ds_core_ra…): il nome non contiene l'ID, restano come sono.
 * - Eventi pianificati (ds_core_agg_riepilogo, ds_core_ra_pulizia…): non contengono ID, restano come sono.
 * - .htaccess: il blocco «DS Core header-dati» resta leggibile e si rinomina alla prima scrittura del modulo
 *   security-headers da una pagina di amministrazione (includes/htaccess.php): la migrazione gira anche sul sito
 *   pubblico, dove DS Core non scrive mai il .htaccess.
 * - DS_CORE_SPENTI in wp-config.php: non si tocca, accetta vecchi e nuovi ID (includes/caricatore.php).
 */
function ds_core_migra_id() {
	global $wpdb;
	$mappa = ds_core_id_rinominati();

	$stati = get_option( 'ds_core_stati', array() );
	if ( is_array( $stati ) ) {
		$dopo = $stati;
		foreach ( $mappa as $vecchio => $nuovo ) {
			if ( isset( $stati[ $vecchio ] ) && ! isset( $stati[ $nuovo ] ) ) {
				$dopo[ $nuovo ] = $stati[ $vecchio ];
			}
		}
		if ( $dopo !== $stati ) {
			update_option( 'ds_core_stati', $dopo, true );
		}
	}

	$errori = get_option( 'ds_core_errori', array() );
	if ( is_array( $errori ) && $errori ) {
		$dopo = array();
		foreach ( $errori as $id => $errore ) {
			$nuovo = ds_core_id_attuale( $id );
			if ( ! isset( $dopo[ $nuovo ] ) || $nuovo === $id ) {
				$dopo[ $nuovo ] = $errore;
			}
		}
		if ( $dopo !== $errori ) {
			update_option( 'ds_core_errori', $dopo, true );
		}
	}

	$storia = get_option( 'ds_core_storia', array() );
	if ( is_array( $storia ) && $storia ) {
		$dopo = $storia;
		foreach ( $dopo as $n => $riga ) {
			if ( is_array( $riga ) && isset( $riga['id'] ) && isset( $mappa[ (string) $riga['id'] ] ) ) {
				$dopo[ $n ]['id'] = $mappa[ (string) $riga['id'] ];
			}
		}
		if ( $dopo !== $storia ) {
			update_option( 'ds_core_storia', $dopo, false );
		}
	}

	// Registro delle attività: una query sola, solo se la tabella esiste (anche a modulo spento, finché ha righe).
	if ( function_exists( 'ds_core_eventi_pronta' ) && ds_core_eventi_pronta() ) {
		$tabella  = ds_core_eventi_tabella();
		$casi     = '';
		$valori   = array();
		foreach ( $mappa as $vecchio => $nuovo ) {
			$casi    .= ' WHEN %s THEN %s';
			$valori[] = $vecchio;
			$valori[] = $nuovo;
		}
		$segnaposti = implode( ',', array_fill( 0, count( $mappa ), '%s' ) );
		$vecchi     = array_keys( $mappa );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders -- tabella propria, segnaposti costruiti dall'elenco fisso.
		$sql = $wpdb->prepare(
			"UPDATE {$tabella} SET origine = CASE origine{$casi} ELSE origine END, oggetto = CASE oggetto{$casi} ELSE oggetto END WHERE origine IN ({$segnaposti}) OR oggetto IN ({$segnaposti})",
			array_merge( $valori, $valori, $vecchi, $vecchi )
		);
		$errori_db = $wpdb->suppress_errors( true );
		$wpdb->query( $sql );
		$wpdb->suppress_errors( $errori_db );
		// phpcs:enable
	}
}

<?php
/**
 * Modulo admin-branding («Brand colors», dalla 0.18.0; docs/ds-core-analisi-pannello-ux.md §3, decisioni di Daniele
 * del 27/11/2026). Solo aspetto, nessun dato cambiato: spento il modulo, tutto torna com'era.
 *
 * 1.2.0 (DS Core 0.18.2), schemi colori completi e personalizzabili (decisioni di Daniele del 27/11/2026):
 * - Schemi proposti come quelli del profilo utente di WordPress, ma costruiti dai colori del sito (ds_core_ab_schemi()
 *   in includes/opzioni.php): «Dal sito (Breakdance)», fino a quattro combinazioni della palette di Breakdance e
 *   «Predefinito di WordPress» per tornare indietro. Scelto uno schema, ogni colore si cambia nel pannello: sfondo del
 *   menu, testo del menu, evidenza (voce attiva), notifiche, link e pulsanti, sottomenu e barra in alto (facoltativi,
 *   dal menu se vuoti). Risoluzione e correzioni del contrasto in ds_core_ab_risolvi() (stessa logica nell'anteprima
 *   dal vivo di assets/pannello.js).
 * - Accento automatico (ds_core_ab_accento_auto()): «Brand» di Breakdance spesso è il colore dei testi (nero), non
 *   l'accento del marchio. Se Brand è neutro o non si distingue dal menu scuro (sotto 3:1), si cercano in ordine Links
 *   colorato, il colore della palette con «brand» nel nome, il primo colore saturo e pieno della palette; altrimenti
 *   nessuno schema (resta quello di WordPress).
 * - Bacheca: schema colori di WordPress «Site brand» (wp_admin_css_color, slug ds-brand) applicato a tutto
 *   l'amministrazione come gli schemi nativi: menu, sottomenu, barra in alto, voce attiva, badge, pulsanti principali,
 *   link, fuoco. Il foglio assets/admin-branding.css usa variabili CSS; i valori li scrive qui un blocco in linea sul
 *   foglio 'colors'. Applicato come predefinito a tutti (filtro get_user_option_admin_color, la scelta nel profilo
 *   sparisce); con «Let each user keep…» chi ha scelto un altro schema nel profilo lo tiene.
 * - Editor a blocchi: --wp-admin-theme-color (e le sue tonalità) nel colore dei link, per pulsanti e selezioni.
 * - Scelta «Black text in the block editor» (riga 12 di docs/ds-core-analisi-mc-funzioni.md): testo nero nell'area di
 *   scrittura, anche nell'editor in iframe (enqueue_block_assets, solo in amministrazione).
 * - Pagina di accesso (scelta spenta di base, versione leggera): solo CSS su login_enqueue_scripts, logo del sito al
 *   posto di quello di WordPress, link del logo verso il sito, pulsanti e link nei colori dello schema. Nessun cambio a
 *   indirizzo, campi, passaggi o protezioni; nessuna risorsa esterna.
 */

defined( 'ABSPATH' ) || exit;

const DS_CORE_AB_SCHEMA = 'ds-brand';

/** Scelte del modulo. */
function ds_core_ab_valori() {
	return ds_core_opzioni_modulo( 'admin-branding' );
}

/** Schema applicato (ds_core_ab_risolvi()), una volta per richiesta. */
function ds_core_ab_calcolo() {
	static $calcolo = null;
	if ( null === $calcolo ) {
		$calcolo = ds_core_ab_risolvi( ds_core_ab_valori() );
	}
	return $calcolo;
}

/** C'è uno schema da applicare: no con «Predefinito di WordPress» o senza un colore per l'evidenza. */
function ds_core_ab_attivo() {
	return ds_core_ab_calcolo()['attivo'];
}

/** Colori calcolati per il foglio (#rrggbb), o null senza schema. */
function ds_core_ab_tavolozza() {
	return ds_core_ab_attivo() ? ds_core_ab_calcolo()['css'] : null;
}

/* ---------- Schema colori della Bacheca ---------- */

add_action( 'admin_init', 'ds_core_ab_registra' );
function ds_core_ab_registra() {
	$t = ds_core_ab_tavolozza();
	if ( ! $t ) {
		return; // Nessuno schema: la scelta nel profilo resta.
	}
	wp_admin_css_color(
		DS_CORE_AB_SCHEMA,
		__( 'Site brand', 'ds-core' ),
		DS_CORE_URL . 'assets/admin-branding.css?ver=' . rawurlencode( DS_CORE_VERSIONE ),
		array( $t['menu'], $t['sotto'], $t['fondo'], $t['badge'] ),
		array(
			'base'    => $t['menu-icona'],
			'focus'   => $t['su-sotto'],
			'current' => $t['testo'],
		)
	);
	// Schema imposto a tutti: la scelta nel profilo non servirebbe, quindi non si mostra.
	if ( empty( ds_core_ab_valori()['propri'] ) ) {
		remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
	}
}

/**
 * Schema di ogni utente: «Site brand», salvo la scelta «Let each user keep…» e un altro schema scelto nel profilo
 * («fresh», il predefinito di WordPress, non conta come scelta). Senza schema quello di ognuno resta com'è (chi aveva
 * salvato «Site brand» nel profilo torna al predefinito di WordPress).
 */
add_filter( 'get_user_option_admin_color', 'ds_core_ab_schema_utente', 10, 1 );
function ds_core_ab_schema_utente( $schema ) {
	if ( ! ds_core_ab_attivo() ) {
		return DS_CORE_AB_SCHEMA === $schema ? 'fresh' : $schema;
	}
	if ( ! empty( ds_core_ab_valori()['propri'] ) && is_string( $schema ) && '' !== $schema && 'fresh' !== $schema ) {
		return $schema;
	}
	return DS_CORE_AB_SCHEMA;
}

/** Variabili CSS dello schema (per il foglio e per l'editor a blocchi). Solo colori #rrggbb e numeri. */
function ds_core_ab_css_variabili() {
	$t = ds_core_ab_tavolozza();
	if ( ! $t ) {
		return '';
	}
	$variabili = '';
	foreach ( $t as $nome => $colore ) {
		$colore = sanitize_hex_color( (string) $colore );
		if ( $colore ) {
			$variabili .= '--ds-ab-' . sanitize_key( $nome ) . ':' . $colore . ';';
		}
	}
	$rgb = ds_core_colore_rgb( $t['link'] );
	$wp  = '--wp-admin-theme-color:' . $t['link'] . ';--wp-admin-theme-color--rgb:' . implode( ',', array_map( 'intval', (array) $rgb ) ) . ';--wp-admin-theme-color-darker-10:' . ds_core_colore_mescola( $t['link'], 'scuro', 0.1 ) . ';--wp-admin-theme-color-darker-20:' . ds_core_colore_mescola( $t['link'], 'scuro', 0.2 ) . ';';
	return ':root{' . $variabili . $wp . '}body.admin-color-' . DS_CORE_AB_SCHEMA . '{' . $wp . '}';
}

add_action( 'admin_enqueue_scripts', 'ds_core_ab_variabili' );
function ds_core_ab_variabili() {
	if ( ! ds_core_ab_attivo() || DS_CORE_AB_SCHEMA !== get_user_option( 'admin_color' ) ) {
		return;
	}
	wp_add_inline_style( 'colors', ds_core_ab_css_variabili() );
}

/*
 * Barra in alto sul sito pubblico (utenti collegati): WordPress carica lì solo admin-bar.css, non lo schema. Si
 * colorano sfondo, testo e badge come in amministrazione, solo per chi vede lo schema.
 */
add_action( 'wp_enqueue_scripts', 'ds_core_ab_barra_sito' );
function ds_core_ab_barra_sito() {
	if ( ! is_admin_bar_showing() || ! ds_core_ab_attivo() || DS_CORE_AB_SCHEMA !== get_user_option( 'admin_color' ) ) {
		return;
	}
	$t = ds_core_ab_tavolozza();
	wp_add_inline_style(
		'admin-bar',
		'#wpadminbar{background:' . $t['barra'] . ';color:' . $t['barra-testo'] . '}#wpadminbar .ab-item,#wpadminbar a.ab-item,#wpadminbar>#wp-toolbar span.ab-label{color:' . $t['barra-testo'] . '}'
		. '#wpadminbar .ab-icon,#wpadminbar .ab-icon:before,#wpadminbar .ab-item:before,#wpadminbar .ab-item:after{color:' . $t['barra-icona'] . '}'
		. '#wpadminbar .menupop .ab-sub-wrapper{background:' . $t['sotto'] . '}#wpadminbar .quicklinks .menupop ul li a{color:' . $t['sotto-testo'] . '}'
		. '#wpadminbar:not(.mobile) .ab-top-menu>li:hover>.ab-item,#wpadminbar .ab-top-menu>li>.ab-item:focus,#wpadminbar .quicklinks .menupop ul li a:hover,#wpadminbar .quicklinks .menupop ul li a:focus{background:' . $t['sotto'] . ';color:' . $t['su-sotto'] . '}'
		. '#wpadminbar .ab-label.awaiting-mod,#wpadminbar .updates-available-count,#wpadminbar #wp-admin-bar-updates .ab-label{background:' . $t['badge'] . ';color:' . $t['badge-testo'] . '}'
	);
}

/* ---------- Editor a blocchi: testo nero (scelta) ---------- */

add_action( 'enqueue_block_assets', 'ds_core_ab_editor' );
function ds_core_ab_editor() {
	if ( ! is_admin() || empty( ds_core_ab_valori()['editor_nero'] ) ) {
		return;
	}
	// Nessun file: solo il blocco in linea, che WordPress porta anche dentro l'editor in iframe.
	wp_register_style( 'ds-core-ab-editor', false, array(), DS_CORE_VERSIONE );
	wp_enqueue_style( 'ds-core-ab-editor' );
	wp_add_inline_style( 'ds-core-ab-editor', '.editor-styles-wrapper,.editor-styles-wrapper.block-editor-writing-flow{color:#000 !important}' );
}

/* ---------- Pagina di accesso (scelta, spenta di base) ---------- */

/** La scelta «Show the site logo and the scheme colors on the login page» è accesa. */
function ds_core_ab_login_acceso() {
	return ! empty( ds_core_ab_valori()['login'] );
}

/** Immagine del logo per la pagina di accesso: logo del tema, poi icona del sito; '' se nessuna. */
function ds_core_ab_logo() {
	$logo = (int) get_theme_mod( 'custom_logo' );
	if ( $logo ) {
		$immagine = wp_get_attachment_image_src( $logo, 'medium' );
		if ( is_array( $immagine ) && ! empty( $immagine[0] ) ) {
			return (string) $immagine[0];
		}
	}
	return (string) get_site_icon_url( 192 );
}

add_action( 'login_enqueue_scripts', 'ds_core_ab_login_stile' );
function ds_core_ab_login_stile() {
	if ( ! ds_core_ab_login_acceso() ) {
		return;
	}
	$t    = ds_core_ab_tavolozza();
	$logo = esc_url_raw( ds_core_ab_logo() );
	$css  = '';
	if ( '' !== $logo ) {
		// esc_url_raw toglie virgolette, barre rovesciate e parentesi angolari: l'indirizzo non può uscire da url("…").
		$css .= '.login h1 a{background-image:url("' . $logo . '");background-size:contain;background-position:center;width:100%;max-width:320px;height:84px}';
	} else {
		// Niente logo né icona: il titolo del sito come testo, al posto del logo di WordPress.
		$css .= '.login h1 a{background-image:none;text-indent:0;width:auto;height:auto;font-size:22px;line-height:1.3;font-weight:600;color:#1d2327;overflow:visible}';
	}
	if ( ! $t ) {
		wp_add_inline_style( 'login', $css ); // Nessuno schema: solo il logo, colori di WordPress.
		return;
	}
	$css .= '.login form{border-top:4px solid ' . $t['fondo'] . '}';
	$css .= '.wp-core-ui .button-primary{background:' . $t['pulsante'] . ';border-color:' . $t['pulsante'] . ';color:' . $t['pulsante-testo'] . '}';
	$css .= '.wp-core-ui .button-primary:hover,.wp-core-ui .button-primary:focus{background:' . $t['pulsante-10'] . ';border-color:' . $t['pulsante-10'] . ';color:' . $t['pulsante-testo'] . '}';
	$css .= '.wp-core-ui .button-primary:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px ' . $t['link'] . '}';
	$css .= '.wp-core-ui .button-secondary,.login .button.wp-hide-pw{color:' . $t['link'] . '}';
	$css .= '.login #nav a:hover,.login #backtoblog a:hover,.login h1 a:focus,.login a:focus{color:' . $t['link'] . '}';
	$css .= '.login input[type=text]:focus,.login input[type=password]:focus,.login input[type=email]:focus,.login input[type=checkbox]:focus{border-color:' . $t['link'] . ';box-shadow:0 0 0 1px ' . $t['link'] . '}';
	$css .= '.login .message,.login .notice-info{border-left-color:' . $t['link'] . '}';
	wp_add_inline_style( 'login', $css );
}

add_filter( 'login_headerurl', 'ds_core_ab_login_url' );
function ds_core_ab_login_url( $url ) {
	return ds_core_ab_login_acceso() ? home_url( '/' ) : $url;
}

add_filter( 'login_headertext', 'ds_core_ab_login_testo' );
function ds_core_ab_login_testo( $testo ) {
	return ds_core_ab_login_acceso() ? wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) : $testo;
}

/* ---------- Pannello ---------- */

/** Stato a parole per la riga di riepilogo (solo nel pannello, dopo init). */
function ds_core_ab_riepilogo() {
	$calcolo = ds_core_ab_calcolo();
	if ( 'wordpress' === $calcolo['schema'] ) {
		return __( 'WordPress default scheme: no colors applied', 'ds-core' );
	}
	if ( ! $calcolo['attivo'] ) {
		return __( 'No highlight color found: choose one. Until then each user keeps their WordPress color scheme', 'ds-core' );
	}
	/* translators: %s: name of the color scheme. */
	return sprintf( __( '“%s” on', 'ds-core' ), ds_core_ab_nome_schema( $calcolo['schema'], ds_core_ab_schemi() ) );
}

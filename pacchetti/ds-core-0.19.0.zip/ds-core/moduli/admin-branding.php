<?php
/**
 * Modulo admin-branding («Brand colors», dalla 0.18.0; docs/ds-core-analisi-pannello-ux.md §3). Solo aspetto, nessun
 * dato cambiato: spento il modulo, tutto torna com'era.
 *
 * 1.3.0 (DS Core 0.19.0), versione leggera (decisione di Daniele del 27/11/2026: «schemi colori e personalizzazione
 * stile WordPress, più orientati al branding, senza incasinarci con i parametri di Breakdance; è solo estetica»):
 * - Bacheca: uno schema colori di WordPress («Site brand», wp_admin_css_color, slug ds-brand) con lo stesso ambito e lo
 *   stesso comportamento degli schemi nativi: assets/admin-branding.css sono le regole di wp-admin/css/colors/_admin.scss
 *   di WordPress 7.1 senza modifiche, con le variabili Sass diventate variabili CSS. Nessuna regola propria, anche al
 *   passaggio del mouse (Daniele, 27/11: «le modifiche del mouse hover vorrei che rimanessero native»): come in Modern e
 *   Blue, la voce del menu sotto il mouse prende il fondo dell'evidenza, la voce attiva si riconosce dal sottomenu aperto
 *   e dalla freccia verso la pagina.
 * - Pochi colori (menu, evidenza, notifiche, testo del menu facoltativo), il resto derivato come in _variables.scss e
 *   portato a un contrasto leggibile (ds_core_ab_variabili(), includes/opzioni.php). Schemi proposti costruiti
 *   sull'evidenza; Breakdance serve solo a suggerirla (ds_core_ab_suggerito()), altrimenti il blu di WordPress.
 * - --wp-admin-theme-color (pulsanti, caselle e campi in WordPress 7) come WordPress lo dà ai suoi schemi in
 *   admin-schemes.css: su body.admin-color-ds-brand, nello stesso blocco dello schema. Nessuna regola per l'editor a
 *   blocchi né per la barra in alto sul sito pubblico (gli schemi nativi non la colorano).
 * - Scelte che restano: «Let each user keep…» (spenta), testo nero nell'editor a blocchi, pagina di accesso (spenta).
 */

defined( 'ABSPATH' ) || exit;

const DS_CORE_AB_SCHEMA = 'ds-brand';

/** Scelte del modulo. */
function ds_core_ab_valori() {
	return ds_core_opzioni_modulo( 'admin-branding' );
}

/** Schema applicato (ds_core_ab_risolvi()), una volta per richiesta. */
function ds_core_ab_calcolo() {
	static $calcolo = null;
	if ( null === $calcolo ) {
		$calcolo = ds_core_ab_risolvi( ds_core_ab_valori() );
	}
	return $calcolo;
}

/** C'è uno schema da applicare: no con «WordPress default». */
function ds_core_ab_attivo() {
	return ds_core_ab_calcolo()['attivo'];
}

/* ---------- Schema colori della Bacheca ---------- */

/*
 * WordPress carica il foglio dello schema con l'handle «colors» e la propria versione (?ver=<WordPress>): dopo un
 * aggiornamento di DS Core il browser teneva il foglio vecchio in cache (danielesmiderle.it, 27/11/2026). La versione
 * diventa quella di DS Core più la data del file (dalla 0.18.3).
 */
add_filter( 'style_loader_src', 'ds_core_ab_versione_foglio', 10, 2 );
function ds_core_ab_versione_foglio( $src, $handle ) {
	if ( 'colors' !== $handle || ! is_string( $src ) || false === strpos( $src, 'assets/admin-branding' ) ) {
		return $src;
	}
	$file = DS_CORE_DIR . 'assets/' . ( is_rtl() ? 'admin-branding-rtl.css' : 'admin-branding.css' );
	$data = file_exists( $file ) ? (string) filemtime( $file ) : '';
	return add_query_arg( 'ver', rawurlencode( DS_CORE_VERSIONE . ( '' !== $data ? '-' . $data : '' ) ), remove_query_arg( 'ver', $src ) );
}

add_action( 'admin_init', 'ds_core_ab_registra' );
function ds_core_ab_registra() {
	if ( ! ds_core_ab_attivo() ) {
		return; // Nessuno schema: la scelta nel profilo resta.
	}
	$v = ds_core_ab_calcolo()['var'];
	wp_admin_css_color(
		DS_CORE_AB_SCHEMA,
		__( 'Site brand', 'ds-core' ),
		DS_CORE_URL . 'assets/admin-branding.css?ver=' . rawurlencode( DS_CORE_VERSIONE ),
		array( $v['menu-background'], $v['menu-submenu-background'], $v['menu-highlight-background'], $v['menu-bubble-background'] ),
		array(
			'base'    => $v['menu-icon'],
			'focus'   => $v['menu-highlight-icon'],
			'current' => $v['menu-current-icon'],
		)
	);
	// Schema imposto a tutti: la scelta nel profilo non servirebbe, quindi non si mostra.
	if ( empty( ds_core_ab_valori()['propri'] ) ) {
		remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
	}
}

/**
 * Schema di ogni utente: «Site brand», salvo la scelta «Let each user keep…» e un altro schema scelto nel profilo.
 * Non contano come scelta il valore vuoto, «modern» (predefinito di WordPress 7) e «fresh» (predefinito fino alla 6.9,
 * salvato su molti utenti vecchi). Senza schema chi aveva «Site brand» torna al predefinito di WordPress.
 */
add_filter( 'get_user_option_admin_color', 'ds_core_ab_schema_utente', 10, 1 );
function ds_core_ab_schema_utente( $schema ) {
	if ( ! ds_core_ab_attivo() ) {
		return DS_CORE_AB_SCHEMA === $schema ? '' : $schema;
	}
	if ( ! empty( ds_core_ab_valori()['propri'] ) && is_string( $schema ) && ! in_array( $schema, array( '', 'modern', 'fresh', DS_CORE_AB_SCHEMA ), true ) ) {
		return $schema;
	}
	return DS_CORE_AB_SCHEMA;
}

/**
 * Valori dello schema per il foglio: le variabili --ds-ab-* (nomi di _variables.scss) e, su body.admin-color-ds-brand,
 * --wp-admin-theme-color con le tonalità più scure come le scrive WordPress per i suoi schemi (admin-schemes.css:
 * darker-10 = luminosità -5%, darker-20 = -10%; bordo del fuoco 2px, 1,5px sugli schermi ad alta densità).
 * Solo colori #rrggbb e numeri.
 */
function ds_core_ab_css_variabili() {
	if ( ! ds_core_ab_attivo() ) {
		return '';
	}
	$v         = ds_core_ab_calcolo()['var'];
	$variabili = '';
	foreach ( $v as $nome => $colore ) {
		$colore = is_string( $colore ) ? sanitize_hex_color( $colore ) : '';
		if ( $colore && 0 !== strpos( $nome, 'tema' ) ) {
			$variabili .= '--ds-ab-' . sanitize_key( $nome ) . ':' . $colore . ';';
		}
	}
	$rgb  = function ( $hex ) {
		return implode( ', ', array_map( 'intval', (array) ds_core_colore_rgb( $hex ) ) );
	};
	$tema = '--wp-admin-theme-color:' . $v['tema'] . ';--wp-admin-theme-color--rgb:' . $rgb( $v['tema'] )
		. ';--wp-admin-theme-color-darker-10:' . $v['tema-scuro5'] . ';--wp-admin-theme-color-darker-10--rgb:' . $rgb( $v['tema-scuro5'] )
		. ';--wp-admin-theme-color-darker-20:' . $v['tema-scuro10'] . ';--wp-admin-theme-color-darker-20--rgb:' . $rgb( $v['tema-scuro10'] )
		. ';--wp-admin-border-width-focus:2px;';
	$body = 'body.admin-color-' . DS_CORE_AB_SCHEMA;
	return ':root{' . $variabili . '}' . $body . '{' . $tema . '}@media (min-resolution:192dpi){' . $body . '{--wp-admin-border-width-focus:1.5px;}}';
}

add_action( 'admin_enqueue_scripts', 'ds_core_ab_variabili_in_linea' );
function ds_core_ab_variabili_in_linea() {
	if ( ! ds_core_ab_attivo() || DS_CORE_AB_SCHEMA !== get_user_option( 'admin_color' ) ) {
		return;
	}
	wp_add_inline_style( 'colors', ds_core_ab_css_variabili() );
}

/* ---------- Editor a blocchi: testo nero (scelta) ---------- */

add_action( 'enqueue_block_assets', 'ds_core_ab_editor' );
function ds_core_ab_editor() {
	if ( ! is_admin() || empty( ds_core_ab_valori()['editor_nero'] ) ) {
		return;
	}
	// Nessun file: solo il blocco in linea, che WordPress porta anche dentro l'editor in iframe.
	wp_register_style( 'ds-core-ab-editor', false, array(), DS_CORE_VERSIONE );
	wp_enqueue_style( 'ds-core-ab-editor' );
	wp_add_inline_style( 'ds-core-ab-editor', '.editor-styles-wrapper,.editor-styles-wrapper.block-editor-writing-flow{color:#000 !important}' );
}

/* ---------- Pagina di accesso (scelta, spenta di base) ---------- */

/** La scelta «Show the site logo and the scheme colors on the login page» è accesa. */
function ds_core_ab_login_acceso() {
	return ! empty( ds_core_ab_valori()['login'] );
}

/** Immagine del logo per la pagina di accesso: logo del tema, poi icona del sito; '' se nessuna. */
function ds_core_ab_logo() {
	$logo = (int) get_theme_mod( 'custom_logo' );
	if ( $logo ) {
		$immagine = wp_get_attachment_image_src( $logo, 'medium' );
		if ( is_array( $immagine ) && ! empty( $immagine[0] ) ) {
			return (string) $immagine[0];
		}
	}
	return (string) get_site_icon_url( 192 );
}

add_action( 'login_enqueue_scripts', 'ds_core_ab_login_stile' );
function ds_core_ab_login_stile() {
	if ( ! ds_core_ab_login_acceso() ) {
		return;
	}
	$logo = esc_url_raw( ds_core_ab_logo() );
	$css  = '';
	if ( '' !== $logo ) {
		// esc_url_raw toglie virgolette, barre rovesciate e parentesi angolari: l'indirizzo non può uscire da url("…").
		$css .= '.login h1 a{background-image:url("' . $logo . '");background-size:contain;background-position:center;width:100%;max-width:320px;height:84px}';
	} else {
		// Niente logo né icona: il titolo del sito come testo, al posto del logo di WordPress.
		$css .= '.login h1 a{background-image:none;text-indent:0;width:auto;height:auto;font-size:22px;line-height:1.3;font-weight:600;color:#1d2327;overflow:visible}';
	}
	if ( ds_core_ab_attivo() ) {
		// Come nella Bacheca: colore dei pulsanti e dei campi (--wp-admin-theme-color, più il pulsante principale scritto
		// per esteso), link nel colore dei link dello schema.
		$v    = ds_core_ab_calcolo()['var'];
		$css .= 'body.login{--wp-admin-theme-color:' . $v['tema'] . ';--wp-admin-theme-color-darker-10:' . $v['tema-scuro5'] . ';--wp-admin-theme-color-darker-20:' . $v['tema-scuro10'] . '}';
		$css .= '.login form{border-top:4px solid ' . $v['menu-background'] . '}';
		$css .= '.wp-core-ui .button-primary{background:' . $v['tema'] . ';border-color:' . $v['tema'] . ';color:#fff}';
		$css .= '.wp-core-ui .button-primary:hover,.wp-core-ui .button-primary:focus{background:' . $v['tema-scuro5'] . ';border-color:' . $v['tema-scuro5'] . ';color:#fff}';
		$css .= '.login #nav a:hover,.login #backtoblog a:hover,.login a:focus{color:' . $v['link'] . '}';
	}
	wp_add_inline_style( 'login', $css );
}

add_filter( 'login_headerurl', 'ds_core_ab_login_url' );
function ds_core_ab_login_url( $url ) {
	return ds_core_ab_login_acceso() ? home_url( '/' ) : $url;
}

add_filter( 'login_headertext', 'ds_core_ab_login_testo' );
function ds_core_ab_login_testo( $testo ) {
	return ds_core_ab_login_acceso() ? wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) : $testo;
}

/* ---------- Pannello ---------- */

/** Stato a parole per la riga di riepilogo (solo nel pannello, dopo init). */
function ds_core_ab_riepilogo() {
	$calcolo = ds_core_ab_calcolo();
	if ( ! $calcolo['attivo'] ) {
		return __( 'WordPress default scheme: no colors applied', 'ds-core' );
	}
	/* translators: %s: name of the color scheme. */
	return sprintf( __( '“%s” on', 'ds-core' ), ds_core_ab_nome_schema( $calcolo['schema'] ) );
}

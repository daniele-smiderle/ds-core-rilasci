<?php
/**
 * Registro dei moduli.
 *
 * Due parti, perché i moduli si caricano su plugins_loaded, prima che WordPress carichi le traduzioni (init):
 * - dati tecnici (file, categoria, stato predefinito, dipendenze…): ds_core_registro(), usato dal caricatore;
 * - testi visibili (titolo, descrizione, avviso, tag), tradotti: ds_core_registro_con_testi(), usato solo dal
 *   pannello, dopo init.
 *
 * I moduli di DS Core sono in ds_core_registro_core() (dati) e ds_core_testi_core() (testi). DS Woo e i plugin dei
 * siti («DS XX», cartella <xx>-site, kb ARCH-10) aggiungono i loro con il filtro 'ds_core_registro', dal file
 * principale del loro plugin:
 *
 *   add_filter( 'ds_core_registro', function ( $moduli ) {
 *       $moduli['my-module'] = array(
 *           'origine'    => 'DS XX',                             // facoltativo, vedi sotto
 *           'file'       => __DIR__ . '/modules/my-module.php',  // percorso completo
 *           'categoria'  => 'site',
 *           'modificato' => '2026-11-26',
 *           // Testi: una funzione chiamata solo dal pannello, quando le traduzioni sono caricate.
 *           'testi'      => function () {
 *               return array(
 *                   'titolo'      => __( 'My module', 'ds-xx' ),
 *                   'descrizione' => __( 'What it does.', 'ds-xx' ),
 *                   'avviso'      => __( 'What happens when it is off.', 'ds-xx' ),
 *                   'tag'         => array( __( 'cart', 'ds-xx' ) ),
 *               );
 *           },
 *           // gli altri campi come sotto
 *       );
 *       return $moduli;
 *   } );
 *
 * I testi si possono dare anche come semplici campi 'titolo', 'descrizione', 'avviso', 'tag' (senza traduzione).
 *
 * Senza 'origine', il pannello mostra il nome del plugin che contiene il file del modulo (intestazione «Plugin
 * Name» del plugin attivo nella stessa cartella); se non si ricava, «External».
 *
 * Le pagine di impostazioni di DS Woo e dei plugin dei siti vanno sotto il menu unico «DS Core» (kb ARCH-10), non in
 * un menu loro. Vedi il commento in cima a includes/pannello.php.
 *
 * Se un plugin registra un modulo con lo stesso ID di uno di DS Core, vale il suo e DS Core salta il proprio
 * (kb ARCH-07: una funzione passa dal sito a DS Core nello stesso rilascio in cui si toglie dal sito).
 *
 * Campi di ogni modulo:
 * - categoria    chiave di ds_core_categorie_ammesse(): security, performance, privacy, admin, content, shop, site
 * - file         percorso relativo a ds-core/ (moduli di DS Core) o completo (moduli esterni)
 * - tipo         array fra PHP, CSS, JS, HTML, conditions
 * - dove         array fra site, admin, checkout, email, rest, cron, login (ds_core_dove_etichette())
 * - versione     versione del modulo
 * - modificato   data dell'ultima modifica del file del modulo, AAAA-MM-GG (per i moduli di DS Core: la data
 *                dell'ultimo commit che tocca il file, git log -1 --format=%cs -- <file>)
 * - sostituisce  snippet o file che il modulo rimpiazza ('' se nessuno)
 * - predefinito  stato al primo rilascio: 'spento' (regola generale) o 'attivo'
 * - tre_stati    true se il modulo ha anche lo stato 'prova' (attivo solo per gli amministratori)
 * - richiede     array( 'classi' => [...], 'funzioni' => [...], 'moduli' => [...] ): il modulo si carica solo
 *                se esistono (es. 'classi' => array( 'WooCommerce' ))
 * - testi        funzione che restituisce titolo, descrizione, avviso (cosa succede se lo si spegne) e tag
 * - opzione      nome dell'opzione in cui DS Core salva le scelte del modulo (dalla 0.13.0). Minuscole, numeri e
 *                trattini bassi, con il prefisso del plugin (ds_core_…, ds_woo_…, mc_…); unico fra i moduli
 * - campi        elenco delle scelte del modulo: chiave => array( 'tipo' => …, 'predefinito' => …, … ). Tipi e chiavi in
 *                includes/opzioni.php. DS Core le mostra nella riga del modulo e le salva anche a modulo spento,
 *                senza eseguire codice del modulo, con un pulsante «Save settings» per modulo. Il modulo le legge con
 *                ds_core_opzioni_modulo( '<id>' ). Etichette, aiuti e nomi delle scelte nella funzione 'testi'
 *                (chiavi 'campi' e 'gruppi'). Salvare non applica niente: il modulo acceso ascolta l'azione
 *                'ds_core_impostazioni_salvate' ( $id, $prima, $dopo ) se deve applicare subito
 * - stato        funzione (o nome di funzione) che stampa lo stato del modulo e le sue azioni (tabelle, «Check
 *                again»…). Sta nel file del modulo, quindi si chiama solo a modulo acceso; da spento la riga lo dice.
 *                Può stampare i suoi <form> verso admin-post.php (con nonce e controllo dei permessi): dopo l'azione,
 *                reindirizzare a admin.php?page=ds-core#ds-impostazioni-<id> riapre la riga.
 *                'impostazioni' (0.12.x) vale ancora come sinonimo di 'stato'
 * - avvisi       true se il modulo manda mail: la riga ricorda a quale indirizzo vanno (ds_core_indirizzo_avvisi(),
 *                l'indirizzo unico di DS Core nelle impostazioni generali)
 * - problemi     funzione (o nome di funzione) che restituisce i problemi del modulo acceso: una stringa o un array
 *                di stringhe brevi e tradotte, vuoto se va tutto bene. Ogni problema compare nell'avviso in cima
 *                al pannello, con un link che apre la riga del modulo.
 * - riepilogo    facoltativo (0.18.0): funzione (o nome di funzione) del modulo acceso che restituisce lo stato in una
 *                frase breve e tradotta («Closed», «Written to .htaccess, checked on …»): apre la riga di riepilogo
 *                sotto la descrizione. Le scelte entrano nel riepilogo con la chiave 'breve' nei testi dei campi
 *                (includes/impostazioni.php). Un errore nella funzione si ignora
 *
 * Esempio per DS Woo e i plugin dei siti (stesso filtro):
 *
 *   'opzione'  => 'ds_xx_my_module',
 *   'campi'    => array(
 *       'limite' => array( 'tipo' => 'number', 'predefinito' => 5, 'min' => 1, 'max' => 50 ),
 *       'colore' => array( 'tipo' => 'color', 'predefinito' => '#1d2327' ),
 *   ),
 *   'stato'    => 'ds_xx_my_module_state',      // stampa lo stato, solo a modulo acceso
 *   'problemi' => 'ds_xx_my_module_problems',   // return array( __( 'The API key is missing.', 'ds-xx' ) );
 *   'testi'    => function () {
 *       return array(
 *           'titolo' => __( 'My module', 'ds-xx' ),
 *           // …
 *           'campi'  => array(
 *               'limite' => array( 'etichetta' => __( 'Limit', 'ds-xx' ), 'aiuto' => __( 'How many.', 'ds-xx' ), 'unita' => __( 'items', 'ds-xx' ) ),
 *               'colore' => array( 'etichetta' => __( 'Color', 'ds-xx' ) ),
 *           ),
 *       );
 *   },
 *
 * Regola: il codice di DS Core è pubblico (pacchetti firmati in un repository pubblico) e identico su tutti i siti.
 * Nessun dominio, nome di cliente, percorso del server o scelta di un sito va scritto qui o nei moduli. Se una
 * funzione non va usata su un sito, il modulo si lascia spento nel pannello di quel sito; il motivo si scrive nella
 * scheda del sito, fuori dal plugin.
 */

defined( 'ABSPATH' ) || exit;

/** Chiavi delle categorie, nell'ordine in cui compaiono nel pannello. Nessuna traduzione: si usa al caricamento. */
function ds_core_categorie_ammesse() {
	return array( 'security', 'performance', 'privacy', 'admin', 'content', 'shop', 'site' );
}

/** Nomi delle categorie, tradotti. Solo dopo init (pannello). */
function ds_core_categorie() {
	$nomi = array(
		'security'    => __( 'Security', 'ds-core' ),
		'performance' => __( 'Performance', 'ds-core' ),
		'privacy'     => __( 'Privacy', 'ds-core' ),
		'admin'       => __( 'Administration', 'ds-core' ),
		'content'     => __( 'Content', 'ds-core' ),
		'shop'        => __( 'Shop', 'ds-core' ),
		'site'        => __( 'Site features', 'ds-core' ),
	);
	return array_merge( array_flip( ds_core_categorie_ammesse() ), $nomi );
}

/** Dove agisce un modulo: codice => nome tradotto. Solo dopo init (pannello). */
function ds_core_dove_etichette() {
	return array(
		'site'     => __( 'site', 'ds-core' ),
		'admin'    => __( 'admin', 'ds-core' ),
		'checkout' => __( 'checkout', 'ds-core' ),
		'email'    => __( 'email', 'ds-core' ),
		'rest'     => __( 'REST', 'ds-core' ),
		'cron'     => __( 'cron', 'ds-core' ),
		'login'    => __( 'login', 'ds-core' ),
	);
}

/** Codici delle versioni precedenti (italiano) → codici attuali, per i moduli esterni scritti prima della 0.8.0. */
function ds_core_codici_vecchi() {
	return array(
		'sicurezza'       => 'security',
		'prestazioni'     => 'performance',
		'amministrazione' => 'admin',
		'contenuti'       => 'content',
		'negozio'         => 'shop',
		'sito'            => 'site',
		'condizioni'      => 'conditions',
	);
}

/**
 * ID dei moduli di DS Core rinominati in inglese nella 0.17.0 (decisione di Daniele del 27/11/2026: il plugin potrà
 * essere venduto e gli ID compaiono nel pannello): vecchio ID → ID attuale. Unico elenco, usato da:
 * - la migrazione una tantum dei dati salvati (ds_core_migra_id(), includes/opzioni.php);
 * - l'interruttore d'emergenza DS_CORE_SPENTI, che accetta sia i vecchi sia i nuovi ID;
 * - le funzioni pubbliche che ricevono un ID (ds_core_stato(), ds_core_opzioni_modulo()…) e il campo 'richiede' dei
 *   moduli esterni, così il codice di DS Woo e dei plugin dei siti scritto con i vecchi ID continua a funzionare;
 * - il .htaccess: il blocco «DS Core header-dati» si legge ancora e si rinomina «DS Core security-headers»;
 * - il pannello e il registro delle attività, per mostrare il nome del modulo nelle righe vecchie.
 * Non si tolgono voci da qui: un sito può aggiornarsi da una versione qualsiasi.
 */
function ds_core_id_rinominati() {
	return array(
		'rest-utenti-chiuso'    => 'rest-users-hidden',
		'autori-chiusi'         => 'author-archives-closed',
		'autore-pubblico'       => 'public-author-name',
		'accesso-code'          => 'claude-code-access',
		'aggiornamenti'         => 'updates-safety-net',
		'header-dati'           => 'security-headers',
		'registro-attivita'     => 'activity-log',
		'xmlrpc-chiuso'         => 'xmlrpc-closed',
		'rest-protetti-chiusi'  => 'rest-protected-hidden',
		'commenti-chiusi'       => 'comments-closed',
		'login-errori-generici' => 'generic-login-errors',
		'controllo-account'     => 'account-checks',
	);
}

/** ID attuale di un modulo: il nuovo se $id è un vecchio ID di DS Core, altrimenti $id com'è. */
function ds_core_id_attuale( $id ) {
	$id    = (string) $id;
	$mappa = ds_core_id_rinominati();
	return $mappa[ $id ] ?? $id;
}

/** Vecchio ID (prima della 0.17.0) di un modulo di DS Core, '' se non è stato rinominato. */
function ds_core_id_vecchio( $id ) {
	$vecchio = array_search( (string) $id, ds_core_id_rinominati(), true );
	return false === $vecchio ? '' : (string) $vecchio;
}

/** Moduli di DS Core: solo dati tecnici. I testi sono in ds_core_testi_core(). */
function ds_core_registro_core() {
	return array(
		'rest-users-hidden'      => array(
			'categoria'   => 'security',
			'file'        => 'moduli/rest-users-hidden.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'rest' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'attivo',
		),
		'author-archives-closed' => array(
			'categoria'   => 'security',
			'file'        => 'moduli/author-archives-closed.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'site' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'attivo',
		),
		'public-author-name'     => array(
			'categoria'   => 'security',
			'file'        => 'moduli/public-author-name.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'site' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'attivo',
		),
		'claude-code-access'     => array(
			'categoria'   => 'security',
			'file'        => 'moduli/claude-code-access.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'rest', 'admin', 'login' ),
			'versione'    => '1.6.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'spento',
			'avvisi'      => true,
			// Dalla 1.5.0 (0.17.0): password per le applicazioni solo agli amministratori, accesa di base.
			'opzione'     => 'ds_core_accesso',
			'campi'       => array(
				'app_solo_admin' => array( 'tipo' => 'checkbox', 'predefinito' => true ),
			),
			'stato'       => 'ds_core_accesso_stato',
			'problemi'    => 'ds_core_accesso_problemi',
			'riepilogo'   => 'ds_core_accesso_riepilogo',
		),
		'updates-safety-net'     => array(
			'categoria'   => 'security',
			'file'        => 'moduli/updates-safety-net.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'admin', 'cron', 'email' ),
			'versione'    => '1.3.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'spento',
			'avvisi'      => true,
			// Stesse chiavi della 0.9.0-0.12.x: i valori già salvati restano validi.
			'opzione'     => 'ds_core_agg',
			'campi'       => array(
				'plugin'  => array( 'tipo' => 'radio', 'scelte' => array( 'auto', 'no' ), 'predefinito' => 'auto', 'gruppo' => 'plugin' ),
				'margine' => array( 'tipo' => 'number', 'min' => 0, 'max' => 720, 'predefinito' => 24, 'gruppo' => 'plugin' ),
				'core'    => array( 'tipo' => 'radio', 'scelte' => array( 'principali', 'sicurezza', 'no' ), 'predefinito' => 'principali', 'gruppo' => 'core' ),
				'giorni'  => array( 'tipo' => 'number', 'min' => 0, 'max' => 90, 'predefinito' => 7, 'gruppo' => 'core' ),
				'manuali' => array( 'tipo' => 'plugins', 'predefinito' => array(), 'predefinito_da' => 'ds_core_agg_manuali_predefiniti', 'gruppo' => 'manuali' ),
			),
			'stato'       => 'ds_core_agg_riquadro',
			'problemi'    => 'ds_core_agg_problemi',
		),
		'no-google-fonts'        => array(
			'categoria'   => 'privacy',
			'file'        => 'moduli/no-google-fonts.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'site' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-26',
			'sostituisce' => 'snippet «Disable Google Fonts»',
			'predefinito' => 'spento',
			'tre_stati'   => true,
		),
		'security-headers'       => array(
			'categoria'   => 'security',
			'file'        => 'moduli/security-headers.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'site' ),
			'versione'    => '1.2.1',
			'modificato'  => '2026-11-27',
			'predefinito' => 'spento',
			'stato'       => 'ds_core_hd_riquadro',
			'problemi'    => 'ds_core_hd_problemi',
			'riepilogo'   => 'ds_core_hd_riepilogo',
		),
		'activity-log'           => array(
			'categoria'   => 'security',
			'file'        => 'moduli/activity-log.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'admin', 'login', 'rest', 'cron', 'email' ),
			'versione'    => '1.4.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'spento',
			'avvisi'      => true,
			'opzione'     => 'ds_core_ra',
			'campi'       => array(
				// Scelta fissa o «personalizzato»; 'giorni' contiene sempre il numero effettivo (includes/eventi.php).
				'conserva'  => array( 'tipo' => 'radio', 'scelte' => array( '30', '90', '365', 'personalizzato' ), 'predefinito' => '90' ),
				'giorni'    => array( 'tipo' => 'number', 'min' => 7, 'max' => 730, 'predefinito' => 90, 'mostra_se' => array( 'conserva', 'personalizzato' ) ),
				'riepilogo' => array( 'tipo' => 'checkbox', 'predefinito' => false ),
			),
			'stato'       => 'ds_core_ra_riquadro',
			'problemi'    => 'ds_core_ra_problemi',
		),
		// Dalla 0.17.0: ingressi chiusi (docs/ds-core-analisi-mc-funzioni.md, decisioni di Daniele del 27/11/2026).
		'xmlrpc-closed'          => array(
			'categoria'   => 'security',
			'file'        => 'moduli/xmlrpc-closed.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'site' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-27',
			'sostituisce' => 'sicurezza-xmlrpc',
			'predefinito' => 'spento',
			'stato'       => 'ds_core_xc_riquadro',
			'problemi'    => 'ds_core_xc_problemi',
			'riepilogo'   => 'ds_core_xc_riepilogo',
		),
		'rest-protected-hidden'  => array(
			'categoria'   => 'security',
			'file'        => 'moduli/rest-protected-hidden.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'rest' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-27',
			'sostituisce' => 'sicurezza-rest-pagine-protette',
			'predefinito' => 'spento',
			'stato'       => 'ds_core_rpc_riquadro',
		),
		'comments-closed'        => array(
			'categoria'   => 'security',
			'file'        => 'moduli/comments-closed.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'site', 'admin', 'rest' ),
			'versione'    => '1.1.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'spento',
			'opzione'     => 'ds_core_cc',
			'campi'       => array(
				'recensioni' => array( 'tipo' => 'checkbox', 'predefinito' => false ),
				// Dalla 0.17.0 (Daniele, 27/11/2026): commenti esistenti tolti dal sito pubblico, senza cancellarli.
				'nascondi'   => array( 'tipo' => 'checkbox', 'predefinito' => false ),
			),
			'stato'       => 'ds_core_cc_riquadro',
			'problemi'    => 'ds_core_cc_problemi',
			'riepilogo'   => 'ds_core_cc_riepilogo',
		),
		'generic-login-errors'   => array(
			'categoria'   => 'security',
			'file'        => 'moduli/generic-login-errors.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'login' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'spento',
		),
		'account-checks'         => array(
			'categoria'   => 'security',
			'file'        => 'moduli/account-checks.php',
			'tipo'        => array( 'PHP' ),
			'dove'        => array( 'admin', 'email' ),
			'versione'    => '1.0.0',
			'modificato'  => '2026-11-27',
			'predefinito' => 'spento',
			'avvisi'      => true,
			'opzione'     => 'ds_core_ca',
			'campi'       => array(
				'senza_2fa' => array( 'tipo' => 'checkbox', 'predefinito' => false ),
				'motivo'    => array( 'tipo' => 'text', 'predefinito' => '', 'lunghezza' => 200 ),
			),
			'stato'       => 'ds_core_ca_riquadro',
			'problemi'    => 'ds_core_ca_problemi',
		),
		// Dalla 0.18.0 (Daniele 27/11/2026, docs/ds-core-analisi-pannello-ux.md §3): colori del brand nell'amministrazione.
		'admin-branding'         => array(
			'categoria'   => 'admin',
			'file'        => 'moduli/admin-branding.php',
			'tipo'        => array( 'PHP', 'CSS' ),
			'dove'        => array( 'admin', 'login' ),
			'versione'    => '1.3.0',
			'modificato'  => '2026-11-27',
			'sostituisce' => 'editor-testo-nero',
			'predefinito' => 'spento',
			'opzione'     => 'ds_core_ab',
			'campi'       => array(
				// 0.19.0: schema colori nativo di WordPress con pochi colori; vuoto = il colore dello schema proposto (l'evidenza:
				// quella suggerita da Breakdance o il blu di WordPress). Schemi e campi della 0.18.x migrati in ds_core_migra().
				'schema'      => array( 'tipo' => 'schemi', 'scelte' => ds_core_ab_codici_schemi(), 'predefinito' => 'scuro', 'gruppo' => 'bacheca' ),
				'accento'     => array( 'tipo' => 'color', 'predefinito' => '', 'gruppo' => 'personalizza' ),
				'menu'        => array( 'tipo' => 'color', 'predefinito' => '', 'gruppo' => 'personalizza' ),
				'notifiche'   => array( 'tipo' => 'color', 'predefinito' => '', 'gruppo' => 'personalizza' ),
				'menu_testo'  => array( 'tipo' => 'color', 'predefinito' => '', 'gruppo' => 'personalizza' ),
				'propri'      => array( 'tipo' => 'checkbox', 'predefinito' => false, 'gruppo' => 'utenti' ),
				'editor_nero' => array( 'tipo' => 'checkbox', 'predefinito' => false, 'gruppo' => 'editor' ),
				'login'       => array( 'tipo' => 'checkbox', 'predefinito' => false, 'gruppo' => 'login' ),
			),
			'riepilogo'   => 'ds_core_ab_riepilogo',
		),
	);
}

/** Testi dei moduli di DS Core, tradotti. Solo dopo init (pannello). */
function ds_core_testi_core() {
	return array(
		'rest-users-hidden'      => array(
			'titolo'      => __( 'User list hidden from the REST API', 'ds-core' ),
			'descrizione' => __( 'People who do not write content cannot read the list of users or a single user profile from the REST API (/wp/v2/users), so they cannot find out usernames. Editors and administrators still see them.', 'ds-core' ),
			'avviso'      => __( 'Anyone can read the list of users through the REST API again.', 'ds-core' ),
			'tag'         => array( __( 'users', 'ds-core' ), __( 'login', 'ds-core' ), __( 'enumeration', 'ds-core' ) ),
		),
		'author-archives-closed' => array(
			'titolo'      => __( 'Author archives closed', 'ds-core' ),
			'descrizione' => __( 'Author archives (?author=1, /author/…) redirect to the home page and author links point to the home page, so usernames never appear in addresses. It also removes authors from the WordPress sitemap and the author link from oEmbed. Editors and administrators still see them.', 'ds-core' ),
			'avviso'      => __( 'With ?author=1 anyone can read the administrator username in the address again.', 'ds-core' ),
			'tag'         => array( __( 'users', 'ds-core' ), __( 'login', 'ds-core' ), __( 'enumeration', 'ds-core' ), __( 'sitemap', 'ds-core' ) ),
		),
		'public-author-name'     => array(
			'titolo'      => __( 'Author named after the site', 'ds-core' ),
			'descrizione' => __( 'On public pages, in the feed and in the data for search engines the author of the content is called like the site (Site Title). Neither the name of the person who runs the site nor the username appears. Accounts are not changed.', 'ds-core' ),
			'avviso'      => __( 'The public name of the account that published the content shows again, and it may be the username.', 'ds-core' ),
			'tag'         => array( __( 'users', 'ds-core' ), __( 'login', 'ds-core' ), __( 'enumeration', 'ds-core' ), __( 'SEO', 'ds-core' ) ),
		),
		'claude-code-access'     => array(
			'titolo'      => __( 'Timed access for Claude Code', 'ds-core' ),
			'descrizione' => __( 'The entry points used by Claude Code stay closed until you open them from the “Claude Code access” box at the top of this page, for 1, 4 or 8 hours; when time is up they close by themselves. While closed, application passwords do not work and MCP and the Agent Connector features answer 403, even to administrators. Browser login, the builder and this panel always work. Every opening, and every closing before time is up, sends an email to the DS Core notification address and to the site administrator. Closed right after it is switched on.', 'ds-core' ),
			'avviso'      => __( 'The Claude Code entry points (MCP, application passwords, Agent Connector features) stay open all the time.', 'ds-core' ),
			'tag'         => array( __( 'MCP', 'ds-core' ), __( 'Claude Code', 'ds-core' ), __( 'application passwords', 'ds-core' ), __( 'Agent Connector', 'ds-core' ) ),
			'campi'       => array(
				'app_solo_admin' => array(
					'etichetta' => __( 'Application passwords', 'ds-core' ),
					'testo'     => __( 'Only administrators', 'ds-core' ),
					'aiuto'     => __( 'Only administrators can create and use application passwords, even while access is open: a customer, author or editor account cannot become an entry point. Passwords already saved are not deleted; the list in the module state shows who still has one.', 'ds-core' ),
					'breve'     => array(
						'1' => __( 'app passwords: administrators only', 'ds-core' ),
						'0' => __( 'app passwords: any account', 'ds-core' ),
					),
				),
			),
		),
		'updates-safety-net'     => array(
			'titolo'      => __( 'Automatic updates safety net', 'ds-core' ),
			'descrizione' => __( 'Plugins, themes and WordPress always get updated. If the hosting handles updates, it gets a head start, 24 hours by default; whatever is still pending after that, DS Core updates with the WordPress system, which rolls back by itself if the site breaks. Minor WordPress versions (security) right away, major versions after a few days. Plugins set to manual never update by themselves. All update emails go to the DS Core notification address.', 'ds-core' ),
			'avviso'      => __( 'Updates go back to depending only on the hosting or on whoever updates by hand.', 'ds-core' ),
			'tag'         => array( __( 'updates', 'ds-core' ), __( 'hosting', 'ds-core' ), __( 'email', 'ds-core' ) ),
			'gruppi'      => array(
				'plugin'  => __( 'Plugins and themes', 'ds-core' ),
				'core'    => __( 'WordPress', 'ds-core' ),
				'manuali' => __( 'Plugins to update by hand', 'ds-core' ),
			),
			'campi'       => array(
				'plugin'  => array(
					'etichetta' => __( 'Automatic updates', 'ds-core' ),
					'scelte'    => array(
						'auto' => __( 'Update automatically', 'ds-core' ),
						'no'   => __( 'Do not update automatically (only list and summary email)', 'ds-core' ),
					),
					'breve'     => array(
						'auto' => _x( 'Automatic', 'updates summary', 'ds-core' ),
						'no'   => __( 'Plugins: list only', 'ds-core' ),
					),
				),
				'margine' => array(
					'etichetta' => __( 'Head start for the hosting', 'ds-core' ),
					'aiuto'     => __( 'Only used when the hosting handles updates: DS Core updates whatever is still pending after this time.', 'ds-core' ),
					'unita'     => __( 'hours', 'ds-core' ),
					'breve'     => function ( $valore, $valori ) {
						/* translators: %d: number of hours. */
						return 'auto' === ( $valori['plugin'] ?? '' ) ? sprintf( __( 'hosting head start %d h', 'ds-core' ), (int) $valore ) : '';
					},
				),
				'core'    => array(
					'etichetta' => __( 'WordPress updates', 'ds-core' ),
					'scelte'    => array(
						'principali' => __( 'Minor versions (security) right away, major versions after the days below', 'ds-core' ),
						'sicurezza'  => __( 'Only minor versions (security); major versions by hand', 'ds-core' ),
						'no'         => __( 'Never automatically', 'ds-core' ),
					),
					'breve'     => function ( $valore, $valori ) {
						if ( 'principali' === $valore ) {
							$giorni = (int) ( $valori['giorni'] ?? 0 );
							/* translators: %d: number of days. */
							return sprintf( _n( 'WordPress: security now, major after %d day', 'WordPress: security now, major after %d days', $giorni, 'ds-core' ), $giorni );
						}
						return 'sicurezza' === $valore ? __( 'WordPress: security only', 'ds-core' ) : __( 'WordPress: by hand', 'ds-core' );
					},
				),
				'giorni'  => array(
					'etichetta' => __( 'Wait for major versions', 'ds-core' ),
					'aiuto'     => __( 'Only with the first choice above.', 'ds-core' ),
					'unita'     => __( 'days', 'ds-core' ),
				),
				'manuali' => array(
					'etichetta' => __( 'Update by hand', 'ds-core' ),
					'aiuto'     => __( 'They never update by themselves: on shops, WooCommerce, payment plugins, DS Woo and the site plugin.', 'ds-core' ),
					'breve'     => function ( $valore ) {
						$quanti = is_array( $valore ) ? count( $valore ) : 0;
						/* translators: %d: number of plugins. */
						return $quanti ? sprintf( _n( '%d plugin by hand', '%d plugins by hand', $quanti, 'ds-core' ), $quanti ) : '';
					},
				),
			),
		),
		'no-google-fonts'        => array(
			'titolo'      => __( 'No Google Fonts', 'ds-core' ),
			'descrizione' => __( 'Public pages make no requests to Google Fonts, so visitors’ IP addresses are not sent to Google and pages load faster. It stops Breakdance from registering Google fonts, drops Google Fonts stylesheets added by themes and plugins, and removes any leftover link from the finished page. The dashboard and the Breakdance builder still use them. Before turning it on, the fonts of the site must be served by the site itself: try it first in Test mode.', 'ds-core' ),
			'avviso'      => __( 'Pages go back to loading fonts from Google, sending visitors’ IP addresses to Google; the privacy policy must mention it.', 'ds-core' ),
			'tag'         => array( __( 'fonts', 'ds-core' ), __( 'GDPR', 'ds-core' ), __( 'performance', 'ds-core' ), __( 'Breakdance', 'ds-core' ) ),
		),
		'security-headers'       => array(
			'titolo'      => __( 'Security headers and exposed files', 'ds-core' ),
			'descrizione' => __( 'Writes a block in the .htaccess file with the security headers (no MIME sniffing, no framing by other sites, limited referrer, no camera, microphone or location, HTTPS only), so they apply to images, fonts and stylesheets too; turns off folder listing; denies readme.html, license.txt and wp-config-sample.php. After writing it checks that the site still answers and otherwise puts the previous file back. It warns if the same headers already come from somewhere else.', 'ds-core' ),
			'avviso'      => __( 'The block is removed from the .htaccess file: no security headers, folder listing back to the hosting default, readme.html and license.txt readable again.', 'ds-core' ),
			'tag'         => array( __( 'headers', 'ds-core' ), __( '.htaccess', 'ds-core' ), __( 'hardening', 'ds-core' ) ),
		),
		'activity-log'           => array(
			'titolo'      => __( 'Activity log', 'ds-core' ),
			'descrizione' => __( 'Keeps a record of who changed what on the site and how: sign-ins of editors and administrators, application passwords, users and roles, plugins, themes and updates, key site settings, MCP calls (only the names of the abilities and tools, never their content) and DS Core events. Visitors, failed logins and shop customers are not recorded. Records stay in a table of their own and are deleted after the chosen number of days; read them under “DS Core” › “Activity log”.', 'ds-core' ),
			'avviso'      => __( 'Nothing new is recorded. The records already saved are deleted when they get older than the chosen number of days, then the table is removed.', 'ds-core' ),
			'tag'         => array( __( 'log', 'ds-core' ), __( 'users', 'ds-core' ), __( 'MCP', 'ds-core' ), __( 'GDPR', 'ds-core' ) ),
			'campi'       => array(
				'conserva'  => array(
					'etichetta' => __( 'Keep records for', 'ds-core' ),
					'aiuto'     => __( 'Older records are deleted every day. Changing this is recorded as an alarm.', 'ds-core' ),
					'scelte'    => array(
						'30'             => __( '30 days', 'ds-core' ),
						'90'             => __( '90 days', 'ds-core' ),
						'365'            => __( '365 days', 'ds-core' ),
						'personalizzato' => __( 'Custom', 'ds-core' ),
					),
					'breve'     => function ( $valore, $valori ) {
						$giorni = (int) ( $valori['giorni'] ?? 90 );
						/* translators: %d: number of days. */
						return sprintf( _n( 'keep %d day', 'keep %d days', $giorni, 'ds-core' ), $giorni );
					},
				),
				'giorni'    => array(
					'etichetta' => __( 'Custom period', 'ds-core' ),
					'aiuto'     => __( 'Used only with “Custom”.', 'ds-core' ),
					'unita'     => __( 'days', 'ds-core' ),
				),
				'riepilogo' => array(
					'etichetta' => __( 'Weekly summary', 'ds-core' ),
					'testo'     => __( 'Send a weekly email with the events to review', 'ds-core' ),
					'aiuto'     => __( 'Sent only in weeks with events to review or alarms: numbers by group and the list of alarms.', 'ds-core' ),
					'breve'     => array(
						'1' => __( 'weekly summary on', 'ds-core' ),
						'0' => __( 'weekly summary off', 'ds-core' ),
					),
				),
			),
		),
		'xmlrpc-closed'          => array(
			'titolo'      => __( 'XML-RPC closed', 'ds-core' ),
			'descrizione' => __( 'Every request to xmlrpc.php gets 403 before WordPress handles it, so nobody can try passwords through it (system.multicall tries hundreds in one request) or send pingbacks. It also removes the X-Pingback header and the RSD link, and the site stops sending pingbacks. Application passwords on the REST API are not affected. It checks twice a day that xmlrpc.php really stays closed and warns if Jetpack, which needs XML-RPC, is active.', 'ds-core' ),
			'avviso'      => __( 'xmlrpc.php answers again (unless the .htaccess file blocks it): password guessing and pingback spam can come back.', 'ds-core' ),
			'tag'         => array( __( 'XML-RPC', 'ds-core' ), __( 'login', 'ds-core' ), __( 'pingback', 'ds-core' ), __( 'hardening', 'ds-core' ) ),
		),
		'rest-protected-hidden'  => array(
			'titolo'      => __( 'Password-protected content hidden from the REST API', 'ds-core' ),
			'descrizione' => __( 'Pages, posts and other public content protected by a password no longer appear in the REST API lists and search, and reading them directly answers as if they did not exist (404), also in oEmbed. It applies to everyone who does not write content, logged-in shop customers included. Editors and administrators still see them; the pages on the site still ask for the password as before.', 'ds-core' ),
			'avviso'      => __( 'Anyone can read the titles, addresses and dates of password-protected content through the REST API again.', 'ds-core' ),
			'tag'         => array( __( 'REST', 'ds-core' ), __( 'password', 'ds-core' ), __( 'privacy', 'ds-core' ) ),
		),
		'comments-closed'        => array(
			'titolo'      => __( 'Comments closed', 'ds-core' ),
			'descrizione' => __( 'Comments, trackbacks and pingbacks are closed on all content, old and new, without changing the database. wp-comments-post.php answers 403, the REST API comments endpoint is removed for people who do not write content, and the Comments menu, column, Discussion box and widget are hidden in the dashboard. Existing comments are never deleted: they still show, unless you choose to hide them from the public site. The module counts approved comments and those with links, lists the latest ones with links, records an alarm if approved comments appear while it is on (approving or replying from the dashboard is only noted, with who did it), and warns about comments waiting for moderation.', 'ds-core' ),
			'avviso'      => __( 'Each content goes back to its own comment and ping settings: trackback spam can come back where pings are open. Hidden comments show again.', 'ds-core' ),
			'tag'         => array( __( 'comments', 'ds-core' ), __( 'trackback', 'ds-core' ), __( 'pingback', 'ds-core' ), __( 'spam', 'ds-core' ) ),
			'campi'       => array(
				'recensioni' => array(
					'etichetta' => __( 'Product reviews', 'ds-core' ),
					'testo'     => __( 'Keep WooCommerce product reviews open', 'ds-core' ),
					'aiuto'     => __( 'Reviews are comments on products: with this on, products follow the WooCommerce settings and the comments page stays in the menu. Without WooCommerce it does nothing.', 'ds-core' ),
					'breve'     => array( '1' => __( 'product reviews open', 'ds-core' ) ),
				),
				'nascondi'   => array(
					'etichetta' => __( 'Existing comments', 'ds-core' ),
					'testo'     => __( 'Also hide existing comments', 'ds-core' ),
					'aiuto'     => __( 'Approved comments, trackbacks and pingbacks disappear from the public site (pages, feeds, REST API) and comment counts show 0. Nothing is deleted: turn this off and they are back. The dashboard still shows them.', 'ds-core' ),
					'breve'     => array(
						'1' => __( 'existing comments hidden', 'ds-core' ),
						'0' => __( 'existing comments shown', 'ds-core' ),
					),
				),
			),
		),
		'generic-login-errors'   => array(
			'titolo'      => __( 'Same login error for everyone', 'ds-core' ),
			'descrizione' => __( 'Failed logins show the same message whether the username, the email address or the password is wrong, on wp-login.php, the WooCommerce “My account” page and every form that uses the WordPress login. A password reset for an account that does not exist ends on the same “check your email” page as a real one, with no email sent. Only the text changes: error codes stay the same, so login attempt limits, two-step login and single sign-on keep working as before.', 'ds-core' ),
			'avviso'      => __( 'Login and password reset tell again whether a username or email address exists on the site.', 'ds-core' ),
			'tag'         => array( __( 'login', 'ds-core' ), __( 'enumeration', 'ds-core' ), __( 'WooCommerce', 'ds-core' ) ),
		),
		'account-checks'         => array(
			'titolo'      => __( 'Account checks', 'ds-core' ),
			'descrizione' => __( 'Warns administrators about administrators without two-step login (Two Factor or Wordfence Login Security), new administrator accounts to confirm (the first time with a security notice, which also goes to the site administrator email), accounts without a role and registration open on a site without a shop or with a default role that can write content. Where two-step login cannot work, mark it as not available: the warning becomes the list of protections that make up for it. It only reports, it never changes accounts.', 'ds-core' ),
			'avviso'      => __( 'No more warnings about accounts: a new administrator or an open registration can go unnoticed.', 'ds-core' ),
			'tag'         => array( __( 'users', 'ds-core' ), __( 'two-step login', 'ds-core' ), __( 'login', 'ds-core' ), __( 'registration', 'ds-core' ) ),
			'campi'       => array(
				'senza_2fa' => array(
					'etichetta' => __( 'Two-step login', 'ds-core' ),
					'testo'     => __( 'Two-step login not available on this site', 'ds-core' ),
					'aiuto'     => __( 'For sites where it cannot work, for example when a single sign-on from another platform skips it. The warning about administrators without two-step login becomes the list of protections that make up for it.', 'ds-core' ),
					'breve'     => array(
						'1' => __( 'two-step login not available here', 'ds-core' ),
						'0' => __( 'two-step login required for administrators', 'ds-core' ),
					),
				),
				'motivo'    => array(
					'etichetta' => __( 'Reason', 'ds-core' ),
					'aiuto'     => __( 'Why two-step login is not available here (shown in the panel).', 'ds-core' ),
				),
			),
		),
		'admin-branding'         => ds_core_testi_admin_branding(),
	);
}

/**
 * Testi di admin-branding (0.18.0; 0.19.0 versione leggera: schema colori nativo, pochi colori), tradotti. A parte perché
 * le strisce degli schemi proposti, i segnaposto dei colori e l'anteprima dipendono dall'evidenza (scelta o suggerita da
 * Breakdance): li calcola ds_core_ab_risolvi() (includes/opzioni.php), senza eseguire codice del modulo. L'anteprima la
 * scrive includes/impostazioni.php, caricato solo in amministrazione: fuori (cron, registro delle attività) restano solo
 * i testi.
 */
function ds_core_testi_admin_branding() {
	$valori    = ds_core_opzioni_modulo( 'admin-branding' );
	$suggerito = ds_core_ab_suggerito();
	$calcolo   = ds_core_ab_risolvi( $valori, $suggerito );
	$evidenza  = $calcolo['evidenza'];

	$schede = array();
	foreach ( ds_core_ab_codici_schemi() as $codice ) {
		$prova             = ds_core_ab_risolvi( array( 'schema' => $codice, 'accento' => $evidenza ), $suggerito );
		$schede[ $codice ] = array(
			'nome'    => ds_core_ab_nome_schema( $codice ),
			'sotto'   => ds_core_ab_sotto_schema( $codice ),
			'strisce' => $prova['attivo'] ? ds_core_ab_strisce( $prova['var'] ) : array( '#1e1e1e', '#3858e9', '#7b90ff' ),
		);
	}

	if ( '' !== $suggerito['hex'] ) {
		/* translators: 1: name of the Breakdance color (e.g. "Yellow - Brand Identity" or "Links"), 2: color code. */
		$aiuto_accento = sprintf( __( 'The current menu item, the item under the mouse, links and buttons. Empty = %1$s %2$s, suggested from the Breakdance colors.', 'ds-core' ), $suggerito['nome'], $suggerito['hex'] );
	} else {
		/* translators: %s: color code. */
		$aiuto_accento = sprintf( __( 'The current menu item, the item under the mouse, links and buttons. Empty = the WordPress blue %s (no colored brand color found in Breakdance).', 'ds-core' ), DS_CORE_AB_BLU );
	}
	$base     = $calcolo['base'] ? $calcolo['base'] : ds_core_ab_base( 'scuro', $evidenza );
	$vuoto_tx = $calcolo['attivo'] ? $calcolo['var']['menu-text'] : '#ffffff';

	$campi = array(
		'schema'     => array(
			'etichetta' => __( 'Proposed schemes', 'ds-core' ),
			'aiuto'     => __( 'Like the color schemes in the user profile, built on the brand color. Submenu, top bar, the item under the mouse and icons follow automatically, as in the WordPress schemes.', 'ds-core' ),
			'schede'    => $schede,
			'breve'     => function ( $valore, $valori ) {
				$codice = in_array( (string) $valore, ds_core_ab_codici_schemi(), true ) ? (string) $valore : 'scuro';
				$nome   = ds_core_ab_nome_schema( $codice );
				if ( 'wordpress' !== $codice ) {
					foreach ( array( 'accento', 'menu', 'notifiche', 'menu_testo' ) as $chiave ) {
						if ( ! empty( $valori[ $chiave ] ) ) {
							/* translators: %s: name of the color scheme. */
							return sprintf( __( 'scheme “%s”, customized', 'ds-core' ), $nome );
						}
					}
				}
				/* translators: %s: name of the color scheme. */
				return sprintf( __( 'scheme “%s”', 'ds-core' ), $nome );
			},
		),
		'accento'    => array(
			'etichetta' => __( 'Highlight (brand color)', 'ds-core' ),
			'aiuto'     => $aiuto_accento,
			'vuoto'     => '' !== $suggerito['hex'] ? $suggerito['hex'] : DS_CORE_AB_BLU,
			'svuota'    => true,
		),
		'menu'       => array(
			'etichetta' => __( 'Menu background', 'ds-core' ),
			'aiuto'     => __( 'Empty = the color of the chosen scheme.', 'ds-core' ),
			'vuoto'     => $base['menu'],
			'svuota'    => true,
		),
		'notifiche'  => array(
			'etichetta' => __( 'Notifications', 'ds-core' ),
			'aiuto'     => __( 'Bubbles with counts (updates, comments). Empty = the WordPress red.', 'ds-core' ),
			'vuoto'     => $base['notifiche'],
			'svuota'    => true,
		),
		'menu_testo' => array(
			'etichetta' => __( 'Menu text (optional)', 'ds-core' ),
			'aiuto'     => __( 'Empty = white or dark, whichever is more readable on the menu. A lighter or darker shade is used if needed to reach 4.5:1.', 'ds-core' ),
			'vuoto'     => $vuoto_tx,
			'svuota'    => true,
		),
	);
	$campi['propri']      = array(
		'etichetta' => __( 'Users’ own schemes', 'ds-core' ),
		'testo'     => __( 'Let each user keep the color scheme chosen in their profile', 'ds-core' ),
		'aiuto'     => __( 'Off: everyone sees these colors and the choice disappears from the profile. On: users who picked another scheme in their profile (for example one with more contrast) keep it; the others see these colors.', 'ds-core' ),
		'breve'     => array(
			'1' => __( 'users can keep their own scheme', 'ds-core' ),
			'0' => __( 'for every user', 'ds-core' ),
		),
	);
	$campi['editor_nero'] = array(
		'etichetta' => __( 'Text in the editor', 'ds-core' ),
		'testo'     => __( 'Black text in the block editor', 'ds-core' ),
		'aiuto'     => __( 'Only while writing: the text of pages and posts in the block editor is black, easier to read. The public site does not change.', 'ds-core' ),
		'breve'     => array( '1' => __( 'black text in the editor', 'ds-core' ) ),
	);
	$campi['login']       = array(
		'etichetta' => __( 'Login page', 'ds-core' ),
		'testo'     => __( 'Show the site logo and the scheme colors on the login page', 'ds-core' ),
		'aiuto'     => __( 'Only the look: the site logo (or the site icon from Settings › General, or else the site title) links to the site, buttons and links take the colors of the scheme. The address, the fields, two-step login and attempt limits stay as they are.', 'ds-core' ),
		'breve'     => array(
			'1' => __( 'login page branded', 'ds-core' ),
			'0' => __( 'login page unchanged', 'ds-core' ),
		),
	);

	$testi = array(
		'titolo'      => __( 'Brand colors', 'ds-core' ),
		'descrizione' => __( 'The dashboard takes the brand colors through a WordPress color scheme, like the ones in the user profile: pick a proposed scheme and, if you want, change the highlight, the menu or the notifications. Everything else (submenu, top bar, the item under the mouse, icons) is derived as in the WordPress schemes, with readable text (WCAG AA). Optional: black text in the block editor, the site logo and colors on the login page. Only the look changes.', 'ds-core' ),
		'avviso'      => __( 'The dashboard goes back to the color scheme each user chose in their profile, and the login page to the WordPress look.', 'ds-core' ),
		'tag'         => array( __( 'branding', 'ds-core' ), __( 'colors', 'ds-core' ), __( 'color scheme', 'ds-core' ), __( 'login page', 'ds-core' ), __( 'block editor', 'ds-core' ) ),
		'gruppi'      => array(
			'bacheca'      => __( 'Dashboard color scheme', 'ds-core' ),
			'personalizza' => __( 'Customize the colors', 'ds-core' ),
			'utenti'       => __( 'Users', 'ds-core' ),
			'editor'       => __( 'Block editor', 'ds-core' ),
			'login'        => __( 'Login page (optional)', 'ds-core' ),
		),
		'campi'       => $campi,
	);
	if ( function_exists( 'ds_core_ab_anteprima_html' ) ) {
		$testi['accanto_html'] = ds_core_ab_anteprima_html( $calcolo, $suggerito, ! empty( $valori['propri'] ) );
	}
	return $testi;
}

/** Strisce di uno schema come nel profilo di WordPress: menu, sottomenu, evidenza, notifiche. */
function ds_core_ab_strisce( $v ) {
	return array( $v['menu-background'], $v['menu-submenu-background'], $v['menu-highlight-background'], $v['menu-bubble-background'] );
}

/** Nome di uno schema proposto. */
function ds_core_ab_nome_schema( $codice ) {
	switch ( $codice ) {
		case 'marchio':
			return __( 'Brand menu', 'ds-core' );
		case 'chiaro':
			return __( 'Light menu', 'ds-core' );
		case 'wordpress':
			return __( 'WordPress default', 'ds-core' );
	}
	return __( 'Dark menu', 'ds-core' );
}

/** Riga sotto il nome di uno schema proposto. */
function ds_core_ab_sotto_schema( $codice ) {
	switch ( $codice ) {
		case 'marchio':
			return __( 'Menu in the brand color, contrasting highlight', 'ds-core' );
		case 'chiaro':
			return __( 'Light menu, highlight in the brand color', 'ds-core' );
		case 'wordpress':
			return __( 'No colors applied: each user keeps their own scheme', 'ds-core' );
	}
	return __( 'Dark menu, highlight in the brand color', 'ds-core' );
}

/** Valori predefiniti dei campi di un modulo. */
function ds_core_modulo_vuoto() {
	return array(
		'origine'     => '',
		'categoria'   => 'admin',
		'titolo'      => '',
		'descrizione' => '',
		'file'        => '',
		'tipo'                   => array( 'PHP' ),
		'dove'                   => array( 'site' ),
		'tag'                    => array(),
		'versione'    => '',
		'modificato'  => '',
		'sostituisce' => '',
		'avviso'      => '',
		'predefinito' => 'spento',
		'tre_stati'   => false,
		'richiede'               => array(),
		'testi'       => null,
		'opzione'     => '',
		'campi'                  => array(),
		'stato'       => null,
		'avvisi'      => false,
		'impostazioni' => null, // 0.12.x: sinonimo di 'stato'
		'problemi'    => null,
		'riepilogo'   => null, // 0.18.0: stato a parole per la riga di riepilogo
	);
}

/**
 * Registro completo (dati tecnici): moduli di DS Core più quelli registrati dagli altri plugin.
 * Calcolato una volta per richiesta, dopo che tutti i plugin sono stati caricati. Nessuna traduzione qui.
 */
function ds_core_registro() {
	static $registro = null;
	if ( null !== $registro && did_action( 'plugins_loaded' ) ) {
		return $registro;
	}

	$vuoto    = ds_core_modulo_vuoto();
	$ammesse  = ds_core_categorie_ammesse();
	$vecchi   = ds_core_codici_vecchi();
	$tutti    = array();

	foreach ( ds_core_registro_core() as $id => $modulo ) {
		$modulo            = array_merge( $vuoto, $modulo );
		$modulo['origine'] = 'DS Core';
		$modulo['file']    = DS_CORE_DIR . ltrim( $modulo['file'], '/' );
		$tutti[ $id ]      = $modulo;
	}

	$esterni = apply_filters( 'ds_core_registro', array() );
	if ( is_array( $esterni ) ) {
		foreach ( $esterni as $id => $modulo ) {
			// Un vecchio ID di DS Core (prima della 0.17.0) vale come quello nuovo: il modulo esterno lo sostituisce.
			$id = ds_core_id_attuale( sanitize_key( $id ) );
			// 'ds-core' è riservato alle impostazioni generali di DS Core.
			if ( '' === $id || 'ds-core' === $id || ! is_array( $modulo ) || empty( $modulo['file'] ) ) {
				continue;
			}
			$modulo            = array_merge( $vuoto, $modulo );
			$modulo['origine'] = is_string( $modulo['origine'] ) ? trim( $modulo['origine'] ) : '';
			// «DS Core» è riservato ai moduli di questo plugin: un modulo esterno non può spacciarsi per uno del core.
			if ( '' === $modulo['origine'] || 'DS Core' === $modulo['origine'] ) {
				$modulo['origine'] = ds_core_origine_da_file( (string) $modulo['file'] );
			}
			$modulo['esterno'] = true;
			// Un modulo esterno con lo stesso ID di uno di DS Core lo sostituisce.
			$tutti[ $id ] = $modulo;
		}
	}

	$opzioni_usate = array();
	$riservate     = ds_core_opzioni_riservate();
	foreach ( $tutti as $id => $modulo ) {
		// Scelte dichiarate (0.13.0): nome dell'opzione valido, non riservato e non già usato da un altro modulo.
		$opzione = is_string( $modulo['opzione'] ) ? $modulo['opzione'] : '';
		if ( '' !== $opzione && ( ! preg_match( '/^[a-z][a-z0-9]*_[a-z0-9_]{1,60}$/', $opzione ) || in_array( $opzione, $riservate, true ) || isset( $opzioni_usate[ $opzione ] ) ) ) {
			$opzione = '';
		}
		$tutti[ $id ]['opzione'] = $opzione;
		if ( '' !== $opzione ) {
			$opzioni_usate[ $opzione ] = true;
		}
		if ( ! is_array( $modulo['campi'] ) || '' === $opzione ) {
			$tutti[ $id ]['campi'] = array();
		}
		if ( empty( $modulo['stato'] ) && ! empty( $modulo['impostazioni'] ) ) {
			$tutti[ $id ]['stato'] = $modulo['impostazioni'];
		}
		$tutti[ $id ]['avvisi'] = ! empty( $modulo['avvisi'] );

		$categoria = $vecchi[ $modulo['categoria'] ] ?? $modulo['categoria'];
		$tutti[ $id ]['categoria'] = in_array( $categoria, $ammesse, true ) ? $categoria : 'admin';
		if ( ! in_array( $modulo['predefinito'], array( 'attivo', 'spento' ), true ) ) {
			$tutti[ $id ]['predefinito'] = 'spento';
		}
		if ( ! is_string( $modulo['modificato'] ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $modulo['modificato'] ) ) {
			$tutti[ $id ]['modificato'] = '';
		}
		foreach ( array( 'tipo', 'dove', 'tag', 'richiede' ) as $campo ) {
			if ( ! is_array( $tutti[ $id ][ $campo ] ) ) {
				$tutti[ $id ][ $campo ] = array();
			}
		}
		// Codici di «dove» e «tipo» delle versioni precedenti (italiano) → codici attuali.
		foreach ( array( 'tipo', 'dove' ) as $campo ) {
			$tutti[ $id ][ $campo ] = array_map(
				function ( $valore ) use ( $vecchi ) {
					$valore = (string) $valore;
					$chiave = strtolower( $valore );
					return $vecchi[ $chiave ] ?? ( 'rest' === $chiave ? 'rest' : $valore );
				},
				$tutti[ $id ][ $campo ]
			);
		}
	}

	if ( did_action( 'plugins_loaded' ) ) {
		$registro = $tutti;
	}
	return $tutti;
}

/**
 * Registro con i testi tradotti (titolo, descrizione, avviso, tag). Solo per il pannello, dopo init.
 */
function ds_core_registro_con_testi() {
	$core     = ds_core_testi_core();
	$registro = ds_core_registro();
	foreach ( $registro as $id => $modulo ) {
		$testi = array();
		if ( empty( $modulo['esterno'] ) && isset( $core[ $id ] ) ) {
			$testi = $core[ $id ];
		} elseif ( is_callable( $modulo['testi'] ) ) {
			$dati  = call_user_func( $modulo['testi'] );
			$testi = is_array( $dati ) ? $dati : array();
		}
		foreach ( array( 'titolo', 'descrizione', 'avviso' ) as $campo ) {
			if ( isset( $testi[ $campo ] ) && is_string( $testi[ $campo ] ) ) {
				$registro[ $id ][ $campo ] = $testi[ $campo ];
			}
			$registro[ $id ][ $campo ] = (string) $registro[ $id ][ $campo ];
		}
		if ( isset( $testi['tag'] ) && is_array( $testi['tag'] ) ) {
			$registro[ $id ]['tag'] = $testi['tag'];
		}
		// Testi delle scelte (0.13.0): etichette, aiuti, unità e nomi delle scelte per campo; titoli dei gruppi.
		$registro[ $id ]['testi_campi']  = isset( $testi['campi'] ) && is_array( $testi['campi'] ) ? $testi['campi'] : array();
		$registro[ $id ]['testi_gruppi'] = isset( $testi['gruppi'] ) && is_array( $testi['gruppi'] ) ? $testi['gruppi'] : array();
		// HTML pronto (0.18.2: riga dei colori e anteprima di admin-branding) solo dai moduli di DS Core, già escapato.
		$registro[ $id ]['testi_accanto'] = empty( $modulo['esterno'] ) && isset( $testi['accanto_html'] ) && is_string( $testi['accanto_html'] ) ? $testi['accanto_html'] : '';
		if ( ! empty( $modulo['esterno'] ) ) {
			foreach ( $registro[ $id ]['testi_campi'] as $chiave => $campo ) {
				if ( is_array( $campo ) ) {
					unset( $registro[ $id ]['testi_campi'][ $chiave ]['dopo_html'] );
				}
			}
		}
		if ( '' === $registro[ $id ]['titolo'] ) {
			$registro[ $id ]['titolo'] = $id;
		}
	}
	return $registro;
}

/**
 * Origine di un modulo esterno registrato senza il campo 'origine': il nome del plugin attivo che contiene il file
 * del modulo (intestazione «Plugin Name»), altrimenti 'External'. Solo per il pannello: non decide nulla.
 */
function ds_core_origine_da_file( $file ) {
	static $nomi = array();

	$file    = wp_normalize_path( $file );
	$plugins = trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) );
	if ( '' === $file || 0 !== strpos( $file, $plugins ) ) {
		return 'External';
	}
	$relativo = substr( $file, strlen( $plugins ) );
	$cartella = strtok( $relativo, '/' );
	if ( false === $cartella || $cartella === $relativo ) {
		return 'External'; // file sciolto in wp-content/plugins/: nessuna cartella da cui ricavare il plugin
	}
	if ( isset( $nomi[ $cartella ] ) ) {
		return $nomi[ $cartella ];
	}

	$nome   = 'External';
	$attivi = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$attivi = array_merge( $attivi, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	foreach ( $attivi as $attivo ) {
		if ( is_string( $attivo ) && 0 === strpos( $attivo, $cartella . '/' ) ) {
			$dati = get_file_data( $plugins . $attivo, array( 'nome' => 'Plugin Name' ) );
			if ( ! empty( $dati['nome'] ) ) {
				$nome = sanitize_text_field( $dati['nome'] );
			}
			break;
		}
	}
	$nomi[ $cartella ] = $nome;
	return $nome;
}

<?php
/**
 * Plugin Name:       DS Core
 * Description:       Common site features (security, performance, privacy, administration) split into modules. Turn them on and off from the “DS Core” › “Modules” menu.
 * Version:           0.18.0
 * Author:            Daniele Smiderle
 * Author URI:        https://www.danielesmiderle.it/
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * Text Domain:       ds-core
 * Domain Path:       /languages
 * Update URI:        ds-core
 *
 * Update URI (dalla 0.16.0): WordPress non cerca questo plugin su wordpress.org e chiede la versione nuova
 * all'aggiornatore firmato (includes/aggiornatore.php, filtro update_plugins_{host}). Deve restare uguale a
 * DS_CORE_RILASCI_URI.
 */

defined( 'ABSPATH' ) || exit;

define( 'DS_CORE_VERSIONE', '0.18.0' );
define( 'DS_CORE_FILE', __FILE__ );
define( 'DS_CORE_DIR', __DIR__ . '/' );
define( 'DS_CORE_URL', plugin_dir_url( __FILE__ ) );

/*
 * Struttura:
 * - includes/registro.php   elenco dei moduli (di DS Core e quelli registrati da DS Woo e dai plugin dei siti)
 * - includes/opzioni.php    scelte dei moduli e di DS Core: lettura con i predefiniti, migrazioni dei dati salvati
 * - includes/eventi.php     API del registro delle attività (ds_core_registra_evento), pulizia giornaliera
 * - includes/avvisi.php     indirizzo degli avvisi: invio (ds_core_manda_avviso), conferma del cambio, emergenza
 * - includes/aggiornatore.php aggiornatore firmato di DS Core (manifest del canale, verifica Ed25519 del pacchetto)
 * - includes/caricatore.php carica i moduli accesi, salta quelli spenti, registra gli errori
 * - includes/htaccess.php   blocchi dei moduli nel .htaccess (scrittura, controllo del sito, pulizia)
 * - includes/pannello.php   menu «DS Core» e pagina «Moduli» in amministrazione
 * - includes/impostazioni.php disegno e salvataggio delle scelte dichiarate nel registro (solo amministrazione)
 * - moduli/                 un file per modulo
 *
 * Un modulo nuovo: file in moduli/ + voce in ds_core_registro_core().
 * Nessun percorso, dominio o account scritto nel codice: tutto si ricava da WordPress (portabilità).
 */
require_once DS_CORE_DIR . 'includes/opzioni.php';
require_once DS_CORE_DIR . 'includes/eventi.php';
require_once DS_CORE_DIR . 'includes/avvisi.php';
// Sempre caricato, anche con l'interruttore d'emergenza: deve poter portare la correzione di un modulo guasto.
require_once DS_CORE_DIR . 'includes/aggiornatore.php';
require_once DS_CORE_DIR . 'includes/registro.php';
require_once DS_CORE_DIR . 'includes/caricatore.php';
require_once DS_CORE_DIR . 'includes/htaccess.php';

// Disattivare DS Core non lascia modifiche: via i blocchi dei moduli dal .htaccess.
register_deactivation_hook( __FILE__, 'ds_core_htaccess_togli_tutti' );
// …e nessun evento pianificato del registro delle attività resta senza chi lo esegue.
register_deactivation_hook( __FILE__, 'ds_core_eventi_disattiva' );

// I moduli si caricano quando tutti i plugin sono caricati, così si possono controllare le dipendenze
// (WooCommerce, DS Woo, il plugin del sito) e i moduli registrati dagli altri plugin.
add_action( 'plugins_loaded', 'ds_core_carica', 5 );

// Traduzioni (regole di WordPress): testi in inglese nel codice, file in languages/ generati da
// strumenti/ds-core-traduzioni.py. Si caricano su init, mai prima: i moduli non traducono nulla al caricamento.
add_action( 'init', 'ds_core_lingue', 1 );
function ds_core_lingue() {
	load_plugin_textdomain( 'ds-core', false, dirname( plugin_basename( DS_CORE_FILE ) ) . '/languages' );
}

if ( is_admin() ) {
	require_once DS_CORE_DIR . 'includes/pannello.php';
	require_once DS_CORE_DIR . 'includes/impostazioni.php';
}

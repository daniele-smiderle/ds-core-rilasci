<?php
/**
 * Blocchi di DS Core nel .htaccess della radice, con il sistema di WordPress (insert_with_markers): ogni modulo ha il
 * suo blocco «# BEGIN DS Core <id>» … «# END DS Core <id>» e non tocca il resto del file.
 *
 * Regole:
 * - si scrive solo da una richiesta di amministrazione e solo se il contenuto cambia;
 * - dopo ogni scrittura si controllano la home e un file statico: se non rispondono 200, si rimette il file di prima;
 * - il blocco di un modulo si toglie quando il modulo si spegne e quando DS Core si disattiva (tutti i blocchi);
 * - l'interruttore d'emergenza DS_CORE_SPENTI non tocca il file: i blocchi restano finché il modulo non si spegne dal
 *   pannello o non si cancellano a mano (sono righe con i marcatori, facili da riconoscere).
 *
 * ID rinominati nella 0.17.0 (ds_core_id_rinominati()): il blocco scritto con il vecchio ID («DS Core header-dati»)
 * si legge ancora come blocco del modulo (security-headers). Alla prima scrittura da amministrazione i suoi marcatori
 * si rinominano sul posto, in una sola scrittura e senza cambiare le righe in mezzo: il sito non resta mai senza
 * intestazioni. Se ci sono tutti e due i blocchi (per esempio dopo un ritorno temporaneo alla 0.16.x), il vecchio si
 * toglie quando si scrive il nuovo. Spegnere il modulo toglie tutti e due.
 */

defined( 'ABSPATH' ) || exit;

/** Percorso del .htaccess della radice di WordPress. */
function ds_core_htaccess_file() {
	if ( ! function_exists( 'get_home_path' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	return get_home_path() . '.htaccess';
}

/** Il server legge il .htaccess? (Apache o LiteSpeed; Nginx no). */
function ds_core_htaccess_supportato() {
	$server = isset( $_SERVER['SERVER_SOFTWARE'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) ) : '';
	return false !== strpos( $server, 'apache' ) || false !== strpos( $server, 'litespeed' );
}

/**
 * Righe attuali del blocco di un modulo, senza i commenti (array vuoto se non c'è). I commenti si tolgono perché
 * insert_with_markers aggiunge in cima al blocco le sue righe di istruzioni.
 */
function ds_core_htaccess_leggi( $id ) {
	if ( ! function_exists( 'extract_from_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}
	$file = ds_core_htaccess_file();
	if ( ! file_exists( $file ) ) {
		return array();
	}
	$righe = ds_core_htaccess_senza_commenti( extract_from_markers( $file, 'DS Core ' . $id ) );
	// Blocco ancora con il vecchio ID (prima della 0.17.0): vale come quello del modulo finché non si rinomina.
	$vecchio = ds_core_id_vecchio( $id );
	if ( ! $righe && '' !== $vecchio ) {
		$righe = ds_core_htaccess_senza_commenti( extract_from_markers( $file, 'DS Core ' . $vecchio ) );
	}
	return $righe;
}

/** Espressione che trova il blocco intero di un ID, marcatori compresi. */
function ds_core_htaccess_regex_blocco( $id ) {
	return '/^# BEGIN DS Core ' . preg_quote( $id, '/' ) . '\R.*?^# END DS Core ' . preg_quote( $id, '/' ) . '\R?/ms';
}

/**
 * Vecchi marcatori (ID di prima della 0.17.0) → nuovi, nel testo del file. Senza blocco nuovo i marcatori del vecchio
 * si rinominano sul posto (righe in mezzo invariate); con tutti e due il vecchio si toglie. Restituisce il testo.
 */
function ds_core_htaccess_testo_rinominato( $testo, $id ) {
	$vecchio = ds_core_id_vecchio( $id );
	if ( '' === $vecchio || false === strpos( $testo, '# BEGIN DS Core ' . $vecchio ) ) {
		return $testo;
	}
	if ( preg_match( '/^# BEGIN DS Core ' . preg_quote( $id, '/' ) . '\R/m', $testo ) ) {
		$pulito = preg_replace( ds_core_htaccess_regex_blocco( $vecchio ), '', $testo );
		return is_string( $pulito ) ? $pulito : $testo;
	}
	$nuovo = preg_replace(
		array( '/^# BEGIN DS Core ' . preg_quote( $vecchio, '/' ) . '(\R)/m', '/^# END DS Core ' . preg_quote( $vecchio, '/' ) . '(\R|$)/m' ),
		array( '# BEGIN DS Core ' . $id . '$1', '# END DS Core ' . $id . '$1' ),
		$testo
	);
	if ( ! is_string( $nuovo ) ) {
		return $testo;
	}
	// Le righe di istruzioni che insert_with_markers mette in cima al blocco nominano il marcatore fra virgolette.
	return str_replace(
		array( '"BEGIN DS Core ' . $vecchio . '"', '"END DS Core ' . $vecchio . '"' ),
		array( '"BEGIN DS Core ' . $id . '"', '"END DS Core ' . $id . '"' ),
		$nuovo
	);
}

/**
 * Rinomina il blocco di un modulo scritto con il vecchio ID (una scrittura, contenuto invariato). True se ha scritto.
 * Solo dalle richieste che possono scrivere il .htaccess (ds_core_htaccess_scrivi()).
 */
function ds_core_htaccess_rinomina( $id ) {
	$file = ds_core_htaccess_file();
	if ( '' === ds_core_id_vecchio( $id ) || ! file_exists( $file ) || ! wp_is_writable( $file ) ) {
		return false;
	}
	$testo = file_get_contents( $file );
	if ( false === $testo ) {
		return false;
	}
	$nuovo = ds_core_htaccess_testo_rinominato( $testo, $id );
	if ( $nuovo === $testo ) {
		return false;
	}
	if ( false === file_put_contents( $file, $nuovo ) ) {
		return false;
	}
	ds_core_htaccess_evento( $id, 'rinominato' );
	return true;
}

/** Righe senza commenti e righe vuote, per confrontare due blocchi. */
function ds_core_htaccess_senza_commenti( $righe ) {
	return array_values(
		array_filter(
			array_map( 'trim', (array) $righe ),
			function ( $riga ) {
				return '' !== $riga && 0 !== strpos( $riga, '#' );
			}
		)
	);
}

/** Risposta della home e di un file statico di WordPress: true se entrambe 200. */
function ds_core_htaccess_sito_ok() {
	$prove = array(
		add_query_arg( 'ds_core_prova', time(), home_url( '/' ) ),
		includes_url( 'css/dashicons.min.css' ),
	);
	foreach ( $prove as $url ) {
		$risposta = wp_remote_get( $url, array( 'timeout' => 20, 'redirection' => 3, 'sslverify' => false ) );
		if ( is_wp_error( $risposta ) || 200 !== (int) wp_remote_retrieve_response_code( $risposta ) ) {
			return false;
		}
	}
	return true;
}

/**
 * Scrive il blocco di un modulo e controlla il sito. $righe vuoto = toglie il blocco.
 * Restituisce true, oppure un codice: 'non-supportato', 'non-scrivibile', 'sito-ko' (file di prima rimesso).
 */
function ds_core_htaccess_scrivi( $id, $righe ) {
	if ( ! ds_core_htaccess_supportato() ) {
		return 'non-supportato';
	}
	if ( ! function_exists( 'insert_with_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}
	$file = ds_core_htaccess_file();
	if ( ( file_exists( $file ) && ! wp_is_writable( $file ) ) || ( ! file_exists( $file ) && ! wp_is_writable( dirname( $file ) ) ) ) {
		ds_core_htaccess_evento( $id, 'non-scrivibile' );
		return 'non-scrivibile';
	}
	// Blocco con il vecchio ID (0.17.0): prima si rinomina, così il confronto e la scrittura valgono per quello.
	if ( $righe ) {
		ds_core_htaccess_rinomina( $id );
	}
	if ( ds_core_htaccess_senza_commenti( $righe ) === ds_core_htaccess_leggi( $id ) ) {
		return true;
	}
	$prima = file_exists( $file ) ? file_get_contents( $file ) : null;
	if ( ! $righe ) {
		// Togliere: via il blocco intero, marcatori compresi (insert_with_markers lascerebbe i marcatori vuoti); anche
		// quello con il vecchio ID, se c'è ancora.
		if ( null !== $prima ) {
			$pulito  = preg_replace( ds_core_htaccess_regex_blocco( $id ), '', $prima );
			$vecchio = ds_core_id_vecchio( $id );
			if ( is_string( $pulito ) && '' !== $vecchio ) {
				$pulito = preg_replace( ds_core_htaccess_regex_blocco( $vecchio ), '', $pulito );
			}
			if ( is_string( $pulito ) && $pulito !== $prima ) {
				file_put_contents( $file, $pulito );
				ds_core_htaccess_evento( $id, 'tolto' );
			}
		}
		return true;
	}
	if ( ! insert_with_markers( $file, 'DS Core ' . $id, (array) $righe ) ) {
		ds_core_htaccess_evento( $id, 'non-scrivibile' );
		return 'non-scrivibile';
	}
	if ( $righe && ! ds_core_htaccess_sito_ok() ) {
		if ( null === $prima ) {
			wp_delete_file( $file );
		} else {
			file_put_contents( $file, $prima );
		}
		ds_core_htaccess_evento( $id, 'ripristinato' );
		return 'sito-ko';
	}
	ds_core_htaccess_evento( $id, 'scritto' );
	return true;
}

/**
 * Registro delle attività (0.14.0): blocco scritto, tolto, file rimesso com'era, file non scrivibile (al più una
 * riga al giorno per modulo, perché il controllo si ripete ogni ora).
 */
function ds_core_htaccess_evento( $id, $azione ) {
	$livelli = array( 'scritto' => 2, 'tolto' => 2, 'ripristinato' => 3, 'non-scrivibile' => 2, 'rinominato' => 1 );
	ds_core_registra_evento(
		'dscore.htaccess',
		array(
			'livello' => $livelli[ $azione ] ?? 2,
			'origine' => $id,
			'oggetto' => $id,
			'dati'    => array( 'azione' => $azione ),
			'ogni'    => 'non-scrivibile' === $azione ? DAY_IN_SECONDS : 0,
		)
	);
}

// Un modulo spento perde il suo blocco (se ne aveva uno).
add_action( 'ds_core_stato_cambiato', 'ds_core_htaccess_modulo_spento', 10, 3 );
function ds_core_htaccess_modulo_spento( $id, $prima, $dopo ) {
	if ( 'spento' === $dopo && ds_core_htaccess_leggi( $id ) ) {
		ds_core_htaccess_scrivi( $id, array() );
	}
}

/** Toglie tutti i blocchi di DS Core (disattivazione del plugin): «disattivare DS Core non lascia modifiche». */
function ds_core_htaccess_togli_tutti() {
	$file = ds_core_htaccess_file();
	if ( ! file_exists( $file ) || ! wp_is_writable( $file ) ) {
		return;
	}
	$testo = file_get_contents( $file );
	if ( false === $testo || false === strpos( $testo, '# BEGIN DS Core ' ) ) {
		return;
	}
	$pulito = preg_replace( '/^# BEGIN DS Core [a-z0-9-]+\R.*?^# END DS Core [a-z0-9-]+\R?/ms', '', $testo );
	if ( is_string( $pulito ) && $pulito !== $testo ) {
		file_put_contents( $file, $pulito );
	}
}

<?php
/**
 * Caricatore dei moduli.
 *
 * Stato scelto di un modulo (opzione ds_core_stati, dal pannello): 'attivo', 'prova' (solo amministratori) o
 * 'spento'. Se nel pannello non è mai stato toccato vale il suo 'predefinito' (di regola 'spento').
 *
 * Prima dello stato scelto vincono, in quest'ordine:
 * 1. l'interruttore d'emergenza in wp-config.php:
 *      define( 'DS_CORE_SPENTI', 'tutti' );                 // spegne tutti i moduli (vale anche 'all')
 *      define( 'DS_CORE_SPENTI', 'modulo-uno,modulo-due' ); // spegne quelli elencati
 *    Gli ID si scrivono come nel pannello; valgono anche i vecchi ID italiani di prima della 0.17.0
 *    (ds_core_id_rinominati(), per esempio 'accesso-code' per claude-code-access).
 * 2. le dipendenze mancanti (campo 'richiede').
 *
 * Non esistono eccezioni per sito scritte nel codice: un modulo da non usare su un sito resta spento nel suo pannello.
 *
 * Un modulo che va in errore mentre si carica viene saltato, l'errore resta nel pannello (opzione
 * ds_core_errori) e il resto del sito funziona. I messaggi d'errore sono tecnici e restano in inglese, come quelli
 * di PHP: si salvano nel database e non dipendono dalla lingua di chi guarda.
 */

defined( 'ABSPATH' ) || exit;

/** ID spenti da wp-config.php ('tutti' = tutti i moduli del registro). */
function ds_core_spenti_da_config() {
	if ( ! defined( 'DS_CORE_SPENTI' ) ) {
		return array();
	}
	$valore = trim( strtolower( (string) DS_CORE_SPENTI ) );
	if ( '' === $valore ) {
		return array();
	}
	if ( in_array( $valore, array( 'tutti', 'tutte', 'all' ), true ) ) {
		return array_keys( ds_core_registro() );
	}
	// Vecchi ID (prima della 0.17.0) e nuovi: una riga scritta in wp-config.php prima del cambio di nome vale ancora.
	return array_values( array_unique( array_map( 'ds_core_id_attuale', array_filter( array_map( 'trim', explode( ',', $valore ) ) ) ) ) );
}

/** Stati scelti dal pannello: array( id => 'attivo'|'prova'|'spento' ). */
function ds_core_stati_salvati() {
	$stati = get_option( 'ds_core_stati', array() );
	return is_array( $stati ) ? $stati : array();
}

/**
 * Stato scelto nel pannello (o predefinito). Accetta anche un vecchio ID (prima della 0.17.0); se lo stato non è
 * ancora salvato con l'ID nuovo (migrazione non ancora fatta) vale quello salvato con il vecchio.
 */
function ds_core_stato_scelto( $id ) {
	$id       = ds_core_id_attuale( $id );
	$registro = ds_core_registro();
	$salvati  = ds_core_stati_salvati();
	$vecchio  = ds_core_id_vecchio( $id );
	$stato    = $salvati[ $id ] ?? ( '' !== $vecchio && isset( $salvati[ $vecchio ] ) ? $salvati[ $vecchio ] : ( $registro[ $id ]['predefinito'] ?? 'spento' ) );
	if ( 'prova' === $stato && empty( $registro[ $id ]['tre_stati'] ) ) {
		$stato = 'attivo';
	}
	return in_array( $stato, array( 'attivo', 'prova', 'spento' ), true ) ? $stato : 'spento';
}

/**
 * Dipendenze mancanti. Il caricatore usa solo se l'elenco è vuoto; i testi (tradotti) servono al pannello.
 */
function ds_core_dipendenze_mancanti( $id ) {
	$id       = ds_core_id_attuale( $id );
	$registro = ds_core_registro();
	$richiede = $registro[ $id ]['richiede'] ?? array();
	$mancanti = array();

	foreach ( (array) ( $richiede['classi'] ?? array() ) as $classe ) {
		if ( ! class_exists( $classe ) ) {
			/* translators: %s: PHP class name. */
			$mancanti[] = sprintf( __( 'class %s', 'ds-core' ), $classe );
		}
	}
	foreach ( (array) ( $richiede['funzioni'] ?? array() ) as $funzione ) {
		if ( ! function_exists( $funzione ) ) {
			/* translators: %s: PHP function name. */
			$mancanti[] = sprintf( __( 'function %s', 'ds-core' ), $funzione );
		}
	}
	foreach ( (array) ( $richiede['moduli'] ?? array() ) as $modulo ) {
		$modulo = ds_core_id_attuale( $modulo ); // un modulo esterno può ancora nominare un vecchio ID
		if ( ! isset( $registro[ $modulo ] ) || 'spento' === ds_core_stato_scelto( $modulo ) ) {
			/* translators: %s: module ID. */
			$mancanti[] = sprintf( __( 'module %s', 'ds-core' ), $modulo );
		}
	}
	return $mancanti;
}

/**
 * Stato effettivo: 'attivo', 'prova', 'spento', 'spento-config' (emergenza), 'dipendenze' (manca qualcosa che il
 * modulo richiede).
 */
function ds_core_stato( $id ) {
	$id = ds_core_id_attuale( $id );
	if ( in_array( $id, ds_core_spenti_da_config(), true ) ) {
		return 'spento-config';
	}
	$scelto = ds_core_stato_scelto( $id );
	if ( 'spento' !== $scelto && ds_core_dipendenze_mancanti( $id ) ) {
		return 'dipendenze';
	}
	return $scelto;
}

/**
 * Aggiunge una riga alla storia del pannello (opzione ds_core_storia, ultime 50 righe, più recenti in cima).
 *
 * La usano il pannello (cambi di stato dei moduli) e i moduli per i loro eventi, per esempio claude-code-access per le
 * aperture e le chiusure. $da e $a sono stati del pannello ('attivo', 'spento', …) o testi brevi.
 * $da e $a si salvano come codici quando possibile (stati del pannello, 'accesso:…' di claude-code-access): il pannello
 * li traduce quando li mostra. $utente: nome di chi ha agito; vuoto = utente collegato; Chi chiama durante l'autenticazione (prima che
 * l'utente sia stabilito) deve passare un nome, per esempio 'automatico', per non rientrare nell'autenticazione.
 * $quando: momento dell'evento (timestamp); 0 = adesso.
 */
function ds_core_storia_aggiungi( $id, $da, $a, $utente = '', $quando = 0 ) {
	$id = ds_core_id_attuale( $id );
	if ( '' === $utente ) {
		$corrente = wp_get_current_user();
		$utente   = $corrente->exists() ? $corrente->user_login : 'automatico';
	}
	$storia = get_option( 'ds_core_storia', array() );
	$storia = is_array( $storia ) ? $storia : array();
	array_unshift(
		$storia,
		array(
			'quando' => $quando ? (int) $quando : time(),
			'utente' => (string) $utente,
			'id'     => (string) $id,
			'da'     => (string) $da,
			'a'      => (string) $a,
		)
	);
	update_option( 'ds_core_storia', array_slice( $storia, 0, 50 ), false );
	// Dalla 0.14.0 la stessa riga va anche nel registro delle attività, se acceso (includes/eventi.php).
	ds_core_eventi_storia( $id, $da, $a, $utente, $quando );
}

/** Carica i moduli attivi; quelli in prova si caricano su 'init', solo per gli amministratori. */
function ds_core_carica() {
	$in_prova = array();
	foreach ( ds_core_registro() as $id => $modulo ) {
		$stato = ds_core_stato( $id );
		if ( 'attivo' === $stato ) {
			ds_core_includi( $id, $modulo );
		} elseif ( 'prova' === $stato ) {
			$in_prova[ $id ] = $modulo;
		}
	}

	if ( $in_prova ) {
		add_action(
			'init',
			function () use ( $in_prova ) {
				if ( ! current_user_can( 'manage_options' ) ) {
					return;
				}
				foreach ( $in_prova as $id => $modulo ) {
					ds_core_includi( $id, $modulo );
				}
			},
			0
		);
	}

	do_action( 'ds_core_caricato' );
}

/** Include il file di un modulo; un errore viene registrato e non ferma il sito. */
function ds_core_includi( $id, $modulo ) {
	$errori = get_option( 'ds_core_errori', array() );
	$errori = is_array( $errori ) ? $errori : array();
	$prima  = $errori;

	if ( ! is_readable( $modulo['file'] ) ) {
		$errori[ $id ] = array( 'quando' => time(), 'messaggio' => 'File not found: ' . basename( $modulo['file'] ) );
	} else {
		try {
			require_once $modulo['file'];
			unset( $errori[ $id ] );
		} catch ( \Throwable $e ) {
			$errori[ $id ] = array(
				'quando'    => time(),
				'messaggio' => get_class( $e ) . ': ' . $e->getMessage() . ' (' . basename( $e->getFile() ) . ':' . $e->getLine() . ')',
			);
			error_log( '[DS Core] modulo ' . $id . ' non caricato: ' . $errori[ $id ]['messaggio'] );
		}
	}

	if ( $errori !== $prima ) {
		update_option( 'ds_core_errori', $errori, true );
		// Registro delle attività: comparsa e scomparsa dell'errore (in coda finché il registro non è caricato).
		if ( isset( $errori[ $id ] ) && ( $prima[ $id ]['messaggio'] ?? '' ) !== $errori[ $id ]['messaggio'] ) {
			ds_core_registra_evento( 'dscore.error', array( 'livello' => 3, 'origine' => $id, 'oggetto' => $id, 'utente' => 'automatico', 'ip' => '', 'dati' => array( 'messaggio' => ds_core_eventi_taglia( $errori[ $id ]['messaggio'], 300 ) ) ) );
		} elseif ( ! isset( $errori[ $id ] ) && isset( $prima[ $id ] ) ) {
			ds_core_registra_evento( 'dscore.error', array( 'livello' => 1, 'origine' => $id, 'oggetto' => $id, 'utente' => 'automatico', 'ip' => '', 'dati' => array( 'risolto' => 1 ) ) );
		}
	}
}

/*
 * Indirizzi del pannello (0.18.0): qui e non in pannello.php perché servono anche ai moduli (ritorno dopo un'azione da
 * admin-post.php) e alle mail.
 */

/**
 * Indirizzo del pannello con la scheda e l'ancora: admin.php?page=ds-core[&tab=…][#…]. Scheda vuota o 'all': senza
 * tab (la scheda d'arrivo).
 */
function ds_core_url_pannello( $scheda = '', $ancora = '' ) {
	$scheda = sanitize_key( (string) $scheda );
	$url    = admin_url( 'admin.php?page=ds-core' . ( '' !== $scheda && 'all' !== $scheda ? '&tab=' . $scheda : '' ) );
	return $url . ( '' !== $ancora ? '#' . ltrim( (string) $ancora, '#' ) : '' );
}

/** Scheda del pannello da cui è partita la richiesta (referer), per tornarci dopo un'azione che ricarica. */
function ds_core_scheda_dal_referer() {
	$da = wp_get_referer();
	if ( ! $da ) {
		return '';
	}
	$parti = wp_parse_url( $da );
	if ( empty( $parti['query'] ) ) {
		return '';
	}
	wp_parse_str( $parti['query'], $valori );
	if ( ( $valori['page'] ?? '' ) !== 'ds-core' || empty( $valori['tab'] ) || ! is_string( $valori['tab'] ) ) {
		return '';
	}
	return sanitize_key( $valori['tab'] );
}

<?php
/**
 * Eventi di DS Core (dalla 0.14.0): un'API sola, ds_core_registra_evento(), per tutto ciò che va nel registro delle
 * attività (modulo activity-log, decisione di Daniele del 27/11/2026, docs/ds-core-analisi-registro-attivita.md).
 * Caricato sempre: poche funzioni, nessuna query finché il modulo è spento.
 *
 * - Modulo spento: ds_core_registra_evento() non fa niente (nessuna tabella, nessuna query). La storia del pannello
 *   (ds_core_storia, ultime 50 righe) e il registro di aggiornamenti restano come prima.
 * - Modulo acceso: ogni evento è una riga della tabella {prefisso}ds_core_eventi (creata dal modulo con dbDelta).
 *   Gli eventi nati mentre i moduli si caricano (errori di caricamento) aspettano in coda fino a 'ds_core_caricato'.
 * - La pulizia giornaliera (conservazione scelta nel modulo: 30, 90 (base) o 365 giorni oppure personalizzata 7-730, più un tetto di righe) sta qui e non
 *   nel modulo: gira anche a modulo spento, così i dati vecchi spariscono comunque; quando il modulo è spento e la
 *   tabella è vuota, la tabella si toglie.
 *
 * DS Woo e i plugin dei siti scrivono i loro eventi con la stessa funzione:
 *
 *   if ( function_exists( 'ds_core_registra_evento' ) ) {
 *       ds_core_registra_evento( 'ds-xx.something', array( 'livello' => 2, 'origine' => 'ds-xx', 'oggetto' => '…' ) );
 *   }
 *
 * Chiavi di un evento: livello (1 informazione, 2 da notare, 3 allarme), origine (chi scrive: 'wordpress', 'ds-core',
 * ID del modulo, plugin), oggetto (cosa: nome del plugin, login dell'utente toccato, nome dell'ability…), dati (array
 * piccolo, salvato come JSON di al più 2 KB), utente / utente_id (chi ha agito; senza, l'utente collegato), via
 * (browser, app-password, mcp, cron, wp-cli, hosting, sistema; senza, ricavata dalla richiesta), quando (timestamp),
 * ogni (secondi: non scrive se lo stesso tipo e oggetto c'è già in questo intervallo).
 *
 * Mai nel registro: password, argomenti delle chiamate MCP, corpi delle richieste, visite, accessi falliti.
 */

defined( 'ABSPATH' ) || exit;

/** Versione dello schema della tabella: cambia solo se cambiano le colonne (il modulo rilancia dbDelta). */
const DS_CORE_EVENTI_SCHEMA = '1';

/** Nome completo della tabella. */
function ds_core_eventi_tabella() {
	global $wpdb;
	return $wpdb->prefix . 'ds_core_eventi';
}

/** La tabella esiste ed è allo schema attuale (opzione autoload: nessuna query in più). */
function ds_core_eventi_pronta() {
	return DS_CORE_EVENTI_SCHEMA === (string) get_option( 'ds_core_ra_db', '' );
}

/** Il modulo activity-log è caricato in questa richiesta. */
function ds_core_eventi_acceso() {
	return defined( 'DS_CORE_RA_ACCESO' );
}

/**
 * Contesto della richiesta, impostato dal modulo: 'mcp' (chiamata MCP o di un'ability) e 'app-password' (accesso con
 * una password per le applicazioni). Serve a dire «via» per gli eventi nati dentro quella richiesta.
 */
function ds_core_eventi_contesto( $chiave, $valore = null ) {
	static $contesto = array();
	if ( null !== $valore ) {
		$contesto[ $chiave ] = $valore;
	}
	return $contesto[ $chiave ] ?? false;
}

/** Da dove arriva la richiesta in corso. Non chiede l'utente collegato prima che WordPress l'abbia stabilito. */
function ds_core_eventi_via() {
	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		return 'wp-cli';
	}
	if ( wp_doing_cron() ) {
		return 'cron';
	}
	if ( ds_core_eventi_contesto( 'mcp' ) ) {
		return 'mcp';
	}
	if ( ds_core_eventi_contesto( 'app-password' ) ) {
		return 'app-password';
	}
	if ( did_action( 'set_current_user' ) && get_current_user_id() ) {
		return 'browser';
	}
	return 'sistema';
}

/**
 * Indirizzo IP di chi fa la richiesta: solo REMOTE_ADDR (le intestazioni dei proxy si possono falsificare). Il filtro
 * 'ds_core_eventi_ip' serve ai siti dietro un proxy fidato.
 */
function ds_core_eventi_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$ip = (string) apply_filters( 'ds_core_eventi_ip', $ip );
	return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
}

/** Testo tagliato a $max caratteri (multibyte se possibile). */
function ds_core_eventi_taglia( $testo, $max ) {
	$testo = (string) $testo;
	return function_exists( 'mb_substr' ) ? mb_substr( $testo, 0, $max ) : substr( $testo, 0, $max );
}

/** JSON dei dati, al più 2 KB: prima si accorciano i testi lunghi, poi si rinuncia ai dati. */
function ds_core_eventi_json( $dati ) {
	if ( ! is_array( $dati ) || ! $dati ) {
		return '';
	}
	$json = (string) wp_json_encode( $dati );
	if ( strlen( $json ) <= 2048 ) {
		return $json;
	}
	array_walk_recursive(
		$dati,
		function ( &$valore ) {
			if ( is_string( $valore ) ) {
				$valore = ds_core_eventi_taglia( $valore, 100 );
			}
		}
	);
	$json = (string) wp_json_encode( $dati );
	return strlen( $json ) <= 2048 ? $json : '{"troncato":true}';
}

/**
 * Registra un evento. Restituisce true se è stato scritto (o messo in coda), false se il registro è spento.
 * 'forza' => true scrive anche se il modulo non è caricato in questa richiesta, purché la tabella esista: serve solo
 * per l'accensione del modulo stesso.
 */
function ds_core_registra_evento( $tipo, $evento = array() ) {
	static $coda = array();

	$evento         = is_array( $evento ) ? $evento : array();
	$evento['tipo'] = (string) $tipo;
	if ( 'svuota-coda' === $tipo ) {
		$attesa = $coda;
		$coda   = array();
		if ( ds_core_eventi_acceso() ) {
			foreach ( $attesa as $voce ) {
				ds_core_eventi_scrivi( $voce );
			}
		}
		return true;
	}
	if ( ds_core_eventi_acceso() || ( ! empty( $evento['forza'] ) && ds_core_eventi_pronta() ) ) {
		return ds_core_eventi_scrivi( $evento );
	}
	if ( ! did_action( 'ds_core_caricato' ) ) {
		// Il modulo potrebbe caricarsi più avanti nella stessa richiesta: la coda si svuota su 'ds_core_caricato'.
		$evento['quando']   = $evento['quando'] ?? time();
		$coda[]             = $evento;
		return true;
	}
	return false;
}

add_action( 'ds_core_caricato', 'ds_core_eventi_svuota_coda', 99 );
function ds_core_eventi_svuota_coda() {
	ds_core_registra_evento( 'svuota-coda' );
}

/** Scrive una riga nella tabella. Un errore del database non ferma mai la richiesta. */
function ds_core_eventi_scrivi( $evento ) {
	global $wpdb;
	if ( ! ds_core_eventi_pronta() ) {
		return false;
	}
	$tipo = preg_replace( '/[^a-z0-9._-]/', '', strtolower( (string) ( $evento['tipo'] ?? '' ) ) );
	if ( '' === $tipo ) {
		return false;
	}
	$tipo    = substr( $tipo, 0, 40 );
	$oggetto = ds_core_eventi_taglia( sanitize_text_field( (string) ( $evento['oggetto'] ?? '' ) ), 191 );
	$quando  = isset( $evento['quando'] ) ? (int) $evento['quando'] : time();
	$tabella = ds_core_eventi_tabella();

	// Una volta ogni N secondi per lo stesso tipo e oggetto (per esempio «.htaccess non scrivibile»).
	if ( ! empty( $evento['ogni'] ) ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabella propria, nome fisso.
		$gia = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tabella} WHERE tipo = %s AND oggetto = %s AND quando >= %d LIMIT 1", $tipo, $oggetto, $quando - (int) $evento['ogni'] ) );
		if ( $gia ) {
			return false;
		}
	}

	// Chi ha agito: dato dall'evento, altrimenti l'utente collegato (solo se WordPress l'ha già stabilito).
	$utente_id = isset( $evento['utente_id'] ) ? (int) $evento['utente_id'] : 0;
	$utente    = isset( $evento['utente'] ) ? (string) $evento['utente'] : null;
	if ( null === $utente && $utente_id ) {
		$dati_utente = get_userdata( $utente_id );
		$utente      = $dati_utente ? $dati_utente->user_login : '';
	}
	if ( null === $utente ) {
		if ( did_action( 'set_current_user' ) && get_current_user_id() ) {
			$corrente  = wp_get_current_user();
			$utente_id = (int) $corrente->ID;
			$utente    = $corrente->user_login;
		} else {
			$utente = 'automatico';
		}
	} elseif ( ! $utente_id && '' !== $utente && 'automatico' !== $utente && did_action( 'set_current_user' ) ) {
		$corrente = wp_get_current_user();
		if ( $corrente->exists() && $corrente->user_login === $utente ) {
			$utente_id = (int) $corrente->ID;
		}
	}

	$via = isset( $evento['via'] ) ? (string) $evento['via'] : ds_core_eventi_via();
	if ( array_key_exists( 'ip', $evento ) ) {
		$ip = filter_var( (string) $evento['ip'], FILTER_VALIDATE_IP ) ? (string) $evento['ip'] : '';
	} else {
		// IP solo per le azioni di persone collegate; mai per cron, WP-CLI e sistema.
		$ip = in_array( $via, array( 'browser', 'app-password', 'mcp' ), true ) ? ds_core_eventi_ip() : '';
	}

	$riga = array(
		'quando'    => $quando,
		'livello'   => max( 1, min( 3, (int) ( $evento['livello'] ?? 1 ) ) ),
		'tipo'      => $tipo,
		'origine'   => substr( preg_replace( '/[^a-z0-9._ -]/i', '', (string) ( $evento['origine'] ?? 'ds-core' ) ), 0, 40 ),
		'utente_id' => max( 0, $utente_id ),
		'utente'    => ds_core_eventi_taglia( sanitize_user( $utente, false ), 60 ),
		'via'       => substr( sanitize_key( $via ), 0, 20 ),
		'ip'        => $ip,
		'oggetto'   => $oggetto,
		'dati'      => ds_core_eventi_json( $evento['dati'] ?? array() ),
	);
	$errori = $wpdb->suppress_errors( true );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- tabella propria, una riga per evento.
	$scritto = $wpdb->insert( $tabella, $riga, array( '%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s' ) );
	$wpdb->suppress_errors( $errori );
	return (bool) $scritto;
}

/**
 * Evento corrispondente a una riga della storia del pannello (ds_core_storia_aggiungi): cambi di stato dei moduli,
 * impostazioni salvate, aperture e chiusure di claude-code-access. Usato anche per copiare la storia nella tabella alla prima
 * accensione del registro.
 */
function ds_core_eventi_da_storia( $id, $da, $a, $utente, $quando ) {
	$id     = (string) $id;
	$a      = (string) $a;
	$evento = array(
		'origine' => 'ds-core' === $id || '' === $id ? 'ds-core' : $id,
		'oggetto' => $id,
		'dati'    => array( 'da' => (string) $da, 'a' => $a ),
		'quando'  => (int) $quando,
	);
	if ( '' !== (string) $utente ) {
		$evento['utente'] = (string) $utente;
	}
	if ( 'automatico' === $utente ) {
		$evento['via'] = wp_doing_cron() ? 'cron' : 'sistema';
		$evento['ip']  = '';
	}
	if ( in_array( $a, array( 'attivo', 'prova', 'spento' ), true ) ) {
		$evento['tipo']    = 'dscore.module';
		// Spegnere il registro è esso stesso un allarme (scritto prima che il modulo si fermi).
		$evento['livello'] = 'activity-log' === $id && 'spento' === $a ? 3 : 2;
	} elseif ( 'impostazioni:salvate' === $a || 'agg:salvate' === $a ) {
		$evento['tipo']    = 'dscore.settings';
		$evento['livello'] = 2;
	} elseif ( 0 === strpos( $a, 'accesso:' ) ) {
		$evento['tipo']    = 'dscore.access';
		// Da notare: aperture, chiusure prima della scadenza ('accesso:chiuso:<origine>', con avviso di sicurezza
		// dalla 0.15.1) e scadenze non valide; la chiusura alla scadenza naturale è solo informazione.
		$evento['livello'] = 0 === strpos( $a, 'accesso:aperto' ) || 0 === strpos( $a, 'accesso:chiuso:' ) || 'accesso:non-valido' === $da ? 2 : 1;
	} elseif ( 0 === strpos( $a, 'avvisi:' ) ) {
		// Cambio dell'indirizzo degli avvisi (0.15.0): 'avvisi:<azione>[:<indirizzo mascherato>]'.
		$parti             = explode( ':', $a, 3 );
		$azione            = 'confermata' === ( $parti[1] ?? '' ) ? 'conferma' : (string) ( $parti[1] ?? '' );
		$evento['tipo']    = 'dscore.alerts';
		$evento['livello'] = in_array( $azione, array( 'richiesta', 'conferma' ), true ) ? 3 : 2;
		$evento['dati']    = array( 'azione' => $azione, 'da' => (string) $da, 'a' => (string) ( $parti[2] ?? $da ) );
	} else {
		$evento['tipo']    = 'dscore.note';
		$evento['livello'] = 1;
	}
	return $evento;
}

/** Riga della storia del pannello → registro (chiamata da ds_core_storia_aggiungi). */
function ds_core_eventi_storia( $id, $da, $a, $utente, $quando ) {
	// Le scelte del registro stesso le annota il modulo, con i valori prima e dopo.
	if ( 'activity-log' === $id && 'impostazioni:salvate' === $a ) {
		return;
	}
	// Il cambio dell'indirizzo degli avvisi lo annota includes/avvisi.php, con IP e dati completi.
	if ( 0 === strpos( (string) $a, 'avvisi:' ) ) {
		return;
	}
	$evento = ds_core_eventi_da_storia( $id, $da, $a, $utente, $quando ? $quando : time() );
	// Accensione del registro: in questa richiesta il modulo non è ancora caricato, si scrive se la tabella c'è già.
	if ( 'activity-log' === $id && 'dscore.module' === $evento['tipo'] && 'spento' !== $a ) {
		$evento['forza'] = true;
	}
	$tipo = $evento['tipo'];
	unset( $evento['tipo'] );
	ds_core_registra_evento( $tipo, $evento );
}

/* ---------- Pulizia (sempre caricata) ---------- */

/** Scelte fisse della conservazione (giorni) e limiti del valore personalizzato. */
const DS_CORE_EVENTI_SCELTE = array( 30, 90, 365 );
const DS_CORE_EVENTI_MIN    = 7;
const DS_CORE_EVENTI_MAX    = 730;

/**
 * Giorni di conservazione scelti nel modulo, letti anche a modulo spento: la scelta fissa (30, 90, 365) oppure, con
 * «personalizzato», il numero scritto a mano (7-730). Un solo numero per la pulizia.
 */
function ds_core_eventi_giorni() {
	// Scelte salvate prima della 0.15.0 (solo il numero) e non ancora migrate: vale il numero.
	$salvate = get_option( 'ds_core_ra', array() );
	if ( is_array( $salvate ) && isset( $salvate['giorni'] ) && ! isset( $salvate['conserva'] ) ) {
		return ds_core_eventi_conserva_da_giorni( $salvate['giorni'] )['giorni'];
	}
	$valori   = ds_core_opzioni_modulo( 'activity-log' );
	$conserva = isset( $valori['conserva'] ) ? (string) $valori['conserva'] : '90';
	if ( 'personalizzato' !== $conserva ) {
		return in_array( (int) $conserva, DS_CORE_EVENTI_SCELTE, true ) ? (int) $conserva : 90;
	}
	$giorni = isset( $valori['giorni'] ) ? (int) $valori['giorni'] : 90;
	return max( DS_CORE_EVENTI_MIN, min( DS_CORE_EVENTI_MAX, $giorni ) );
}

/** Da un numero di giorni salvato prima della 0.15.0 alle due chiavi nuove (migrazione). */
function ds_core_eventi_conserva_da_giorni( $giorni ) {
	$giorni = (int) $giorni;
	if ( in_array( $giorni, DS_CORE_EVENTI_SCELTE, true ) ) {
		return array( 'conserva' => (string) $giorni, 'giorni' => $giorni );
	}
	return array( 'conserva' => 'personalizzato', 'giorni' => max( DS_CORE_EVENTI_MIN, min( DS_CORE_EVENTI_MAX, $giorni ) ) );
}

/**
 * Salvataggio delle scelte del registro (anche a modulo spento): con una scelta fissa il campo dei giorni prende quel
 * numero, così nel database c'è sempre il numero di giorni effettivo. Lato server conta la scelta, non il campo.
 */
add_filter( 'ds_core_impostazioni_da_salvare', 'ds_core_eventi_normalizza_scelte', 10, 2 );
function ds_core_eventi_normalizza_scelte( $dopo, $id ) {
	if ( 'activity-log' !== $id || ! is_array( $dopo ) ) {
		return $dopo;
	}
	$conserva = (string) ( $dopo['conserva'] ?? '90' );
	if ( 'personalizzato' !== $conserva ) {
		$dopo['giorni'] = in_array( (int) $conserva, DS_CORE_EVENTI_SCELTE, true ) ? (int) $conserva : 90;
	}
	return $dopo;
}

/**
 * Pulizia giornaliera: righe più vecchie della conservazione, poi oltre il tetto (20.000 righe, filtro
 * 'ds_core_eventi_tetto'), a lotti da 5.000. Con il modulo spento e la tabella vuota, toglie la tabella.
 */
add_action( 'ds_core_ra_pulizia', 'ds_core_eventi_pulisci' );
function ds_core_eventi_pulisci() {
	global $wpdb;
	if ( ! ds_core_eventi_pronta() ) {
		if ( '' === (string) get_option( 'ds_core_ra_db', '' ) ) {
			wp_clear_scheduled_hook( 'ds_core_ra_pulizia' );
		}
		return 0;
	}
	$tabella = ds_core_eventi_tabella();
	$limite  = time() - ds_core_eventi_giorni() * DAY_IN_SECONDS;
	$tolte   = 0;
	// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabella propria, nome fisso.
	for ( $giro = 0; $giro < 40; $giro++ ) {
		$n      = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$tabella} WHERE quando < %d LIMIT 5000", $limite ) );
		$tolte += $n;
		if ( $n < 5000 ) {
			break;
		}
	}
	$tetto  = max( 1000, (int) apply_filters( 'ds_core_eventi_tetto', 20000 ) );
	$soglia = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tabella} ORDER BY id DESC LIMIT 1 OFFSET %d", $tetto ) );
	if ( $soglia ) {
		for ( $giro = 0; $giro < 40; $giro++ ) {
			$n      = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$tabella} WHERE id <= %d LIMIT 5000", $soglia ) );
			$tolte += $n;
			if ( $n < 5000 ) {
				break;
			}
		}
	}
	if ( 'spento' === ds_core_stato_scelto( 'activity-log' ) && ! $wpdb->get_var( "SELECT id FROM {$tabella} LIMIT 1" ) ) {
		ds_core_eventi_togli_tabella();
	}
	// phpcs:enable
	return $tolte;
}

/** Toglie tabella, versione dello schema e pulizia (modulo spento e registro vuoto, disinstallazione). */
function ds_core_eventi_togli_tabella() {
	global $wpdb;
	$tabella = ds_core_eventi_tabella();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabella propria.
	$wpdb->query( "DROP TABLE IF EXISTS {$tabella}" );
	delete_option( 'ds_core_ra_db' );
	wp_clear_scheduled_hook( 'ds_core_ra_pulizia' );
	wp_clear_scheduled_hook( 'ds_core_ra_riepilogo' );
}

// La pulizia è pianificata finché la tabella esiste, anche a modulo spento (opzione e cron in autoload: niente query).
add_action( 'init', 'ds_core_eventi_pianifica_pulizia' );
function ds_core_eventi_pianifica_pulizia() {
	if ( ds_core_eventi_pronta() && ! wp_next_scheduled( 'ds_core_ra_pulizia' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ds_core_ra_pulizia' );
	}
}

// Spegnendo il registro si ferma il riepilogo settimanale; la pulizia continua finché ci sono righe.
add_action( 'ds_core_stato_cambiato', 'ds_core_eventi_modulo_cambiato', 10, 3 );
function ds_core_eventi_modulo_cambiato( $id, $prima, $dopo ) {
	if ( 'activity-log' === $id && 'spento' === $dopo ) {
		wp_clear_scheduled_hook( 'ds_core_ra_riepilogo' );
	}
}

/** Disattivazione di DS Core: nessun evento pianificato resta senza chi lo esegue. */
function ds_core_eventi_disattiva() {
	wp_clear_scheduled_hook( 'ds_core_ra_pulizia' );
	wp_clear_scheduled_hook( 'ds_core_ra_riepilogo' );
}

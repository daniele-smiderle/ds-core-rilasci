<?php
/**
 * Pannello «DS Core» in amministrazione.
 *
 * Solo amministratori (manage_options). Moduli divisi per categoria (Sicurezza, Prestazioni, …) con un interruttore
 * immediato su ogni riga, come in Code Snippets: levetta per i moduli a due stati, pulsanti Spento | Prova | Attivo
 * per quelli a tre stati; un clic salva subito via AJAX (azione ds_core_imposta, nonce, solo amministratori).
 * Filtri lato client per stato, categoria, origine, tag e ricerca; azioni in blocco (Attiva, In prova, Spegni)
 * accanto alla casella «Seleziona tutti», via AJAX (ds_core_blocco), con il modulo HTML come ripiego senza
 * JavaScript. Errori e storia delle modifiche. Nessun editor di codice: il codice si cambia solo nel repository.
 *
 * Azioni sull'intera categoria nella testata di ogni categoria, con conferma (riuso di ds_core_blocco).
 *
 * Impostazioni dei moduli dentro la loro riga (0.12.0): un modulo che nel registro dichiara 'impostazioni' ha il
 * pulsante «Settings» che apre una riga sotto la sua (button con aria-expanded e aria-controls; lo stato aperto si
 * ricorda nel browser). Se dichiara 'problemi', in cima compare un avviso breve con un link che apre la sua riga. In
 * cima restano solo i riquadri dell'aggancio 'ds_core_pannello_riquadri' (oggi «Claude Code access»).
 * Assistenza: riquadro in fondo alla pagina, scheda «Aiuto» di WordPress, link nell'elenco Plugin e nel piè di
 * pagina, tutti verso una mail precompilata con nome del sito e versioni (DS_CORE_ASSISTENZA).
 *
 * Scelte dichiarate nel registro (0.13.0, includes/impostazioni.php): nella riga sotto il modulo prima lo stato e le
 * azioni (solo a modulo acceso, chieste di nuovo con ds_core_riga dopo un cambio di stato), poi le scelte con il loro
 * «Save settings», visibili e salvabili anche a modulo spento. In fondo alla pagina le impostazioni generali di DS
 * Core (#ds-generali): l'indirizzo unico per tutte le mail; sotto, il riquadro «DS Core updates» (0.16.1, solo righe
 * informative: ultimo controllo; canale e indirizzo solo con il canale di prova o DS_CORE_RILASCI_URL).
 *
 * Icone degli stati (0.12.1): acceso = simbolo di accensione, prova = provetta, spento = cerchio barrato, sui
 * pulsanti a tre stati e sulle azioni in blocco; le azioni su tutta la categoria usano lo stesso simbolo con un
 * secondo dietro. Stesso disegno delle icone dell'aspetto (ds_core_icona), testo sempre accanto.
 *
 * Aspetto: chiaro, scuro o automatico (segue il sistema operativo), scelto da ogni amministratore per sé
 * (metadato utente ds_core_tema) e applicato solo alle pagine di DS Core: il resto dell'amministrazione non cambia.
 *
 * Registro delle attività (0.14.0): la sottopagina «Activity log» la aggiunge il modulo activity-log quando è
 * acceso; qui serve solo ds_core_schermata_nostra() per stile e aspetto.
 *
 * Nuovo pannello (0.18.0, docs/ds-core-analisi-pannello-ux.md, decisioni di Daniele del 27/11/2026):
 * - sottomenu Modules · Activity log (se acceso) · Settings · Help & support: le ultime due sono voci senza pagina
 *   propria che puntano a admin.php?page=ds-core&tab=…, registrate a priorità 99 (restano in fondo anche con DS Woo e
 *   i plugin dei siti); la voce giusta si evidenzia con il filtro submenu_file e, cambiando scheda senza ricaricare,
 *   dallo script;
 * - schede in stile WordPress (nav-tab): All · categorie con moduli │ Settings · Help. Il server disegna tutto e
 *   nasconde (hidden) le parti non scelte secondo ?tab=, così senza JavaScript le schede sono link veri; con
 *   JavaScript il cambio è immediato e l'indirizzo segue con history.replaceState. Modello «Tabs» di WAI-ARIA;
 * - righe compatte a 4 colonne (selezione, interruttore, modulo, «Settings»/«Details»), con una riga di descrizione e
 *   una di riepilogo (ds_core_riepilogo_html(), includes/impostazioni.php); tutto il resto nella riga aperta, l'ID
 *   del modulo e «Replaces» solo in «Technical details»;
 * - impostazioni generali nella scheda Settings (righe con «Change»), aiuto, emergenza e assistenza nella scheda
 *   Help; «Recent changes» chiuso sotto l'elenco, ultime 5 righe.
 * Il ritorno dopo un'azione che ricarica (admin-post.php) tiene la scheda: ds_core_url_pannello() con la scheda
 * letta dal referer (ds_core_scheda_dal_referer()).
 *
 * Lingue (regole di WordPress): testi in inglese nel codice, text domain 'ds-core', traduzioni in languages/
 * (.l10n.php, .mo, .po; JSON per il JavaScript via wp.i18n). Le genera strumenti/ds-core-traduzioni.py. Ogni
 * amministratore vede il pannello nella lingua del suo profilo. Date e ore nel formato delle impostazioni del sito.
 *
 * Menu unico (kb ARCH-10): il menu di primo livello «DS Core» (slug 'ds-core') ha come prima voce «Moduli», questa
 * pagina. DS Woo e i plugin dei siti («DS XX») non creano un menu loro: aggiungono le loro pagine sotto «DS Core»,
 * con priorità dopo la 10 così il menu esiste già:
 *
 *   add_action( 'admin_menu', function () {
 *       add_submenu_page( 'ds-core', __( 'DS XX settings', 'ds-xx' ), 'DS XX', 'manage_options', 'ds-xx', 'ds_xx_pagina' );
 *   }, 20 );
 *
 * L'aggancio della loro pagina per admin_enqueue_scripts è 'ds-core_page_<slug>' (es. 'ds-core_page_ds-xx').
 * I loro moduli entrano invece in questa pagina con il filtro 'ds_core_registro' (includes/registro.php).
 */

defined( 'ABSPATH' ) || exit;

const DS_CORE_PAGINA = 'ds-core';

/*
 * Assistenza: un solo indirizzo, scritto qui. Il link apre la mail con oggetto e dati del sito già compilati
 * (nome, indirizzo, versioni), così chi scrive non deve cercarli. Niente voto: DS Core non è su wordpress.org.
 */
const DS_CORE_ASSISTENZA = 'daniele@danielesmiderle.it';

/**
 * Icone del pannello: SVG in linea, 16×16, nel colore del testo (currentColor), nascoste ai lettori di schermo
 * perché il testo accanto dice già tutto. Restituisce markup fisso, senza dati esterni.
 */
function ds_core_icona( $nome ) {
	$tratto = 'fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"';
	$forme  = array(
		// Cerchio diviso a metà: segue il sistema.
		'auto'   => '<circle cx="8" cy="8" r="6.25" ' . $tratto . '/><path d="M8 1.75a6.25 6.25 0 0 1 0 12.5z" fill="currentColor"/>',
		// Sole.
		'chiaro' => '<circle cx="8" cy="8" r="3" ' . $tratto . '/><path d="M8 .75v2M8 13.25v2M.75 8h2M13.25 8h2M2.87 2.87l1.42 1.42M11.71 11.71l1.42 1.42M2.87 13.13l1.42-1.42M11.71 4.29l1.42-1.42" ' . $tratto . '/>',
		// Luna.
		'scuro'  => '<path d="M13.6 10.1A6 6 0 0 1 5.9 2.4a6 6 0 1 0 7.7 7.7z" ' . $tratto . '/>',
		// Lucchetto aperto e chiuso (claude-code-access).
		'aperto' => '<rect x="2.75" y="7.25" width="10.5" height="7" rx="1.5" ' . $tratto . '/><path d="M5.25 7.25V4.75a2.75 2.75 0 0 1 5.4-.75" ' . $tratto . '/>',
		'chiuso' => '<rect x="2.75" y="7.25" width="10.5" height="7" rx="1.5" ' . $tratto . '/><path d="M5.25 7.25V4.75a2.75 2.75 0 0 1 5.5 0v2.5" ' . $tratto . '/>',
		// Busta (assistenza).
		'mail'   => '<rect x="1.75" y="3.25" width="12.5" height="9.5" rx="1.5" ' . $tratto . '/><path d="M2.25 4.25 8 8.75l5.75-4.5" ' . $tratto . '/>',
		// Croce (togli i filtri).
		'x'      => '<path d="M4.5 4.5l7 7M11.5 4.5l-7 7" ' . $tratto . '/>',
		/*
		 * Stati del modulo, una famiglia sola: acceso = simbolo di accensione, prova = provetta, spento = cerchio
		 * barrato. Servono ai pulsanti a tre stati della riga e ai pulsanti delle azioni in blocco.
		 */
		'acceso' => '<path d="M4.4 4.1a5.5 5.5 0 1 0 7.2 0M8 1.75V7" ' . $tratto . '/>',
		'prova'  => '<path d="M5.75 1.75h4.5M6.75 1.75v4.5L2.9 12.6a1.15 1.15 0 0 0 1 1.65h8.2a1.15 1.15 0 0 0 1-1.65L9.25 6.25v-4.5M4.55 10h6.9" ' . $tratto . '/>',
		'spento' => '<circle cx="8" cy="8" r="6.25" ' . $tratto . '/><path d="M3.6 3.6l8.8 8.8" ' . $tratto . '/>',
		/*
		 * Tutta la categoria: lo stesso simbolo, più piccolo e in basso a sinistra, con l'arco di un secondo
		 * simbolo dietro (in alto a destra) che dice «tutti, non uno».
		 */
		'tutti-acceso' => '<path d="M3.32 6.57a4.5 4.5 0 1 0 6.36 0M6.5 4.25v4.5M9.5 2a4.5 4.5 0 0 1 4.5 4.5" ' . $tratto . '/>',
		'tutti-spento' => '<circle cx="6.5" cy="9.5" r="4.5" ' . $tratto . '/><path d="M3.32 6.32l6.36 6.36M9.5 2a4.5 4.5 0 0 1 4.5 4.5" ' . $tratto . '/>',
		// Freccia a destra: apre le impostazioni nella riga; ruota verso il basso quando sono aperte (CSS).
		'freccia' => '<path d="M6 3.5 10.5 8 6 12.5" ' . $tratto . '/>',
		// Spunta: impostazioni salvate.
		'spunta' => '<path d="M3 8.5 6.5 12 13 4.5" ' . $tratto . '/>',
		// Orologio: richiesta in attesa di conferma (indirizzo degli avvisi).
		'attesa' => '<circle cx="8" cy="8" r="6.25" ' . $tratto . '/><path d="M8 4.5V8l2.5 1.75" ' . $tratto . '/>',
		// Triangolo con punto esclamativo: il modulo ha un problema.
		'attenzione' => '<path d="M8 1.9 14.6 13.6H1.4z" ' . $tratto . '/><path d="M8 6.2v3.4" ' . $tratto . '/><circle cx="8" cy="11.6" r=".8" fill="currentColor"/>',
	);
	if ( ! isset( $forme[ $nome ] ) ) {
		return '';
	}
	return '<svg class="ds-icona" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false">' . $forme[ $nome ] . '</svg>';
}

add_action( 'admin_menu', 'ds_core_menu' );
function ds_core_menu() {
	add_menu_page( 'DS Core', 'DS Core', 'manage_options', DS_CORE_PAGINA, 'ds_core_pagina', 'dashicons-shield', 80 );
	// Stesso slug del menu: la prima voce si chiama «Moduli» invece di ripetere «DS Core».
	$aggancio = add_submenu_page( DS_CORE_PAGINA, __( 'Modules – DS Core', 'ds-core' ), __( 'Modules', 'ds-core' ), 'manage_options', DS_CORE_PAGINA, 'ds_core_pagina' );
	if ( $aggancio ) {
		add_action( 'load-' . $aggancio, 'ds_core_aiuto' );
	}
}

/*
 * Voci «Settings» e «Help & support» (0.18.0): schede della stessa pagina, registrate senza funzione con l'indirizzo
 * come slug (WordPress lo usa così com'è nel link). Priorità 99: dopo le pagine di DS Woo e dei plugin dei siti (20).
 */
add_action( 'admin_menu', 'ds_core_menu_fondo', 99 );
function ds_core_menu_fondo() {
	add_submenu_page( DS_CORE_PAGINA, __( 'Settings – DS Core', 'ds-core' ), __( 'Settings', 'ds-core' ), 'manage_options', ds_core_slug_scheda( 'settings' ) );
	add_submenu_page( DS_CORE_PAGINA, __( 'Help & support – DS Core', 'ds-core' ), __( 'Help & support', 'ds-core' ), 'manage_options', ds_core_slug_scheda( 'help' ) );
}

/** Slug (e indirizzo relativo a wp-admin/) della voce del sottomenu che apre una scheda. */
function ds_core_slug_scheda( $scheda ) {
	return 'admin.php?page=' . DS_CORE_PAGINA . '&tab=' . $scheda;
}

/** Voce del sottomenu evidenziata sulla pagina dei moduli: Settings e Help secondo ?tab=, altrimenti Modules. */
add_filter( 'submenu_file', 'ds_core_submenu_file', 10, 2 );
function ds_core_submenu_file( $file, $genitore = '' ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo quale voce evidenziare.
	$pagina = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( DS_CORE_PAGINA !== $pagina ) {
		return $file;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$scheda = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
	return in_array( $scheda, array( 'settings', 'help' ), true ) ? ds_core_slug_scheda( $scheda ) : DS_CORE_PAGINA;
}

add_filter( 'plugin_action_links_' . plugin_basename( DS_CORE_FILE ), 'ds_core_link_plugin' );
function ds_core_link_plugin( $link ) {
	array_unshift( $link, '<a href="' . esc_url( admin_url( 'admin.php?page=' . DS_CORE_PAGINA ) ) . '">' . esc_html__( 'Panel', 'ds-core' ) . '</a>' );
	return $link;
}

/** Link mailto per l'assistenza, con oggetto «DS Core support – <Titolo del sito>» e i dati del sito nel testo. */
function ds_core_link_assistenza() {
	$sito = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	/* translators: %s: site title. */
	$oggetto = sprintf( __( 'DS Core support – %s', 'ds-core' ), '' !== $sito ? $sito : home_url() );
	$testo   = implode(
		"\n",
		array(
			/* translators: %s: site address. */
			sprintf( __( 'Site: %s', 'ds-core' ), home_url() ),
			'DS Core: ' . DS_CORE_VERSIONE,
			'WordPress: ' . get_bloginfo( 'version' ),
			'PHP: ' . PHP_VERSION,
			'',
			__( 'Describe the problem or the question:', 'ds-core' ),
			'',
		)
	);
	return 'mailto:' . DS_CORE_ASSISTENZA . '?subject=' . rawurlencode( $oggetto ) . '&body=' . rawurlencode( $testo );
}

add_filter( 'plugin_row_meta', 'ds_core_meta_plugin', 10, 2 );
function ds_core_meta_plugin( $meta, $file ) {
	if ( plugin_basename( DS_CORE_FILE ) === $file ) {
		$meta[] = '<a href="' . esc_url( ds_core_link_assistenza(), array( 'mailto' ) ) . '">' . esc_html__( 'Support', 'ds-core' ) . '</a>';
	}
	return $meta;
}

/** Scheda «Aiuto» di WordPress (in alto a destra) sulla pagina dei moduli. */
function ds_core_aiuto() {
	$schermata = get_current_screen();
	if ( ! $schermata ) {
		return;
	}
	$link = '<a href="' . esc_url( ds_core_link_assistenza(), array( 'mailto' ) ) . '">' . esc_html( DS_CORE_ASSISTENZA ) . '</a>';
	$schermata->add_help_tab(
		array(
			'id'      => 'ds-core-come',
			'title'   => __( 'How it works', 'ds-core' ),
			'content' => '<p>' . esc_html__( 'Each row is a feature of the site. The yellow switch is on, the grey one is off; modules with “Off | Test | On” in test mode only work for administrators. Every change is saved immediately and listed under “Recent changes”.', 'ds-core' ) . '</p>'
				. '<p>' . ds_core_testo_aiuto_righe() . '</p>'
				. '<p>' . esc_html__( 'All DS Core emails go to one address, set in the “Settings” tab.', 'ds-core' ) . '</p>',
		)
	);
	$schermata->add_help_tab(
		array(
			'id'      => 'ds-core-emergenza',
			'title'   => __( 'If something goes wrong', 'ds-core' ),
			'content' => '<p>' . sprintf(
				/* translators: %s: line of code to add to wp-config.php. */
				esc_html__( 'If the site has a problem after you turn on a module, turn it off here. If you cannot get into the dashboard, the emergency switch in wp-config.php turns modules off without uninstalling anything: %s, or the module names separated by commas.', 'ds-core' ),
				"<code>define( 'DS_CORE_SPENTI', 'all' );</code>"
			) . '</p>',
		)
	);
	$schermata->add_help_tab(
		array(
			'id'      => 'ds-core-assistenza',
			'title'   => __( 'Support', 'ds-core' ),
			'content' => '<p>' . sprintf(
				/* translators: %s: support email address (link). */
				esc_html__( 'For a problem or a question write to %s. The email starts with the site name and versions already filled in.', 'ds-core' ),
				$link
			) . '</p>',
		)
	);
	$schermata->set_help_sidebar( '<p><strong>' . esc_html__( 'Support', 'ds-core' ) . '</strong></p><p><a href="' . esc_url( ds_core_link_assistenza(), array( 'mailto' ) ) . '">' . esc_html__( 'Email support', 'ds-core' ) . '</a></p>' );
}

/** Testo d'aiuto sulle righe dei moduli (scheda Help e aiuto di WordPress). Già escapato. */
function ds_core_testo_aiuto_righe() {
	return esc_html__( 'The line under each module sums up its settings and what it is doing. “Settings” (or “Details”) opens the module right below its row, even while it is off, so you can set it up before turning it on. Each module has its own “Save settings” button; saving does not turn anything on. To change several modules at once, select them with the checkboxes: the bulk action bar appears. If a module needs attention, a short notice at the top of the page says so and its link opens the module.', 'ds-core' );
}

/**
 * Schermate di DS Core che usano il foglio di stile, l'aspetto chiaro/scuro e il piè di pagina del pannello: la
 * pagina «Moduli» e le sottopagine aggiunte dai moduli con il filtro 'ds_core_schermate' (dalla 0.14.0, «Activity
 * log» del modulo activity-log). Il JavaScript del pannello resta solo sulla pagina «Moduli».
 */
function ds_core_schermata_nostra( $id ) {
	$schermate = apply_filters( 'ds_core_schermate', array( 'toplevel_page_' . DS_CORE_PAGINA ) );
	return in_array( (string) $id, (array) $schermate, true );
}

/** Piè di pagina dell'amministrazione, solo sulle pagine di DS Core. */
add_filter( 'admin_footer_text', 'ds_core_piede_admin' );
function ds_core_piede_admin( $testo ) {
	$schermata = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $schermata && ds_core_schermata_nostra( $schermata->id ) ) {
		return 'DS Core ' . esc_html( DS_CORE_VERSIONE ) . ' – <a href="' . esc_url( ds_core_link_assistenza(), array( 'mailto' ) ) . '">' . esc_html__( 'support', 'ds-core' ) . '</a>';
	}
	return $testo;
}

add_action( 'admin_enqueue_scripts', 'ds_core_risorse' );
function ds_core_risorse( $hook ) {
	if ( ! ds_core_schermata_nostra( $hook ) ) {
		return;
	}
	wp_enqueue_style( 'ds-core-pannello', DS_CORE_URL . 'assets/pannello.css', array(), DS_CORE_VERSIONE );
	if ( 'toplevel_page_' . DS_CORE_PAGINA !== $hook ) {
		return;
	}
	wp_enqueue_script( 'ds-core-pannello', DS_CORE_URL . 'assets/pannello.js', array( 'wp-i18n' ), DS_CORE_VERSIONE, true );
	// Testi del JavaScript: wp.i18n con i file JSON in languages/ (regola di WordPress).
	wp_set_script_translations( 'ds-core-pannello', 'ds-core', DS_CORE_DIR . 'languages' );
	wp_localize_script(
		'ds-core-pannello',
		'dsCore',
		array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'ds_core_imposta' ),
		)
	);
}

/** Aspetto scelto dall'utente collegato: 'auto' (predefinito), 'chiaro' o 'scuro'. */
function ds_core_tema_utente() {
	$tema = get_user_meta( get_current_user_id(), 'ds_core_tema', true );
	return in_array( $tema, array( 'auto', 'chiaro', 'scuro' ), true ) ? $tema : 'auto';
}

/** Classe sul <body> delle pagine di DS Core, così il tema copre anche lo sfondo attorno al pannello. */
add_filter( 'admin_body_class', 'ds_core_classe_body' );
function ds_core_classe_body( $classi ) {
	$schermata = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $schermata && ds_core_schermata_nostra( $schermata->id ) ) {
		$classi .= ' ds-tema-' . ds_core_tema_utente();
	}
	return $classi;
}

add_action( 'wp_ajax_ds_core_tema', 'ds_core_ajax_tema' );
function ds_core_ajax_tema() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'messaggio' => __( 'You do not have permission to do this.', 'ds-core' ) ), 403 );
	}
	check_ajax_referer( 'ds_core_imposta', 'nonce' );
	$tema = isset( $_POST['tema'] ) ? sanitize_key( wp_unslash( $_POST['tema'] ) ) : '';
	if ( ! in_array( $tema, array( 'auto', 'chiaro', 'scuro' ), true ) ) {
		wp_send_json_error( array( 'messaggio' => __( 'Invalid appearance.', 'ds-core' ) ), 400 );
	}
	update_user_meta( get_current_user_id(), 'ds_core_tema', $tema );
	wp_send_json_success( array( 'tema' => $tema ) );
}

/** Minuscole anche per le lettere accentate quando c'è mbstring (ricerca e tag del pannello). */
function ds_core_minuscole( $testo ) {
	return function_exists( 'mb_strtolower' ) ? mb_strtolower( $testo, 'UTF-8' ) : strtolower( $testo );
}

/** Etichette degli stati, tradotte. */
function ds_core_etichette() {
	return array(
		'attivo'        => __( 'on', 'ds-core' ),
		'prova'         => __( 'in test', 'ds-core' ),
		'spento'        => __( 'off', 'ds-core' ),
		'spento-config' => __( 'off from wp-config', 'ds-core' ),
		'dipendenze'    => __( 'missing a dependency', 'ds-core' ),
		'errore'        => __( 'error', 'ds-core' ),
	);
}

/**
 * Testo di una voce della storia ($da o $a). Le voci si salvano come codici (stati, 'accesso:…') e si traducono
 * qui; le voci scritte prima della 0.8.0 sono testo libero e si mostrano come sono.
 */
function ds_core_storia_testo( $valore ) {
	$valore    = (string) $valore;
	$etichette = ds_core_etichette();
	if ( isset( $etichette[ $valore ] ) ) {
		return $etichette[ $valore ];
	}
	if ( 'agg:salvate' === $valore || 'impostazioni:salvate' === $valore ) {
		return __( 'settings saved', 'ds-core' );
	}
	if ( 'agg:impostazioni' === $valore || 'impostazioni' === $valore ) {
		return __( 'settings', 'ds-core' );
	}
	if ( 0 === strpos( $valore, 'avvisi:' ) ) {
		// Cambio dell'indirizzo degli avvisi (0.15.0): 'avvisi:<azione>[:<indirizzo mascherato>]'.
		$parti = explode( ':', $valore, 3 );
		$a     = $parti[2] ?? '';
		switch ( $parti[1] ?? '' ) {
			case 'richiesta':
				/* translators: %s: masked email address. */
				return sprintf( __( 'notification address change requested to %s', 'ds-core' ), $a );
			case 'confermata':
				/* translators: %s: masked email address. */
				return sprintf( __( 'notification address changed to %s (confirmed)', 'ds-core' ), $a );
			case 'annullata':
				return __( 'notification address change cancelled', 'ds-core' );
			case 'scaduta':
				return __( 'notification address change expired without confirmation', 'ds-core' );
		}
		return $valore;
	}
	if ( 0 !== strpos( $valore, 'accesso:' ) ) {
		return $valore;
	}
	$parti = explode( ':', $valore );
	switch ( $parti[1] ?? '' ) {
		case 'aperto':
			$fino = isset( $parti[2] ) ? (int) $parti[2] : 0;
			$data = $fino ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $fino ) : '';
			if ( isset( $parti[3] ) ) {
				/* translators: 1: date and time when access closes, 2: number of hours, 3: where it was opened from. */
				return sprintf( __( 'open until %1$s (%2$d h, %3$s)', 'ds-core' ), $data, (int) $parti[3], ds_core_origine_testo( $parti[4] ?? '' ) );
			}
			/* translators: %s: date and time when access closes. */
			return sprintf( __( 'open until %s', 'ds-core' ), $data );
		case 'chiuso':
			if ( isset( $parti[2] ) ) {
				/* translators: %s: where it was closed from (panel). */
				return sprintf( __( 'closed (%s)', 'ds-core' ), ds_core_origine_testo( $parti[2] ) );
			}
			return __( 'closed', 'ds-core' );
		case 'scaduto':
			return __( 'closed (time is up)', 'ds-core' );
		case 'non-valido':
			return __( 'invalid expiry', 'ds-core' );
	}
	return $valore;
}

/** Da dove è partita un'azione di claude-code-access. */
function ds_core_origine_testo( $origine ) {
	$nomi = array(
		'pannello' => __( 'panel', 'ds-core' ),
		'firma'    => __( 'signed request', 'ds-core' ),
	);
	return $nomi[ $origine ] ?? $origine;
}

/** Nome di chi ha agito, nella storia: 'automatico' si traduce, gli altri sono nomi utente. */
function ds_core_storia_utente( $utente ) {
	return 'automatico' === $utente ? __( 'automatic', 'ds-core' ) : (string) $utente;
}

/** Nome dell'origine di un modulo: «External» si traduce, gli altri sono nomi di plugin. */
function ds_core_origine_nome( $origine ) {
	return 'External' === $origine ? __( 'External', 'ds-core' ) : (string) $origine;
}

/** Tipo di un modulo: «conditions» si traduce, gli altri sono sigle (PHP, CSS, JS, HTML). */
function ds_core_tipo_nome( $tipo ) {
	return 'conditions' === $tipo ? __( 'Conditions', 'ds-core' ) : (string) $tipo;
}

/**
 * Cambia lo stato scelto di un modulo. Restituisce true o un messaggio d'errore (tradotto).
 */
function ds_core_imposta_stato( $id, $stato ) {
	$id       = ds_core_id_attuale( $id ); // vecchi ID (prima della 0.17.0) accettati
	$registro = ds_core_registro();
	if ( ! isset( $registro[ $id ] ) ) {
		return __( 'Unknown module.', 'ds-core' );
	}
	$ammessi = ! empty( $registro[ $id ]['tre_stati'] ) ? array( 'attivo', 'prova', 'spento' ) : array( 'attivo', 'spento' );
	if ( 'prova' === $stato && ! in_array( $stato, $ammessi, true ) ) {
		return __( 'This module only has on and off, no test mode.', 'ds-core' );
	}
	if ( ! in_array( $stato, $ammessi, true ) ) {
		return __( 'State not allowed for this module.', 'ds-core' );
	}
	if ( in_array( $id, ds_core_spenti_da_config(), true ) ) {
		return __( 'The module is turned off by the emergency switch in wp-config.php.', 'ds-core' );
	}

	$prima = ds_core_stato_scelto( $id );
	if ( $prima === $stato ) {
		return true;
	}

	$stati        = ds_core_stati_salvati();
	$stati[ $id ] = $stato;
	update_option( 'ds_core_stati', $stati, true );

	ds_core_storia_aggiungi( $id, $prima, $stato );

	// I moduli cambiano ciò che vedono i visitatori: la cache di pagina va svuotata.
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
	do_action( 'ds_core_stato_cambiato', $id, $prima, $stato );

	return true;
}

/** Stato da mostrare: l'errore di caricamento prevale sullo stato. */
function ds_core_stato_visibile( $id, $errori ) {
	$stato = ds_core_stato( $id );
	if ( isset( $errori[ $id ] ) && in_array( $stato, array( 'attivo', 'prova' ), true ) ) {
		return 'errore';
	}
	return $stato;
}

add_action( 'wp_ajax_ds_core_imposta', 'ds_core_ajax_imposta' );
function ds_core_ajax_imposta() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'messaggio' => __( 'You do not have permission to do this.', 'ds-core' ) ), 403 );
	}
	check_ajax_referer( 'ds_core_imposta', 'nonce' );

	$id    = isset( $_POST['id'] ) ? sanitize_key( wp_unslash( $_POST['id'] ) ) : '';
	$stato = isset( $_POST['stato'] ) ? sanitize_key( wp_unslash( $_POST['stato'] ) ) : '';
	$esito = ds_core_imposta_stato( $id, $stato );
	if ( true !== $esito ) {
		wp_send_json_error( array( 'messaggio' => $esito ), 400 );
	}

	wp_send_json_success( ds_core_dati_riga( $id ) );
}

/** Stato di una riga dopo un salvataggio, per aggiornare il pannello senza ricaricare. */
function ds_core_dati_riga( $id ) {
	$errori  = get_option( 'ds_core_errori', array() );
	$visto   = ds_core_stato_visibile( $id, is_array( $errori ) ? $errori : array() );
	$mancano = 'dipendenze' === $visto ? implode( ', ', ds_core_dipendenze_mancanti( $id ) ) : '';
	return array(
		'stato'     => $visto,
		'scelto'    => ds_core_stato_scelto( $id ),
		'etichetta' => ds_core_etichette()[ $visto ] ?? $visto,
		/* translators: %s: list of missing dependencies. */
		'messaggio' => $mancano ? sprintf( __( 'Saved, but it stays inactive until this is available: %s.', 'ds-core' ), $mancano ) : __( 'Saved.', 'ds-core' ),
		// Riepilogo della riga (0.18.0): in questa richiesta il modulo appena acceso non è ancora caricato, quindi
		// lo stato a parole arriva con la seconda richiesta (ds_core_riga); qui basta lo stato e le scelte.
		'riepilogo' => ds_core_riepilogo_html( $id, $visto ),
	);
}

/** Azioni in blocco via AJAX: stesso nonce degli interruttori, stessa funzione di salvataggio. */
add_action( 'wp_ajax_ds_core_blocco', 'ds_core_ajax_blocco' );
function ds_core_ajax_blocco() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'messaggio' => __( 'You do not have permission to do this.', 'ds-core' ) ), 403 );
	}
	check_ajax_referer( 'ds_core_imposta', 'nonce' );

	$stato = isset( $_POST['stato'] ) ? sanitize_key( wp_unslash( $_POST['stato'] ) ) : '';
	$ids   = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? array_unique( array_map( 'sanitize_key', wp_unslash( $_POST['ids'] ) ) ) : array();
	if ( ! in_array( $stato, array( 'attivo', 'prova', 'spento' ), true ) || ! $ids ) {
		wp_send_json_error( array( 'messaggio' => __( 'Choose an action and at least one module.', 'ds-core' ) ), 400 );
	}

	$righe   = array();
	$fatti   = 0;
	$saltati = 0;
	foreach ( $ids as $id ) {
		$esito = ds_core_imposta_stato( $id, $stato );
		if ( true === $esito ) {
			$fatti++;
		} else {
			$saltati++;
		}
		$righe[ $id ] = array_merge( ds_core_dati_riga( $id ), array( 'errore' => true === $esito ? '' : $esito ) );
	}
	/* translators: 1: number of modules updated, 2: number of modules skipped. */
	$messaggio = sprintf( __( 'Modules updated: %1$d. Skipped: %2$d.', 'ds-core' ), $fatti, $saltati );
	if ( $saltati ) {
		$messaggio .= ' ' . __( 'The reason is shown in the row of each one.', 'ds-core' );
	}
	wp_send_json_success(
		array(
			'righe'     => $righe,
			'messaggio' => $messaggio,
		)
	);
}

/** Azioni in blocco senza JavaScript (ripiego del modulo HTML): stesso effetto, con ricarica della pagina. */
add_action( 'admin_post_ds_core_blocco', 'ds_core_blocco' );
function ds_core_blocco() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_blocco' );

	$azione  = isset( $_POST['ds_azione'] ) ? sanitize_key( wp_unslash( $_POST['ds_azione'] ) ) : '';
	$ids     = isset( $_POST['ds_scelti'] ) && is_array( $_POST['ds_scelti'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['ds_scelti'] ) ) : array();
	$fatti   = 0;
	$saltati = 0;
	if ( in_array( $azione, array( 'attivo', 'prova', 'spento' ), true ) ) {
		foreach ( $ids as $id ) {
			if ( true === ds_core_imposta_stato( $id, $azione ) ) {
				$fatti++;
			} else {
				$saltati++;
			}
		}
	}
	wp_safe_redirect( add_query_arg( array( 'ds_fatti' => $fatti, 'ds_saltati' => $saltati ), ds_core_url_pannello( ds_core_scheda_dal_referer() ) ) );
	exit;
}

add_action( 'admin_post_ds_core_pulisci_errori', 'ds_core_pulisci_errori' );
function ds_core_pulisci_errori() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_pulisci_errori' );
	update_option( 'ds_core_errori', array(), true );
	wp_safe_redirect( add_query_arg( array( 'ds_errori' => 'svuotati' ), ds_core_url_pannello( ds_core_scheda_dal_referer() ) ) );
	exit;
}

/** Data e ora nel formato delle impostazioni del sito. */
function ds_core_data( $timestamp ) {
	return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $timestamp );
}

/** Data AAAA-MM-GG del registro nel formato del sito, dentro <time>. Restituisce HTML già escapato. */
function ds_core_data_giorno( $giorno ) {
	if ( ! $giorno ) {
		return '—';
	}
	$data = DateTime::createFromFormat( '!Y-m-d', $giorno, new DateTimeZone( 'UTC' ) );
	if ( ! $data ) {
		return esc_html( $giorno );
	}
	return '<time datetime="' . esc_attr( $giorno ) . '">' . esc_html( wp_date( get_option( 'date_format' ), $data->getTimestamp() + 12 * HOUR_IN_SECONDS ) ) . '</time>';
}

/*
 * Riga sotto il modulo (dalla 0.12.0; dalla 0.13.0 scelte dichiarate, stato e problemi). Il pannello non sa nulla
 * dei singoli moduli: DS Woo e i plugin dei siti aggiungono i loro allo stesso modo, con il filtro 'ds_core_registro'.
 * Disegno e salvataggio delle scelte: includes/impostazioni.php.
 */

/**
 * Problemi di un modulo acceso (o in prova), dalla sua funzione 'problemi': array di stringhe, vuoto se va tutto bene
 * o se il modulo è spento. Un errore nella funzione del modulo non ferma il pannello: diventa un problema.
 */
function ds_core_problemi_modulo( $id, $modulo, $visto ) {
	if ( empty( $modulo['problemi'] ) || ! in_array( $visto, array( 'attivo', 'prova' ), true ) || ! is_callable( $modulo['problemi'] ) ) {
		return array();
	}
	try {
		$problemi = call_user_func( $modulo['problemi'], $id );
	} catch ( Throwable $e ) {
		/* translators: %s: error message. */
		return array( sprintf( __( 'The module could not check its own state: %s', 'ds-core' ), $e->getMessage() ) );
	}
	if ( is_string( $problemi ) ) {
		$problemi = array( $problemi );
	}
	if ( ! is_array( $problemi ) ) {
		return array();
	}
	return array_values( array_filter( array_map( 'strval', array_filter( $problemi, 'is_scalar' ) ), 'strlen' ) );
}

/** Interruttore di una riga: levetta (due stati) o pulsanti Spento | Prova | Attivo (tre stati). */
function ds_core_interruttore( $id, $modulo, $scelto, $bloccato ) {
	$titolo = $modulo['titolo'] ? $modulo['titolo'] : $id;
	if ( ! empty( $modulo['tre_stati'] ) ) {
		$scelte = array(
			'spento' => _x( 'Off', 'module state button', 'ds-core' ),
			'prova'  => _x( 'Test', 'module state button', 'ds-core' ),
			'attivo' => _x( 'On', 'module state button', 'ds-core' ),
		);
		/* translators: %s: module title. */
		echo '<div class="ds-segmenti" role="group" aria-label="' . esc_attr( sprintf( __( 'State of %s', 'ds-core' ), $titolo ) ) . '">';
		foreach ( $scelte as $valore => $nome ) {
			printf(
				'<button type="button" class="ds-segmento ds-segmento--%1$s" data-ds-valore="%1$s" aria-pressed="%2$s"%3$s>%5$s%4$s</button>',
				esc_attr( $valore ),
				$valore === $scelto ? 'true' : 'false',
				$bloccato ? ' disabled' : '',
				esc_html( $nome ),
				ds_core_icona( 'attivo' === $valore ? 'acceso' : $valore ) // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso.
			);
		}
		echo '</div>';
		return;
	}
	printf(
		'<button type="button" class="ds-levetta" role="switch" aria-checked="%1$s" aria-label="%2$s"%3$s><span class="ds-levetta-pallino" aria-hidden="true"></span></button>',
		'spento' !== $scelto ? 'true' : 'false',
		esc_attr( $titolo ),
		$bloccato ? ' disabled' : ''
	);
}

/**
 * Schede del pannello nell'ordine: 'all', le categorie che hanno moduli (ordine di ds_core_categorie_ammesse()),
 * 'settings', 'help'.
 */
function ds_core_schede( $per_categoria ) {
	$schede = array( 'all' );
	foreach ( $per_categoria as $chiave => $moduli ) {
		if ( $moduli ) {
			$schede[] = $chiave;
		}
	}
	$schede[] = 'settings';
	$schede[] = 'help';
	return $schede;
}

/** Scheda chiesta con ?tab=, se esiste; altrimenti 'all'. */
function ds_core_scheda_scelta( $schede ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo quale scheda mostrare.
	$scheda = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'all';
	return in_array( $scheda, $schede, true ) ? $scheda : 'all';
}

/**
 * Una riga del modulo (riga compatta più riga aperta) dentro il suo <tbody>. Stampa HTML con escape.
 */
function ds_core_riga_modulo( $id, $modulo, $ctx ) {
	$errori    = $ctx['errori'];
	$etichette = $ctx['etichette'];
	$visto     = ds_core_stato_visibile( $id, $errori );
	$scelto    = ds_core_stato_scelto( $id );
	$bloccato  = 'spento-config' === $visto;
	$mancano   = 'spento' !== $scelto ? ds_core_dipendenze_mancanti( $id ) : array();
	$parole    = array_values( array_unique( array_map( 'ds_core_minuscole', array_map( 'strval', $modulo['tag'] ) ) ) );
	$tipi      = array_map( 'ds_core_tipo_nome', $modulo['tipo'] );
	$dove      = array_map(
		function ( $codice ) use ( $ctx ) {
			return $ctx['dove'][ $codice ] ?? $codice;
		},
		$modulo['dove']
	);
	$con_campi = '' !== $modulo['opzione'] && ! empty( $modulo['campi'] );
	$suoi      = $ctx['problemi'][ $id ] ?? array();
	$nome_cat  = $ctx['categorie'][ $modulo['categoria'] ] ?? '';
	$testo     = ds_core_minuscole( $modulo['titolo'] . ' ' . $nome_cat . ' ' . $modulo['descrizione'] . ' ' . implode( ' ', $parole ) . ' ' . ds_core_origine_nome( $modulo['origine'] ) . ' ' . $id );
	$aperto    = $ctx['aperto'] === $id;
	?>
	<?php /* Un <tbody> per modulo: la riga compatta e, sotto, la riga aperta (si nascondono insieme). */ ?>
	<tbody class="ds-modulo">
	<tr class="ds-riga<?php echo $suoi ? ' ds-riga--problema' : ''; ?><?php echo $aperto ? ' is-aperto' : ''; ?>" data-ds-id="<?php echo esc_attr( $id ); ?>" data-ds-categoria-riga="<?php echo esc_attr( $modulo['categoria'] ); ?>" data-ds-stato="<?php echo esc_attr( $visto ); ?>" data-ds-scelto="<?php echo esc_attr( $scelto ); ?>" data-ds-origine="<?php echo esc_attr( $modulo['origine'] ); ?>" data-ds-tag="<?php echo esc_attr( implode( '|', $parole ) ); ?>" data-ds-testo="<?php echo esc_attr( $testo ); ?>">
		<?php /* translators: %s: module title. */ ?>
		<th scope="row" class="check-column"><input type="checkbox" form="ds-modulo-blocco" name="ds_scelti[]" value="<?php echo esc_attr( $id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Select %s', 'ds-core' ), $modulo['titolo'] ) ); ?>"></th>
		<td class="ds-col-stato">
			<?php ds_core_interruttore( $id, $modulo, $scelto, $bloccato ); ?>
			<span class="ds-stato ds-stato--<?php echo esc_attr( $visto ); ?>"><?php echo esc_html( $etichette[ $visto ] ?? $visto ); ?></span>
			<span class="ds-riga-messaggio"></span>
		</td>
		<td class="ds-col-modulo">
			<p class="ds-titolo-riga">
				<strong class="ds-titolo" id="ds-titolo-<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $modulo['titolo'] ); ?></strong>
				<span class="ds-attenzione"<?php echo $suoi ? '' : ' hidden'; ?>><?php echo ds_core_icona( 'attenzione' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Needs attention', 'ds-core' ); ?></span>
			</p>
			<p class="ds-descrizione"><?php echo esc_html( $modulo['descrizione'] ); ?></p>
			<?php if ( isset( $errori[ $id ] ) ) : ?>
				<p class="ds-errore"><strong><?php esc_html_e( 'Error:', 'ds-core' ); ?></strong> <?php echo esc_html( $errori[ $id ]['messaggio'] ?? '' ); ?></p>
			<?php endif; ?>
			<?php echo ds_core_riepilogo_html( $id, $visto ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato. ?>
		</td>
		<td class="ds-col-azione">
			<?php
			/*
			 * Link vero verso la riga aperta (#ds-impostazioni-<id>): senza JavaScript la apre il CSS (:target); con
			 * JavaScript è un pulsante (role, aria-expanded, aria-controls, Spazio e Invio) che apre e chiude.
			 */
			?>
			<a href="#ds-impostazioni-<?php echo esc_attr( $id ); ?>" class="ds-apri" id="ds-apri-<?php echo esc_attr( $id ); ?>" role="button" aria-expanded="<?php echo $aperto ? 'true' : 'false'; ?>" aria-controls="ds-impostazioni-<?php echo esc_attr( $id ); ?>"><?php echo ds_core_icona( 'freccia' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php echo $con_campi ? esc_html__( 'Settings', 'ds-core' ) : esc_html__( 'Details', 'ds-core' ); ?><span class="screen-reader-text"> <?php echo esc_html( $modulo['titolo'] ); ?></span></a>
		</td>
	</tr>
	<tr class="ds-dettagli<?php echo $suoi ? ' ds-dettagli--problema' : ''; ?>" id="ds-impostazioni-<?php echo esc_attr( $id ); ?>" data-ds-dettagli="<?php echo esc_attr( $id ); ?>"<?php echo $aperto ? '' : ' hidden'; ?>>
		<td colspan="4">
			<div class="ds-dettagli-corpo" role="region" aria-labelledby="ds-titolo-<?php echo esc_attr( $id ); ?>">
				<div class="ds-dettagli-stato" data-ds-stato-area="<?php echo esc_attr( $id ); ?>"><?php echo ds_core_stato_html( $id, $modulo, $visto, $suoi ); // phpcs:ignore WordPress.Security.EscapeOutput -- stampato dalla funzione del modulo, che fa l'escape; i messaggi del pannello sono già escapati. ?></div>
				<p class="ds-descrizione-intera"><?php echo esc_html( $modulo['descrizione'] ); ?></p>
				<?php if ( $modulo['avviso'] ) : ?>
					<p class="ds-avviso"><strong><?php esc_html_e( 'If you turn it off:', 'ds-core' ); ?></strong> <?php echo esc_html( $modulo['avviso'] ); ?></p>
				<?php endif; ?>
				<?php if ( $mancano ) : ?>
					<p class="ds-avviso"><strong><?php esc_html_e( 'Requires:', 'ds-core' ); ?></strong> <?php echo esc_html( implode( ', ', $mancano ) ); ?></p>
				<?php endif; ?>
				<?php if ( $con_campi && ! $bloccato ) : ?>
					<?php echo ds_core_impostazioni_form( $id, array( 'campi' => $modulo['testi_campi'], 'gruppi' => $modulo['testi_gruppi'] ), ! in_array( $visto, array( 'attivo', 'prova' ), true ), $modulo['avvisi'] ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato. ?>
				<?php endif; ?>
				<details class="ds-tecnici">
					<summary><?php esc_html_e( 'Technical details', 'ds-core' ); ?></summary>
					<dl>
						<dt><?php esc_html_e( 'Technical name', 'ds-core' ); ?></dt>
						<dd>
							<span class="ds-copia"><code id="ds-id-<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $id ); ?></code><button type="button" class="button button-small ds-copia-pulsante" data-ds-copia="ds-id-<?php echo esc_attr( $id ); ?>" hidden><?php esc_html_e( 'Copy', 'ds-core' ); ?></button><span class="ds-copia-esito" role="status" aria-live="polite"></span></span>
							<span class="ds-grigio ds-blocco-testo"><?php esc_html_e( 'Used only by the emergency switch in wp-config.php and by support.', 'ds-core' ); ?></span>
						</dd>
						<dt><?php esc_html_e( 'Works on', 'ds-core' ); ?></dt>
						<dd><?php echo esc_html( $dove ? implode( ', ', $dove ) : '—' ); ?></dd>
						<dt><?php esc_html_e( 'Tags', 'ds-core' ); ?></dt>
						<dd>
							<?php if ( $parole ) : ?>
								<?php foreach ( $parole as $parola ) : ?>
									<button type="button" class="ds-tag" data-ds-tag="<?php echo esc_attr( $parola ); ?>" aria-pressed="false" title="<?php esc_attr_e( 'Show only modules with this tag', 'ds-core' ); ?>"><?php echo esc_html( $parola ); ?></button>
								<?php endforeach; ?>
							<?php else : ?>
								—
							<?php endif; ?>
						</dd>
						<dt><?php esc_html_e( 'Type', 'ds-core' ); ?></dt>
						<dd><?php echo esc_html( $tipi ? implode( ', ', $tipi ) : '—' ); ?></dd>
						<dt><?php esc_html_e( 'Source', 'ds-core' ); ?></dt>
						<dd><?php echo esc_html( ds_core_origine_nome( $modulo['origine'] ) ); ?></dd>
						<dt><?php esc_html_e( 'Version', 'ds-core' ); ?></dt>
						<dd>
							<?php echo esc_html( $modulo['versione'] ? $modulo['versione'] : '—' ); ?>
							<?php if ( $modulo['modificato'] ) : ?>
								<?php /* translators: %s: date of the last change to the module code. */ ?>
								<span class="ds-grigio"><?php echo wp_kses( sprintf( __( 'code updated %s', 'ds-core' ), ds_core_data_giorno( $modulo['modificato'] ) ), array( 'time' => array( 'datetime' => true ) ) ); ?></span>
							<?php endif; ?>
						</dd>
						<?php if ( $modulo['sostituisce'] ) : ?>
							<dt><?php esc_html_e( 'Replaces', 'ds-core' ); ?></dt>
							<dd><?php echo esc_html( $modulo['sostituisce'] ); ?></dd>
						<?php endif; ?>
					</dl>
				</details>
			</div>
		</td>
	</tr>
	</tbody>
	<?php
}

function ds_core_pagina() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$registro  = ds_core_registro_con_testi();
	$categorie = ds_core_categorie();
	$etichette = ds_core_etichette();
	$errori    = get_option( 'ds_core_errori', array() );
	$errori    = is_array( $errori ) ? $errori : array();
	$storia    = get_option( 'ds_core_storia', array() );
	$storia    = is_array( $storia ) ? $storia : array();
	$config    = ds_core_spenti_da_config();

	$per_categoria = array();
	foreach ( $categorie as $chiave => $nome ) {
		$per_categoria[ $chiave ] = array();
	}
	$origini = array();
	$tag     = array();
	foreach ( $registro as $id => $modulo ) {
		$per_categoria[ $modulo['categoria'] ][ $id ] = $modulo;
		$origini[ $modulo['origine'] ]                = true;
		foreach ( $modulo['tag'] as $parola ) {
			$tag[ ds_core_minuscole( (string) $parola ) ] = true;
		}
	}
	// Prima DS Core, poi le altre origini in ordine alfabetico.
	$origini = array_map( 'strval', array_keys( $origini ) );
	usort(
		$origini,
		function ( $a, $b ) {
			$core = (int) ( 'DS Core' === $b ) - (int) ( 'DS Core' === $a );
			return 0 !== $core ? $core : strcasecmp( $a, $b );
		}
	);
	$tag = array_map( 'strval', array_keys( $tag ) );
	sort( $tag, SORT_STRING );

	$schede = ds_core_schede( $per_categoria );
	$scelta = ds_core_scheda_scelta( $schede );
	// Vista dei moduli: 'all' o una categoria. Con Settings e Help l'elenco resta nella pagina, nascosto, su «All».
	$vista = in_array( $scelta, array( 'settings', 'help' ), true ) ? 'all' : $scelta;

	$conta          = array( 'tutti' => 0, 'attivo' => 0, 'prova' => 0, 'spento' => 0, 'errore' => 0 );
	$problemi       = array();
	$problemi_per   = array();
	foreach ( $registro as $id => $modulo ) {
		$visto   = ds_core_stato_visibile( $id, $errori );
		$trovati = ds_core_problemi_modulo( $id, $modulo, $visto );
		if ( $trovati ) {
			$problemi[ $id ]                          = $trovati;
			$problemi_per[ $modulo['categoria'] ]     = ( $problemi_per[ $modulo['categoria'] ] ?? 0 ) + 1;
		}
		if ( 'all' !== $vista && $modulo['categoria'] !== $vista ) {
			continue;
		}
		$conta['tutti']++;
		if ( isset( $conta[ $visto ] ) ) {
			$conta[ $visto ]++;
		} else {
			$conta['spento']++;
		}
	}
	$nomi_schede = array(
		'all'      => __( 'All', 'ds-core' ),
		'settings' => __( 'Settings', 'ds-core' ),
		'help'     => __( 'Help', 'ds-core' ),
	);
	$pannello_di = function ( $scheda ) {
		return in_array( $scheda, array( 'settings', 'help' ), true ) ? 'ds-pannello-' . $scheda : 'ds-pannello-moduli';
	};
	// Senza JavaScript si apre la riga del modulo salvato senza JavaScript (esito conservato un minuto).
	$ripiego = get_transient( 'ds_core_imp_' . get_current_user_id() );
	$aperto  = is_array( $ripiego ) && isset( $registro[ $ripiego['id'] ?? '' ] ) ? (string) $ripiego['id'] : '';
	$ctx     = array(
		'errori'    => $errori,
		'etichette' => $etichette,
		'dove'      => ds_core_dove_etichette(),
		'problemi'  => $problemi,
		'categorie' => $categorie,
		'aperto'    => $aperto,
	);
	?>
	<div class="wrap ds-core" data-ds-scheda="<?php echo esc_attr( $scelta ); ?>">
		<div class="ds-testata">
			<h1>DS Core <span class="ds-versione"><?php echo esc_html( DS_CORE_VERSIONE ); ?></span></h1>
			<div class="ds-tema" role="group" aria-label="<?php esc_attr_e( 'Panel appearance', 'ds-core' ); ?>">
				<?php
				$tema   = ds_core_tema_utente();
				$scelte = array(
					'auto'   => __( 'Automatic', 'ds-core' ),
					'chiaro' => __( 'Light', 'ds-core' ),
					'scuro'  => __( 'Dark', 'ds-core' ),
				);
				foreach ( $scelte as $valore => $nome ) {
					printf(
						'<button type="button" class="ds-tema-scelta" data-ds-tema="%1$s" aria-pressed="%2$s"%3$s>%5$s%4$s</button>',
						esc_attr( $valore ),
						$valore === $tema ? 'true' : 'false',
						'auto' === $valore ? ' title="' . esc_attr__( 'Follows the light/dark setting of your computer', 'ds-core' ) . '"' : '',
						esc_html( $nome ),
						ds_core_icona( $valore ) // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso.
					);
				}
				?>
			</div>
		</div>
		<hr class="wp-header-end">

		<div class="ds-messaggio" role="status" aria-live="polite"></div>

		<?php if ( isset( $_GET['ds_fatti'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo il messaggio dopo il reindirizzamento. ?>
			<div class="notice notice-success is-dismissible"><p>
				<?php
				printf(
					/* translators: 1: number of modules updated, 2: number of modules skipped. */
					esc_html__( 'Modules updated: %1$d. Skipped: %2$d (blocked by wp-config or not suited to the chosen state).', 'ds-core' ),
					(int) $_GET['ds_fatti'], // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					(int) ( $_GET['ds_saltati'] ?? 0 ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				);
				?>
			</p></div>
		<?php endif; ?>

		<?php if ( $config ) : ?>
			<div class="notice notice-warning"><p>
				<?php
				printf(
					/* translators: %s: name of the wp-config.php constant. */
					esc_html__( 'Emergency switch active in wp-config.php (%s): the listed modules stay off whatever this page says. To turn them back on, remove the line from wp-config.php.', 'ds-core' ),
					'<code>DS_CORE_SPENTI</code>'
				);
				?>
			</p></div>
		<?php endif; ?>

		<?php if ( $errori ) : ?>
			<div class="notice notice-error">
				<p><strong><?php esc_html_e( 'Modules not loaded because of an error', 'ds-core' ); ?></strong> <?php esc_html_e( '(the rest of the site works):', 'ds-core' ); ?></p>
				<ul>
					<?php foreach ( $errori as $id => $errore ) : ?>
						<?php
						// Titolo del modulo con l'ID fra parentesi (l'ID serve all'interruttore d'emergenza).
						$nome_errore = isset( $registro[ $id ] ) ? $registro[ $id ]['titolo'] . ' (' . $id . ')' : (string) $id;
						?>
						<li><?php echo esc_html( $nome_errore ); ?> — <?php echo esc_html( ds_core_data( $errore['quando'] ?? 0 ) ); ?> — <?php echo esc_html( $errore['messaggio'] ?? '' ); ?></li>
					<?php endforeach; ?>
				</ul>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="ds_core_pulisci_errori">
					<?php wp_nonce_field( 'ds_core_pulisci_errori' ); ?>
					<p><button type="submit" class="button"><?php esc_html_e( 'Clear the error list', 'ds-core' ); ?></button></p>
				</form>
			</div>
		<?php endif; ?>

		<?php
		// Riquadri in cima alla pagina, visibili da tutte le schede: solo quelli che servono sempre a portata di mano
		// (oggi la barra «Claude Code access» di claude-code-access, su una riga).
		do_action( 'ds_core_pannello_riquadri' );
		?>

		<?php
		/*
		 * Avviso breve se un modulo ha problemi (funzione 'problemi' del registro): una riga per modulo, il link porta
		 * alla scheda della categoria e apre la riga del modulo (senza JavaScript la apre il CSS con :target).
		 */
		?>
		<?php if ( $problemi ) : ?>
			<div class="notice notice-warning ds-problemi">
				<p><strong><?php echo ds_core_icona( 'attenzione' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php echo esc_html( _n( 'This module needs attention:', 'These modules need attention:', count( $problemi ), 'ds-core' ) ); ?></strong></p>
				<ul>
					<?php foreach ( $problemi as $id => $elenco ) : ?>
						<li>
							<a href="<?php echo esc_url( ds_core_url_pannello( $registro[ $id ]['categoria'], 'ds-impostazioni-' . $id ) ); ?>" data-ds-apri="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $registro[ $id ]['titolo'] ); ?></a>:
							<?php echo esc_html( implode( ' ', $elenco ) ); ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<?php /* Schede (stile WordPress, modello «Tabs» di WAI-ARIA): link veri, il JavaScript le cambia senza ricaricare. */ ?>
		<nav class="nav-tab-wrapper ds-schede" role="tablist" aria-label="<?php esc_attr_e( 'DS Core sections', 'ds-core' ); ?>">
			<?php foreach ( $schede as $scheda ) :
				$attiva = $scheda === $scelta;
				$altro  = in_array( $scheda, array( 'settings', 'help' ), true );
				$nome   = $nomi_schede[ $scheda ] ?? ( $categorie[ $scheda ] ?? $scheda );
				$numero = 'all' === $scheda ? count( $registro ) : ( $altro ? 0 : count( $per_categoria[ $scheda ] ) );
				$segni  = 'all' === $scheda ? count( $problemi ) : ( $problemi_per[ $scheda ] ?? 0 );
				?>
				<?php if ( 'settings' === $scheda ) : ?>
					<span class="ds-schede-spazio" aria-hidden="true"></span>
				<?php endif; ?>
				<a href="<?php echo esc_url( ds_core_url_pannello( $scheda ) ); ?>" class="nav-tab ds-scheda<?php echo $attiva ? ' nav-tab-active' : ''; ?><?php echo $altro ? ' ds-scheda--altro' : ''; ?>" id="ds-scheda-<?php echo esc_attr( $scheda ); ?>" role="tab" data-ds-scheda="<?php echo esc_attr( $scheda ); ?>" aria-selected="<?php echo $attiva ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $pannello_di( $scheda ) ); ?>" tabindex="<?php echo $attiva ? '0' : '-1'; ?>">
					<?php echo esc_html( $nome ); ?>
					<?php if ( ! $altro ) : ?>
						<span class="ds-scheda-conta">(<?php echo (int) $numero; ?>)</span>
					<?php endif; ?>
					<?php if ( $segni ) : ?>
						<span class="ds-scheda-segno"><?php echo ds_core_icona( 'attenzione' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php echo (int) $segni; ?><span class="screen-reader-text">
							<?php
							/* translators: %d: number of modules. */
							echo esc_html( sprintf( _n( '%d module needs attention', '%d modules need attention', $segni, 'ds-core' ), $segni ) );
							?>
						</span></span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</nav>

		<div class="ds-pannello" id="ds-pannello-moduli" role="tabpanel" aria-labelledby="ds-scheda-<?php echo esc_attr( $vista ); ?>" tabindex="-1"<?php echo $vista === $scelta ? '' : ' hidden'; ?>>
		<?php if ( ! $registro ) : ?>
			<p class="ds-vuoto"><?php esc_html_e( 'No modules yet: this version only contains the plugin structure.', 'ds-core' ); ?></p>
		<?php else : ?>

		<div class="ds-filtri">
			<ul class="subsubsub" aria-label="<?php esc_attr_e( 'Filter by state', 'ds-core' ); ?>">
				<?php
				$filtri = array(
					'tutti'  => __( 'All', 'ds-core' ),
					'attivo' => _x( 'On', 'filter: modules that are on', 'ds-core' ),
					'prova'  => _x( 'In test', 'filter: modules in test', 'ds-core' ),
					'spento' => _x( 'Off', 'filter: modules that are off', 'ds-core' ),
					'errore' => __( 'With errors', 'ds-core' ),
				);
				$ultimo = array_key_last( $filtri );
				foreach ( $filtri as $chiave => $nome ) :
					?>
					<li><a href="#" data-ds-filtro="<?php echo esc_attr( $chiave ); ?>"<?php echo 'tutti' === $chiave ? ' class="current" aria-current="true"' : ''; ?>><?php echo esc_html( $nome ); ?> <span class="count">(<span data-ds-conta="<?php echo esc_attr( $chiave ); ?>"><?php echo (int) $conta[ $chiave ]; ?></span>)</span></a><?php echo $chiave !== $ultimo ? ' |' : ''; ?></li>
				<?php endforeach; ?>
			</ul>
			<div class="ds-filtri-scelte">
				<label class="screen-reader-text" for="ds-cerca"><?php esc_html_e( 'Search modules', 'ds-core' ); ?></label>
				<input type="search" id="ds-cerca" placeholder="<?php esc_attr_e( 'Search all modules', 'ds-core' ); ?>">
				<span class="ds-piu-filtri" id="ds-piu-filtri" hidden>
					<?php if ( count( $origini ) > 1 ) : ?>
						<label class="screen-reader-text" for="ds-origine"><?php esc_html_e( 'Source', 'ds-core' ); ?></label>
						<select id="ds-origine">
							<option value=""><?php esc_html_e( 'All sources', 'ds-core' ); ?></option>
							<?php foreach ( $origini as $origine ) : ?>
								<option value="<?php echo esc_attr( $origine ); ?>"><?php echo esc_html( ds_core_origine_nome( $origine ) ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php endif; ?>
					<label class="screen-reader-text" for="ds-tag"><?php esc_html_e( 'Tag', 'ds-core' ); ?></label>
					<select id="ds-tag">
						<option value=""><?php esc_html_e( 'All tags', 'ds-core' ); ?></option>
						<?php foreach ( $tag as $parola ) : ?>
							<option value="<?php echo esc_attr( $parola ); ?>"><?php echo esc_html( $parola ); ?></option>
						<?php endforeach; ?>
					</select>
				</span>
				<button type="button" class="button-link ds-mostra-filtri" aria-expanded="false" aria-controls="ds-piu-filtri" hidden><?php esc_html_e( 'More filters', 'ds-core' ); ?></button>
				<button type="button" class="button-link ds-azzera ds-con-icona" hidden><?php echo ds_core_icona( 'x' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Clear filters', 'ds-core' ); ?></button>
			</div>
		</div>
		<p class="ds-nota-ricerca" role="status" aria-live="polite" hidden></p>

		<?php
		/*
		 * Il <form> delle azioni in blocco è vuoto e sta fuori dalle tabelle: caselle e pulsanti gli appartengono con
		 * l'attributo form="ds-modulo-blocco". Così le impostazioni nelle righe possono avere i loro <form>, che non
		 * si possono annidare in un altro.
		 */
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ds-modulo-blocco" class="ds-modulo-blocco">
			<input type="hidden" name="action" value="ds_core_blocco">
			<?php wp_nonce_field( 'ds_core_blocco' ); ?>
		</form>
		<div class="ds-elenco">
			<?php /* Barra delle azioni in blocco: con JavaScript compare solo con almeno un modulo scelto. */ ?>
			<div class="ds-blocco" role="group" aria-label="<?php esc_attr_e( 'Bulk actions', 'ds-core' ); ?>">
				<label class="ds-blocco-tutti"><input type="checkbox" id="ds-seleziona-visibili"> <?php esc_html_e( 'Select all', 'ds-core' ); ?></label>
				<span class="ds-blocco-azioni">
					<button type="submit" form="ds-modulo-blocco" name="ds_azione" value="attivo" class="button button-small ds-con-icona ds-blocco-attiva"><?php echo ds_core_icona( 'acceso' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Turn on', 'ds-core' ); ?></button>
					<button type="submit" form="ds-modulo-blocco" name="ds_azione" value="prova" class="button button-small ds-con-icona" title="<?php esc_attr_e( 'Only modules with three states', 'ds-core' ); ?>"><?php echo ds_core_icona( 'prova' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php echo esc_html_x( 'Test', 'bulk action', 'ds-core' ); ?></button>
					<button type="submit" form="ds-modulo-blocco" name="ds_azione" value="spento" class="button button-small ds-con-icona"><?php echo ds_core_icona( 'spento' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Turn off', 'ds-core' ); ?></button>
				</span>
				<span class="ds-blocco-conta" aria-live="polite"><?php esc_html_e( 'No modules selected', 'ds-core' ); ?></span>
				<button type="button" class="button-link ds-blocco-annulla" hidden><?php esc_html_e( 'Clear selection', 'ds-core' ); ?></button>
			</div>

			<p class="ds-nessuno" hidden><?php esc_html_e( 'No modules match the filters.', 'ds-core' ); ?></p>

			<?php foreach ( $per_categoria as $chiave => $moduli ) :
				if ( ! $moduli ) {
					continue;
				}
				$totale = count( $moduli );
				$accesi = 0;
				foreach ( $moduli as $id_modulo => $m ) {
					if ( 'spento' !== ds_core_stato_scelto( $id_modulo ) ) {
						$accesi++;
					}
				}
				$nome_cat = $categorie[ $chiave ];
				?>
				<section class="ds-categoria" data-ds-categoria="<?php echo esc_attr( $chiave ); ?>" aria-labelledby="ds-categoria-<?php echo esc_attr( $chiave ); ?>"<?php echo 'all' === $vista || $vista === $chiave ? '' : ' hidden'; ?>>
					<div class="ds-categoria-testata">
						<h2 id="ds-categoria-<?php echo esc_attr( $chiave ); ?>"><?php echo esc_html( $nome_cat ); ?></h2>
						<span class="ds-categoria-conta" data-ds-categoria-conta>
							<?php
							/* translators: 1: number of modules on, 2: number of modules in the category. */
							echo esc_html( sprintf( __( '%1$d of %2$d on', 'ds-core' ), $accesi, $totale ) );
							?>
						</span>
						<?php
						/*
						 * Azioni sull'intera categoria: stanno nella testata, non nelle righe, hanno il bordo tratteggiato
						 * (vale per un gruppo) e chiedono conferma con il numero di moduli. Nascoste durante una ricerca.
						 */
						?>
						<?php /* translators: %s: category name. */ ?>
						<div class="ds-categoria-azioni" role="group" aria-label="<?php echo esc_attr( sprintf( __( 'Whole category %s', 'ds-core' ), $nome_cat ) ); ?>">
							<?php /* translators: 1: number of modules, 2: category name. */ ?>
							<button type="button" class="ds-categoria-azione" data-ds-categoria-azione="attivo" data-ds-domanda="<?php echo esc_attr( sprintf( _n( 'Turn on the %1$d module in %2$s?', 'Turn on all %1$d modules in %2$s?', $totale, 'ds-core' ), $totale, $nome_cat ) ); ?>"><?php echo ds_core_icona( 'tutti-acceso' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Turn on all', 'ds-core' ); ?></button>
							<?php /* translators: 1: number of modules, 2: category name. */ ?>
							<button type="button" class="ds-categoria-azione" data-ds-categoria-azione="spento" data-ds-domanda="<?php echo esc_attr( sprintf( _n( 'Turn off the %1$d module in %2$s?', 'Turn off all %1$d modules in %2$s?', $totale, 'ds-core' ), $totale, $nome_cat ) ); ?>"><?php echo ds_core_icona( 'tutti-spento' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Turn off all', 'ds-core' ); ?></button>
						</div>
						<div class="ds-categoria-conferma" role="group" aria-label="<?php esc_attr_e( 'Confirm', 'ds-core' ); ?>" hidden>
							<span class="ds-categoria-domanda"></span>
							<button type="button" class="button button-small ds-categoria-si"><?php esc_html_e( 'Confirm', 'ds-core' ); ?></button>
							<button type="button" class="button-link ds-categoria-no"><?php esc_html_e( 'Cancel', 'ds-core' ); ?></button>
						</div>
					</div>
					<table class="widefat ds-tabella">
						<thead>
							<tr>
								<?php /* translators: %s: category name. */ ?>
								<td class="check-column"><input type="checkbox" class="ds-seleziona-tutti" aria-label="<?php echo esc_attr( sprintf( __( 'Select all modules in %s', 'ds-core' ), $nome_cat ) ); ?>"></td>
								<th scope="col" class="ds-col-stato"><?php esc_html_e( 'State', 'ds-core' ); ?></th>
								<th scope="col" class="ds-col-modulo"><?php esc_html_e( 'Module', 'ds-core' ); ?></th>
								<td class="ds-col-azione"><span class="screen-reader-text"><?php esc_html_e( 'Settings and details', 'ds-core' ); ?></span></td>
							</tr>
						</thead>
						<?php foreach ( $moduli as $id => $modulo ) : ?>
							<?php ds_core_riga_modulo( $id, $modulo, $ctx ); ?>
						<?php endforeach; ?>
					</table>
				</section>
			<?php endforeach; ?>
			<p class="ds-elenco-piede"><button type="button" class="button-link ds-chiudi-tutti" hidden><?php esc_html_e( 'Collapse all', 'ds-core' ); ?></button></p>
		</div>
		<?php endif; ?>

		<?php ds_core_storia_html( $storia, $registro ); ?>
		</div>

		<div class="ds-pannello" id="ds-pannello-settings" role="tabpanel" aria-labelledby="ds-scheda-settings" tabindex="-1"<?php echo 'settings' === $scelta ? '' : ' hidden'; ?>>
			<?php ds_core_generali_html( $registro, $config ); ?>
		</div>

		<div class="ds-pannello" id="ds-pannello-help" role="tabpanel" aria-labelledby="ds-scheda-help" tabindex="-1"<?php echo 'help' === $scelta ? '' : ' hidden'; ?>>
			<?php ds_core_aiuto_html(); ?>
		</div>
	</div>
	<?php
}

/**
 * «Recent changes» sotto l'elenco dei moduli, chiuso (<details>): le ultime 5 righe, il resto (fino a 50) dietro
 * «Show all», più il link al registro delle attività se è acceso.
 */
function ds_core_storia_html( $storia, $registro ) {
	$riga = function ( $voce ) use ( $registro ) {
		$vid = ds_core_id_attuale( $voce['id'] ?? '' ); // righe con un vecchio ID (prima della 0.17.0)
		echo '<tr><td>' . esc_html( ds_core_data( $voce['quando'] ?? 0 ) ) . '</td>';
		echo '<td>' . esc_html( ds_core_storia_utente( $voce['utente'] ?? '' ) ) . '</td>';
		echo '<td>' . esc_html( isset( $registro[ $vid ] ) ? $registro[ $vid ]['titolo'] : ( 'ds-core' === $vid ? __( 'General settings', 'ds-core' ) : $vid ) ) . '</td>';
		echo '<td>' . esc_html( ds_core_storia_testo( $voce['da'] ?? '' ) ) . ' → ' . esc_html( ds_core_storia_testo( $voce['a'] ?? '' ) ) . '</td></tr>';
	};
	$testata = '<thead><tr><th scope="col">' . esc_html__( 'When', 'ds-core' ) . '</th><th scope="col">' . esc_html__( 'Who', 'ds-core' ) . '</th><th scope="col">' . esc_html__( 'Module', 'ds-core' ) . '</th><th scope="col">' . esc_html__( 'Change', 'ds-core' ) . '</th></tr></thead>';
	$prime   = array_slice( $storia, 0, 5 );
	$altre   = array_slice( $storia, 5 );
	?>
	<details class="ds-storia">
		<summary><?php esc_html_e( 'Recent changes', 'ds-core' ); ?></summary>
		<?php if ( $storia ) : ?>
			<div class="ds-tabella-contenitore">
				<table class="widefat striped ds-storia-tabella">
					<?php echo $testata; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato. ?>
					<tbody>
						<?php array_map( $riga, $prime ); ?>
					</tbody>
				</table>
			</div>
			<?php if ( $altre ) : ?>
				<details class="ds-storia-altre">
					<?php /* translators: %d: number of changes. */ ?>
					<summary><?php echo esc_html( sprintf( __( 'Show all %d', 'ds-core' ), count( $storia ) ) ); ?></summary>
					<div class="ds-tabella-contenitore">
						<table class="widefat striped ds-storia-tabella">
							<?php echo $testata; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato. ?>
							<tbody>
								<?php array_map( $riga, $altre ); ?>
							</tbody>
						</table>
					</div>
				</details>
			<?php endif; ?>
		<?php else : ?>
			<p><?php esc_html_e( 'No changes yet.', 'ds-core' ); ?></p>
		<?php endif; ?>
		<?php if ( defined( 'DS_CORE_RA_PAGINA' ) && function_exists( 'ds_core_eventi_acceso' ) && ds_core_eventi_acceso() ) : ?>
			<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=' . DS_CORE_RA_PAGINA ) ); ?>"><?php esc_html_e( 'All changes in the activity log', 'ds-core' ); ?></a></p>
		<?php endif; ?>
	</details>
	<?php
}

/**
 * Scheda «Settings»: impostazioni generali di DS Core a righe (etichetta, riepilogo, «Change»). Indirizzo degli avvisi
 * (stesso modulo HTML e stesso salvataggio della 0.13.0-0.15.0, aperto da «Change»; aperto da solo con una richiesta
 * di cambio in attesa), aggiornamenti di DS Core (solo informazioni, 0.16.1), interruttore d'emergenza.
 */
function ds_core_generali_html( $registro, $config ) {
	$bloccato  = '' !== ds_core_avvisi_bloccato();
	$attesa    = ds_core_avvisi_attesa();
	$ripiego   = get_transient( 'ds_core_imp_' . get_current_user_id() );
	$aperto    = $attesa || ( is_array( $ripiego ) && 'ds-core' === ( $ripiego['id'] ?? '' ) );
	$con_mail  = array();
	foreach ( $registro as $modulo ) {
		if ( ! empty( $modulo['avvisi'] ) ) {
			$con_mail[] = $modulo['titolo'];
		}
	}
	$rilasci = ds_core_rilasci_pannello_html( false );
	?>
	<section class="ds-generali" id="ds-generali" aria-labelledby="ds-generali-titolo">
		<h2 id="ds-generali-titolo" class="screen-reader-text"><?php esc_html_e( 'General settings', 'ds-core' ); ?></h2>
		<p class="ds-generali-intro"><?php esc_html_e( 'Choices that apply to all of DS Core, whichever modules are on.', 'ds-core' ); ?></p>
		<div class="ds-generali-righe">
			<div class="ds-generale<?php echo $aperto ? ' is-aperto' : ''; ?>">
				<div class="ds-generale-riga">
					<span class="ds-generale-etichetta" id="ds-generale-avvisi-titolo"><?php esc_html_e( 'Notification address', 'ds-core' ); ?></span>
					<div class="ds-generale-riepilogo">
						<p>
							<?php
							if ( $attesa ) {
								$nuovo = '' !== (string) $attesa['indirizzo'] ? (string) $attesa['indirizzo'] : ds_core_avvisi_admin();
								/* translators: %s: email address waiting for confirmation. */
								echo esc_html( sprintf( __( 'Waiting for confirmation from %s', 'ds-core' ), $nuovo ) );
							} else {
								printf(
									/* translators: %s: email address, or a list of addresses. */
									esc_html__( 'All DS Core emails go to %s.', 'ds-core' ),
									ds_core_avvisi_destinatari_html() // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato.
								);
								if ( $bloccato ) {
									echo ' ' . esc_html__( 'Set in wp-config.php', 'ds-core' );
								}
							}
							?>
						</p>
						<?php if ( $con_mail ) : ?>
							<?php /* translators: %s: list of module titles. */ ?>
							<p class="ds-grigio"><?php echo esc_html( sprintf( __( 'Used by: %s.', 'ds-core' ), implode( ', ', $con_mail ) ) ); ?></p>
						<?php endif; ?>
					</div>
					<a href="#ds-generale-avvisi" class="button ds-cambia" role="button" aria-expanded="<?php echo $aperto ? 'true' : 'false'; ?>" aria-controls="ds-generale-avvisi"><?php esc_html_e( 'Change', 'ds-core' ); ?></a>
				</div>
				<div class="ds-generale-aperto" id="ds-generale-avvisi" role="region" aria-labelledby="ds-generale-avvisi-titolo"<?php echo $aperto ? '' : ' hidden'; ?>>
					<?php echo ds_core_impostazioni_form( 'ds-core', ds_core_avvisi_testi_pannello() ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato. ?>
					<?php echo ds_core_avvisi_dopo_form_html(); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato. ?>
				</div>
			</div>
			<div class="ds-generale">
				<div class="ds-generale-riga">
					<span class="ds-generale-etichetta"><?php esc_html_e( 'DS Core updates', 'ds-core' ); ?></span>
					<div class="ds-generale-riepilogo">
						<?php /* translators: %s: version number. */ ?>
						<p><?php echo esc_html( sprintf( __( 'Version %s installed. New versions arrive as signed updates in Dashboard › Updates.', 'ds-core' ), DS_CORE_VERSIONE ) ); ?></p>
						<?php echo $rilasci; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato. ?>
					</div>
				</div>
			</div>
			<div class="ds-generale">
				<div class="ds-generale-riga">
					<span class="ds-generale-etichetta"><?php esc_html_e( 'Emergency switch', 'ds-core' ); ?></span>
					<div class="ds-generale-riepilogo">
						<p>
							<?php
							if ( $config ) {
								$nomi = array();
								foreach ( $config as $id ) {
									$nomi[] = isset( $registro[ $id ] ) ? $registro[ $id ]['titolo'] : $id;
								}
								/* translators: %s: list of module titles. */
								echo esc_html( sprintf( __( 'In use: turned off from wp-config.php: %s.', 'ds-core' ), implode( ', ', $nomi ) ) );
							} else {
								esc_html_e( 'Not in use.', 'ds-core' );
							}
							?>
							<a href="<?php echo esc_url( ds_core_url_pannello( 'help', 'ds-emergenza' ) ); ?>" data-ds-vai="help"><?php esc_html_e( 'How it works', 'ds-core' ); ?></a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
}

/** Scheda «Help»: come funziona, emergenza (con la riga da copiare), assistenza. */
function ds_core_aiuto_html() {
	?>
	<div class="ds-aiuto">
		<h2><?php esc_html_e( 'How it works', 'ds-core' ); ?></h2>
		<p><?php esc_html_e( 'Common features of the site, grouped by category. Each row is a feature: the yellow switch is on, the grey one is off; modules with “Off | Test | On” in test mode only work for administrators. Switches save immediately and every change is listed under “Recent changes”.', 'ds-core' ); ?></p>
		<p><?php echo ds_core_testo_aiuto_righe(); // phpcs:ignore WordPress.Security.EscapeOutput -- già escapato. ?></p>
		<p><?php esc_html_e( 'The search always looks in all modules, whichever tab is open. Settings that apply to all of DS Core, such as the address for its emails, are in the “Settings” tab.', 'ds-core' ); ?></p>

		<h2 id="ds-emergenza"><?php esc_html_e( 'If something goes wrong', 'ds-core' ); ?></h2>
		<p><?php esc_html_e( 'Turn the module off here. If you cannot get into the dashboard, add this line to wp-config.php: it turns modules off without uninstalling anything. Instead of “all” you can list the technical names shown in each module’s “Technical details”, separated by commas.', 'ds-core' ); ?></p>
		<p class="ds-copia"><code id="ds-riga-emergenza">define( 'DS_CORE_SPENTI', 'all' );</code><button type="button" class="button button-small ds-copia-pulsante" data-ds-copia="ds-riga-emergenza" hidden><?php esc_html_e( 'Copy', 'ds-core' ); ?></button><span class="ds-copia-esito" role="status" aria-live="polite"></span></p>

		<h2><?php esc_html_e( 'Support', 'ds-core' ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: %s: support email address. */
				esc_html__( 'For a problem or a question about these features write to %s. The email starts with the site name and versions already filled in: just add what is happening.', 'ds-core' ),
				'<strong>' . esc_html( DS_CORE_ASSISTENZA ) . '</strong>'
			);
			?>
		</p>
		<p><a class="button ds-con-icona" href="<?php echo esc_url( ds_core_link_assistenza(), array( 'mailto' ) ); ?>"><?php echo ds_core_icona( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Email support', 'ds-core' ); ?></a></p>
	</div>
	<?php
}

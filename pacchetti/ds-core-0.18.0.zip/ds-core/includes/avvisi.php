<?php
/**
 * Indirizzo degli avvisi di DS Core (dalla 0.15.0, decisione di Daniele del 27/11/2026, docs/ds-core-regole.md,
 * «Indirizzo degli avvisi»). Caricato sempre: invio delle mail, conferma del cambio, controllo dell'interruttore
 * d'emergenza. Il disegno nel pannello sta in includes/impostazioni.php e includes/pannello.php.
 *
 * A chi vanno le mail
 * - Indirizzo effettivo (ds_core_indirizzo_avvisi()), in quest'ordine: la costante DS_CORE_INDIRIZZO_AVVISI in
 *   wp-config.php se è un indirizzo valido (blocco facoltativo); l'indirizzo confermato delle impostazioni generali
 *   (opzione ds_core_generali, chiave 'avvisi'); altrimenti l'email dell'amministratore del sito (admin_email).
 * - Scelta «anche all'amministratore» (chiave 'anche_admin', spenta di base): ogni mail va anche ad admin_email.
 * - Avvisi di sicurezza: vanno sempre anche ad admin_email, qualunque sia la scelta. Quali sono si decide in un punto
 *   solo, ds_core_avvisi_tipi_sicurezza(); chi manda una mail passa il tipo a ds_core_manda_avviso() e non sceglie i
 *   destinatari. DS Woo e i plugin dei siti possono aggiungere tipi con il filtro 'ds_core_avvisi_sicurezza', mai
 *   toglierne.
 * - Una mail per destinatario: nessuno vede gli altri indirizzi.
 *
 * Cambio dell'indirizzo (vale solo dopo la conferma dal nuovo indirizzo)
 * - Salvare un indirizzo diverso da quello confermato, oppure svuotare il campo, crea una richiesta in attesa
 *   (opzione ds_core_avvisi_attesa, non in autoload). Svuotare conta come cambio: le mail passerebbero
 *   all'amministratore del sito, e chi controlla il sito può aver cambiato admin_email; la conferma arriva quindi ad
 *   admin_email. Fino alla conferma le mail vanno all'indirizzo di prima.
 * - Al nuovo indirizzo parte una mail con il link di conferma; al vecchio indirizzo effettivo e ad admin_email parte
 *   subito l'avviso di sicurezza con l'indirizzo nuovo mascherato (x***@dominio), utente, data e IP.
 * - Token: 32 byte casuali (random_bytes), nel database solo l'impronta SHA-256, confronto con hash_equals, un uso
 *   solo, scadenza 48 ore. Il link apre una pagina con un pulsante: la conferma avviene solo con il POST, così i
 *   programmi che aprono i link delle mail per controllarli non confermano da soli. Il link funziona anche senza
 *   essere collegati (chi legge il nuovo indirizzo può non avere un account): l'autorizzazione è il token, che solo
 *   chi riceve la mail conosce. Una richiesta nuova sostituisce quella in attesa (il link vecchio smette di
 *   funzionare); al massimo una richiesta al minuto.
 * - Annullamento dal pannello (manage_options e nonce). Scadenza: evento pianificato alla fine delle 48 ore, e
 *   controllo a ogni lettura della richiesta.
 * - Guardia: l'indirizzo confermato si scrive solo da qui (conferma, migrazioni). Un update_option() diretto
 *   dell'opzione ds_core_generali, per esempio da options.php, mantiene l'indirizzo di prima.
 * - Tutto nel registro delle attività (tipo dscore.alerts): richiesta e conferma come allarme, annullamento,
 *   scadenza e link non valido da notare.
 *
 * Blocco facoltativo in wp-config.php:  define( 'DS_CORE_INDIRIZZO_AVVISI', 'nome@example.com' );
 * Con la costante valida il campo del pannello è in sola lettura e le richieste in attesa non valgono più.
 *
 * Interruttore d'emergenza (DS_CORE_SPENTI in wp-config.php): quando il suo valore cambia DS Core lo annota nel
 * registro come allarme e manda l'avviso di sicurezza (opzione ds_core_emergenza_vista con l'ultimo valore visto).
 */

defined( 'ABSPATH' ) || exit;

/** Opzione della richiesta di cambio in attesa. */
const DS_CORE_AVVISI_ATTESA = 'ds_core_avvisi_attesa';

/** Validità del link di conferma: 48 ore. */
const DS_CORE_AVVISI_DURATA = 172800;

/** Tempo minimo fra due richieste di cambio: un minuto. */
const DS_CORE_AVVISI_PAUSA = 60;

/* ---------- Tipi di avviso ---------- */

/**
 * Tipi di avviso di sicurezza: vanno sempre anche all'email dell'amministratore del sito. Punto unico della
 * decisione (Daniele, 27/11/2026). 'accesso.chiusura' dalla 0.15.1: chiusura dell'accesso di Claude Code prima della
 * scadenza o per scadenza non valida (alla scadenza naturale nessuna mail). 'aggiornatore.firma' dalla 0.16.0:
 * aggiornamento di DS Core rifiutato per la firma (includes/aggiornatore.php). 'account.amministratore' dalla 0.17.0
 * (Daniele, 27/11/2026): amministratore nuovo notato dal modulo account-checks. 'registro.allarme' è riservato: oggi
 * DS Core non manda mail per singoli allarmi del registro.
 */
function ds_core_avvisi_tipi_sicurezza() {
	$base  = array( 'accesso.apertura', 'accesso.chiusura', 'avvisi.richiesta', 'avvisi.conferma', 'emergenza', 'registro.allarme', 'aggiornatore.firma', 'account.amministratore' );
	$altri = apply_filters( 'ds_core_avvisi_sicurezza', array() );
	$altri = is_array( $altri ) ? array_map( 'strval', array_filter( $altri, 'is_scalar' ) ) : array();
	// Il filtro può solo aggiungere: i tipi di base restano comunque.
	return array_values( array_unique( array_merge( $base, $altri ) ) );
}

function ds_core_avviso_di_sicurezza( $tipo ) {
	return in_array( (string) $tipo, ds_core_avvisi_tipi_sicurezza(), true );
}

/* ---------- Indirizzi ---------- */

/** Indirizzo fissato in wp-config.php con DS_CORE_INDIRIZZO_AVVISI, se valido; altrimenti ''. */
function ds_core_avvisi_bloccato() {
	if ( ! defined( 'DS_CORE_INDIRIZZO_AVVISI' ) ) {
		return '';
	}
	$indirizzo = trim( (string) DS_CORE_INDIRIZZO_AVVISI );
	return is_email( $indirizzo ) ? $indirizzo : '';
}

/** True se la costante c'è ma non è un indirizzo valido (il pannello lo dice; vale come se non ci fosse). */
function ds_core_avvisi_costante_errata() {
	return defined( 'DS_CORE_INDIRIZZO_AVVISI' ) && '' === ds_core_avvisi_bloccato();
}

/** Indirizzo confermato nelle impostazioni generali ('' = amministratore del sito). */
function ds_core_avvisi_confermato() {
	$generali = get_option( 'ds_core_generali', array() );
	$avvisi   = is_array( $generali ) && isset( $generali['avvisi'] ) ? trim( (string) $generali['avvisi'] ) : '';
	return is_email( $avvisi ) ? $avvisi : '';
}

/** Email dell'amministratore del sito. */
function ds_core_avvisi_admin() {
	return trim( (string) get_option( 'admin_email' ) );
}

/** Indirizzo effettivo per le mail di DS Core: costante, poi indirizzo confermato, poi amministratore del sito. */
function ds_core_indirizzo_avvisi() {
	$bloccato = ds_core_avvisi_bloccato();
	if ( '' !== $bloccato ) {
		return $bloccato;
	}
	$confermato = ds_core_avvisi_confermato();
	return '' !== $confermato ? $confermato : ds_core_avvisi_admin();
}

/** Scelta «anche all'amministratore del sito». */
function ds_core_avvisi_anche_admin() {
	$generali = ds_core_opzioni_modulo( 'ds-core' );
	return ! empty( $generali['anche_admin'] );
}

/** Destinatari di un avviso del tipo dato, senza doppioni (confronto senza maiuscole). */
function ds_core_avvisi_destinatari( $tipo = '', $extra = array() ) {
	$elenco = array( ds_core_indirizzo_avvisi() );
	if ( ds_core_avviso_di_sicurezza( $tipo ) || ds_core_avvisi_anche_admin() ) {
		$elenco[] = ds_core_avvisi_admin();
	}
	$elenco = array_merge( $elenco, (array) $extra );
	$fuori  = array();
	foreach ( $elenco as $indirizzo ) {
		$indirizzo = trim( (string) $indirizzo );
		if ( is_email( $indirizzo ) && ! isset( $fuori[ strtolower( $indirizzo ) ] ) ) {
			$fuori[ strtolower( $indirizzo ) ] = $indirizzo;
		}
	}
	return array_values( $fuori );
}

/**
 * Manda un avviso di DS Core. $tipo dice se è di sicurezza (ds_core_avvisi_tipi_sicurezza()); $extra: indirizzi in
 * più (per esempio il vecchio indirizzo dopo un cambio). Una mail per destinatario. Restituisce true se almeno una
 * mail è partita. Oggetto e testo li prepara chi chiama, nella lingua del sito.
 */
function ds_core_manda_avviso( $tipo, $oggetto, $testo, $extra = array() ) {
	$mandata = false;
	foreach ( ds_core_avvisi_destinatari( $tipo, $extra ) as $indirizzo ) {
		$mandata = wp_mail( $indirizzo, $oggetto, $testo ) || $mandata;
	}
	return $mandata;
}

/**
 * Destinatari di un tipo di avviso in HTML già escapato, per le frasi del pannello («… go to a and b»). Elenco nella
 * forma della lingua dell'amministratore (wp_sprintf_l).
 */
function ds_core_avvisi_destinatari_html( $tipo = '' ) {
	$parti = array();
	foreach ( ds_core_avvisi_destinatari( $tipo ) as $indirizzo ) {
		$parti[] = '<strong>' . esc_html( $indirizzo ) . '</strong>';
	}
	return $parti ? wp_sprintf_l( '%l', $parti ) : '<strong>—</strong>';
}

/** Indirizzo mascherato per mail e registro: prima lettera, tre asterischi, dominio (n***@example.com). */
function ds_core_avvisi_maschera( $indirizzo ) {
	$indirizzo = trim( (string) $indirizzo );
	if ( ! is_email( $indirizzo ) ) {
		return '';
	}
	list( $nome, $dominio ) = explode( '@', $indirizzo, 2 );
	$prima = function_exists( 'mb_substr' ) ? mb_substr( $nome, 0, 1 ) : substr( $nome, 0, 1 );
	return $prima . '***@' . $dominio;
}

/* ---------- Scrittura dell'indirizzo confermato (guardia) ---------- */

/** Permesso di cambiare l'indirizzo confermato in questa richiesta: solo conferma e migrazioni. */
function ds_core_avvisi_permesso( $valore = null ) {
	static $permesso = false;
	if ( null !== $valore ) {
		$permesso = (bool) $valore;
	}
	return $permesso;
}

/** Scrive l'indirizzo confermato ('' = amministratore del sito). Unico punto che lo cambia. */
function ds_core_avvisi_scrivi_confermato( $indirizzo ) {
	$generali           = get_option( 'ds_core_generali', array() );
	$generali           = is_array( $generali ) ? $generali : array();
	$generali['avvisi'] = is_email( $indirizzo ) ? sanitize_email( $indirizzo ) : '';
	ds_core_avvisi_permesso( true );
	update_option( 'ds_core_generali', $generali, false );
	ds_core_avvisi_permesso( false );
	ds_core_opzioni_svuota();
}

/** Ogni altra scrittura dell'opzione mantiene l'indirizzo confermato di prima. */
add_filter( 'pre_update_option_ds_core_generali', 'ds_core_avvisi_guardia', 10, 2 );
function ds_core_avvisi_guardia( $nuovo, $vecchio ) {
	if ( ds_core_avvisi_permesso() ) {
		return $nuovo;
	}
	$prima = is_array( $vecchio ) && isset( $vecchio['avvisi'] ) ? (string) $vecchio['avvisi'] : '';
	if ( ! is_array( $nuovo ) ) {
		$nuovo = array();
	}
	if ( ( $nuovo['avvisi'] ?? '' ) !== $prima ) {
		$nuovo['avvisi'] = $prima;
	}
	return $nuovo;
}

/* ---------- Richiesta di cambio ---------- */

/**
 * Richiesta in attesa: array( indirizzo, hash, scade, quando, utente, utente_id, ip ), oppure null. Una richiesta
 * scaduta si chiude qui (registro); con la costante in wp-config.php non vale nessuna richiesta.
 */
function ds_core_avvisi_attesa() {
	$attesa = get_option( DS_CORE_AVVISI_ATTESA, false );
	if ( ! is_array( $attesa ) || empty( $attesa['hash'] ) || ! isset( $attesa['indirizzo'], $attesa['scade'] ) ) {
		return null;
	}
	if ( '' !== ds_core_avvisi_bloccato() ) {
		return null;
	}
	if ( (int) $attesa['scade'] < time() ) {
		ds_core_avvisi_chiudi( 'scaduta', $attesa );
		return null;
	}
	return $attesa;
}

/** Evento del registro delle attività per il cambio dell'indirizzo. */
function ds_core_avvisi_evento( $azione, $livello, $dati = array(), $evento = array() ) {
	ds_core_registra_evento(
		'dscore.alerts',
		array_merge(
			array(
				'livello' => $livello,
				'origine' => 'ds-core',
				'oggetto' => 'ds-core',
				'dati'    => array_merge( array( 'azione' => $azione ), $dati ),
			),
			$evento
		)
	);
}

/** Chiude la richiesta in attesa senza cambiare nulla: 'annullata' (dal pannello), 'scaduta', 'sostituita'. */
function ds_core_avvisi_chiudi( $motivo, $attesa = null ) {
	$attesa = is_array( $attesa ) ? $attesa : get_option( DS_CORE_AVVISI_ATTESA, false );
	delete_option( DS_CORE_AVVISI_ATTESA );
	wp_clear_scheduled_hook( 'ds_core_avvisi_scadenza' );
	if ( ! is_array( $attesa ) || 'sostituita' === $motivo ) {
		return;
	}
	$a = ds_core_avvisi_maschera( '' !== (string) ( $attesa['indirizzo'] ?? '' ) ? $attesa['indirizzo'] : ds_core_avvisi_admin() );
	if ( 'annullata' === $motivo ) {
		ds_core_avvisi_evento( 'annullata', 2, array( 'a' => $a ) );
		ds_core_storia_aggiungi( 'ds-core', $a, 'avvisi:annullata' );
	} else {
		ds_core_avvisi_evento( 'scaduta', 2, array( 'a' => $a ), array( 'utente' => 'automatico', 'ip' => '' ) );
		ds_core_storia_aggiungi( 'ds-core', $a, 'avvisi:scaduta', 'automatico' );
	}
}

// Fine delle 48 ore: la richiesta si chiude anche se nessuno apre il pannello.
add_action( 'ds_core_avvisi_scadenza', 'ds_core_avvisi_attesa' );

/** IP di chi fa la richiesta (solo REMOTE_ADDR, come il registro). */
function ds_core_avvisi_ip() {
	return ds_core_eventi_ip();
}

/** Data e ora nel formato del sito. */
function ds_core_avvisi_data( $quando ) {
	return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $quando );
}

/** Link di conferma (pagina con il pulsante, poi POST). */
function ds_core_avvisi_link( $token ) {
	return add_query_arg(
		array(
			'action' => 'ds_core_avvisi_conferma',
			't'      => $token,
		),
		admin_url( 'admin-post.php' )
	);
}

/**
 * Chiede il cambio dell'indirizzo verso $nuovo ('' = amministratore del sito). Restituisce true oppure il motivo
 * (tradotto) per cui non si è fatto nulla. Chi chiama controlla permessi e nonce.
 */
function ds_core_avvisi_richiedi( $nuovo ) {
	$nuovo = trim( (string) $nuovo );
	if ( '' !== $nuovo && ! is_email( $nuovo ) ) {
		return __( 'Enter a valid email address, or leave the field empty.', 'ds-core' );
	}
	if ( '' !== ds_core_avvisi_bloccato() ) {
		return __( 'The notification address is set in wp-config.php and cannot be changed here.', 'ds-core' );
	}
	$prima = get_option( DS_CORE_AVVISI_ATTESA, false );
	if ( is_array( $prima ) && isset( $prima['quando'] ) && (int) $prima['quando'] > time() - DS_CORE_AVVISI_PAUSA ) {
		return __( 'A confirmation email was sent less than a minute ago. Wait a minute before asking again.', 'ds-core' );
	}
	$destinazione = '' !== $nuovo ? $nuovo : ds_core_avvisi_admin();
	if ( ! is_email( $destinazione ) ) {
		return __( 'The site administrator email is not valid: set it in Settings › General first.', 'ds-core' );
	}

	$vecchio = ds_core_indirizzo_avvisi();
	$utente  = wp_get_current_user();
	$token   = bin2hex( random_bytes( 32 ) );
	$attesa  = array(
		'indirizzo' => '' !== $nuovo ? sanitize_email( $nuovo ) : '',
		'hash'      => hash( 'sha256', $token ),
		'quando'    => time(),
		'scade'     => time() + DS_CORE_AVVISI_DURATA,
		'utente'    => $utente->exists() ? $utente->user_login : '',
		'utente_id' => $utente->exists() ? (int) $utente->ID : 0,
		'ip'        => ds_core_avvisi_ip(),
	);
	if ( is_array( $prima ) ) {
		ds_core_avvisi_chiudi( 'sostituita', $prima );
	}
	update_option( DS_CORE_AVVISI_ATTESA, $attesa, false );

	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

	// 1. Al nuovo indirizzo: il link. Nessun nome utente: chi riceve può non essere chi ha chiesto.
	/* translators: %s: site title. */
	$oggetto = sprintf( __( '[%s] Confirm the address for DS Core notices', 'ds-core' ), $sito );
	$testo   = implode(
		"\n",
		array(
			/* translators: %s: site address. */
			sprintf( __( 'Someone asked to send the DS Core notices of %s to this address.', 'ds-core' ), home_url( '/' ) ),
			'',
			__( 'To confirm, open this link and press the button on the page. The link works once and expires in 48 hours:', 'ds-core' ),
			ds_core_avvisi_link( $token ),
			'',
			__( 'If you were not expecting this email, ignore it: nothing changes.', 'ds-core' ),
		)
	);
	$partita = wp_mail( $destinazione, $oggetto, $testo );
	if ( ! $partita ) {
		delete_option( DS_CORE_AVVISI_ATTESA );
		if ( $cambiata ) {
			restore_previous_locale();
		}
		return __( 'The confirmation email could not be sent, so nothing changed. Check that the site can send email.', 'ds-core' );
	}

	// 2. Avviso di sicurezza al vecchio indirizzo effettivo e all'amministratore del sito.
	$mascherato = ds_core_avvisi_maschera( $destinazione );
	/* translators: %s: site title. */
	$oggetto = sprintf( __( '[%s] Change of the DS Core notification address requested', 'ds-core' ), $sito );
	$testo   = implode(
		"\n",
		array(
			/* translators: 1: site address, 2: masked new email address. */
			sprintf( __( 'Someone asked to change the DS Core notification address of %1$s to %2$s.', 'ds-core' ), home_url( '/' ), $mascherato ),
			'',
			/* translators: %s: username. */
			sprintf( __( 'Requested by: %s', 'ds-core' ), '' !== $attesa['utente'] ? $attesa['utente'] : __( 'unknown', 'ds-core' ) ),
			/* translators: %s: date and time. */
			sprintf( __( 'When: %s', 'ds-core' ), ds_core_avvisi_data( $attesa['quando'] ) ),
			/* translators: %s: IP address. */
			sprintf( __( 'IP address: %s', 'ds-core' ), '' !== $attesa['ip'] ? $attesa['ip'] : __( 'unknown', 'ds-core' ) ),
			'',
			__( 'The change takes effect only when it is confirmed from the new address, within 48 hours. Until then the notices keep coming here.', 'ds-core' ),
			__( 'If you did not ask for it: open the panel, cancel the request under General settings, then change the password of the account above.', 'ds-core' ),
			admin_url( 'admin.php?page=ds-core&tab=settings#ds-generali' ),
		)
	);
	ds_core_manda_avviso( 'avvisi.richiesta', $oggetto, $testo );
	if ( $cambiata ) {
		restore_previous_locale();
	}

	wp_schedule_single_event( $attesa['scade'] + 60, 'ds_core_avvisi_scadenza' );
	$da = ds_core_avvisi_maschera( $vecchio );
	ds_core_avvisi_evento( 'richiesta', 3, array( 'da' => $da, 'a' => $mascherato ) );
	ds_core_storia_aggiungi( 'ds-core', $da, 'avvisi:richiesta:' . $mascherato );
	return true;
}

/* ---------- Conferma dal link (anche senza essere collegati) ---------- */

add_action( 'admin_post_ds_core_avvisi_conferma', 'ds_core_avvisi_conferma' );
add_action( 'admin_post_nopriv_ds_core_avvisi_conferma', 'ds_core_avvisi_conferma' );
function ds_core_avvisi_conferma() {
	nocache_headers();
	$metodo = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
	// phpcs:disable WordPress.Security.NonceVerification -- l'autorizzazione è il token monouso (vedi in cima al file).
	$token = isset( $_REQUEST['t'] ) ? strtolower( sanitize_text_field( wp_unslash( $_REQUEST['t'] ) ) ) : '';
	// phpcs:enable
	$sito   = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$titolo = __( 'DS Core notification address', 'ds-core' );
	$attesa = ds_core_avvisi_attesa();
	$valido = is_array( $attesa ) && 1 === preg_match( '/^[a-f0-9]{64}$/', $token ) && hash_equals( (string) $attesa['hash'], hash( 'sha256', $token ) );

	if ( ! $valido ) {
		if ( '' !== $token && ! get_transient( 'ds_core_avvisi_link_ko' ) ) {
			// Una riga all'ora al massimo: un link vecchio aperto più volte non riempie il registro. (Non 'ogni':
			// quello confronta tipo e oggetto, e salterebbe la riga se nell'ora c'è già una richiesta.)
			set_transient( 'ds_core_avvisi_link_ko', 1, HOUR_IN_SECONDS );
			ds_core_avvisi_evento( 'link-non-valido', 2 );
		}
		$testo = '' !== ds_core_avvisi_bloccato()
			? __( 'The notification address of this site is set in wp-config.php: nothing changed.', 'ds-core' )
			: __( 'This link is not valid or has expired: nothing changed. If you still need the change, save the address again in the DS Core panel to receive a new link.', 'ds-core' );
		wp_die( '<h1>' . esc_html( $titolo ) . '</h1><p>' . esc_html( $testo ) . '</p>', esc_html( $titolo ), array( 'response' => 410 ) );
	}

	$destinazione = '' !== (string) $attesa['indirizzo'] ? (string) $attesa['indirizzo'] : ds_core_avvisi_admin();
	$mascherato   = ds_core_avvisi_maschera( $destinazione );

	if ( 'POST' !== $metodo ) {
		// Prima apertura: solo la pagina con il pulsante (i controlli automatici dei link non confermano nulla).
		$html  = '<h1>' . esc_html( $titolo ) . '</h1>';
		$html .= '<p>' . esc_html(
			sprintf(
				/* translators: 1: site title, 2: masked email address. */
				__( 'Confirm that the DS Core notices of %1$s go to %2$s from now on.', 'ds-core' ),
				$sito,
				$mascherato
			)
		) . '</p>';
		$html .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		$html .= '<input type="hidden" name="action" value="ds_core_avvisi_conferma">';
		$html .= '<input type="hidden" name="t" value="' . esc_attr( $token ) . '">';
		$html .= '<p><button type="submit" class="button button-primary button-large">' . esc_html__( 'Confirm the address', 'ds-core' ) . '</button></p>';
		$html .= '</form>';
		$html .= '<p>' . esc_html(
			sprintf(
				/* translators: %s: date and time when the link expires. */
				__( 'The link expires on %s. If you were not expecting it, close this page: nothing changes.', 'ds-core' ),
				ds_core_avvisi_data( $attesa['scade'] )
			)
		) . '</p>';
		wp_die( $html, esc_html( $titolo ), array( 'response' => 200 ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato.
	}

	// Conferma: un uso solo.
	$vecchio = ds_core_indirizzo_avvisi();
	delete_option( DS_CORE_AVVISI_ATTESA );
	wp_clear_scheduled_hook( 'ds_core_avvisi_scadenza' );
	ds_core_avvisi_scrivi_confermato( (string) $attesa['indirizzo'] );

	$da = ds_core_avvisi_maschera( $vecchio );
	ds_core_avvisi_evento( 'conferma', 3, array( 'da' => $da, 'a' => $mascherato, 'chiesto_da' => (string) $attesa['utente'] ), array( 'utente' => '', 'via' => 'browser', 'ip' => ds_core_avvisi_ip() ) );
	ds_core_storia_aggiungi( 'ds-core', $da, 'avvisi:confermata:' . $mascherato, 'link' );

	// Avviso di sicurezza: nuovo indirizzo, amministratore del sito e anche il vecchio indirizzo.
	$cambiata = switch_to_locale( get_locale() );
	/* translators: %s: site title. */
	$oggetto = sprintf( __( '[%s] DS Core notification address changed', 'ds-core' ), $sito );
	$testo   = implode(
		"\n",
		array(
			/* translators: 1: site address, 2: masked new email address. */
			sprintf( __( 'The DS Core notices of %1$s now go to %2$s. The change was confirmed from the link sent to that address.', 'ds-core' ), home_url( '/' ), $mascherato ),
			'',
			/* translators: %s: username. */
			sprintf( __( 'Requested by: %s', 'ds-core' ), '' !== (string) $attesa['utente'] ? $attesa['utente'] : __( 'unknown', 'ds-core' ) ),
			/* translators: %s: date and time. */
			sprintf( __( 'Confirmed: %s', 'ds-core' ), ds_core_avvisi_data( time() ) ),
			/* translators: %s: IP address. */
			sprintf( __( 'IP address: %s', 'ds-core' ), '' !== ds_core_avvisi_ip() ? ds_core_avvisi_ip() : __( 'unknown', 'ds-core' ) ),
			'',
			__( 'If you did not expect this change, open the panel and set the right address again, then check the administrator accounts.', 'ds-core' ),
			admin_url( 'admin.php?page=ds-core&tab=settings#ds-generali' ),
		)
	);
	ds_core_manda_avviso( 'avvisi.conferma', $oggetto, $testo, array( $vecchio ) );
	if ( $cambiata ) {
		restore_previous_locale();
	}

	$html = '<h1>' . esc_html( $titolo ) . '</h1><p>' . esc_html(
		sprintf(
			/* translators: 1: site title, 2: masked email address. */
			__( 'Done: the DS Core notices of %1$s now go to %2$s.', 'ds-core' ),
			$sito,
			$mascherato
		)
	) . '</p>';
	wp_die( $html, esc_html( $titolo ), array( 'response' => 200 ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato.
}

/* ---------- Annullamento dal pannello ---------- */

add_action( 'admin_post_ds_core_avvisi_annulla', 'ds_core_avvisi_annulla' );
function ds_core_avvisi_annulla() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_avvisi_annulla' );
	$attesa = get_option( DS_CORE_AVVISI_ATTESA, false );
	if ( is_array( $attesa ) ) {
		ds_core_avvisi_chiudi( 'annullata', $attesa );
		$messaggio = __( 'Request cancelled: the notification address stays as it was.', 'ds-core' );
	} else {
		$messaggio = __( 'There is no request to cancel.', 'ds-core' );
	}
	set_transient( 'ds_core_imp_' . get_current_user_id(), array( 'id' => 'ds-core', 'ok' => true, 'messaggio' => $messaggio, 'errori' => array() ), MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'admin.php?page=ds-core&tab=settings' ) . '#ds-generali' );
	exit;
}

/* ---------- Interruttore d'emergenza ---------- */

/** Valore dell'interruttore d'emergenza in wp-config.php, come scritto ('' = assente). */
function ds_core_avvisi_valore_emergenza() {
	return defined( 'DS_CORE_SPENTI' ) ? ds_core_eventi_taglia( trim( strtolower( (string) DS_CORE_SPENTI ) ), 200 ) : '';
}

// Su init (traduzioni pronte): confronto con l'ultimo valore visto, opzione in autoload, nessuna query in più.
add_action( 'init', 'ds_core_avvisi_emergenza', 20 );
function ds_core_avvisi_emergenza() {
	$ora   = ds_core_avvisi_valore_emergenza();
	$vista = get_option( 'ds_core_emergenza_vista', false );
	$prima = false === $vista ? '' : (string) $vista;
	if ( $ora === $prima ) {
		if ( false === $vista ) {
			update_option( 'ds_core_emergenza_vista', '', true );
		}
		return;
	}
	update_option( 'ds_core_emergenza_vista', $ora, true );
	ds_core_registra_evento(
		'dscore.emergency',
		array(
			'livello' => 3,
			'origine' => 'ds-core',
			'oggetto' => 'ds-core',
			'utente'  => 'automatico',
			'ip'      => '',
			'dati'    => array( 'da' => $prima, 'a' => $ora ),
		)
	);
	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	if ( '' === $ora ) {
		/* translators: %s: site title. */
		$oggetto = sprintf( __( '[%s] DS Core emergency switch removed', 'ds-core' ), $sito );
		/* translators: %s: site address. */
		$riga = sprintf( __( 'The DS Core emergency switch (DS_CORE_SPENTI) has been removed from wp-config.php on %s: the modules follow the panel again.', 'ds-core' ), home_url( '/' ) );
	} else {
		/* translators: %s: site title. */
		$oggetto = sprintf( __( '[%s] DS Core emergency switch set', 'ds-core' ), $sito );
		/* translators: 1: site address, 2: value of the switch (module names or "all"). */
		$riga = sprintf( __( 'The DS Core emergency switch in wp-config.php on %1$s now turns off: %2$s.', 'ds-core' ), home_url( '/' ), $ora );
	}
	ds_core_manda_avviso(
		'emergenza',
		$oggetto,
		implode(
			"\n",
			array(
				$riga,
				'',
				__( 'Only someone with access to the site files can change wp-config.php. If it was not you or your developer, check the hosting account and the site files.', 'ds-core' ),
				admin_url( 'admin.php?page=ds-core' ),
			)
		)
	);
	if ( $cambiata ) {
		restore_previous_locale();
	}
}

<?php
/**
 * Modulo no-google-fonts: nessuna richiesta a Google Fonts dalle pagine pubbliche.
 *
 * Privacy (l'indirizzo IP del visitatore non arriva a Google) e prestazioni (niente collegamenti a server esterni).
 * Tre livelli, perché un solo filtro non basta su tutti i siti:
 * 1. Breakdance: i font Google non vengono registrati (filtro breakdance_register_font, come lo snippet «Disable
 *    Google Fonts» che sostituisce);
 * 2. WordPress: i fogli di stile accodati da temi e plugin con indirizzo fonts.googleapis.com non vengono stampati;
 * 3. pagina finita: si tolgono i <link> rimasti verso fonts.googleapis.com e fonts.gstatic.com (fogli, preconnect,
 *    dns-prefetch, preload). Su un sito il link di Breakdance usciva fra le dipendenze degli elementi e solo questo
 *    livello l'ha tolto.
 *
 * Solo pagine pubbliche: niente amministrazione, AJAX, REST, feed né builder di Breakdance (lì i font servono per
 * scegliere). Prima di accenderlo i font usati dal sito devono essere serviti dal sito (caricati in locale), altrimenti
 * i testi passano ai caratteri di sistema: per questo il modulo ha anche lo stato «Prova» (solo amministratori).
 */

defined( 'ABSPATH' ) || exit;

/** Indirizzo di Google Fonts? */
function ds_core_ngf_google( $url ) {
	return (bool) preg_match( '#^(?:https?:)?//fonts\.(?:googleapis|gstatic)\.com/#i', trim( (string) $url ) );
}

/** Siamo su una pagina pubblica dove togliere i font? */
function ds_core_ngf_pagina_pubblica() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || is_feed() || is_customize_preview() ) {
		return false;
	}
	// Builder di Breakdance: la scelta dei font usa Google Fonts.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo lettura per decidere se filtrare.
	if ( isset( $_GET['breakdance'] ) || isset( $_GET['breakdance_iframe'] ) ) {
		return false;
	}
	return true;
}

// 1. Breakdance: niente registrazione dei font Google.
add_filter( 'breakdance_register_font', 'ds_core_ngf_breakdance' );
function ds_core_ngf_breakdance( $font ) {
	if ( is_array( $font ) && ! empty( $font['dependencies']['googleFonts'] ) ) {
		return false;
	}
	return $font;
}

// 2. WordPress: niente fogli di stile di Google Fonts accodati da temi e plugin.
add_filter( 'style_loader_src', 'ds_core_ngf_stile', 9999 );
function ds_core_ngf_stile( $src ) {
	if ( ds_core_ngf_google( $src ) && ds_core_ngf_pagina_pubblica() ) {
		return false;
	}
	return $src;
}

// Niente preconnect o dns-prefetch verso Google Fonts aggiunti da WordPress.
add_filter( 'wp_resource_hints', 'ds_core_ngf_suggerimenti', 9999 );
function ds_core_ngf_suggerimenti( $suggerimenti ) {
	if ( ! is_array( $suggerimenti ) || ! ds_core_ngf_pagina_pubblica() ) {
		return $suggerimenti;
	}
	return array_values(
		array_filter(
			$suggerimenti,
			function ( $voce ) {
				$url = is_array( $voce ) ? ( $voce['href'] ?? '' ) : $voce;
				return ! ds_core_ngf_google( $url ) && ! preg_match( '#^(?:https?:)?//fonts\.(?:googleapis|gstatic)\.com/?$#i', (string) $url );
			}
		)
	);
}

// 3. Pagina finita: via i <link> rimasti verso Google Fonts.
add_action( 'template_redirect', 'ds_core_ngf_avvia', 0 );
function ds_core_ngf_avvia() {
	if ( ds_core_ngf_pagina_pubblica() ) {
		ob_start( 'ds_core_ngf_filtra' );
	}
}

/** Toglie dall'HTML i tag <link> verso fonts.googleapis.com o fonts.gstatic.com. Lascia intatto il resto. */
function ds_core_ngf_filtra( $html ) {
	if ( ! is_string( $html ) || false === stripos( $html, 'fonts.g' ) || false === stripos( $html, '<html' ) ) {
		return $html;
	}
	$pulito = preg_replace( '#<link\b[^>]*\bhref\s*=\s*(["\']?)(?:https?:)?//fonts\.(?:googleapis|gstatic)\.com[^>]*>\s*#i', '', $html );
	return is_string( $pulito ) ? $pulito : $html;
}

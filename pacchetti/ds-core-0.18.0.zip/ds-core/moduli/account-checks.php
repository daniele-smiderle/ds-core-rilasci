<?php
/**
 * Modulo account-checks (dalla 0.17.0): segnalazioni sugli account, solo lettura (non cambia né cancella nulla).
 *
 * - Amministratori senza accesso in due passaggi. Riconosce il plugin Two Factor (Two_Factor_Core) e Wordfence Login
 *   Security; altri plugin si collegano con il filtro 'ds_core_ca_2fa_attivo' ( null|bool $attivo, WP_User $utente ).
 *   Dove il due passaggi non si può usare (per esempio un accesso unico da un'altra piattaforma che lo scavalca) si
 *   accende la scelta «Two-step login not available on this site», con il motivo: l'avviso diventa l'elenco delle
 *   protezioni che lo compensano (limite ai tentativi, messaggi d'errore generici, XML-RPC chiuso, password per le
 *   applicazioni solo agli amministratori, registro delle attività…), presenti o no.
 * - Amministratori nuovi: il modulo ricorda gli amministratori che conosce (opzione ds_core_ca_noti; alla prima
 *   accensione quelli presenti). Uno nuovo, anche creato scrivendo nel database senza passare da WordPress, resta
 *   segnalato finché un amministratore non lo conferma dal pannello; alla prima vista parte un avviso di sicurezza
 *   (tipo 'account.amministratore', dalla 0.17.0: va all'indirizzo degli avvisi e sempre anche all'email
 *   dell'amministratore del sito, decisione di Daniele del 27/11/2026) e un evento «da notare» va nel registro.
 * - Account senza ruolo sul sito (rimasti da plugin tolti o da ruoli cancellati).
 * - Registrazione aperta (Impostazioni › Generali, users_can_register) su un sito senza negozio WooCommerce, e in ogni
 *   caso con un ruolo predefinito che può scrivere contenuti.
 *
 * Il controllo gira dalle pagine di amministrazione aperte da un amministratore, al più una volta l'ora (subito dopo
 * un cambio di ruolo o un utente nuovo). Gli avvisi compaiono nel pannello di DS Core e, in breve, nella Bacheca e
 * nella pagina Utenti.
 *
 * Da fare più avanti (ds-core-moduli.md): email con dominio sbagliato o senza MX, persone con più account.
 */

defined( 'ABSPATH' ) || exit;

/* ---------- Dati ---------- */

/** Amministratori del sito (manage_options): WP_User, al più 200. */
function ds_core_ca_amministratori() {
	return get_users(
		array(
			'capability' => 'manage_options',
			'number'     => 200,
			'orderby'    => 'login',
		)
	);
}

/** Nome del plugin di accesso in due passaggi riconosciuto, '' se nessuno. */
function ds_core_ca_2fa_plugin() {
	if ( class_exists( 'Two_Factor_Core' ) ) {
		return 'Two Factor';
	}
	if ( class_exists( '\WordfenceLS\Controller_Users' ) ) {
		return 'Wordfence Login Security';
	}
	return (string) apply_filters( 'ds_core_ca_2fa_plugin', '' );
}

/** L'utente usa l'accesso in due passaggi: true, false o null (non si sa: nessun plugin riconosciuto). */
function ds_core_ca_2fa_attivo( $utente ) {
	$attivo = null;
	if ( class_exists( 'Two_Factor_Core' ) && method_exists( 'Two_Factor_Core', 'is_user_using_two_factor' ) ) {
		$attivo = (bool) Two_Factor_Core::is_user_using_two_factor( $utente->ID );
	}
	if ( ! $attivo && class_exists( '\WordfenceLS\Controller_Users' ) && method_exists( '\WordfenceLS\Controller_Users', 'shared' ) ) {
		$controllo = \WordfenceLS\Controller_Users::shared();
		if ( method_exists( $controllo, 'has_2fa_active' ) ) {
			$attivo = (bool) $controllo->has_2fa_active( $utente );
		}
	}
	$filtrato = apply_filters( 'ds_core_ca_2fa_attivo', $attivo, $utente );
	return null === $filtrato ? null : (bool) $filtrato;
}

/** Scelte del modulo. */
function ds_core_ca_scelte() {
	$valori = ds_core_opzioni_modulo( 'account-checks' );
	return array(
		'senza_2fa' => ! empty( $valori['senza_2fa'] ),
		'motivo'    => (string) ( $valori['motivo'] ?? '' ),
	);
}

/** Login degli amministratori senza accesso in due passaggi (o di tutti, se nessun plugin è riconosciuto). */
function ds_core_ca_senza_2fa() {
	$fuori = array();
	foreach ( ds_core_ca_amministratori() as $utente ) {
		if ( true !== ds_core_ca_2fa_attivo( $utente ) ) {
			$fuori[] = $utente->user_login;
		}
	}
	return $fuori;
}

/**
 * Protezioni che compensano l'assenza del due passaggi: chiave => array( 'nome' => testo, 'presente' => bool ).
 * Plugin riconosciuti dalla cartella fra i plugin attivi; moduli di DS Core dallo stato effettivo.
 */
function ds_core_ca_compensazioni() {
	$attivi = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$attivi = array_merge( $attivi, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	$cartelle = array();
	foreach ( $attivi as $file ) {
		$cartelle[ strtok( (string) $file, '/' ) ] = true;
	}
	$modulo = function ( $id ) {
		return 'attivo' === ds_core_stato( $id );
	};
	$app    = $modulo( 'claude-code-access' );
	if ( $app ) {
		$valori = ds_core_opzioni_modulo( 'claude-code-access' );
		$app    = ! isset( $valori['app_solo_admin'] ) || ! empty( $valori['app_solo_admin'] );
	}
	return array(
		'limite'     => array(
			'nome'     => __( 'Limit on login attempts (Limit Login Attempts Reloaded or Wordfence)', 'ds-core' ),
			'presente' => isset( $cartelle['limit-login-attempts-reloaded'] ) || isset( $cartelle['wordfence'] ) || class_exists( 'Limit_Login_Attempts' ),
		),
		'messaggi'   => array( 'nome' => __( 'Same error message for every failed login (DS Core)', 'ds-core' ), 'presente' => $modulo( 'generic-login-errors' ) ),
		'xmlrpc'     => array( 'nome' => __( 'XML-RPC closed (DS Core)', 'ds-core' ), 'presente' => $modulo( 'xmlrpc-closed' ) ),
		'accesso'    => array( 'nome' => __( 'Timed access for Claude Code (DS Core)', 'ds-core' ), 'presente' => $modulo( 'claude-code-access' ) ),
		'app'        => array( 'nome' => __( 'Application passwords only for administrators (DS Core)', 'ds-core' ), 'presente' => $app ),
		'utenti'     => array( 'nome' => __( 'User list and author archives hidden (DS Core)', 'ds-core' ), 'presente' => $modulo( 'rest-users-hidden' ) && $modulo( 'author-archives-closed' ) ),
		'registro'   => array( 'nome' => __( 'Activity log with sign-ins of administrators (DS Core)', 'ds-core' ), 'presente' => $modulo( 'activity-log' ) ),
	);
}

/** Numero di account senza ruolo su questo sito. */
function ds_core_ca_senza_ruolo() {
	$conta = count_users();
	return (int) ( $conta['avail_roles']['none'] ?? 0 );
}

/**
 * Registrazione aperta: '' se va bene, 'senza-negozio' (aperta senza WooCommerce) o 'ruolo' (aperta con un ruolo
 * predefinito che può scrivere contenuti: grave in ogni caso).
 */
function ds_core_ca_registrazione() {
	if ( ! get_option( 'users_can_register' ) ) {
		return '';
	}
	$ruolo = get_role( (string) get_option( 'default_role', 'subscriber' ) );
	if ( $ruolo && $ruolo->has_cap( 'edit_posts' ) ) {
		return 'ruolo';
	}
	return class_exists( 'WooCommerce' ) ? '' : 'senza-negozio';
}

/* ---------- Amministratori nuovi ---------- */

/** ID degli amministratori nuovi da confermare: id => momento in cui il modulo li ha visti. */
function ds_core_ca_nuovi() {
	$nuovi = get_option( 'ds_core_ca_nuovi', array() );
	return is_array( $nuovi ) ? array_map( 'intval', $nuovi ) : array();
}

/**
 * Confronta gli amministratori di adesso con quelli noti. Alla prima volta li prende tutti come noti. Un nuovo
 * amministratore: mail all'indirizzo degli avvisi ed evento nel registro, una volta sola.
 */
function ds_core_ca_controlla() {
	$adesso = array();
	foreach ( ds_core_ca_amministratori() as $utente ) {
		$adesso[ (int) $utente->ID ] = $utente;
	}
	set_transient( 'ds_core_ca_controllato', 1, HOUR_IN_SECONDS );

	$noti = get_option( 'ds_core_ca_noti', null );
	if ( ! is_array( $noti ) ) {
		update_option( 'ds_core_ca_noti', array_keys( $adesso ), false );
		return;
	}
	$noti  = array_map( 'intval', $noti );
	$nuovi = ds_core_ca_nuovi();
	// Chi non è più amministratore esce da tutti e due gli elenchi.
	$noti_dopo  = array_values( array_intersect( $noti, array_keys( $adesso ) ) );
	$nuovi_dopo = array_intersect_key( $nuovi, $adesso );
	$visti      = array();
	foreach ( $adesso as $id => $utente ) {
		if ( ! in_array( $id, $noti_dopo, true ) && ! isset( $nuovi_dopo[ $id ] ) ) {
			$nuovi_dopo[ $id ] = time();
			$visti[]           = $utente;
		}
	}
	if ( $noti_dopo !== $noti ) {
		update_option( 'ds_core_ca_noti', $noti_dopo, false );
	}
	if ( $nuovi_dopo !== $nuovi ) {
		update_option( 'ds_core_ca_nuovi', $nuovi_dopo, false );
	}
	foreach ( $visti as $utente ) {
		ds_core_registra_evento(
			'dscore.check',
			array(
				'livello' => 2,
				'origine' => 'account-checks',
				'oggetto' => 'account-checks',
				'dati'    => array( 'azione' => 'nuovo-admin', 'utente' => $utente->user_login ),
			)
		);
	}
	if ( $visti ) {
		ds_core_ca_mail( $visti );
	}
}

/**
 * Mail per gli amministratori nuovi, nella lingua del sito: avviso di sicurezza (ds_core_avvisi_tipi_sicurezza()),
 * quindi all'indirizzo degli avvisi di DS Core e anche all'email dell'amministratore del sito, una mail per indirizzo.
 */
function ds_core_ca_mail( $utenti ) {
	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$formato  = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
	/* translators: %s: site title. */
	$oggetto = sprintf( __( '[%s] New administrator account', 'ds-core' ), $sito );
	$righe   = array(
		/* translators: %s: site address. */
		sprintf( __( 'DS Core has noticed new administrator accounts on %s:', 'ds-core' ), home_url( '/' ) ),
		'',
	);
	foreach ( $utenti as $utente ) {
		/* translators: 1: username, 2: date and time the account was registered. */
		$righe[] = sprintf( __( '- %1$s (registered on %2$s)', 'ds-core' ), $utente->user_login, wp_date( $formato, strtotime( $utente->user_registered . ' UTC' ) ) );
	}
	$righe[] = '';
	$righe[] = __( 'If you know about them, confirm them in the DS Core panel (“Account checks”). If not, remove the administrator role and change the passwords of the other administrators.', 'ds-core' );
	$righe[] = admin_url( 'admin.php?page=ds-core' ) . '#ds-impostazioni-account-checks';
	ds_core_manda_avviso( 'account.amministratore', $oggetto, implode( "\n", $righe ) );
	if ( $cambiata ) {
		restore_previous_locale();
	}
}

// Dalle pagine di amministrazione, al più una volta l'ora.
add_action( 'admin_init', 'ds_core_ca_controllo_periodico' );
function ds_core_ca_controllo_periodico() {
	if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) || get_transient( 'ds_core_ca_controllato' ) ) {
		return;
	}
	ds_core_ca_controlla();
}

// Ruolo cambiato o utente nuovo: il controllo si rifà alla prossima pagina di amministrazione.
add_action( 'set_user_role', 'ds_core_ca_da_rifare' );
add_action( 'user_register', 'ds_core_ca_da_rifare' );
add_action( 'deleted_user', 'ds_core_ca_da_rifare' );
function ds_core_ca_da_rifare() {
	delete_transient( 'ds_core_ca_controllato' );
}

add_action( 'admin_post_ds_core_ca_conferma', 'ds_core_ca_conferma' );
function ds_core_ca_conferma() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_ca_conferma' );
	$id    = isset( $_POST['utente'] ) ? absint( $_POST['utente'] ) : 0;
	$nuovi = ds_core_ca_nuovi();
	if ( $id && isset( $nuovi[ $id ] ) ) {
		unset( $nuovi[ $id ] );
		update_option( 'ds_core_ca_nuovi', $nuovi, false );
		$noti   = array_map( 'intval', (array) get_option( 'ds_core_ca_noti', array() ) );
		$noti[] = $id;
		update_option( 'ds_core_ca_noti', array_values( array_unique( $noti ) ), false );
		$utente = get_userdata( $id );
		ds_core_registra_evento(
			'dscore.check',
			array(
				'livello' => 1,
				'origine' => 'account-checks',
				'oggetto' => 'account-checks',
				'dati'    => array( 'azione' => 'admin-confermato', 'utente' => $utente ? $utente->user_login : (string) $id ),
			)
		);
	}
	wp_safe_redirect( ds_core_url_pannello( ds_core_scheda_dal_referer(), 'ds-impostazioni-account-checks' ) );
	exit;
}

/* ---------- Avvisi ---------- */

/** Problemi per l'avviso in cima al pannello e per la Bacheca. */
function ds_core_ca_problemi() {
	$problemi = array();
	$scelte   = ds_core_ca_scelte();

	if ( ! $scelte['senza_2fa'] ) {
		$senza = ds_core_ca_senza_2fa();
		if ( $senza && '' === ds_core_ca_2fa_plugin() ) {
			/* translators: %s: list of usernames. */
			$problemi[] = sprintf( __( 'No two-step login plugin is active: these administrators sign in with the password only: %s.', 'ds-core' ), implode( ', ', $senza ) );
		} elseif ( $senza ) {
			/* translators: %s: list of usernames. */
			$problemi[] = sprintf( __( 'Administrators without two-step login: %s.', 'ds-core' ), implode( ', ', $senza ) );
		}
	}

	$nuovi = ds_core_ca_nuovi();
	if ( $nuovi ) {
		$nomi = array();
		foreach ( array_keys( $nuovi ) as $id ) {
			$utente = get_userdata( $id );
			$nomi[] = $utente ? $utente->user_login : (string) $id;
		}
		/* translators: %s: list of usernames. */
		$problemi[] = sprintf( __( 'New administrator accounts to confirm: %s.', 'ds-core' ), implode( ', ', $nomi ) );
	}

	$senza_ruolo = ds_core_ca_senza_ruolo();
	if ( $senza_ruolo ) {
		/* translators: %d: number of accounts. */
		$problemi[] = sprintf( _n( '%d account has no role on this site.', '%d accounts have no role on this site.', $senza_ruolo, 'ds-core' ), $senza_ruolo );
	}

	$registrazione = ds_core_ca_registrazione();
	if ( 'ruolo' === $registrazione ) {
		$problemi[] = __( 'Anyone can register, and new accounts get a role that can write content: change “New User Default Role” in Settings › General.', 'ds-core' );
	} elseif ( 'senza-negozio' === $registrazione ) {
		$problemi[] = __( 'Anyone can register an account (Settings › General › Membership), but this site has no shop.', 'ds-core' );
	}
	return $problemi;
}

// Avviso breve per gli amministratori nella Bacheca e nella pagina Utenti.
add_action( 'admin_notices', 'ds_core_ca_avviso_bacheca' );
function ds_core_ca_avviso_bacheca() {
	$schermata = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! current_user_can( 'manage_options' ) || ! $schermata || ! in_array( $schermata->id, array( 'dashboard', 'users' ), true ) ) {
		return;
	}
	$problemi = ds_core_ca_problemi();
	if ( ! $problemi ) {
		return;
	}
	?>
	<div class="notice notice-warning">
		<p><strong><?php esc_html_e( 'DS Core – account checks', 'ds-core' ); ?></strong></p>
		<ul style="list-style:disc;margin-left:1.5em">
			<?php foreach ( $problemi as $problema ) : ?>
				<li><?php echo esc_html( $problema ); ?></li>
			<?php endforeach; ?>
		</ul>
		<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=ds-core' ) . '#ds-impostazioni-account-checks' ); ?>"><?php esc_html_e( 'Open the account checks', 'ds-core' ); ?></a></p>
	</div>
	<?php
}

/* ---------- Pannello ---------- */

/** Stato nella riga del modulo (solo a modulo acceso). */
function ds_core_ca_riquadro() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$scelte  = ds_core_ca_scelte();
	$plugin  = ds_core_ca_2fa_plugin();
	$formato = get_option( 'date_format' );
	$nuovi   = ds_core_ca_nuovi();
	$si      = function_exists( 'ds_core_icona' ) ? ds_core_icona( 'acceso' ) : '';
	?>
	<div class="ds-account-checks">
		<h4><?php esc_html_e( 'Two-step login', 'ds-core' ); ?></h4>
		<?php if ( $scelte['senza_2fa'] ) : ?>
			<p class="ds-accesso-stato">
				<?php esc_html_e( 'Marked as not available on this site.', 'ds-core' ); ?>
				<?php if ( '' !== $scelte['motivo'] ) : ?>
					<?php
					/* translators: %s: reason written by the administrator. */
					echo esc_html( sprintf( __( 'Reason: %s', 'ds-core' ), $scelte['motivo'] ) );
					?>
				<?php endif; ?>
			</p>
			<p><?php esc_html_e( 'Protections that make up for it:', 'ds-core' ); ?></p>
			<ul class="ds-elenco-compensazioni">
				<?php foreach ( ds_core_ca_compensazioni() as $voce ) : ?>
					<li class="<?php echo $voce['presente'] ? '' : 'ds-avviso'; ?>">
						<?php echo $voce['presente'] ? esc_html__( 'Yes', 'ds-core' ) : esc_html__( 'Missing', 'ds-core' ); ?> – <?php echo esc_html( $voce['nome'] ); ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p class="ds-accesso-stato">
				<?php
				if ( '' !== $plugin ) {
					/* translators: %s: plugin name. */
					echo esc_html( sprintf( __( 'Plugin found: %s.', 'ds-core' ), $plugin ) );
				} else {
					esc_html_e( 'No two-step login plugin found (Two Factor is the standard one).', 'ds-core' );
				}
				?>
			</p>
			<table class="widefat striped ds-ra-mini">
				<thead><tr><th scope="col"><?php esc_html_e( 'Administrator', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Two-step login', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Registered', 'ds-core' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( ds_core_ca_amministratori() as $utente ) : ?>
					<?php $attivo = ds_core_ca_2fa_attivo( $utente ); ?>
					<tr>
						<td><a href="<?php echo esc_url( admin_url( 'user-edit.php?user_id=' . (int) $utente->ID ) ); ?>"><?php echo esc_html( $utente->user_login ); ?></a></td>
						<td class="<?php echo true === $attivo ? '' : 'ds-avviso'; ?>"><?php echo true === $attivo ? esc_html__( 'Yes', 'ds-core' ) : esc_html__( 'No', 'ds-core' ); ?></td>
						<td><?php echo esc_html( wp_date( $formato, strtotime( $utente->user_registered . ' UTC' ) ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="ds-grigio"><?php esc_html_e( 'If two-step login cannot work on this site, turn on “Two-step login not available on this site” in the settings below and write why.', 'ds-core' ); ?></p>
		<?php endif; ?>

		<?php if ( $nuovi ) : ?>
			<h4><?php esc_html_e( 'New administrators', 'ds-core' ); ?></h4>
			<p class="ds-avviso"><?php esc_html_e( 'These administrator accounts appeared after the module was turned on. Confirm the ones you know; for the others remove the administrator role.', 'ds-core' ); ?></p>
			<table class="widefat striped ds-ra-mini">
				<tbody>
				<?php foreach ( $nuovi as $id => $quando ) : ?>
					<?php $utente = get_userdata( $id ); ?>
					<tr>
						<td><?php echo esc_html( $utente ? $utente->user_login : (string) $id ); ?></td>
						<td>
							<?php
							/* translators: %s: date and time. */
							echo esc_html( sprintf( __( 'Noticed on %s', 'ds-core' ), wp_date( $formato . ' ' . get_option( 'time_format' ), (int) $quando ) ) );
							?>
						</td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="ds_core_ca_conferma">
								<input type="hidden" name="utente" value="<?php echo (int) $id; ?>">
								<?php wp_nonce_field( 'ds_core_ca_conferma' ); ?>
								<button type="submit" class="button ds-con-icona"><?php echo $si; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Confirm', 'ds-core' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<h4><?php esc_html_e( 'Other checks', 'ds-core' ); ?></h4>
		<ul>
			<li>
				<?php
				$senza_ruolo = ds_core_ca_senza_ruolo();
				if ( $senza_ruolo ) {
					/* translators: %d: number of accounts. */
					echo esc_html( sprintf( _n( '%d account has no role on this site.', '%d accounts have no role on this site.', $senza_ruolo, 'ds-core' ), $senza_ruolo ) );
					echo ' <a href="' . esc_url( admin_url( 'users.php?role=none' ) ) . '">' . esc_html__( 'Show them', 'ds-core' ) . '</a>';
				} else {
					esc_html_e( 'Every account has a role.', 'ds-core' );
				}
				?>
			</li>
			<li>
				<?php
				switch ( ds_core_ca_registrazione() ) {
					case 'ruolo':
						esc_html_e( 'Registration is open and new accounts get a role that can write content.', 'ds-core' );
						break;
					case 'senza-negozio':
						esc_html_e( 'Registration is open, but this site has no shop: turn off “Anyone can register” in Settings › General if nobody needs an account.', 'ds-core' );
						break;
					default:
						echo esc_html( get_option( 'users_can_register' ) ? __( 'Registration is open (the shop needs it).', 'ds-core' ) : __( 'Registration is closed.', 'ds-core' ) );
				}
				?>
			</li>
		</ul>
	</div>
	<?php
}

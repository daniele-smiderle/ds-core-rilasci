<?php
// Un file per modulo, con la sua voce in includes/registro.php. Nessun accesso diretto.

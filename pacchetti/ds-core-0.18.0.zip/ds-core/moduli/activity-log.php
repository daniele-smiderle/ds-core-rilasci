<?php
/**
 * Modulo activity-log: registro delle attività in versione ridotta (decisione di Daniele del 27/11/2026,
 * docs/ds-core-analisi-registro-attivita.md). Risponde a «chi ha fatto cosa, e quando» dopo un problema o un sospetto.
 *
 * Cosa registra (un INSERT per evento, solo su accessi, azioni in amministrazione, cron e richieste REST
 * autenticate; nessuna scrittura sulle pagine viste dai visitatori):
 * - accessi riusciti dal browser di chi ha un ruolo da redattore in su (wp_login);
 * - uso di una password per le applicazioni (la prima richiesta di ogni ora per utente), creazione e cancellazione;
 * - utenti da redattore in su: creati, cancellati, ruolo cambiato; email e password degli amministratori cambiate;
 * - plugin installati, attivati, disattivati, cancellati, aggiornati; temi installati, cambiati, aggiornati,
 *   cancellati; WordPress aggiornato; aggiornamenti fatti fuori da WordPress (dal modulo updates-safety-net);
 * - opzioni critiche (elenco chiuso): siteurl, home, admin_email (solo il dominio nuovo), users_can_register,
 *   default_role, blog_public, permalink_structure;
 * - MCP: ogni execute-ability e ogni lancio di un'ability dalla REST, con il solo nome dell'ability; le altre chiamate
 *   MCP riassunte per ora e per utente (numero e nomi degli strumenti). Mai gli argomenti;
 * - DS Core: moduli accesi e spenti, impostazioni salvate, claude-code-access, .htaccess, errori di caricamento.
 *
 * Cosa non registra: visite, accessi falliti (li tiene Limit Login Attempts), clienti dei negozi e iscritti,
 * password, argomenti delle chiamate MCP, corpi delle richieste, valori delle opzioni fuori dall'elenco.
 *
 * Tabella {prefisso}ds_core_eventi creata con dbDelta alla prima richiesta dopo l'accensione (versione dello schema
 * nell'opzione ds_core_ra_db), con la copia della storia del pannello e del registro di aggiornamenti. Pulizia
 * giornaliera e scrittura in includes/eventi.php. Scelte (opzione ds_core_ra, dichiarate nel registro): giorni di
 * conservazione (30, 90 di base o 365 giorni, oppure personalizzata 7-730 dalla 1.1.0) e riepilogo settimanale (spento di base) all'indirizzo unico degli avvisi.
 * Consultazione: «DS Core» › «Activity log» (capacità manage_options, filtro 'ds_core_registro_capacita' per
 * restringere). Nessuna modifica o cancellazione di righe dall'interfaccia.
 */

defined( 'ABSPATH' ) || exit;

define( 'DS_CORE_RA_ACCESO', true );

const DS_CORE_RA_PAGINA = 'ds-core-registro';

/* ---------- Tabella ---------- */

/**
 * Crea o aggiorna la tabella (dbDelta) se lo schema salvato non è quello attuale. Se il database rifiuta, riprova
 * dopo un'ora (niente tentativi a ogni richiesta) e il pannello lo dice.
 */
function ds_core_ra_prepara() {
	global $wpdb;
	if ( ds_core_eventi_pronta() || get_transient( 'ds_core_ra_db_errore' ) ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	$nuova   = '' === (string) get_option( 'ds_core_ra_db', '' );
	$tabella = ds_core_eventi_tabella();
	$sql     = "CREATE TABLE {$tabella} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  quando int(10) unsigned NOT NULL DEFAULT 0,
  livello tinyint(3) unsigned NOT NULL DEFAULT 1,
  tipo varchar(40) NOT NULL DEFAULT '',
  origine varchar(40) NOT NULL DEFAULT '',
  utente_id bigint(20) unsigned NOT NULL DEFAULT 0,
  utente varchar(60) NOT NULL DEFAULT '',
  via varchar(20) NOT NULL DEFAULT '',
  ip varchar(45) NOT NULL DEFAULT '',
  oggetto varchar(191) NOT NULL DEFAULT '',
  dati text NOT NULL,
  PRIMARY KEY  (id),
  KEY quando (quando),
  KEY tipo_quando (tipo,quando)
) " . $wpdb->get_charset_collate() . ';';

	$errori = $wpdb->suppress_errors( true );
	dbDelta( $sql );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- controllo dell'esistenza della tabella propria.
	$esiste = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabella ) ) ) === $tabella;
	$wpdb->suppress_errors( $errori );
	if ( ! $esiste ) {
		set_transient( 'ds_core_ra_db_errore', time(), HOUR_IN_SECONDS );
		error_log( '[DS Core] activity log table not created: ' . $wpdb->last_error );
		return;
	}
	update_option( 'ds_core_ra_db', DS_CORE_EVENTI_SCHEMA, true );
	if ( $nuova ) {
		ds_core_ra_importa();
	}
}
ds_core_ra_prepara();

/**
 * Prima accensione: copia nella tabella la storia del pannello (ds_core_storia) e il registro degli aggiornamenti
 * (ds_core_agg_registro), in ordine di tempo. Le due opzioni restano come sono.
 */
function ds_core_ra_importa() {
	$voci   = array();
	$storia = get_option( 'ds_core_storia', array() );
	foreach ( is_array( $storia ) ? $storia : array() as $riga ) {
		if ( ! is_array( $riga ) ) {
			continue;
		}
		$evento                      = ds_core_eventi_da_storia( $riga['id'] ?? '', $riga['da'] ?? '', $riga['a'] ?? '', (string) ( $riga['utente'] ?? '' ), (int) ( $riga['quando'] ?? 0 ) );
		$evento['dati']['importato'] = 1;
		$evento['via']               = $evento['via'] ?? ( 'automatico' === ( $riga['utente'] ?? '' ) ? 'sistema' : 'browser' );
		$evento['ip']                = '';
		$voci[]                      = $evento;
	}
	$agg = get_option( 'ds_core_agg_registro', array() );
	foreach ( is_array( $agg ) ? $agg : array() as $riga ) {
		if ( ! is_array( $riga ) || empty( $riga['chiave'] ) ) {
			continue;
		}
		$voci[] = ds_core_ra_evento_aggiornamento( $riga ) + array( 'ip' => '' );
	}
	usort(
		$voci,
		function ( $a, $b ) {
			return (int) $a['quando'] <=> (int) $b['quando'];
		}
	);
	foreach ( $voci as $voce ) {
		ds_core_eventi_scrivi( $voce );
	}
}

/**
 * Evento da una riga del registro di aggiornamenti (chiave 'plugin:<file>', 'tema:<cartella>', 'core:wordpress';
 * chi: 'automatico', 'wp-cli', 'esterno' = fuori da WordPress, oppure il login di una persona).
 */
function ds_core_ra_evento_aggiornamento( $riga ) {
	$chiave = (string) $riga['chiave'];
	$chi    = (string) ( $riga['chi'] ?? '' );
	$errore = 'errore' === ( $riga['esito'] ?? 'ok' );
	if ( 'esterno' === $chi ) {
		$tipo = 'update.external';
	} elseif ( 0 === strpos( $chiave, 'plugin:' ) ) {
		$tipo = 'plugin.update';
	} elseif ( 0 === strpos( $chiave, 'tema:' ) ) {
		$tipo = 'theme.update';
	} else {
		$tipo = 'core.update';
	}
	$vie = array( 'esterno' => 'hosting', 'automatico' => 'cron', 'wp-cli' => 'wp-cli' );
	return array(
		'tipo'    => $tipo,
		'livello' => $errore ? 3 : 1,
		'origine' => 'updates-safety-net',
		'oggetto' => preg_replace( '/^(plugin|tema|core):/', '', $chiave ),
		'utente'  => isset( $vie[ $chi ] ) ? ( 'esterno' === $chi ? '' : 'automatico' ) : $chi,
		'via'     => $vie[ $chi ] ?? 'browser',
		'quando'  => (int) ( $riga['quando'] ?? time() ),
		'dati'    => array(
			'chiave'    => $chiave,
			'versione'  => (string) ( $riga['versione'] ?? '' ),
			'ritardo'   => (int) ( $riga['ritardo'] ?? 0 ),
			'esito'     => $errore ? 'errore' : 'ok',
			'importato' => 1,
		),
	);
}

/* ---------- Chi conta ---------- */

/** Utente da registrare: ruolo da redattore in su (chi gestisce il sito). Clienti dei negozi e iscritti mai. */
function ds_core_ra_registrabile( $utente ) {
	$utente = $utente instanceof WP_User ? $utente : get_userdata( (int) $utente );
	if ( ! $utente || ! $utente->exists() ) {
		return false;
	}
	return (bool) apply_filters( 'ds_core_ra_utente_registrabile', user_can( $utente, 'edit_others_posts' ), $utente );
}

/** Il ruolo (chiave) è da redattore in su? */
function ds_core_ra_ruolo_registrabile( $ruolo ) {
	$oggetto = get_role( (string) $ruolo );
	return $oggetto && $oggetto->has_cap( 'edit_others_posts' );
}

/** La richiesta in corso è una chiamata MCP (rotta /mcp/… della REST)? Si guarda solo l'indirizzo. */
function ds_core_ra_richiesta_mcp() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo lettura della rotta richiesta.
	$rotta = isset( $_GET['rest_route'] ) ? sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ) : '';
	if ( '' === $rotta && isset( $_SERVER['REQUEST_URI'] ) ) {
		$percorso = (string) wp_parse_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH );
		$prefisso = '/' . trim( rest_get_url_prefix(), '/' ) . '/';
		$posto    = strpos( $percorso, $prefisso );
		$rotta    = false === $posto ? '' : '/' . substr( $percorso, $posto + strlen( $prefisso ) );
	}
	return (bool) preg_match( '#^/mcp(/|$)#', $rotta );
}

/* ---------- Accessi e password per le applicazioni ---------- */

add_action( 'wp_login', 'ds_core_ra_accesso', 10, 2 );
function ds_core_ra_accesso( $login, $utente ) {
	if ( ! $utente instanceof WP_User || ! ds_core_ra_registrabile( $utente ) ) {
		return;
	}
	// L'utente collegato non è ancora stabilito: chi ha agito si passa esplicitamente.
	ds_core_registra_evento(
		'login',
		array(
			'livello'   => 1,
			'origine'   => 'wordpress',
			'utente_id' => $utente->ID,
			'utente'    => $utente->user_login,
			'via'       => 'browser',
			'dati'      => array( 'ruolo' => implode( ',', (array) $utente->roles ) ),
		)
	);
}

/**
 * Accesso con una password per le applicazioni. Gira dentro l'autenticazione di WordPress: niente funzioni
 * dell'utente corrente. Una riga per utente all'ora (la prima richiesta), con il nome della password usata.
 */
add_action( 'application_password_did_authenticate', 'ds_core_ra_password_app_usata', 10, 2 );
function ds_core_ra_password_app_usata( $utente, $voce ) {
	global $wpdb;
	$mcp = ds_core_ra_richiesta_mcp();
	ds_core_eventi_contesto( 'app-password', true );
	if ( $mcp ) {
		ds_core_eventi_contesto( 'mcp', true );
	}
	if ( ! $utente instanceof WP_User || ! ds_core_ra_registrabile( $utente ) || ! ds_core_eventi_pronta() ) {
		return;
	}
	$tabella = ds_core_eventi_tabella();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabella propria, indice (tipo, quando).
	$gia = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tabella} WHERE tipo = %s AND quando >= %d AND utente_id = %d LIMIT 1", 'app-password.use', time() - HOUR_IN_SECONDS, $utente->ID ) );
	if ( $gia ) {
		return;
	}
	ds_core_registra_evento(
		'app-password.use',
		array(
			'livello'   => 1,
			'origine'   => 'wordpress',
			'utente_id' => $utente->ID,
			'utente'    => $utente->user_login,
			'via'       => $mcp ? 'mcp' : 'app-password',
			'oggetto'   => is_array( $voce ) ? (string) ( $voce['name'] ?? '' ) : '',
		)
	);
}

// Creazione: si legge solo il nome della password, mai la password (terzo argomento dell'azione).
add_action( 'wp_create_application_password', 'ds_core_ra_password_app_creata', 10, 2 );
function ds_core_ra_password_app_creata( $utente_id, $voce ) {
	ds_core_ra_password_app_evento( 'app-password.create', $utente_id, $voce );
}

add_action( 'wp_delete_application_password', 'ds_core_ra_password_app_cancellata', 10, 2 );
function ds_core_ra_password_app_cancellata( $utente_id, $voce ) {
	ds_core_ra_password_app_evento( 'app-password.delete', $utente_id, $voce );
}

function ds_core_ra_password_app_evento( $tipo, $utente_id, $voce ) {
	$utente = get_userdata( (int) $utente_id );
	if ( ! $utente || ! ds_core_ra_registrabile( $utente ) ) {
		return;
	}
	ds_core_registra_evento(
		$tipo,
		array(
			'livello' => 'app-password.create' === $tipo && user_can( $utente, 'manage_options' ) ? 3 : 2,
			'origine' => 'wordpress',
			'oggetto' => $utente->user_login,
			'dati'    => array( 'nome' => is_array( $voce ) ? (string) ( $voce['name'] ?? '' ) : '' ),
		)
	);
}

/* ---------- Utenti ---------- */

add_action( 'user_register', 'ds_core_ra_utente_creato', 10, 1 );
function ds_core_ra_utente_creato( $utente_id ) {
	$utente = get_userdata( (int) $utente_id );
	if ( ! $utente || ! ds_core_ra_registrabile( $utente ) ) {
		return;
	}
	ds_core_registra_evento(
		'user.create',
		array(
			'livello' => user_can( $utente, 'manage_options' ) ? 3 : 2,
			'origine' => 'wordpress',
			'oggetto' => $utente->user_login,
			'dati'    => array( 'ruolo' => implode( ',', (array) $utente->roles ) ),
		)
	);
}

add_action( 'delete_user', 'ds_core_ra_utente_cancellato', 10, 1 );
function ds_core_ra_utente_cancellato( $utente_id ) {
	$utente = get_userdata( (int) $utente_id );
	if ( ! $utente || ! ds_core_ra_registrabile( $utente ) ) {
		return;
	}
	ds_core_registra_evento(
		'user.delete',
		array(
			'livello' => user_can( $utente, 'manage_options' ) ? 3 : 2,
			'origine' => 'wordpress',
			'oggetto' => $utente->user_login,
			'dati'    => array( 'ruolo' => implode( ',', (array) $utente->roles ) ),
		)
	);
}

// Ruolo cambiato. Alla creazione di un utente WordPress assegna il ruolo con la stessa azione e nessun ruolo di prima:
// quel caso lo copre già «utente creato».
add_action( 'set_user_role', 'ds_core_ra_ruolo_cambiato', 10, 3 );
function ds_core_ra_ruolo_cambiato( $utente_id, $ruolo, $prima ) {
	$prima = array_values( array_filter( (array) $prima, 'is_string' ) );
	if ( ! $prima || array( (string) $ruolo ) === $prima ) {
		return;
	}
	$conta = ds_core_ra_ruolo_registrabile( $ruolo );
	foreach ( $prima as $vecchio ) {
		$conta = $conta || ds_core_ra_ruolo_registrabile( $vecchio );
	}
	$utente = get_userdata( (int) $utente_id );
	if ( ! $conta || ! $utente ) {
		return;
	}
	ds_core_registra_evento(
		'user.role',
		array(
			'livello' => 'administrator' === $ruolo ? 3 : 2,
			'origine' => 'wordpress',
			'oggetto' => $utente->user_login,
			'dati'    => array( 'da' => implode( ',', $prima ), 'a' => (string) $ruolo ),
		)
	);
}

// Email o password di un amministratore cambiate dal profilo (o da chiunque usi wp_update_user).
add_action( 'profile_update', 'ds_core_ra_profilo', 10, 2 );
function ds_core_ra_profilo( $utente_id, $prima ) {
	$utente = get_userdata( (int) $utente_id );
	if ( ! $utente || ! $prima instanceof WP_User ) {
		return;
	}
	if ( ! user_can( $utente, 'manage_options' ) && ! user_can( $prima, 'manage_options' ) ) {
		return;
	}
	if ( strtolower( (string) $prima->user_email ) !== strtolower( (string) $utente->user_email ) ) {
		ds_core_registra_evento(
			'user.email',
			array(
				'livello' => 3,
				'origine' => 'wordpress',
				'oggetto' => $utente->user_login,
				// Solo il dominio nuovo: l'indirizzo intero è un dato personale che al registro non serve.
				'dati'    => array( 'dominio' => ds_core_ra_dominio( $utente->user_email ) ),
			)
		);
	}
	if ( (string) $prima->user_pass !== (string) $utente->user_pass ) {
		ds_core_registra_evento(
			'user.password',
			array(
				'livello' => 2,
				'origine' => 'wordpress',
				'oggetto' => $utente->user_login,
			)
		);
	}
}

// Password reimpostata con il link della mail «password dimenticata»: chi agisce non è collegato.
add_action( 'after_password_reset', 'ds_core_ra_password_reimpostata', 10, 1 );
function ds_core_ra_password_reimpostata( $utente ) {
	if ( ! $utente instanceof WP_User || ! user_can( $utente, 'manage_options' ) ) {
		return;
	}
	ds_core_registra_evento(
		'user.password',
		array(
			'livello' => 2,
			'origine' => 'wordpress',
			'oggetto' => $utente->user_login,
			'utente'  => '',
			'via'     => 'browser',
			'dati'    => array( 'reset' => 1 ),
		)
	);
}

/** Dominio di un indirizzo email (dopo la @), minuscolo. */
function ds_core_ra_dominio( $email ) {
	$email = (string) $email;
	$posto = strrpos( $email, '@' );
	return false === $posto ? '' : strtolower( substr( $email, $posto + 1 ) );
}

/* ---------- Plugin, temi, aggiornamenti ---------- */

/** Nome e versione di un plugin dal suo file (anche fuori dall'amministrazione: cron, WP-CLI, MCP). */
function ds_core_ra_dati_plugin( $file ) {
	$file     = (string) $file;
	$percorso = WP_PLUGIN_DIR . '/' . $file;
	if ( '' === $file || ! is_readable( $percorso ) ) {
		return array( 'nome' => $file, 'versione' => '' );
	}
	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$dati = get_plugin_data( $percorso, false, false );
	return array(
		'nome'     => '' !== (string) ( $dati['Name'] ?? '' ) ? (string) $dati['Name'] : $file,
		'versione' => (string) ( $dati['Version'] ?? '' ),
	);
}

add_action( 'activated_plugin', 'ds_core_ra_plugin_attivato', 10, 1 );
function ds_core_ra_plugin_attivato( $file ) {
	$dati = ds_core_ra_dati_plugin( $file );
	ds_core_registra_evento( 'plugin.activate', array( 'livello' => 2, 'origine' => 'wordpress', 'oggetto' => $file, 'dati' => array( 'nome' => $dati['nome'] ) ) );
}

add_action( 'deactivated_plugin', 'ds_core_ra_plugin_disattivato', 10, 1 );
function ds_core_ra_plugin_disattivato( $file ) {
	$dati = ds_core_ra_dati_plugin( $file );
	// Disattivare DS Core ferma anche il registro: allarme.
	$livello = plugin_basename( DS_CORE_FILE ) === $file ? 3 : 2;
	ds_core_registra_evento( 'plugin.deactivate', array( 'livello' => $livello, 'origine' => 'wordpress', 'oggetto' => $file, 'dati' => array( 'nome' => $dati['nome'] ) ) );
}

/** Nome del plugin letto prima della cancellazione (dopo, il file non c'è più). */
function ds_core_ra_nome_cancellato( $file, $nome = null ) {
	static $nomi = array();
	if ( null !== $nome ) {
		$nomi[ $file ] = $nome;
	}
	return $nomi[ $file ] ?? $file;
}

add_action( 'delete_plugin', 'ds_core_ra_plugin_da_cancellare', 10, 1 );
function ds_core_ra_plugin_da_cancellare( $file ) {
	ds_core_ra_nome_cancellato( $file, ds_core_ra_dati_plugin( $file )['nome'] );
}

add_action( 'deleted_plugin', 'ds_core_ra_plugin_cancellato', 10, 2 );
function ds_core_ra_plugin_cancellato( $file, $cancellato ) {
	if ( $cancellato ) {
		ds_core_registra_evento( 'plugin.delete', array( 'livello' => 2, 'origine' => 'wordpress', 'oggetto' => $file, 'dati' => array( 'nome' => ds_core_ra_nome_cancellato( $file ) ) ) );
	}
}

add_action( 'switch_theme', 'ds_core_ra_tema_cambiato', 10, 3 );
function ds_core_ra_tema_cambiato( $nome, $nuovo, $vecchio = null ) {
	ds_core_registra_evento(
		'theme.switch',
		array(
			'livello' => 2,
			'origine' => 'wordpress',
			'oggetto' => $nuovo instanceof WP_Theme ? $nuovo->get_stylesheet() : (string) $nome,
			'dati'    => array(
				'da' => $vecchio instanceof WP_Theme ? (string) $vecchio->get( 'Name' ) : '',
				'a'  => (string) $nome,
			),
		)
	);
}

add_action( 'deleted_theme', 'ds_core_ra_tema_cancellato', 10, 2 );
function ds_core_ra_tema_cancellato( $cartella, $cancellato ) {
	if ( $cancellato ) {
		ds_core_registra_evento( 'theme.delete', array( 'livello' => 2, 'origine' => 'wordpress', 'oggetto' => (string) $cartella ) );
	}
}

/**
 * Installazioni e aggiornamenti che passano dall'upgrader di WordPress (persona, cron automatico, WP-CLI, MCP).
 * Gli aggiornamenti fatti fuori da WordPress (hosting) li annota il modulo updates-safety-net, se acceso.
 */
add_action( 'upgrader_process_complete', 'ds_core_ra_upgrader', 20, 2 );
function ds_core_ra_upgrader( $upgrader, $extra ) {
	$azione = (string) ( $extra['action'] ?? '' );
	$tipo   = (string) ( $extra['type'] ?? '' );
	if ( ! in_array( $azione, array( 'install', 'update' ), true ) || ! in_array( $tipo, array( 'plugin', 'theme', 'core' ), true ) ) {
		return;
	}
	$errore = isset( $upgrader->skin->result ) && is_wp_error( $upgrader->skin->result );
	$esito  = $errore ? 'errore' : 'ok';

	if ( 'install' === $azione ) {
		if ( 'plugin' === $tipo ) {
			$file = is_object( $upgrader ) && method_exists( $upgrader, 'plugin_info' ) ? (string) $upgrader->plugin_info() : '';
			$dati = ds_core_ra_dati_plugin( $file );
			ds_core_registra_evento( 'plugin.install', array( 'livello' => 2, 'origine' => 'wordpress', 'oggetto' => $file, 'dati' => $dati + array( 'esito' => $esito ) ) );
		} elseif ( 'theme' === $tipo ) {
			$tema = is_object( $upgrader ) && method_exists( $upgrader, 'theme_info' ) ? $upgrader->theme_info() : false;
			ds_core_registra_evento(
				'theme.install',
				array(
					'livello' => 2,
					'origine' => 'wordpress',
					'oggetto' => $tema instanceof WP_Theme ? $tema->get_stylesheet() : '',
					'dati'    => array( 'nome' => $tema instanceof WP_Theme ? (string) $tema->get( 'Name' ) : '', 'esito' => $esito ),
				)
			);
		}
		return;
	}

	if ( 'plugin' === $tipo ) {
		$files = (array) ( $extra['plugins'] ?? ( isset( $extra['plugin'] ) ? array( $extra['plugin'] ) : array() ) );
		foreach ( $files as $file ) {
			$dati = ds_core_ra_dati_plugin( $file );
			ds_core_registra_evento( 'plugin.update', array( 'livello' => $errore ? 3 : 1, 'origine' => 'wordpress', 'oggetto' => (string) $file, 'dati' => $dati + array( 'esito' => $esito ) ) );
		}
	} elseif ( 'theme' === $tipo ) {
		$temi = (array) ( $extra['themes'] ?? ( isset( $extra['theme'] ) ? array( $extra['theme'] ) : array() ) );
		foreach ( $temi as $cartella ) {
			$tema = wp_get_theme( (string) $cartella );
			ds_core_registra_evento(
				'theme.update',
				array(
					'livello' => $errore ? 3 : 1,
					'origine' => 'wordpress',
					'oggetto' => (string) $cartella,
					'dati'    => array( 'nome' => $tema->exists() ? (string) $tema->get( 'Name' ) : (string) $cartella, 'versione' => $tema->exists() ? (string) $tema->get( 'Version' ) : '', 'esito' => $esito ),
				)
			);
		}
	} else {
		ds_core_registra_evento( 'core.update', array( 'livello' => $errore ? 3 : 1, 'origine' => 'wordpress', 'oggetto' => 'WordPress', 'dati' => array( 'versione' => ds_core_ra_versione_wordpress(), 'esito' => $esito ) ) );
	}
}

/** Versione di WordPress scritta sul disco (dopo un aggiornamento la variabile globale è ancora quella vecchia). */
function ds_core_ra_versione_wordpress() {
	$file = ABSPATH . WPINC . '/version.php';
	if ( ! is_readable( $file ) ) {
		return (string) get_bloginfo( 'version' );
	}
	$testo = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- file locale di WordPress.
	return preg_match( '/\$wp_version\s*=\s*\'([^\']+)\'/', $testo, $trovato ) ? $trovato[1] : (string) get_bloginfo( 'version' );
}

/* ---------- Opzioni critiche ---------- */

/** Elenco chiuso delle opzioni da seguire. */
function ds_core_ra_opzioni_critiche() {
	return array( 'siteurl', 'home', 'admin_email', 'users_can_register', 'default_role', 'blog_public', 'permalink_structure' );
}

foreach ( ds_core_ra_opzioni_critiche() as $ds_core_ra_opzione ) {
	add_action( 'update_option_' . $ds_core_ra_opzione, 'ds_core_ra_opzione_cambiata', 10, 3 );
}
unset( $ds_core_ra_opzione );

/** Valore da salvare: corto, e per admin_email solo il dominio. */
function ds_core_ra_valore_opzione( $nome, $valore ) {
	if ( 'admin_email' === $nome ) {
		return ds_core_ra_dominio( is_scalar( $valore ) ? (string) $valore : '' );
	}
	if ( in_array( $nome, array( 'users_can_register', 'blog_public' ), true ) ) {
		return (string) (int) ( is_scalar( $valore ) ? $valore : 0 );
	}
	return ds_core_eventi_taglia( is_scalar( $valore ) ? (string) $valore : '', 191 );
}

function ds_core_ra_opzione_cambiata( $vecchio, $nuovo, $nome ) {
	$prima = ds_core_ra_valore_opzione( $nome, $vecchio );
	$dopo  = ds_core_ra_valore_opzione( $nome, $nuovo );
	if ( $prima === $dopo && 'admin_email' !== $nome ) {
		return;
	}
	if ( 'admin_email' === $nome && strtolower( (string) $vecchio ) === strtolower( (string) $nuovo ) ) {
		return;
	}
	switch ( $nome ) {
		case 'siteurl':
		case 'home':
		case 'admin_email':
			$livello = 3;
			break;
		case 'users_can_register':
			$livello = '1' === $dopo ? 3 : 2;
			break;
		case 'default_role':
			$livello = ds_core_ra_ruolo_registrabile( $dopo ) ? 3 : 2;
			break;
		case 'permalink_structure':
			$livello = 1;
			break;
		default:
			$livello = 2;
	}
	ds_core_registra_evento(
		'option.change',
		array(
			'livello' => $livello,
			'origine' => 'wordpress',
			'oggetto' => $nome,
			'dati'    => 'admin_email' === $nome ? array( 'dominio' => $dopo ) : array( 'da' => $prima, 'a' => $dopo ),
		)
	);
}

/* ---------- MCP e abilities ---------- */

/** Nome di un'ability pulito (es. «plugin/ability-name»). */
function ds_core_ra_nome_ability( $nome ) {
	return substr( preg_replace( '#[^a-z0-9/_.-]#', '', strtolower( is_scalar( $nome ) ? (string) $nome : '' ) ), 0, 191 );
}

// Contesto della richiesta: gli eventi nati dentro una chiamata MCP o di un'ability hanno «via = mcp».
add_filter( 'rest_pre_dispatch', 'ds_core_ra_rest_contesto', 0, 3 );
function ds_core_ra_rest_contesto( $risultato, $server, $richiesta ) {
	$rotta = $richiesta instanceof WP_REST_Request ? $richiesta->get_route() : '';
	if ( preg_match( '#^/mcp(/|$)#', $rotta ) || preg_match( '#^/wp-abilities/v1/abilities/.+/run/?$#', $rotta ) ) {
		ds_core_eventi_contesto( 'mcp', true );
	}
	return $risultato;
}

/**
 * Dopo una chiamata MCP o il lancio di un'ability (solo utenti collegati: le richieste anonime sono visite).
 * execute-ability e /wp-abilities/v1/abilities/<nome>/run: una riga ciascuna con il solo nome dell'ability; le altre
 * chiamate MCP: un riassunto per ora e per utente. Gli argomenti non si leggono mai, solo il nome dello strumento.
 */
add_filter( 'rest_post_dispatch', 'ds_core_ra_rest_dopo', 9999, 3 );
function ds_core_ra_rest_dopo( $risposta, $server, $richiesta ) {
	if ( ! $richiesta instanceof WP_REST_Request || ! get_current_user_id() ) {
		return $risposta;
	}
	$rotta = $richiesta->get_route();
	$stato = $risposta instanceof WP_HTTP_Response ? (int) $risposta->get_status() : 200;

	if ( preg_match( '#^/wp-abilities/v1/abilities/(.+)/run/?$#', $rotta, $trovato ) ) {
		ds_core_registra_evento(
			'mcp.ability',
			array(
				'livello' => 2,
				'origine' => 'abilities',
				'via'     => 'mcp',
				'oggetto' => ds_core_ra_nome_ability( urldecode( $trovato[1] ) ),
				'dati'    => array( 'rotta' => 'rest', 'stato' => $stato ),
			)
		);
		return $risposta;
	}
	if ( ! preg_match( '#^/mcp(/|$)#', $rotta ) ) {
		return $risposta;
	}

	$messaggi = $richiesta->get_json_params();
	if ( ! is_array( $messaggi ) ) {
		return $risposta;
	}
	if ( isset( $messaggi['method'] ) ) {
		$messaggi = array( $messaggi );
	}
	$conteggi = array();
	foreach ( array_slice( $messaggi, 0, 50 ) as $messaggio ) {
		if ( ! is_array( $messaggio ) || ! isset( $messaggio['method'] ) || ! is_string( $messaggio['method'] ) ) {
			continue;
		}
		$metodo = substr( preg_replace( '#[^a-z0-9/_.-]#i', '', $messaggio['method'] ), 0, 60 );
		$nome   = '';
		if ( 'tools/call' === $metodo && isset( $messaggio['params']['name'] ) && is_string( $messaggio['params']['name'] ) ) {
			$nome = substr( preg_replace( '#[^a-z0-9/_.-]#i', '', $messaggio['params']['name'] ), 0, 80 );
		}
		if ( '' !== $nome && preg_match( '/execute-ability$/', $nome ) ) {
			$argomenti = isset( $messaggio['params']['arguments'] ) && is_array( $messaggio['params']['arguments'] ) ? $messaggio['params']['arguments'] : array();
			// Del contenuto della chiamata si legge solo il nome dell'ability, mai i parametri.
			$ability = $argomenti['ability_name'] ?? ( $argomenti['ability'] ?? ( $argomenti['name'] ?? '' ) );
			ds_core_registra_evento(
				'mcp.ability',
				array(
					'livello' => 2,
					'origine' => 'mcp',
					'via'     => 'mcp',
					'oggetto' => ds_core_ra_nome_ability( $ability ),
					'dati'    => array( 'strumento' => $nome, 'stato' => $stato ),
				)
			);
			continue;
		}
		$chiave              = '' !== $nome ? $nome : $metodo;
		$conteggi[ $chiave ] = ( $conteggi[ $chiave ] ?? 0 ) + 1;
	}
	if ( $conteggi ) {
		ds_core_ra_riassunto_mcp( $conteggi, $stato >= 400 );
	}
	return $risposta;
}

/** Riassunto orario delle chiamate MCP di un utente: aggiorna la riga dell'ora invece di scriverne una per chiamata. */
function ds_core_ra_riassunto_mcp( $conteggi, $errore ) {
	global $wpdb;
	if ( ! ds_core_eventi_pronta() ) {
		return;
	}
	$tabella = ds_core_eventi_tabella();
	$ora     = time() - ( time() % HOUR_IN_SECONDS );
	$utente  = get_current_user_id();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabella propria, indice (tipo, quando).
	$riga = $wpdb->get_row( $wpdb->prepare( "SELECT id, dati FROM {$tabella} WHERE tipo = %s AND quando >= %d AND utente_id = %d ORDER BY id DESC LIMIT 1", 'mcp.calls', $ora, $utente ) );
	$dati = $riga ? json_decode( (string) $riga->dati, true ) : array();
	$dati = is_array( $dati ) ? $dati : array();
	$dati['n']         = (int) ( $dati['n'] ?? 0 ) + array_sum( $conteggi );
	$dati['errori']    = (int) ( $dati['errori'] ?? 0 ) + ( $errore ? 1 : 0 );
	$dati['strumenti'] = isset( $dati['strumenti'] ) && is_array( $dati['strumenti'] ) ? $dati['strumenti'] : array();
	foreach ( $conteggi as $nome => $quanti ) {
		if ( ! isset( $dati['strumenti'][ $nome ] ) && count( $dati['strumenti'] ) >= 40 ) {
			$nome = 'altro';
		}
		$dati['strumenti'][ $nome ] = (int) ( $dati['strumenti'][ $nome ] ?? 0 ) + (int) $quanti;
	}
	if ( $riga ) {
		$errori = $wpdb->suppress_errors( true );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- tabella propria, una riga.
		$wpdb->update( $tabella, array( 'dati' => ds_core_eventi_json( $dati ) ), array( 'id' => (int) $riga->id ), array( '%s' ), array( '%d' ) );
		$wpdb->suppress_errors( $errori );
		return;
	}
	ds_core_registra_evento( 'mcp.calls', array( 'livello' => 1, 'origine' => 'mcp', 'via' => 'mcp', 'dati' => $dati ) );
}

/* ---------- Scelte del modulo ---------- */

/** Scelte: giorni di conservazione e riepilogo settimanale. */
function ds_core_ra_impostazioni() {
	$valori = array_merge( array( 'giorni' => 90, 'riepilogo' => false ), ds_core_opzioni_modulo( 'activity-log' ) );
	// Un solo numero di giorni, dalla scelta fissa o dal valore personalizzato (includes/eventi.php, 0.15.0).
	$valori['giorni']    = ds_core_eventi_giorni();
	$valori['riepilogo'] = ! empty( $valori['riepilogo'] );
	return $valori;
}

// Cambiare la conservazione o il riepilogo è esso stesso un allarme, con i valori prima e dopo.
add_action( 'ds_core_impostazioni_salvate', 'ds_core_ra_impostazioni_salvate', 10, 3 );
function ds_core_ra_impostazioni_salvate( $id, $prima, $dopo ) {
	if ( 'activity-log' !== $id ) {
		return;
	}
	ds_core_registra_evento(
		'dscore.settings',
		array(
			'livello' => 3,
			'origine' => 'activity-log',
			'oggetto' => 'activity-log',
			'dati'    => array(
				'giorni_da'    => (int) ( $prima['giorni'] ?? 90 ),
				'giorni_a'     => (int) ( $dopo['giorni'] ?? 90 ),
				'riepilogo_da' => ! empty( $prima['riepilogo'] ) ? 1 : 0,
				'riepilogo_a'  => ! empty( $dopo['riepilogo'] ) ? 1 : 0,
			),
		)
	);
	ds_core_ra_pianifica();
}

// Riepilogo settimanale: pianificato solo se scelto. Si controlla in amministrazione e in cron, mai sul sito pubblico
// (l'opzione delle scelte non è in autoload).
add_action( 'admin_init', 'ds_core_ra_pianifica' );
function ds_core_ra_pianifica() {
	$scelto    = ds_core_ra_impostazioni()['riepilogo'];
	$prossimo  = wp_next_scheduled( 'ds_core_ra_riepilogo' );
	if ( $scelto && ! $prossimo ) {
		wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', 'ds_core_ra_riepilogo' );
	} elseif ( ! $scelto && $prossimo ) {
		wp_clear_scheduled_hook( 'ds_core_ra_riepilogo' );
	}
}

/* ---------- Testi degli eventi ---------- */

/** Gruppi per il filtro e il riepilogo: codice => tipi. */
function ds_core_ra_gruppi() {
	return array(
		'accessi'       => array( 'login', 'app-password.use' ),
		'utenti'        => array( 'user.create', 'user.delete', 'user.role', 'user.email', 'user.password', 'app-password.create', 'app-password.delete' ),
		'plugin'        => array( 'plugin.install', 'plugin.activate', 'plugin.deactivate', 'plugin.delete', 'theme.install', 'theme.switch', 'theme.delete' ),
		'aggiornamenti' => array( 'plugin.update', 'theme.update', 'core.update', 'update.external' ),
		'impostazioni'  => array( 'option.change' ),
		'mcp'           => array( 'mcp.ability', 'mcp.calls' ),
		'dscore'        => array( 'dscore.module', 'dscore.settings', 'dscore.access', 'dscore.htaccess', 'dscore.error', 'dscore.alerts', 'dscore.emergency', 'dscore.note', 'dscore.update', 'dscore.check' ),
	);
}

/** Nomi dei gruppi, tradotti. */
function ds_core_ra_gruppi_nomi() {
	return array(
		'accessi'       => __( 'Sign-ins', 'ds-core' ),
		'utenti'        => __( 'Users and application passwords', 'ds-core' ),
		'plugin'        => __( 'Plugins and themes', 'ds-core' ),
		'aggiornamenti' => __( 'Updates', 'ds-core' ),
		'impostazioni'  => __( 'Site settings', 'ds-core' ),
		'mcp'           => __( 'MCP and abilities', 'ds-core' ),
		'dscore'        => 'DS Core',
	);
}

/** Gruppo di un tipo di evento ('' se nessuno). */
function ds_core_ra_gruppo_di( $tipo ) {
	foreach ( ds_core_ra_gruppi() as $gruppo => $tipi ) {
		if ( in_array( $tipo, $tipi, true ) ) {
			return $gruppo;
		}
	}
	return '';
}

function ds_core_ra_livelli() {
	return array(
		1 => __( 'Information', 'ds-core' ),
		2 => __( 'To review', 'ds-core' ),
		3 => __( 'Alarm', 'ds-core' ),
	);
}

function ds_core_ra_vie() {
	return array(
		'browser'      => __( 'browser', 'ds-core' ),
		'app-password' => __( 'application password', 'ds-core' ),
		'mcp'          => 'MCP',
		'cron'         => __( 'scheduled task', 'ds-core' ),
		'wp-cli'       => 'WP-CLI',
		'hosting'      => __( 'hosting', 'ds-core' ),
		'sistema'      => __( 'system', 'ds-core' ),
	);
}

/** Dati JSON di una riga, come array. */
function ds_core_ra_dati( $riga ) {
	$dati = json_decode( (string) ( $riga->dati ?? '' ), true );
	return is_array( $dati ) ? $dati : array();
}

/** Nome di un ruolo (o di più ruoli separati da virgole), tradotto da WordPress. */
function ds_core_ra_ruolo( $ruoli ) {
	$nomi  = function_exists( 'wp_roles' ) ? wp_roles()->get_names() : array();
	$fuori = array();
	foreach ( array_filter( explode( ',', (string) $ruoli ) ) as $ruolo ) {
		$fuori[] = isset( $nomi[ $ruolo ] ) ? translate_user_role( $nomi[ $ruolo ] ) : $ruolo;
	}
	return $fuori ? implode( ', ', $fuori ) : '—';
}

/** Nome di uno stato dei moduli (stessi testi del pannello). */
function ds_core_ra_stato_nome( $stato ) {
	$nomi = array(
		'attivo' => __( 'on', 'ds-core' ),
		'prova'  => __( 'in test', 'ds-core' ),
		'spento' => __( 'off', 'ds-core' ),
	);
	return $nomi[ $stato ] ?? (string) $stato;
}

/** Testo di un codice di claude-code-access ('accesso:aperto:<fino>:<ore>:<origine>', 'accesso:chiuso…'…). */
function ds_core_ra_accesso_testo( $codice ) {
	$parti = explode( ':', (string) $codice );
	switch ( $parti[1] ?? '' ) {
		case 'aperto':
			$fino = isset( $parti[2] ) ? (int) $parti[2] : 0;
			/* translators: %s: date and time when access closes. */
			return sprintf( __( 'Claude Code access opened until %s', 'ds-core' ), $fino ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $fino ) : '—' );
		case 'scaduto':
			return __( 'Claude Code access closed (time is up)', 'ds-core' );
		case 'non-valido':
			return __( 'Claude Code access closed (invalid expiry)', 'ds-core' );
		case 'chiuso':
			// 'accesso:chiuso:<origine>': chiusa a mano prima della scadenza.
			if ( isset( $parti[2] ) && '' !== $parti[2] ) {
				return __( 'Claude Code access closed before time is up', 'ds-core' );
			}
	}
	return __( 'Claude Code access closed', 'ds-core' );
}

/** Descrizione di un evento, tradotta, in testo semplice (da escapare all'uscita). */
function ds_core_ra_descrivi( $riga ) {
	$dati  = ds_core_ra_dati( $riga );
	$esito = 'errore' === ( $dati['esito'] ?? 'ok' );
	switch ( (string) $riga->tipo ) {
		case 'login':
			return __( 'Logged in', 'ds-core' );
		case 'app-password.use':
			return __( 'Signed in with an application password', 'ds-core' );
		case 'app-password.create':
			return __( 'Application password created', 'ds-core' );
		case 'app-password.delete':
			return __( 'Application password deleted', 'ds-core' );
		case 'user.create':
			/* translators: %s: role name. */
			return sprintf( __( 'User created with the role %s', 'ds-core' ), ds_core_ra_ruolo( $dati['ruolo'] ?? '' ) );
		case 'user.delete':
			return __( 'User deleted', 'ds-core' );
		case 'user.role':
			/* translators: 1: previous role, 2: new role. */
			return sprintf( __( 'Role changed from %1$s to %2$s', 'ds-core' ), ds_core_ra_ruolo( $dati['da'] ?? '' ), ds_core_ra_ruolo( $dati['a'] ?? '' ) );
		case 'user.email':
			/* translators: %s: email domain. */
			return sprintf( __( 'Administrator email changed (new domain: %s)', 'ds-core' ), (string) ( $dati['dominio'] ?? '' ) );
		case 'user.password':
			return empty( $dati['reset'] ) ? __( 'Administrator password changed', 'ds-core' ) : __( 'Administrator password reset from the email link', 'ds-core' );
		case 'plugin.install':
			return $esito ? __( 'Plugin installation failed', 'ds-core' ) : __( 'Plugin installed', 'ds-core' );
		case 'plugin.activate':
			return __( 'Plugin activated', 'ds-core' );
		case 'plugin.deactivate':
			return __( 'Plugin deactivated', 'ds-core' );
		case 'plugin.delete':
			return __( 'Plugin deleted', 'ds-core' );
		case 'theme.install':
			return $esito ? __( 'Theme installation failed', 'ds-core' ) : __( 'Theme installed', 'ds-core' );
		case 'theme.switch':
			/* translators: 1: previous theme, 2: new theme. */
			return sprintf( __( 'Theme changed from %1$s to %2$s', 'ds-core' ), '' !== (string) ( $dati['da'] ?? '' ) ? $dati['da'] : '—', (string) ( $dati['a'] ?? '' ) );
		case 'theme.delete':
			return __( 'Theme deleted', 'ds-core' );
		case 'plugin.update':
		case 'theme.update':
		case 'core.update':
			if ( $esito ) {
				return __( 'Update failed', 'ds-core' );
			}
			/* translators: %s: version number. */
			return '' !== (string) ( $dati['versione'] ?? '' ) ? sprintf( __( 'Updated to %s', 'ds-core' ), $dati['versione'] ) : __( 'Updated', 'ds-core' );
		case 'update.external':
			/* translators: 1: version number, 2: how long it waited (e.g. "2 days"). */
			return sprintf( __( 'Updated to %1$s outside WordPress (hosting), after %2$s', 'ds-core' ), (string) ( $dati['versione'] ?? '' ), human_time_diff( 0, max( 60, (int) ( $dati['ritardo'] ?? 0 ) ) ) );
		case 'option.change':
			if ( 'admin_email' === $riga->oggetto ) {
				/* translators: %s: email domain. */
				return sprintf( __( 'Site administration email changed (new domain: %s)', 'ds-core' ), (string) ( $dati['dominio'] ?? '' ) );
			}
			/* translators: 1: previous value, 2: new value. */
			return sprintf( __( 'Setting changed from “%1$s” to “%2$s”', 'ds-core' ), (string) ( $dati['da'] ?? '' ), (string) ( $dati['a'] ?? '' ) );
		case 'mcp.ability':
			return (int) ( $dati['stato'] ?? 200 ) >= 400 ? __( 'Ability run refused or failed', 'ds-core' ) : __( 'Ability run', 'ds-core' );
		case 'mcp.calls':
			$n = (int) ( $dati['n'] ?? 0 );
			/* translators: %d: number of MCP calls. */
			return sprintf( _n( '%d MCP call in this hour', '%d MCP calls in this hour', $n, 'ds-core' ), $n );
		case 'dscore.module':
			/* translators: 1: previous state (on, off, in test), 2: new state. */
			return sprintf( __( 'Module switched from %1$s to %2$s', 'ds-core' ), ds_core_ra_stato_nome( $dati['da'] ?? '' ), ds_core_ra_stato_nome( $dati['a'] ?? '' ) );
		case 'dscore.settings':
			if ( isset( $dati['giorni_a'] ) ) {
				return sprintf(
					/* translators: 1: previous number of days, 2: new number of days, 3: weekly summary before (on/off), 4: weekly summary now (on/off). */
					__( 'Activity log settings changed: kept for %1$d days, now %2$d; weekly summary %3$s, now %4$s', 'ds-core' ),
					(int) ( $dati['giorni_da'] ?? 90 ),
					(int) $dati['giorni_a'],
					ds_core_ra_stato_nome( empty( $dati['riepilogo_da'] ) ? 'spento' : 'attivo' ),
					ds_core_ra_stato_nome( empty( $dati['riepilogo_a'] ) ? 'spento' : 'attivo' )
				);
			}
			return __( 'Settings saved', 'ds-core' );
		case 'dscore.access':
			return ds_core_ra_accesso_testo( $dati['a'] ?? '' );
		case 'dscore.htaccess':
			$azioni = array(
				'scritto'        => __( 'Block written to .htaccess', 'ds-core' ),
				'tolto'          => __( 'Block removed from .htaccess', 'ds-core' ),
				'ripristinato'   => __( '.htaccess put back as it was: the site did not answer after the change', 'ds-core' ),
				'non-scrivibile' => __( '.htaccess is not writable', 'ds-core' ),
				'rinominato'     => __( 'Block in .htaccess renamed after the module ID (same rules)', 'ds-core' ),
			);
			return $azioni[ $dati['azione'] ?? '' ] ?? '.htaccess';
		case 'dscore.alerts':
			$azioni = array(
				/* translators: 1: masked current address, 2: masked new address. */
				'richiesta'       => __( 'Notification address change requested, from %1$s to %2$s', 'ds-core' ),
				/* translators: 1: masked previous address, 2: masked new address. */
				'conferma'        => __( 'Notification address changed from %1$s to %2$s, confirmed from the email link', 'ds-core' ),
				/* translators: 1: masked current address, 2: masked requested address. */
				'annullata'       => __( 'Notification address change to %2$s cancelled', 'ds-core' ),
				/* translators: 1: masked current address, 2: masked requested address. */
				'scaduta'         => __( 'Notification address change to %2$s expired without confirmation', 'ds-core' ),
				'link-non-valido' => __( 'Confirmation link for the notification address used but not valid or expired', 'ds-core' ),
			);
			$azione = (string) ( $dati['azione'] ?? '' );
			return isset( $azioni[ $azione ] ) ? sprintf( $azioni[ $azione ], (string) ( $dati['da'] ?? '' ), (string) ( $dati['a'] ?? '' ) ) : __( 'Notification address', 'ds-core' );
		case 'dscore.emergency':
			if ( '' === (string) ( $dati['a'] ?? '' ) ) {
				return __( 'Emergency switch removed from wp-config.php', 'ds-core' );
			}
			/* translators: %s: value of the emergency switch (module names or "all"). */
			return sprintf( __( 'Emergency switch in wp-config.php set to “%s”', 'ds-core' ), (string) $dati['a'] );
		case 'dscore.update':
			// Aggiornatore firmato (0.16.0, includes/aggiornatore.php).
			$versione = (string) ( $dati['versione'] ?? '' );
			switch ( (string) ( $dati['azione'] ?? '' ) ) {
				case 'disponibile':
					/* translators: 1: version number, 2: update channel. */
					return sprintf( __( 'DS Core %1$s available on the %2$s channel', 'ds-core' ), $versione, ds_core_rilasci_canale_nome( (string) ( $dati['canale'] ?? '' ) ) );
				case 'verificato':
					/* translators: %s: version number. */
					return sprintf( __( 'DS Core %s package signature verified: installation allowed', 'ds-core' ), $versione );
				case 'rifiutato':
					/* translators: 1: version number, 2: reason. */
					return sprintf( __( 'DS Core %1$s update refused: %2$s', 'ds-core' ), '' !== $versione ? $versione : '?', ds_core_rilasci_motivo_testo( (string) ( $dati['motivo'] ?? '' ) ) );
				case 'errore':
					/* translators: %s: reason. */
					return sprintf( __( 'DS Core update check failed: %s', 'ds-core' ), ds_core_rilasci_motivo_testo( (string) ( $dati['motivo'] ?? '' ) ) );
				case 'canale':
					/* translators: 1: previous update channel, 2: new update channel. */
					return sprintf( __( 'DS Core update channel changed from %1$s to %2$s', 'ds-core' ), ds_core_rilasci_canale_nome( (string) ( $dati['da'] ?? '' ) ), ds_core_rilasci_canale_nome( (string) ( $dati['a'] ?? '' ) ) );
				case 'indirizzo':
					/* translators: 1: previous address, 2: new address ("—" when empty). */
					return sprintf( __( 'DS Core release address changed from %1$s to %2$s', 'ds-core' ), '' !== (string) ( $dati['da'] ?? '' ) ? $dati['da'] : '—', '' !== (string) ( $dati['a'] ?? '' ) ? $dati['a'] : '—' );
			}
			return __( 'DS Core updates', 'ds-core' );
		case 'dscore.check':
			// Controlli dei moduli (0.17.0): xmlrpc-closed, account-checks, comments-closed.
			switch ( (string) ( $dati['azione'] ?? '' ) ) {
				case 'xmlrpc-aperto':
					return __( 'xmlrpc.php still answers with the list of methods', 'ds-core' );
				case 'nuovo-admin':
					/* translators: %s: username. */
					return sprintf( __( 'New administrator account noticed: %s', 'ds-core' ), (string) ( $dati['utente'] ?? '' ) );
				case 'admin-confermato':
					/* translators: %s: username. */
					return sprintf( __( 'New administrator account confirmed: %s', 'ds-core' ), (string) ( $dati['utente'] ?? '' ) );
				case 'commenti-approvati':
					$quanti = (int) ( $dati['nuovi'] ?? 0 ) + (int) ( $dati['vecchi'] ?? 0 );
					/* translators: %d: number of comments. */
					return sprintf( _n( '%d approved comment appeared while comments are closed', '%d approved comments appeared while comments are closed', $quanti, 'ds-core' ), $quanti );
				case 'commenti-verificati':
					return __( 'Approved comments marked as checked', 'ds-core' );
				case 'commento-approvato-bacheca':
					// 0.18.0: moderazione dalla Bacheca di chi può moderare (da notare, non allarme).
					return __( 'Comment approved from the dashboard while comments are closed', 'ds-core' );
				case 'commento-risposta-bacheca':
					return __( 'Reply posted from the dashboard while comments are closed', 'ds-core' );
			}
			return __( 'Module check', 'ds-core' );
		case 'dscore.error':
			/* translators: %s: error message. */
			return empty( $dati['risolto'] ) ? sprintf( __( 'Module not loaded because of an error: %s', 'ds-core' ), (string) ( $dati['messaggio'] ?? '' ) ) : __( 'Module loads again without errors', 'ds-core' );
	}
	return (string) $riga->tipo;
}

/** Oggetto di un evento in testo semplice: nome del plugin, del modulo, login, ability, strumenti MCP. */
function ds_core_ra_oggetto( $riga ) {
	static $moduli = null;
	$dati = ds_core_ra_dati( $riga );
	$tipo = (string) $riga->tipo;
	if ( 'dscore.update' === $tipo ) {
		return 'DS Core';
	}
	if ( 0 === strpos( $tipo, 'dscore.' ) ) {
		if ( null === $moduli ) {
			$moduli = did_action( 'init' ) ? ds_core_registro_con_testi() : array();
		}
		if ( 'ds-core' === $riga->oggetto ) {
			return __( 'General settings', 'ds-core' );
		}
		// Righe scritte con un vecchio ID (prima della 0.17.0) e non migrate: il nome del modulo di adesso.
		$id = ds_core_id_attuale( (string) $riga->oggetto );
		return isset( $moduli[ $id ] ) ? $moduli[ $id ]['titolo'] : (string) $riga->oggetto;
	}
	if ( 'mcp.calls' === $tipo ) {
		$strumenti = isset( $dati['strumenti'] ) && is_array( $dati['strumenti'] ) ? $dati['strumenti'] : array();
		arsort( $strumenti );
		$voci = array();
		foreach ( $strumenti as $nome => $quanti ) {
			$voci[] = $nome . ' (' . (int) $quanti . ')';
		}
		return implode( ', ', $voci );
	}
	if ( 'app-password.create' === $tipo || 'app-password.delete' === $tipo ) {
		return '' !== (string) ( $dati['nome'] ?? '' ) ? $riga->oggetto . ' – ' . $dati['nome'] : (string) $riga->oggetto;
	}
	if ( '' !== (string) ( $dati['nome'] ?? '' ) ) {
		return (string) $dati['nome'];
	}
	if ( 'update.external' === $tipo || 'core.update' === $tipo ) {
		return 'wordpress' === $riga->oggetto || 'WordPress' === $riga->oggetto ? 'WordPress' : (string) $riga->oggetto;
	}
	return (string) $riga->oggetto;
}

/** Chi ha agito, in testo semplice. */
function ds_core_ra_chi( $riga ) {
	$utente = (string) $riga->utente;
	if ( 'automatico' === $utente ) {
		return __( 'automatic', 'ds-core' );
	}
	return '' === $utente ? '—' : $utente;
}

/* ---------- Lettura ---------- */

/** Capacità per leggere il registro: manage_options, il filtro può solo restringere (si chiedono entrambe). */
function ds_core_ra_puo_leggere() {
	$capacita = apply_filters( 'ds_core_registro_capacita', 'manage_options' );
	$capacita = is_string( $capacita ) && '' !== $capacita ? $capacita : 'manage_options';
	return current_user_can( 'manage_options' ) && current_user_can( $capacita );
}

/** Filtri della pagina dalla richiesta, puliti. */
function ds_core_ra_filtri() {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- filtri di sola lettura (GET), nessuna azione.
	$periodo = isset( $_GET['ds_periodo'] ) ? sanitize_key( wp_unslash( $_GET['ds_periodo'] ) ) : '30';
	$gruppo  = isset( $_GET['ds_gruppo'] ) ? sanitize_key( wp_unslash( $_GET['ds_gruppo'] ) ) : '';
	$livello = isset( $_GET['ds_livello'] ) ? (int) $_GET['ds_livello'] : 0;
	$via     = isset( $_GET['ds_via'] ) ? sanitize_key( wp_unslash( $_GET['ds_via'] ) ) : '';
	$cerca   = isset( $_GET['ds_cerca'] ) ? ds_core_eventi_taglia( sanitize_text_field( wp_unslash( $_GET['ds_cerca'] ) ), 100 ) : '';
	$pagina  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
	// phpcs:enable
	return array(
		'periodo' => in_array( $periodo, array( 'oggi', '7', '30', 'tutto' ), true ) ? $periodo : '30',
		'gruppo'  => isset( ds_core_ra_gruppi()[ $gruppo ] ) ? $gruppo : '',
		'livello' => in_array( $livello, array( 2, 3 ), true ) ? $livello : 0,
		'via'     => isset( ds_core_ra_vie()[ $via ] ) ? $via : '',
		'cerca'   => $cerca,
		'pagina'  => $pagina,
	);
}

/** Inizio del periodo scelto (timestamp), 0 = tutto. «Oggi» parte dalla mezzanotte del fuso del sito. */
function ds_core_ra_inizio( $periodo ) {
	if ( 'oggi' === $periodo ) {
		return ( new DateTimeImmutable( 'today', wp_timezone() ) )->getTimestamp();
	}
	return 'tutto' === $periodo ? 0 : time() - (int) $periodo * DAY_IN_SECONDS;
}

/**
 * Righe del registro con i filtri: array( 'righe' => oggetti, 'totale' => numero ). Query preparate; solo indici su
 * quando e (tipo, quando); la ricerca libera guarda oggetto, utente e IP.
 */
function ds_core_ra_cerca( $filtri, $per_pagina = 50 ) {
	global $wpdb;
	if ( ! ds_core_eventi_pronta() ) {
		return array( 'righe' => array(), 'totale' => 0 );
	}
	$tabella = ds_core_eventi_tabella();
	$dove    = array( '1=1' );
	$valori  = array();
	$inizio  = ds_core_ra_inizio( $filtri['periodo'] );
	if ( $inizio ) {
		$dove[]   = 'quando >= %d';
		$valori[] = $inizio;
	}
	if ( $filtri['livello'] ) {
		$dove[]   = 'livello >= %d';
		$valori[] = $filtri['livello'];
	}
	if ( '' !== $filtri['gruppo'] ) {
		$tipi     = ds_core_ra_gruppi()[ $filtri['gruppo'] ];
		$dove[]   = 'tipo IN (' . implode( ',', array_fill( 0, count( $tipi ), '%s' ) ) . ')';
		$valori   = array_merge( $valori, $tipi );
	}
	if ( '' !== $filtri['via'] ) {
		$dove[]   = 'via = %s';
		$valori[] = $filtri['via'];
	}
	if ( '' !== $filtri['cerca'] ) {
		$simile   = '%' . $wpdb->esc_like( $filtri['cerca'] ) . '%';
		$dove[]   = '(oggetto LIKE %s OR utente LIKE %s OR ip LIKE %s OR dati LIKE %s)';
		$valori   = array_merge( $valori, array( $simile, $simile, $simile, $simile ) );
	}
	$condizione = implode( ' AND ', $dove );
	$scarto     = ( max( 1, (int) $filtri['pagina'] ) - 1 ) * $per_pagina;
	// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- tabella propria; condizioni con segnaposto, valori passati a prepare().
	$conta  = "SELECT COUNT(*) FROM {$tabella} WHERE {$condizione}";
	$elenco = "SELECT * FROM {$tabella} WHERE {$condizione} ORDER BY quando DESC, id DESC LIMIT %d OFFSET %d";
	$totale = (int) $wpdb->get_var( $valori ? $wpdb->prepare( $conta, $valori ) : $conta );
	$righe  = $wpdb->get_results( $wpdb->prepare( $elenco, array_merge( $valori, array( $per_pagina, $scarto ) ) ) );
	// phpcs:enable
	return array( 'righe' => is_array( $righe ) ? $righe : array(), 'totale' => $totale );
}

/** Conteggi degli ultimi $giorni giorni: array( gruppo => array( 'tutti' => n, 'da_vedere' => n ) ). */
function ds_core_ra_conteggi( $giorni ) {
	global $wpdb;
	$conteggi = array();
	if ( ! ds_core_eventi_pronta() ) {
		return $conteggi;
	}
	$tabella = ds_core_eventi_tabella();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabella propria.
	$righe = $wpdb->get_results( $wpdb->prepare( "SELECT tipo, livello, COUNT(*) AS n FROM {$tabella} WHERE quando >= %d GROUP BY tipo, livello", time() - (int) $giorni * DAY_IN_SECONDS ) );
	foreach ( (array) $righe as $riga ) {
		$gruppo = ds_core_ra_gruppo_di( (string) $riga->tipo );
		$gruppo = '' === $gruppo ? 'dscore' : $gruppo;
		if ( ! isset( $conteggi[ $gruppo ] ) ) {
			$conteggi[ $gruppo ] = array( 'tutti' => 0, 'da_vedere' => 0 );
		}
		$conteggi[ $gruppo ]['tutti'] += (int) $riga->n;
		if ( (int) $riga->livello >= 2 ) {
			$conteggi[ $gruppo ]['da_vedere'] += (int) $riga->n;
		}
	}
	return $conteggi;
}

/* ---------- Riepilogo settimanale ---------- */

/**
 * Mail del lunedì (o del giorno scelto da WordPress), solo se attivata e solo se nella settimana ci sono eventi da
 * vedere o allarmi: numeri per gruppo ed elenco degli allarmi. All'indirizzo unico degli avvisi, nella lingua del sito.
 */
add_action( 'ds_core_ra_riepilogo', 'ds_core_ra_manda_riepilogo' );
function ds_core_ra_manda_riepilogo() {
	global $wpdb;
	if ( ! ds_core_ra_impostazioni()['riepilogo'] || ! ds_core_eventi_pronta() ) {
		return false;
	}
	$conteggi  = ds_core_ra_conteggi( 7 );
	$da_vedere = array_sum( wp_list_pluck( $conteggi, 'da_vedere' ) );
	if ( ! $da_vedere ) {
		return false;
	}
	$tabella = ds_core_eventi_tabella();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabella propria.
	$allarmi = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$tabella} WHERE quando >= %d AND livello = 3 ORDER BY quando DESC, id DESC LIMIT 30", time() - 7 * DAY_IN_SECONDS ) );

	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$nomi     = ds_core_ra_gruppi_nomi();
	$vie      = ds_core_ra_vie();
	/* translators: %s: site address. */
	$righe = array( sprintf( __( 'Activity log of %s, last 7 days:', 'ds-core' ), home_url( '/' ) ), '' );
	foreach ( $nomi as $gruppo => $nome ) {
		if ( empty( $conteggi[ $gruppo ] ) ) {
			continue;
		}
		/* translators: 1: group name, 2: number of events, 3: number of events to review. */
		$righe[] = sprintf( __( '- %1$s: %2$d events, %3$d to review', 'ds-core' ), $nome, $conteggi[ $gruppo ]['tutti'], $conteggi[ $gruppo ]['da_vedere'] );
	}
	if ( $allarmi ) {
		$righe[] = '';
		$righe[] = __( 'Alarms:', 'ds-core' );
		foreach ( $allarmi as $riga ) {
			$oggetto = ds_core_ra_oggetto( $riga );
			$righe[] = sprintf(
				/* translators: 1: date and time, 2: event description, 3: what it concerns, 4: who, 5: how (browser, MCP…). */
				__( '- %1$s: %2$s (%3$s), by %4$s via %5$s', 'ds-core' ),
				wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $riga->quando ),
				ds_core_ra_descrivi( $riga ),
				'' !== $oggetto ? $oggetto : '—',
				ds_core_ra_chi( $riga ),
				$vie[ $riga->via ] ?? $riga->via
			);
		}
	}
	$righe[] = '';
	$righe[] = admin_url( 'admin.php?page=' . DS_CORE_RA_PAGINA );
	/* translators: 1: site title, 2: number of events to review. */
	$oggetto = sprintf( _n( '[%1$s] Activity log: %2$d event to review this week', '[%1$s] Activity log: %2$d events to review this week', $da_vedere, 'ds-core' ), $sito, $da_vedere );
	$mandata = ds_core_manda_avviso( 'registro.riepilogo', $oggetto, implode( "\n", $righe ) );
	if ( $cambiata ) {
		restore_previous_locale();
	}
	return $mandata;
}

/* ---------- Informativa privacy ---------- */

// Testo proposto in Impostazioni › Privacy (strumento standard di WordPress), senza nomi.
add_action( 'admin_init', 'ds_core_ra_privacy' );
function ds_core_ra_privacy() {
	if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
		return;
	}
	$testo = sprintf(
		/* translators: %d: number of days the records are kept. */
		__( 'For security, this site records the sign-ins and the changes made by the people who manage it (username, IP address, date and time). Visitors are not recorded. The records are kept for %d days and then deleted automatically.', 'ds-core' ),
		ds_core_ra_impostazioni()['giorni']
	);
	wp_add_privacy_policy_content( 'DS Core', wpautop( esc_html( $testo ) ) );
}

/* ---------- Pannello: riga del modulo ---------- */

/** Problemi per l'avviso in cima al pannello. */
function ds_core_ra_problemi() {
	if ( ds_core_eventi_pronta() ) {
		return array();
	}
	return array( __( 'The activity log table could not be created in the database, so nothing is being recorded. DS Core tries again every hour.', 'ds-core' ) );
}

/** Stato nella riga del modulo: numeri della settimana, conservazione, ultimi eventi, link alla pagina. */
function ds_core_ra_riquadro() {
	global $wpdb;
	if ( ! ds_core_ra_puo_leggere() || ! ds_core_eventi_pronta() ) {
		return;
	}
	$conteggi = ds_core_ra_conteggi( 7 );
	$tutti    = array_sum( wp_list_pluck( $conteggi, 'tutti' ) );
	$vedere   = array_sum( wp_list_pluck( $conteggi, 'da_vedere' ) );
	$tabella  = ds_core_eventi_tabella();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabella propria.
	$righe  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tabella}" );
	$ultimi = ds_core_ra_cerca( array( 'periodo' => 'tutto', 'gruppo' => '', 'livello' => 0, 'via' => '', 'cerca' => '', 'pagina' => 1 ), 5 );
	?>
	<div class="ds-ra-riquadro">
		<p>
			<?php
			printf(
				/* translators: 1: number of events, 2: number of events to review. */
				esc_html( _n( '%1$d event in the last 7 days, %2$d to review.', '%1$d events in the last 7 days, %2$d to review.', $tutti, 'ds-core' ) ),
				(int) $tutti,
				(int) $vedere
			);
			echo ' ';
			printf(
				/* translators: 1: number of days, 2: number of records. */
				esc_html__( 'Records are kept for %1$d days; %2$s in the log now.', 'ds-core' ),
				(int) ds_core_ra_impostazioni()['giorni'],
				esc_html( number_format_i18n( $righe ) )
			);
			?>
		</p>
		<?php if ( $ultimi['righe'] ) : ?>
			<table class="widefat striped ds-ra-mini">
				<thead><tr><th scope="col"><?php esc_html_e( 'When', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Event', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Who', 'ds-core' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $ultimi['righe'] as $riga ) : ?>
					<tr class="ds-ra--l<?php echo (int) $riga->livello; ?>">
						<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $riga->quando ) ); ?></td>
						<td><?php echo esc_html( ds_core_ra_descrivi( $riga ) ); ?></td>
						<td><?php echo esc_html( ds_core_ra_chi( $riga ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . DS_CORE_RA_PAGINA ) ); ?>"><?php esc_html_e( 'Open the activity log', 'ds-core' ); ?></a></p>
	</div>
	<?php
}

/* ---------- Pagina «Activity log» ---------- */

add_action( 'admin_menu', 'ds_core_ra_menu', 20 );
function ds_core_ra_menu() {
	if ( ! defined( 'DS_CORE_PAGINA' ) ) {
		return;
	}
	add_submenu_page( DS_CORE_PAGINA, __( 'Activity log – DS Core', 'ds-core' ), __( 'Activity log', 'ds-core' ), 'manage_options', DS_CORE_RA_PAGINA, 'ds_core_ra_pagina' );
}

// Foglio di stile, aspetto chiaro/scuro e piè di pagina del pannello anche su questa pagina.
add_filter( 'ds_core_schermate', 'ds_core_ra_schermata' );
function ds_core_ra_schermata( $schermate ) {
	$schermate[] = 'ds-core_page_' . DS_CORE_RA_PAGINA;
	return $schermate;
}

/** Link alla pagina con i filtri dati (gli altri tolti). */
function ds_core_ra_link( $argomenti = array() ) {
	return add_query_arg( array_merge( array( 'page' => DS_CORE_RA_PAGINA ), $argomenti ), admin_url( 'admin.php' ) );
}

/** Nome del giorno per l'intestazione: «Today», «Yesterday» o la data nel formato del sito. */
function ds_core_ra_nome_giorno( $giorno ) {
	$fuso = wp_timezone();
	$oggi = ( new DateTimeImmutable( 'now', $fuso ) )->format( 'Y-m-d' );
	$ieri = ( new DateTimeImmutable( 'yesterday', $fuso ) )->format( 'Y-m-d' );
	if ( $giorno === $oggi ) {
		return __( 'Today', 'ds-core' );
	}
	if ( $giorno === $ieri ) {
		return __( 'Yesterday', 'ds-core' );
	}
	$data    = DateTimeImmutable::createFromFormat( '!Y-m-d', $giorno, $fuso );
	$formato = (string) get_option( 'date_format' );
	// Il giorno della settimana davanti alla data, se il formato del sito non lo mostra già.
	$formato = false === strpbrk( $formato, 'lD' ) ? 'l ' . $formato : $formato;
	return $data ? wp_date( $formato, $data->getTimestamp() + 12 * HOUR_IN_SECONDS ) : $giorno;
}

function ds_core_ra_pagina() {
	if ( ! ds_core_ra_puo_leggere() ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	$filtri     = ds_core_ra_filtri();
	$per_pagina = 50;
	$risultato  = ds_core_ra_cerca( $filtri, $per_pagina );
	$pagine     = max( 1, (int) ceil( $risultato['totale'] / $per_pagina ) );
	$livelli    = ds_core_ra_livelli();
	$vie        = ds_core_ra_vie();
	$gruppi     = ds_core_ra_gruppi_nomi();
	$filtrato   = '30' !== $filtri['periodo'] || '' !== $filtri['gruppo'] || $filtri['livello'] || '' !== $filtri['via'] || '' !== $filtri['cerca'];
	$periodi    = array(
		'oggi'  => __( 'Today', 'ds-core' ),
		'7'     => __( 'Last 7 days', 'ds-core' ),
		'30'    => __( 'Last 30 days', 'ds-core' ),
		'tutto' => __( 'Everything kept', 'ds-core' ),
	);

	// Righe divise per giorno (fuso del sito), con il numero di eventi del giorno in questa pagina.
	$giorni = array();
	foreach ( $risultato['righe'] as $riga ) {
		$giorni[ wp_date( 'Y-m-d', (int) $riga->quando ) ][] = $riga;
	}
	?>
	<div class="wrap ds-core ds-ra">
		<div class="ds-testata">
			<h1><?php esc_html_e( 'Activity log', 'ds-core' ); ?> <span class="ds-versione">DS Core <?php echo esc_html( DS_CORE_VERSIONE ); ?></span></h1>
		</div>
		<hr class="wp-header-end">
		<p class="ds-intro">
			<?php
			printf(
				/* translators: %d: number of days. */
				esc_html__( 'Who changed what on this site, and how. Records are kept for %d days and then deleted automatically; nobody can edit or delete them from here.', 'ds-core' ),
				(int) ds_core_ra_impostazioni()['giorni']
			);
			?>
			<a href="<?php echo esc_url( ds_core_url_pannello( 'security', 'ds-impostazioni-activity-log' ) ); ?>"><?php esc_html_e( 'Log settings', 'ds-core' ); ?></a>
		</p>

		<?php if ( ! ds_core_eventi_pronta() ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', ds_core_ra_problemi() ) ); ?></p></div>
		<?php endif; ?>

		<form class="ds-ra-filtri" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" role="search" aria-label="<?php esc_attr_e( 'Filter the activity log', 'ds-core' ); ?>">
			<input type="hidden" name="page" value="<?php echo esc_attr( DS_CORE_RA_PAGINA ); ?>">
			<label class="ds-ra-filtro">
				<span><?php esc_html_e( 'Period', 'ds-core' ); ?></span>
				<select name="ds_periodo">
					<?php foreach ( $periodi as $valore => $nome ) : ?>
						<option value="<?php echo esc_attr( $valore ); ?>"<?php selected( $filtri['periodo'], $valore ); ?>><?php echo esc_html( $nome ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="ds-ra-filtro">
				<span><?php esc_html_e( 'Events', 'ds-core' ); ?></span>
				<select name="ds_gruppo">
					<option value=""><?php esc_html_e( 'All events', 'ds-core' ); ?></option>
					<?php foreach ( $gruppi as $valore => $nome ) : ?>
						<option value="<?php echo esc_attr( $valore ); ?>"<?php selected( $filtri['gruppo'], $valore ); ?>><?php echo esc_html( $nome ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="ds-ra-filtro">
				<span><?php esc_html_e( 'Importance', 'ds-core' ); ?></span>
				<select name="ds_livello">
					<option value="0"><?php esc_html_e( 'Everything', 'ds-core' ); ?></option>
					<option value="2"<?php selected( $filtri['livello'], 2 ); ?>><?php esc_html_e( 'To review and alarms', 'ds-core' ); ?></option>
					<option value="3"<?php selected( $filtri['livello'], 3 ); ?>><?php esc_html_e( 'Alarms only', 'ds-core' ); ?></option>
				</select>
			</label>
			<label class="ds-ra-filtro">
				<span><?php esc_html_e( 'How', 'ds-core' ); ?></span>
				<select name="ds_via">
					<option value=""><?php esc_html_e( 'Any way', 'ds-core' ); ?></option>
					<?php foreach ( $vie as $valore => $nome ) : ?>
						<option value="<?php echo esc_attr( $valore ); ?>"<?php selected( $filtri['via'], $valore ); ?>><?php echo esc_html( $nome ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="ds-ra-filtro ds-ra-filtro--cerca">
				<span><?php esc_html_e( 'Search', 'ds-core' ); ?></span>
				<input type="search" name="ds_cerca" value="<?php echo esc_attr( $filtri['cerca'] ); ?>" placeholder="<?php esc_attr_e( 'Username, plugin, ability, IP address', 'ds-core' ); ?>">
			</label>
			<span class="ds-ra-filtri-azioni">
				<button type="submit" class="button"><?php esc_html_e( 'Show', 'ds-core' ); ?></button>
				<?php if ( $filtrato ) : ?>
					<a class="ds-con-icona" href="<?php echo esc_url( ds_core_ra_link() ); ?>"><?php echo ds_core_icona( 'x' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Clear filters', 'ds-core' ); ?></a>
				<?php endif; ?>
			</span>
		</form>

		<p class="ds-ra-conta" role="status">
			<?php
			/* translators: %s: number of events. */
			echo esc_html( sprintf( _n( '%s event', '%s events', $risultato['totale'], 'ds-core' ), number_format_i18n( $risultato['totale'] ) ) );
			?>
		</p>

		<?php if ( ! $risultato['righe'] ) : ?>
			<p class="ds-vuoto"><?php echo esc_html( $filtrato ? __( 'No events match these filters. Widen the period or clear the filters.', 'ds-core' ) : __( 'Nothing recorded yet. Events appear here as soon as someone signs in or changes something.', 'ds-core' ) ); ?></p>
		<?php else : ?>
			<div class="ds-tabella-contenitore">
				<table class="widefat ds-ra-tabella">
					<thead>
						<tr>
							<th scope="col" class="ds-ra-col-ora"><?php esc_html_e( 'Time', 'ds-core' ); ?></th>
							<th scope="col" class="ds-ra-col-evento"><?php esc_html_e( 'Event', 'ds-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Concerns', 'ds-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Who', 'ds-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'How', 'ds-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'IP address', 'ds-core' ); ?></th>
						</tr>
					</thead>
					<?php foreach ( $giorni as $giorno => $righe ) : ?>
						<tbody class="ds-ra-giorno">
							<tr class="ds-ra-giorno-testata">
								<th scope="rowgroup" colspan="6">
									<span class="ds-ra-giorno-nome"><?php echo esc_html( ds_core_ra_nome_giorno( $giorno ) ); ?></span>
									<?php /* translators: %d: number of events. */ ?>
									<span class="ds-ra-giorno-conta"><?php echo esc_html( sprintf( _n( '%d event', '%d events', count( $righe ), 'ds-core' ), count( $righe ) ) ); ?></span>
								</th>
							</tr>
							<?php foreach ( $righe as $riga ) :
								$livello = max( 1, min( 3, (int) $riga->livello ) );
								$oggetto = ds_core_ra_oggetto( $riga );
								$gruppo  = ds_core_ra_gruppo_di( (string) $riga->tipo );
								?>
								<tr class="ds-ra-riga ds-ra--l<?php echo (int) $livello; ?>">
									<td class="ds-ra-col-ora"><time datetime="<?php echo esc_attr( gmdate( 'c', (int) $riga->quando ) ); ?>" title="<?php echo esc_attr( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $riga->quando ) ); ?>"><?php echo esc_html( wp_date( get_option( 'time_format' ), (int) $riga->quando ) ); ?></time></td>
									<td class="ds-ra-col-evento">
										<?php if ( $livello > 1 ) : ?>
											<span class="ds-ra-livello ds-ra-livello--<?php echo (int) $livello; ?>"><?php echo 3 === $livello ? ds_core_icona( 'attenzione' ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php echo esc_html( $livelli[ $livello ] ); ?></span>
										<?php endif; ?>
										<span class="ds-ra-descrizione"><?php echo esc_html( ds_core_ra_descrivi( $riga ) ); ?></span>
										<?php if ( '' !== $gruppo ) : ?>
											<span class="ds-ra-gruppo"><?php echo esc_html( $gruppi[ $gruppo ] ); ?></span>
										<?php endif; ?>
									</td>
									<td class="ds-ra-col-oggetto"><?php echo '' !== $oggetto ? esc_html( $oggetto ) : '—'; ?><?php echo 'option.change' === $riga->tipo ? ' <code>' . esc_html( $riga->oggetto ) . '</code>' : ''; ?></td>
									<td><?php echo esc_html( ds_core_ra_chi( $riga ) ); ?></td>
									<td><?php echo esc_html( $vie[ $riga->via ] ?? ( '' !== (string) $riga->via ? $riga->via : '—' ) ); ?></td>
									<td class="ds-ra-col-ip"><?php echo '' !== (string) $riga->ip ? esc_html( $riga->ip ) : '—'; ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					<?php endforeach; ?>
				</table>
			</div>

			<?php if ( $pagine > 1 ) : ?>
				<nav class="tablenav ds-ra-pagine" aria-label="<?php esc_attr_e( 'Pages of the activity log', 'ds-core' ); ?>">
					<div class="tablenav-pages">
						<?php
						// paginate_links() restituisce HTML già escapato da WordPress.
						echo paginate_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'current'   => min( $filtri['pagina'], $pagine ),
								'total'     => $pagine,
								'prev_text' => __( 'Newer', 'ds-core' ),
								'next_text' => __( 'Older', 'ds-core' ),
							)
						);
						?>
					</div>
				</nav>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<?php
}

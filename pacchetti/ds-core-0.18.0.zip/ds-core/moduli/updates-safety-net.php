<?php
/**
 * Modulo updates-safety-net: rete di sicurezza per gli aggiornamenti di plugin, temi e WordPress.
 *
 * Usa il sistema di aggiornamento automatico di WordPress (con il ripristino automatico in caso di errore grave,
 * WordPress 6.6+), deciso così:
 * - capisce se gli aggiornamenti li fa l'hosting (qualcosa sul sito ha spento l'aggiornatore di WordPress, kb WP-15)
 *   e in quel caso gli lascia un margine
 *   (predefinito 24 ore): DS Core aggiorna solo ciò che dopo il margine è ancora in sospeso. Senza hosting che
 *   aggiorna, plugin e temi si aggiornano al primo controllo di WordPress (due volte al giorno);
 * - WordPress: le versioni minori (sicurezza) subito; le principali dopo N giorni (predefinito 7) o mai;
 * - i plugin scelti come manuali (sui negozi: WooCommerce, pagamenti, DS Woo, plugin del sito) non si aggiornano mai
 *   da soli: compaiono nell'elenco e nel riepilogo;
 * - tiene nota di ogni aggiornamento in sospeso (da quando) e di chi l'ha fatto (DS Core, una persona, l'hosting), così
 *   si misura il ritardo dell'hosting;
 * - tutte le mail di aggiornamento (quelle di WordPress e il riepilogo giornaliero di DS Core, mandato solo se c'è
 *   qualcosa in ritardo) vanno all'indirizzo unico di DS Core (impostazioni generali del pannello, salvato nel
 *   database del sito, mai nel codice); con «anche all'amministratore» una mail separata per destinatario (1.2.3).
 *
 * DS Core stesso (1.3.0): in automatico anche sui negozi (kb ARCH-09), senza margine per l'hosting, salvo «automatici
 * spenti»; la versione nuova e la verifica della firma le porta l'aggiornatore firmato (includes/aggiornatore.php).
 *
 * Non blocca l'hosting: lavora solo dove l'hosting non è arrivato in tempo. Non scavalca DISALLOW_FILE_MODS.
 *
 * Opzioni: ds_core_agg (scelte, dichiarate nel registro dalla 1.2.0: DS Core le mostra e le salva anche a modulo
 * spento), ds_core_agg_visti (in sospeso: chiave => versione e da quando), ds_core_agg_registro (ultimi 50 eventi).
 * Evento cron: ds_core_agg_riepilogo (giornaliero). Il predefinito dei plugin manuali è in includes/opzioni.php
 * (ds_core_agg_manuali_predefiniti()), perché serve anche a modulo spento.
 */

defined( 'ABSPATH' ) || exit;

/* ---------- Impostazioni ---------- */

/**
 * Scelte del modulo (campi dichiarati nel registro, salvati da DS Core): plugin, margine, core, giorni, manuali.
 * I limiti (margine 0-720 ore, giorni 0-90) li applica già DS Core; qui restano come rete se il registro cambiasse.
 */
function ds_core_agg_impostazioni() {
	$valori = array_merge(
		array(
			'plugin'  => 'auto',
			'margine' => 24,
			'core'    => 'principali',
			'giorni'  => 7,
			'manuali' => array(),
		),
		ds_core_opzioni_modulo( 'updates-safety-net' )
	);
	$valori['margine'] = max( 0, min( 720, (int) $valori['margine'] ) );
	$valori['giorni']  = max( 0, min( 90, (int) $valori['giorni'] ) );
	$valori['manuali'] = is_array( $valori['manuali'] ) ? $valori['manuali'] : array();
	return $valori;
}

/** Indirizzo a cui mandare tutte le mail di aggiornamento: quello unico di DS Core. */
function ds_core_agg_indirizzo() {
	return ds_core_indirizzo_avvisi();
}

/**
 * C'è un sistema di aggiornamento dell'hosting? Si riconosce senza nomi (il codice è pubblico e non dice quale
 * hosting usano i siti): l'hosting che aggiorna spegne l'aggiornatore automatico di WordPress, quindi si guarda se il
 * filtro 'automatic_updater_disabled' è vero senza il nostro. Filtro 'ds_core_agg_hosting' per correggere a mano.
 */
function ds_core_agg_hosting() {
	static $hosting = null;
	if ( null === $hosting ) {
		$base = defined( 'AUTOMATIC_UPDATER_DISABLED' ) ? (bool) AUTOMATIC_UPDATER_DISABLED : false;
		remove_filter( 'automatic_updater_disabled', 'ds_core_agg_aggiornatore', 9999 );
		$hosting = (bool) apply_filters( 'automatic_updater_disabled', $base );
		add_filter( 'automatic_updater_disabled', 'ds_core_agg_aggiornatore', 9999 );
	}
	return (bool) apply_filters( 'ds_core_agg_hosting', $hosting );
}

/* ---------- Registro degli aggiornamenti in sospeso ---------- */

function ds_core_agg_visti() {
	$visti = get_option( 'ds_core_agg_visti', array() );
	return is_array( $visti ) ? $visti : array();
}

/** Aggiunge una riga al registro degli aggiornamenti (ultimi 50, più recenti in cima). */
function ds_core_agg_annota( $voce ) {
	$registro = get_option( 'ds_core_agg_registro', array() );
	$registro = is_array( $registro ) ? $registro : array();
	$voce = array_merge( array( 'quando' => time() ), $voce );
	array_unshift( $registro, $voce );
	update_option( 'ds_core_agg_registro', array_slice( $registro, 0, 50 ), false );
	// Registro delle attività (0.14.0): gli aggiornamenti fatti fuori da WordPress (hosting). Quelli passati
	// dall'upgrader di WordPress li annota il modulo activity-log stesso.
	if ( 'esterno' === ( $voce['chi'] ?? '' ) && function_exists( 'ds_core_ra_evento_aggiornamento' ) ) {
		$evento = ds_core_ra_evento_aggiornamento( $voce );
		unset( $evento['dati']['importato'] );
		$tipo = $evento['tipo'];
		unset( $evento['tipo'] );
		ds_core_registra_evento( $tipo, $evento );
	}
}

/**
 * Aggiorna l'elenco degli aggiornamenti in sospeso ogni volta che WordPress salva i risultati di un controllo.
 * Un aggiornamento che sparisce dall'elenco senza essere passato da WordPress (upgrader) è stato fatto da fuori:
 * di solito l'hosting. Si annota con il ritardo.
 */
add_action( 'set_site_transient_update_plugins', 'ds_core_agg_controlla_plugin' );
function ds_core_agg_controlla_plugin( $valore ) {
	ds_core_agg_allinea( 'plugin', isset( $valore->response ) && is_array( $valore->response ) ? $valore->response : array() );
}

add_action( 'set_site_transient_update_themes', 'ds_core_agg_controlla_temi' );
function ds_core_agg_controlla_temi( $valore ) {
	ds_core_agg_allinea( 'tema', isset( $valore->response ) && is_array( $valore->response ) ? $valore->response : array() );
}

add_action( 'set_site_transient_update_core', 'ds_core_agg_controlla_core' );
function ds_core_agg_controlla_core( $valore ) {
	$in_sospeso = array();
	if ( isset( $valore->updates ) && is_array( $valore->updates ) ) {
		foreach ( $valore->updates as $offerta ) {
			if ( isset( $offerta->response, $offerta->current ) && 'upgrade' === $offerta->response ) {
				$in_sospeso['wordpress'] = array( 'new_version' => $offerta->current );
				break;
			}
		}
	}
	ds_core_agg_allinea( 'core', $in_sospeso );
}

/** $risposta: chiave (file del plugin, cartella del tema, 'wordpress') => dati dell'aggiornamento. */
function ds_core_agg_allinea( $tipo, $risposta ) {
	$visti = ds_core_agg_visti();
	$prima = $visti;
	$ora   = time();
	$nuovi = array();
	foreach ( $risposta as $chiave => $dati ) {
		$dati    = (array) $dati;
		$k       = $tipo . ':' . $chiave;
		$versione = (string) ( $dati['new_version'] ?? '' );
		$nuovi[ $k ] = array(
			'versione' => $versione,
			'da'       => isset( $visti[ $k ]['da'] ) ? (int) $visti[ $k ]['da'] : $ora,
		);
	}
	foreach ( $visti as $k => $dati ) {
		if ( 0 !== strpos( $k, $tipo . ':' ) || isset( $nuovi[ $k ] ) ) {
			continue;
		}
		// Sparito dall'elenco senza passare dall'upgrader di WordPress (altrimenti l'ha già tolto ds_core_agg_fatto).
		ds_core_agg_annota(
			array(
				'chiave'   => $k,
				'versione' => $dati['versione'] ?? '',
				'chi'      => 'esterno',
				'ritardo'  => $ora - (int) ( $dati['da'] ?? $ora ),
				'esito'    => 'ok',
			)
		);
		unset( $visti[ $k ] );
	}
	foreach ( $visti as $k => $dati ) {
		if ( 0 === strpos( $k, $tipo . ':' ) ) {
			unset( $visti[ $k ] );
		}
	}
	$visti = array_merge( $visti, $nuovi );
	if ( $visti !== $prima ) {
		update_option( 'ds_core_agg_visti', $visti, false );
	}
}

/** Ore da cui un aggiornamento è in sospeso (0 se non è nell'elenco). */
function ds_core_agg_ore_in_sospeso( $chiave ) {
	$visti = ds_core_agg_visti();
	return isset( $visti[ $chiave ]['da'] ) ? ( time() - (int) $visti[ $chiave ]['da'] ) / HOUR_IN_SECONDS : 0;
}

/* ---------- Decisioni per l'aggiornamento automatico di WordPress ---------- */

// Riaccende l'aggiornatore automatico di WordPress se l'hosting l'ha spento: le regole sotto decidono cosa aggiorna.
// Priorità alta per avere l'ultima parola sul filtro dell'hosting. DISALLOW_FILE_MODS resta rispettato.
add_filter( 'automatic_updater_disabled', 'ds_core_agg_aggiornatore', 9999 );
function ds_core_agg_aggiornatore( $spento ) {
	if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
		return $spento;
	}
	return false;
}

/** Un plugin o tema in sospeso è maturo per DS Core? (margine per l'hosting, plugin manuali, scelta «no»). */
function ds_core_agg_maturo( $chiave, $file_plugin = '' ) {
	$valori = ds_core_agg_impostazioni();
	if ( 'auto' !== $valori['plugin'] ) {
		return false;
	}
	if ( $file_plugin && in_array( $file_plugin, $valori['manuali'], true ) ) {
		return false;
	}
	if ( ds_core_agg_hosting() && ds_core_agg_ore_in_sospeso( $chiave ) < $valori['margine'] ) {
		return false;
	}
	return true;
}

add_filter( 'auto_update_plugin', 'ds_core_agg_plugin', 9999, 2 );
function ds_core_agg_plugin( $aggiorna, $elemento ) {
	$file = isset( $elemento->plugin ) ? (string) $elemento->plugin : '';
	if ( '' === $file ) {
		return $aggiorna;
	}
	if ( plugin_basename( DS_CORE_FILE ) === $file ) {
		/*
		 * DS Core (1.3.0, DS Core 0.16.0): in automatico su tutti i siti, negozi compresi (kb ARCH-09), senza margine
		 * per l'hosting (arriva solo dal suo aggiornatore firmato, che verifica il pacchetto). Restano le scelte
		 * esplicite del sito: aggiornamenti automatici spenti, oppure DS Core fra i plugin manuali.
		 */
		$valori = ds_core_agg_impostazioni();
		return 'auto' === $valori['plugin'] && ! in_array( $file, $valori['manuali'], true );
	}
	return ds_core_agg_maturo( 'plugin:' . $file, $file );
}

add_filter( 'auto_update_theme', 'ds_core_agg_tema', 9999, 2 );
function ds_core_agg_tema( $aggiorna, $elemento ) {
	$tema = isset( $elemento->theme ) ? (string) $elemento->theme : '';
	return '' === $tema ? $aggiorna : ds_core_agg_maturo( 'tema:' . $tema );
}

// WordPress: le minori (sicurezza) sempre, salvo «no»; le principali solo con «principali» e dopo N giorni.
add_filter( 'allow_minor_auto_core_updates', 'ds_core_agg_core_minori', 9999 );
function ds_core_agg_core_minori( $permesso ) {
	return 'no' !== ds_core_agg_impostazioni()['core'];
}

add_filter( 'allow_major_auto_core_updates', 'ds_core_agg_core_principali', 9999 );
function ds_core_agg_core_principali( $permesso ) {
	$valori = ds_core_agg_impostazioni();
	if ( 'principali' !== $valori['core'] ) {
		return false;
	}
	return ds_core_agg_ore_in_sospeso( 'core:wordpress' ) >= $valori['giorni'] * 24;
}

add_filter( 'allow_dev_auto_core_updates', '__return_false', 9999 );

/* ---------- Chi ha aggiornato ---------- */

// Ogni aggiornamento che passa dall'upgrader di WordPress: automatico (DS Core), da una persona o da WP-CLI.
add_action( 'upgrader_process_complete', 'ds_core_agg_fatto', 10, 2 );
function ds_core_agg_fatto( $upgrader, $extra ) {
	if ( empty( $extra['action'] ) || 'update' !== $extra['action'] || empty( $extra['type'] ) ) {
		return;
	}
	$chiavi = array();
	if ( 'plugin' === $extra['type'] ) {
		foreach ( (array) ( $extra['plugins'] ?? ( isset( $extra['plugin'] ) ? array( $extra['plugin'] ) : array() ) ) as $file ) {
			$chiavi[] = 'plugin:' . $file;
		}
	} elseif ( 'theme' === $extra['type'] ) {
		foreach ( (array) ( $extra['themes'] ?? ( isset( $extra['theme'] ) ? array( $extra['theme'] ) : array() ) ) as $tema ) {
			$chiavi[] = 'tema:' . $tema;
		}
	} elseif ( 'core' === $extra['type'] ) {
		$chiavi[] = 'core:wordpress';
	}
	if ( ! $chiavi ) {
		return;
	}
	if ( doing_action( 'wp_maybe_auto_update' ) ) {
		$chi = 'automatico';
	} elseif ( defined( 'WP_CLI' ) && WP_CLI ) {
		$chi = 'wp-cli';
	} else {
		$utente = wp_get_current_user();
		$chi    = $utente->exists() ? $utente->user_login : 'esterno';
	}
	$errore = isset( $upgrader->skin->result ) && is_wp_error( $upgrader->skin->result );
	$visti  = ds_core_agg_visti();
	foreach ( $chiavi as $k ) {
		ds_core_agg_annota(
			array(
				'chiave'   => $k,
				'versione' => $visti[ $k ]['versione'] ?? '',
				'chi'      => $chi,
				'ritardo'  => isset( $visti[ $k ]['da'] ) ? time() - (int) $visti[ $k ]['da'] : 0,
				'esito'    => $errore ? 'errore' : 'ok',
			)
		);
		if ( ! $errore ) {
			unset( $visti[ $k ] );
		}
	}
	update_option( 'ds_core_agg_visti', $visti, false );
}

/* ---------- Mail ---------- */

/*
 * Tutte le mail di aggiornamento di WordPress all'indirizzo degli avvisi di DS Core. Con «anche all'amministratore»
 * (0.15.0) i destinatari sono due: dalla 1.2.3 (DS Core 0.15.1, decisione di Daniele del 27/11/2026) partono mail
 * separate, una per destinatario, come gli avvisi di DS Core, così nessuno vede l'altro indirizzo.
 *
 * Come: a WordPress resta un solo destinatario (il primo, l'indirizzo degli avvisi) e le copie per gli altri partono
 * qui, con wp_mail() e lo stesso oggetto (decodificato come fa WordPress), testo e intestazioni. WordPress manda la sua
 * mail subito dopo questi filtri (WP_Automatic_Updater), quindi ogni destinatario riceve una mail sola.
 * Non in 'pre_wp_mail': lì gli argomenti hanno già passato il filtro 'wp_mail', e rimandarli con wp_mail() li farebbe
 * passare due volte (firme o piè di pagina aggiunti da altri plugin comparirebbero doppi); in più un plugin SMTP che
 * sostituisce wp_mail() può non chiamare 'pre_wp_mail'. Una stessa mail filtrata due volte nella stessa richiesta non
 * manda copie doppie.
 */
add_filter( 'auto_core_update_email', 'ds_core_agg_destinatario', 9999 );
add_filter( 'auto_plugin_theme_update_email', 'ds_core_agg_destinatario', 9999 );
add_filter( 'automatic_updates_debug_email', 'ds_core_agg_destinatario', 9999 );
function ds_core_agg_destinatario( $mail ) {
	static $copie = array();
	if ( ! is_array( $mail ) ) {
		return $mail;
	}
	$destinatari = ds_core_avvisi_destinatari( 'aggiornamenti.wordpress' );
	if ( ! $destinatari ) {
		return $mail; // Nessun indirizzo valido: resta il destinatario di WordPress.
	}
	$mail['to'] = array_shift( $destinatari );
	if ( ! $destinatari ) {
		return $mail;
	}
	$oggetto      = wp_specialchars_decode( (string) ( $mail['subject'] ?? '' ) );
	$testo        = (string) ( $mail['body'] ?? '' );
	$intestazioni = $mail['headers'] ?? '';
	foreach ( $destinatari as $altro ) {
		$chiave = md5( strtolower( $altro ) . "\n" . $oggetto . "\n" . $testo );
		if ( isset( $copie[ $chiave ] ) ) {
			continue;
		}
		$copie[ $chiave ] = true;
		wp_mail( $altro, $oggetto, $testo, $intestazioni );
	}
	return $mail;
}

// Riepilogo giornaliero di DS Core, solo se qualcosa è in ritardo.
add_action( 'init', 'ds_core_agg_pianifica' );
function ds_core_agg_pianifica() {
	if ( ! wp_next_scheduled( 'ds_core_agg_riepilogo' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ds_core_agg_riepilogo' );
	}
}

/** Elementi in ritardo: manuali oltre il margine, automatici oltre il margine più un giorno (DS Core non è riuscito). */
function ds_core_agg_in_ritardo() {
	$valori  = ds_core_agg_impostazioni();
	$ritardo = array();
	foreach ( ds_core_agg_visti() as $k => $dati ) {
		$ore     = ( time() - (int) $dati['da'] ) / HOUR_IN_SECONDS;
		$file    = 0 === strpos( $k, 'plugin:' ) ? substr( $k, 7 ) : '';
		$manuale = $file && in_array( $file, $valori['manuali'], true );
		if ( 'core:wordpress' === $k ) {
			$soglia = 'principali' === $valori['core'] ? $valori['giorni'] * 24 + 24 : PHP_INT_MAX;
		} else {
			$soglia = $manuale || 'auto' !== $valori['plugin'] ? $valori['margine'] : $valori['margine'] + 24;
		}
		if ( $ore >= $soglia ) {
			$ritardo[ $k ] = array( 'versione' => $dati['versione'], 'ore' => (int) $ore, 'manuale' => $manuale );
		}
	}
	return $ritardo;
}

add_action( 'ds_core_agg_riepilogo', 'ds_core_agg_manda_riepilogo' );
function ds_core_agg_manda_riepilogo() {
	$ritardo = ds_core_agg_in_ritardo();
	if ( ! $ritardo ) {
		return;
	}
	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$righe    = array(
		/* translators: %s: site address. */
		sprintf( __( 'These updates on %s are still pending:', 'ds-core' ), home_url( '/' ) ),
		'',
	);
	foreach ( $ritardo as $k => $dati ) {
		$righe[] = sprintf(
			/* translators: 1: plugin, theme or WordPress name, 2: new version, 3: number of hours, 4: "(manual)" note or empty. */
			__( '- %1$s %2$s: pending for %3$d hours%4$s', 'ds-core' ),
			ds_core_agg_nome( $k ),
			$dati['versione'],
			$dati['ore'],
			$dati['manuale'] ? ' ' . __( '(set to manual: update it yourself)', 'ds-core' ) : ''
		);
	}
	$righe[] = '';
	$righe[] = admin_url( 'admin.php?page=ds-core' );
	/* translators: 1: site title, 2: number of pending updates. */
	$oggetto = sprintf( _n( '[%1$s] %2$d update is overdue', '[%1$s] %2$d updates are overdue', count( $ritardo ), 'ds-core' ), $sito, count( $ritardo ) );
	ds_core_manda_avviso( 'aggiornamenti.riepilogo', $oggetto, implode( "\n", $righe ) );
	if ( $cambiata ) {
		restore_previous_locale();
	}
}

/** Nome leggibile di una chiave 'plugin:<file>', 'tema:<cartella>', 'core:wordpress'. */
function ds_core_agg_nome( $chiave ) {
	if ( 'core:wordpress' === $chiave ) {
		return 'WordPress';
	}
	if ( 0 === strpos( $chiave, 'plugin:' ) ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$file    = substr( $chiave, 7 );
		$plugins = get_plugins();
		return $plugins[ $file ]['Name'] ?? $file;
	}
	$tema = wp_get_theme( substr( $chiave, 5 ) );
	return $tema->exists() ? $tema->get( 'Name' ) : substr( $chiave, 5 );
}

/* ---------- Pannello ---------- */

/** Ore come testo breve («5 h», «2 giorni»). */
function ds_core_agg_durata( $secondi ) {
	return human_time_diff( time() - max( 60, (int) $secondi ), time() );
}

/**
 * Problemi da mostrare nell'avviso in cima al pannello (campo 'problemi' del registro): aggiornamenti in ritardo e
 * DISALLOW_FILE_MODS, che impedisce a WordPress di aggiornare.
 */
function ds_core_agg_problemi() {
	$problemi = array();
	if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
		$problemi[] = __( 'WordPress cannot update anything by itself: DISALLOW_FILE_MODS is set in wp-config.php.', 'ds-core' );
	}
	$ritardo = count( ds_core_agg_in_ritardo() );
	if ( $ritardo ) {
		/* translators: %d: number of overdue updates. */
		$problemi[] = sprintf( _n( '%d update is overdue.', '%d updates are overdue.', $ritardo, 'ds-core' ), $ritardo );
	}
	return $problemi;
}

/**
 * Stato del modulo, dentro la riga del modulo nel pannello (campo 'stato' del registro): chi aggiorna, aggiornamenti
 * in sospeso, ultimi aggiornamenti. Le scelte sotto le disegna e le salva DS Core (campi del registro).
 */
function ds_core_agg_riquadro() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$valori   = ds_core_agg_impostazioni();
	$hosting  = ds_core_agg_hosting();
	$visti    = ds_core_agg_visti();
	$ritardo  = ds_core_agg_in_ritardo();
	$registro = get_option( 'ds_core_agg_registro', array() );
	$registro = is_array( $registro ) ? array_slice( $registro, 0, 10 ) : array();
	$chi_nomi = array(
		'automatico' => __( 'DS Core (automatic)', 'ds-core' ),
		'esterno'    => __( 'outside WordPress (hosting)', 'ds-core' ),
		'wp-cli'     => __( 'WP-CLI (hosting or command line)', 'ds-core' ),
	);
	?>
	<div class="ds-aggiornamenti">
		<?php // DISALLOW_FILE_MODS e ritardi: li mostra il pannello, sopra queste impostazioni (ds_core_agg_problemi()). ?>
		<p class="ds-accesso-stato">
			<?php
			if ( $hosting ) {
				printf(
					/* translators: %d: number of hours. */
					esc_html__( 'Updates on this site are handled by the hosting. DS Core steps in for whatever is still pending after %d hours.', 'ds-core' ),
					(int) $valori['margine']
				);
			} else {
				esc_html_e( 'No hosting update system found: DS Core updates plugins and themes at the next WordPress check (twice a day).', 'ds-core' );
			}
			?>
		</p>

		<?php if ( $visti ) : ?>
			<table class="widefat striped ds-agg-tabella">
				<thead><tr><th scope="col"><?php esc_html_e( 'Pending update', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'New version', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Pending for', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'What happens', 'ds-core' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $visti as $k => $dati ) :
					$file    = 0 === strpos( $k, 'plugin:' ) ? substr( $k, 7 ) : '';
					$manuale = $file && in_array( $file, $valori['manuali'], true );
					if ( 'core:wordpress' === $k ) {
						$cosa = __( 'Minor versions right away; major versions as set below.', 'ds-core' );
					} elseif ( $manuale ) {
						$cosa = __( 'Manual: update it yourself.', 'ds-core' );
					} elseif ( 'auto' !== $valori['plugin'] ) {
						$cosa = __( 'Automatic updates are off.', 'ds-core' );
					} elseif ( $hosting && ds_core_agg_ore_in_sospeso( $k ) < $valori['margine'] ) {
						$cosa = __( 'Waiting for the hosting, then DS Core.', 'ds-core' );
					} else {
						$cosa = __( 'DS Core at the next WordPress check.', 'ds-core' );
					}
					?>
					<tr<?php echo isset( $ritardo[ $k ] ) ? ' class="ds-agg-ritardo"' : ''; ?>>
						<td><?php echo esc_html( ds_core_agg_nome( $k ) ); ?></td>
						<td><?php echo esc_html( $dati['versione'] ); ?></td>
						<td><?php echo esc_html( ds_core_agg_durata( time() - (int) $dati['da'] ) ); ?></td>
						<td><?php echo esc_html( $cosa ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p><?php esc_html_e( 'Everything is up to date.', 'ds-core' ); ?></p>
		<?php endif; ?>

		<?php if ( $registro ) : ?>
			<details class="ds-agg-registro">
				<summary><?php esc_html_e( 'Latest updates and who made them', 'ds-core' ); ?></summary>
				<table class="widefat striped ds-agg-tabella">
					<thead><tr><th scope="col"><?php esc_html_e( 'When', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'What', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Who', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Delay', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Result', 'ds-core' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $registro as $voce ) : ?>
						<tr>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $voce['quando'] ) ); ?></td>
							<td><?php echo esc_html( ds_core_agg_nome( (string) $voce['chiave'] ) . ( ! empty( $voce['versione'] ) ? ' ' . $voce['versione'] : '' ) ); ?></td>
							<td><?php echo esc_html( $chi_nomi[ $voce['chi'] ] ?? $voce['chi'] ); ?></td>
							<td><?php echo esc_html( ! empty( $voce['ritardo'] ) ? ds_core_agg_durata( $voce['ritardo'] ) : '—' ); ?></td>
							<td><?php echo 'ok' === $voce['esito'] ? esc_html__( 'done', 'ds-core' ) : esc_html__( 'error', 'ds-core' ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</details>
		<?php endif; ?>
	</div>
	<?php
}

<?php
/**
 * Modulo claude-code-access.
 *
 * Gli ingressi usati da Claude Code restano chiusi finché un amministratore non li apre a tempo dal pannello di
 * DS Core (1, 4 o 8 ore). Alla scadenza si richiudono da soli: l'ora si controlla a ogni richiesta, senza cron.
 * Non esiste «aperto per sempre». I plugin (Agent Connector, Universal Abilities, Breakdance) restano attivi e
 * aggiornabili: si chiudono solo gli ingressi.
 *
 * Da chiuso:
 * - le password per le applicazioni non funzionano (wp_is_application_passwords_available → false): non entrano
 *   né nell'API REST né in XML-RPC. Le password salvate non si cancellano e tornano valide all'apertura;
 * - l'API REST risponde 403 a /mcp/*, /acfw-auth/v1/*, /agent-connector-for-wp/v1/* e
 *   /wp-abilities/v1/abilities/agent-connector-for-wp/*, anche agli amministratori collegati dal browser: un
 *   account rubato non diventa esecuzione di codice. Stessa risposta per tutti i casi, senza dire perché.
 *
 * Restano sempre raggiungibili: il login dal browser (cookie, non usa le password per le applicazioni), il
 * pannello di DS Core (admin-post e admin-ajax, non REST), il builder di Breakdance e tutte le altre rotte REST.
 *
 * Fallisce chiuso: opzione mancante, illeggibile, scaduta o con una scadenza oltre la durata massima = chiuso.
 *
 * Ogni apertura e chiusura va nella storia del pannello (ds_core_storia) come codice ('accesso:aperto:<fino>:<ore>:
 * <origine>', 'accesso:chiuso[:<origine>]', 'accesso:scaduto', 'accesso:non-valido'), tradotto dal pannello quando
 * lo mostra; ogni apertura manda una mail all'indirizzo unico degli avvisi di DS Core (dalla 1.2.0; vuoto =
 * amministratore del sito), nella lingua del sito. Dalla 1.4.0 (DS Core 0.15.1, decisione di Daniele del 27/11/2026)
 * anche la chiusura prima della scadenza («Chiudi ora», in futuro la firma) e la chiusura per una scadenza non valida
 * mandano l'avviso di sicurezza, con chi, quando e IP; la chiusura alla scadenza naturale no.
 *
 * Dalla 1.5.0 (DS Core 0.17.0) la scelta «solo amministratori» (accesa di base) limita le password per le
 * applicazioni a chi ha manage_options, anche a finestra aperta; vedi in fondo al file.
 *
 * Emergenza: define( 'DS_CORE_SPENTI', 'claude-code-access' ); in wp-config.php spegne il modulo, quindi apre tutto.
 *
 * Opzioni: ds_core_accesso_fino (timestamp di chiusura; assente = chiuso). Riservata alla fase 2:
 * ds_core_accesso_nonce (numeri unici delle aperture firmate dal PC, rotta /ds-core/v1/accesso). La rotta della
 * fase 2 non rientra fra quelle chiuse qui sotto e dovrà aprire con ds_core_accesso_apri( $ore, 'firma' ).
 */

defined( 'ABSPATH' ) || exit;

const DS_CORE_ACCESSO_OPZIONE = 'ds_core_accesso_fino';

/** Durate ammesse, in ore. Niente filtro: l'elenco non si allarga dall'esterno. */
function ds_core_accesso_durate() {
	return array( 1, 4, 8 );
}

/** Durata massima in secondi: una scadenza più lontana di così non è valida. */
function ds_core_accesso_massimo() {
	return max( ds_core_accesso_durate() ) * HOUR_IN_SECONDS;
}

/**
 * Scadenza dell'apertura in corso (timestamp) oppure 0 = chiuso.
 * Una scadenza passata o non valida viene tolta e la chiusura scritta nella storia, una volta sola.
 */
function ds_core_accesso_fino() {
	$valore = get_option( DS_CORE_ACCESSO_OPZIONE, '' );
	if ( empty( $valore ) ) {
		return 0;
	}
	if ( is_int( $valore ) ) {
		$valore = (string) $valore;
	}
	if ( ! is_string( $valore ) || ! ctype_digit( $valore ) ) {
		ds_core_accesso_scaduto( 0 );
		return 0;
	}
	$fino = (int) $valore;
	$ora  = time();
	if ( $fino <= $ora ) {
		ds_core_accesso_scaduto( $fino );
		return 0;
	}
	if ( $fino > $ora + ds_core_accesso_massimo() + MINUTE_IN_SECONDS ) {
		ds_core_accesso_scaduto( 0 );
		return 0;
	}
	return $fino;
}

function ds_core_accesso_aperto() {
	return ds_core_accesso_fino() > 0;
}

/**
 * Chiusura automatica (scadenza raggiunta, $fino > 0) o per valore non valido ($fino = 0).
 * Può girare durante l'autenticazione: niente funzioni dell'utente corrente, utente 'automatico'.
 */
function ds_core_accesso_scaduto( $fino ) {
	static $fatto = false;
	if ( $fatto ) {
		return;
	}
	$fatto = true;
	// Solo la richiesta che cancella davvero l'opzione scrive la storia (niente righe doppie fra richieste parallele).
	if ( delete_option( DS_CORE_ACCESSO_OPZIONE ) ) {
		if ( $fino ) {
			// Scadenza naturale: solo la storia e il registro, nessuna mail (Daniele, 27/11/2026).
			ds_core_storia_aggiungi( 'claude-code-access', ds_core_accesso_descrivi( $fino ), 'accesso:scaduto', 'automatico', $fino );
		} else {
			// Scadenza illeggibile o troppo lontana: l'opzione è stata scritta senza passare dal pannello.
			ds_core_storia_aggiungi( 'claude-code-access', 'accesso:non-valido', 'accesso:chiuso', 'automatico' );
			ds_core_accesso_avviso_chiusura( 0, 'non-valido' );
		}
	}
}

/** Codice per la storia: 'accesso:aperto:<fino>' o 'accesso:chiuso'. */
function ds_core_accesso_descrivi( $fino ) {
	return $fino ? 'accesso:aperto:' . (int) $fino : 'accesso:chiuso';
}

/**
 * Apre per $ore ore da adesso (sostituisce un'apertura in corso: si può allungare o accorciare).
 * $origine: 'pannello' (fase 1) o, in futuro, 'firma'. Restituisce true se la mail è partita, false se no,
 * WP_Error se la durata non è ammessa.
 */
function ds_core_accesso_apri( $ore, $origine ) {
	$ore = (int) $ore;
	if ( ! in_array( $ore, ds_core_accesso_durate(), true ) ) {
		return new WP_Error( 'ds_core_accesso_durata', __( 'Duration not allowed.', 'ds-core' ) );
	}
	$prima = ds_core_accesso_fino();
	$fino  = time() + $ore * HOUR_IN_SECONDS;
	update_option( DS_CORE_ACCESSO_OPZIONE, (string) $fino, true );
	ds_core_storia_aggiungi( 'claude-code-access', ds_core_accesso_descrivi( $prima ), 'accesso:aperto:' . $fino . ':' . $ore . ':' . sanitize_key( $origine ) );
	do_action( 'ds_core_accesso_aperto', $fino, $origine );
	return ds_core_accesso_mail( $fino, $ore, $origine );
}

/**
 * Chiude subito. $origine: 'pannello' o, in futuro, 'firma'. Se l'accesso era aperto è una chiusura prima della
 * scadenza: storia, registro delle attività e avviso di sicurezza (dalla 1.4.0). Restituisce true se la mail è
 * partita, false se no, null se l'accesso era già chiuso (niente da avvisare).
 */
function ds_core_accesso_chiudi( $origine ) {
	$prima = ds_core_accesso_fino();
	delete_option( DS_CORE_ACCESSO_OPZIONE );
	if ( ! $prima ) {
		return null;
	}
	ds_core_storia_aggiungi( 'claude-code-access', ds_core_accesso_descrivi( $prima ), 'accesso:chiuso:' . sanitize_key( $origine ) );
	do_action( 'ds_core_accesso_chiuso', $origine );
	return ds_core_accesso_avviso_chiusura( $prima, $origine );
}

/**
 * Avviso di sicurezza per una chiusura prima della scadenza ($fino = scadenza che aveva, $origine 'pannello' o
 * 'firma') o per una scadenza non valida ($fino = 0, $origine 'non-valido'). Va all'indirizzo degli avvisi e sempre
 * anche all'email dell'amministratore del sito (tipo 'accesso.chiusura', includes/avvisi.php), nella lingua del sito.
 * La chiusura per scadenza non valida può avvenire durante l'autenticazione, prima di 'init': allora la mail parte
 * su 'init' (traduzioni pronte). Restituisce true se è partita, false se no, null se rimandata.
 */
function ds_core_accesso_avviso_chiusura( $fino, $origine ) {
	$utente = did_action( 'set_current_user' ) ? wp_get_current_user() : null;
	$dati   = array(
		'fino'    => (int) $fino,
		'origine' => sanitize_key( $origine ),
		'quando'  => time(),
		'chi'     => $utente && $utente->exists() ? $utente->user_login : '',
		'ip'      => 'non-valido' === $origine ? '' : ds_core_eventi_ip(),
	);
	if ( ! did_action( 'init' ) ) {
		add_action(
			'init',
			function () use ( $dati ) {
				ds_core_accesso_mail_chiusura( $dati );
			},
			99,
			0
		);
		return null;
	}
	return ds_core_accesso_mail_chiusura( $dati );
}

/** Testo e invio dell'avviso di chiusura (dati preparati da ds_core_accesso_avviso_chiusura()). */
function ds_core_accesso_mail_chiusura( $dati ) {
	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$formato  = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
	if ( 'non-valido' === $dati['origine'] ) {
		/* translators: %s: site title. */
		$oggetto = sprintf( __( '[%s] Claude Code access closed: invalid expiry', 'ds-core' ), $sito );
		$righe   = array(
			/* translators: %s: site address. */
			sprintf( __( 'Claude Code access on %s has been closed because its stored expiry was not valid.', 'ds-core' ), home_url( '/' ) ),
			'',
			/* translators: %s: date and time. */
			sprintf( __( 'When: %s', 'ds-core' ), wp_date( $formato, $dati['quando'] ) ),
			'',
			__( 'Only the DS Core panel writes the expiry. If nobody changed the database by hand, someone with access to it may have tried to keep access open: check the administrator accounts and the hosting account.', 'ds-core' ),
		);
	} else {
		/* translators: %s: site title. */
		$oggetto = sprintf( __( '[%s] Claude Code access closed before time', 'ds-core' ), $sito );
		$righe   = array(
			/* translators: %s: site address. */
			sprintf( __( 'Claude Code access on %s has been closed before its expiry.', 'ds-core' ), home_url( '/' ) ),
			'',
			/* translators: 1: username, 2: where it was closed from (panel). */
			sprintf( __( 'Closed by: %1$s (%2$s)', 'ds-core' ), '' !== $dati['chi'] ? $dati['chi'] : __( 'unknown', 'ds-core' ), $dati['origine'] ),
			/* translators: %s: date and time. */
			sprintf( __( 'When: %s', 'ds-core' ), wp_date( $formato, $dati['quando'] ) ),
			/* translators: %s: IP address. */
			sprintf( __( 'IP address: %s', 'ds-core' ), '' !== $dati['ip'] ? $dati['ip'] : __( 'unknown', 'ds-core' ) ),
			/* translators: %s: date and time when access would have closed by itself. */
			sprintf( __( 'It was open until: %s', 'ds-core' ), wp_date( $formato, $dati['fino'] ) ),
			'',
			__( 'If you did not close it, someone else with an administrator account did: check the administrator accounts.', 'ds-core' ),
		);
	}
	$righe[] = admin_url( 'admin.php?page=ds-core' );
	$inviata = ds_core_manda_avviso( 'accesso.chiusura', $oggetto, implode( "\n", $righe ) );
	if ( $cambiata ) {
		restore_previous_locale();
	}
	return $inviata;
}

/**
 * Mail di apertura all'indirizzo unico degli avvisi di DS Core (impostazioni generali; vuoto = amministratore del
 * sito, dalla 1.2.0), nella lingua del sito (non di chi apre). Dalla 1.3.0 (DS Core 0.15.0) è un avviso di
 * sicurezza: va sempre anche all'email dell'amministratore del sito.
 */
function ds_core_accesso_mail( $fino, $ore, $origine ) {
	$cambiata = switch_to_locale( get_locale() );

	$sito    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$utente  = wp_get_current_user();
	$chi     = $utente->exists() ? $utente->user_login : $origine;
	$ip      = isset( $_SERVER['REMOTE_ADDR'] ) ? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP ) : false;
	$quando  = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $fino );
	/* translators: 1: site title, 2: time when access closes. */
	$oggetto = sprintf( __( '[%1$s] Claude Code access open until %2$s', 'ds-core' ), $sito, wp_date( get_option( 'time_format' ), $fino ) );
	$testo   = implode(
		"\n",
		array(
			/* translators: %s: site address. */
			sprintf( __( 'Claude Code access has been opened on %s.', 'ds-core' ), home_url( '/' ) ),
			'',
			/* translators: 1: username, 2: where it was opened from (panel). */
			sprintf( __( 'Opened by: %1$s (%2$s)', 'ds-core' ), $chi, $origine ),
			/* translators: %s: IP address. */
			sprintf( __( 'IP address: %s', 'ds-core' ), $ip ? $ip : __( 'unknown', 'ds-core' ) ),
			/* translators: 1: number of hours, 2: date and time when access closes. */
			sprintf( __( 'Duration: %1$d h, until %2$s. Then it closes by itself.', 'ds-core' ), $ore, $quando ),
			'',
			__( 'If you did not open it: go to the panel and press “Close now”, then change the password of the account above.', 'ds-core' ),
			admin_url( 'admin.php?page=ds-core' ),
		)
	);
	// Avviso di sicurezza (0.15.0): va anche all'email dell'amministratore del sito (includes/avvisi.php).
	$inviata = ds_core_manda_avviso( 'accesso.apertura', $oggetto, $testo );

	if ( $cambiata ) {
		restore_previous_locale();
	}
	return $inviata;
}

/* ---------- Chiusura ---------- */

// Controllo della scadenza a ogni richiesta (un'opzione caricata in memoria, nessuna query in più): la chiusura
// automatica finisce nella storia alla prima richiesta dopo la scadenza, con l'ora della scadenza.
add_action( 'init', 'ds_core_accesso_fino', 1, 0 );

// Priorità alta: ha l'ultima parola anche se un altro plugin riaccende le password per le applicazioni.
add_filter( 'wp_is_application_passwords_available', 'ds_core_accesso_password_app', 9999 );
function ds_core_accesso_password_app( $disponibili ) {
	return ds_core_accesso_aperto() ? $disponibili : false;
}

/**
 * Rotte chiuse. WordPress confronta le rotte senza distinguere maiuscole e minuscole: qui si normalizza allo
 * stesso modo (minuscole, barre doppie, codifica %).
 */
function ds_core_accesso_rotta_chiusa( $rotta ) {
	$rotta = strtolower( rawurldecode( (string) $rotta ) );
	$rotta = '/' . ltrim( (string) preg_replace( '#/+#', '/', $rotta ), '/' );
	return (bool) preg_match( '#^/(?:mcp|acfw-auth/v1|agent-connector-for-wp/v1|wp-abilities/v1/abilities/agent-connector-for-wp)(?:/|$)#', $rotta );
}

// Priorità alta: vale anche se un filtro precedente ha già preparato una risposta. Vale anche per le richieste
// interne (rest_do_request) e per quelle dentro /batch/v1, che passano dallo stesso filtro.
add_filter( 'rest_pre_dispatch', 'ds_core_accesso_rest', 9999, 3 );
function ds_core_accesso_rest( $risultato, $server, $richiesta ) {
	if ( ! ( $richiesta instanceof WP_REST_Request ) || ! ds_core_accesso_rotta_chiusa( $richiesta->get_route() ) ) {
		return $risultato;
	}
	if ( ds_core_accesso_aperto() ) {
		return $risultato;
	}
	// La stessa risposta standard di WordPress per ogni caso chiuso.
	return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to do that.' ), array( 'status' => 403 ) );
}

/* ---------- Pannello ---------- */

add_action( 'admin_post_ds_core_accesso', 'ds_core_accesso_pulsante' );
function ds_core_accesso_pulsante() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_accesso' );

	$scelta = isset( $_POST['ds_accesso'] ) ? sanitize_key( wp_unslash( $_POST['ds_accesso'] ) ) : '';
	if ( 'chiudi' === $scelta ) {
		$mail  = ds_core_accesso_chiudi( 'pannello' );
		$esito = false === $mail ? 'chiuso-senza-mail' : 'chiuso';
	} elseif ( ctype_digit( $scelta ) && in_array( (int) $scelta, ds_core_accesso_durate(), true ) ) {
		$mail  = ds_core_accesso_apri( (int) $scelta, 'pannello' );
		$esito = true === $mail ? 'aperto' : 'aperto-senza-mail';
	} else {
		$esito = 'errore';
	}
	wp_safe_redirect( add_query_arg( array( 'ds_accesso' => $esito ), ds_core_url_pannello( ds_core_scheda_dal_referer() ) ) );
	exit;
}

add_action( 'ds_core_pannello_riquadri', 'ds_core_accesso_riquadro' );
/**
 * Barra «Claude Code access» in cima al pannello, visibile da tutte le schede (0.18.0: su una riga): stato, pulsanti
 * 1/4/8 h e, ad accesso aperto, «Close now» in rosso. Le spiegazioni stanno nella riga del modulo (ds_core_accesso_stato).
 */
function ds_core_accesso_riquadro() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$fino = ds_core_accesso_fino();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo il messaggio dopo il reindirizzamento.
	$esito    = isset( $_GET['ds_accesso'] ) ? sanitize_key( wp_unslash( $_GET['ds_accesso'] ) ) : '';
	$messaggi = array(
		'aperto'            => array( 'success', __( 'Access opened. The notification email has been sent.', 'ds-core' ) ),
		'aperto-senza-mail' => array( 'warning', __( 'Access opened, but the notification email was not sent: check that the site can send email.', 'ds-core' ) ),
		'chiuso'            => array( 'success', __( 'Access closed.', 'ds-core' ) ),
		'chiuso-senza-mail' => array( 'warning', __( 'Access closed, but the notification email was not sent: check that the site can send email.', 'ds-core' ) ),
		'errore'            => array( 'error', __( 'Invalid choice: nothing has changed.', 'ds-core' ) ),
	);
	// Icone del pannello (includes/pannello.php): lucchetto aperto e chiuso.
	$icona = function ( $nome ) {
		return function_exists( 'ds_core_icona' ) ? ds_core_icona( $nome ) : '';
	};
	?>
	<?php if ( isset( $messaggi[ $esito ] ) ) : ?>
		<div class="notice notice-<?php echo esc_attr( $messaggi[ $esito ][0] ); ?> is-dismissible"><p><?php echo esc_html( $messaggi[ $esito ][1] ); ?></p></div>
	<?php endif; ?>
	<form class="ds-accesso ds-accesso--<?php echo $fino ? 'aperto' : 'chiuso'; ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" aria-label="<?php esc_attr_e( 'Claude Code access', 'ds-core' ); ?>">
		<input type="hidden" name="action" value="ds_core_accesso">
		<?php wp_nonce_field( 'ds_core_accesso' ); ?>
		<p class="ds-accesso-stato">
			<?php echo $icona( $fino ? 'aperto' : 'chiuso' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?>
			<strong><?php esc_html_e( 'Claude Code access:', 'ds-core' ); ?></strong>
			<?php
			if ( $fino ) {
				printf(
					/* translators: 1: date and time when access closes, 2: time left (e.g. "2 hours"). */
					esc_html__( 'open until %1$s (%2$s left)', 'ds-core' ),
					esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $fino ) ),
					esc_html( human_time_diff( time(), $fino ) )
				);
			} else {
				echo esc_html_x( 'closed', 'Claude Code access', 'ds-core' );
			}
			?>
		</p>
		<span class="ds-accesso-azioni">
			<?php foreach ( ds_core_accesso_durate() as $n => $ore ) : ?>
				<?php /* translators: %d: number of hours. */ ?>
				<button type="submit" name="ds_accesso" value="<?php echo (int) $ore; ?>" class="button button-small" aria-label="<?php echo esc_attr( sprintf( __( 'Open for %d h', 'ds-core' ), $ore ) ); ?>"><?php echo esc_html( 0 === $n ? sprintf( __( 'Open for %d h', 'ds-core' ), $ore ) : sprintf( _x( '%d h', 'hours, short', 'ds-core' ), $ore ) ); ?></button>
			<?php endforeach; ?>
			<?php if ( $fino ) : ?>
				<button type="submit" name="ds_accesso" value="chiudi" class="button button-small ds-con-icona ds-pulsante-stop"><?php echo $icona( 'chiuso' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Close now', 'ds-core' ); ?></button>
			<?php endif; ?>
		</span>
	</form>
	<?php
}

/** Stato a parole per la riga di riepilogo del pannello (0.18.0). */
function ds_core_accesso_riepilogo() {
	$fino = ds_core_accesso_fino();
	if ( ! $fino ) {
		return _x( 'Closed', 'Claude Code access', 'ds-core' );
	}
	/* translators: %s: time when access closes. */
	return sprintf( __( 'Open until %s', 'ds-core' ), wp_date( get_option( 'time_format' ), $fino ) );
}

// Promemoria nella barra di amministrazione finché l'accesso è aperto.
add_action( 'admin_bar_menu', 'ds_core_accesso_barra', 100 );
function ds_core_accesso_barra( $barra ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$fino = ds_core_accesso_fino();
	if ( ! $fino ) {
		return;
	}
	$barra->add_node(
		array(
			'id'    => 'ds-core-accesso',
			/* translators: %s: time when access closes. */
			'title' => esc_html( sprintf( __( 'Code open until %s', 'ds-core' ), wp_date( get_option( 'time_format' ), $fino ) ) ),
			'href'  => admin_url( 'admin.php?page=ds-core' ),
		)
	);
}

/* ---------- Password per le applicazioni solo agli amministratori (dalla 1.5.0, DS Core 0.17.0) ---------- */

/*
 * Scelta 'app_solo_admin' (accesa di base): solo chi ha manage_options può creare e usare password per le
 * applicazioni. Così un account di cliente, autore o redattore con una password per le applicazioni non diventa un
 * ingresso nemmeno a finestra aperta. Le password già salvate non si cancellano: il pannello elenca chi ne ha ancora
 * una (solo nome utente e numero, mai le password) perché si tolgano dal profilo.
 */

/** La scelta «solo amministratori» è accesa. */
function ds_core_accesso_app_solo_admin() {
	$valori = ds_core_opzioni_modulo( 'claude-code-access' );
	return ! isset( $valori['app_solo_admin'] ) || ! empty( $valori['app_solo_admin'] );
}

// Priorità alta: ha l'ultima parola sugli altri plugin. Vale per la creazione (profilo) e per l'accesso.
add_filter( 'wp_is_application_passwords_available_for_user', 'ds_core_accesso_app_per_utente', 9999, 2 );
function ds_core_accesso_app_per_utente( $disponibili, $utente ) {
	if ( ! $disponibili || ! ds_core_accesso_app_solo_admin() ) {
		return $disponibili;
	}
	return $utente instanceof WP_User && user_can( $utente, 'manage_options' );
}

/**
 * Utenti non amministratori che hanno password per le applicazioni salvate: array di
 * array( 'id', 'login', 'ruoli', 'quante' ). Al più 50.
 */
function ds_core_accesso_app_non_admin() {
	if ( ! class_exists( 'WP_Application_Passwords' ) ) {
		return array();
	}
	$utenti = get_users(
		array(
			'meta_key'     => WP_Application_Passwords::USERMETA_KEY_APPLICATION_PASSWORDS, // phpcs:ignore WordPress.DB.SlowDBQuery -- solo nel pannello.
			'meta_compare' => 'EXISTS',
			'number'       => 200,
			'orderby'      => 'login',
		)
	);
	$fuori = array();
	foreach ( $utenti as $utente ) {
		if ( user_can( $utente, 'manage_options' ) ) {
			continue;
		}
		$quante = count( WP_Application_Passwords::get_user_application_passwords( $utente->ID ) );
		if ( $quante ) {
			$fuori[] = array(
				'id'     => (int) $utente->ID,
				'login'  => $utente->user_login,
				'ruoli'  => (array) $utente->roles,
				'quante' => $quante,
			);
		}
		if ( count( $fuori ) >= 50 ) {
			break;
		}
	}
	return $fuori;
}

/** Problemi per l'avviso in cima al pannello. */
function ds_core_accesso_problemi() {
	$utenti = ds_core_accesso_app_non_admin();
	if ( ! $utenti ) {
		return array();
	}
	$nomi = implode( ', ', wp_list_pluck( $utenti, 'login' ) );
	if ( ds_core_accesso_app_solo_admin() ) {
		/* translators: %s: list of usernames. */
		return array( sprintf( __( 'Accounts that are not administrators still have application passwords (blocked, to delete from the profile): %s.', 'ds-core' ), $nomi ) );
	}
	/* translators: %s: list of usernames. */
	return array( sprintf( __( 'Accounts that are not administrators have application passwords they can use while access is open: %s.', 'ds-core' ), $nomi ) );
}

/** Stato nella riga del modulo: chi non è amministratore e ha ancora password per le applicazioni. */
function ds_core_accesso_stato() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$utenti = ds_core_accesso_app_non_admin();
	$nomi   = function_exists( 'wp_roles' ) ? wp_roles()->get_names() : array();
	?>
	<p class="ds-grigio">
		<?php
		printf(
			/* translators: %s: email address, or a list of addresses. */
			esc_html__( 'Open it from the “Claude Code access” bar at the top of this page. Opening while access is already open starts again from now with the new duration. Every opening, and every closing before time is up, sends an email to %s; closing when time is up does not. Browser login, this panel and the builder also work while closed.', 'ds-core' ),
			ds_core_avvisi_destinatari_html( 'accesso.apertura' ) // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato.
		);
		?>
	</p>
	<div class="ds-accesso-app">
		<?php if ( ! $utenti ) : ?>
			<p class="ds-accesso-stato"><?php esc_html_e( 'No account other than administrators has application passwords.', 'ds-core' ); ?></p>
		<?php else : ?>
			<p class="ds-avviso">
				<?php
				echo esc_html(
					ds_core_accesso_app_solo_admin()
						? __( 'These accounts are not administrators but still have application passwords. They cannot use them while “Only administrators” is on: delete them from the profile if nobody needs them.', 'ds-core' )
						: __( 'These accounts are not administrators and can sign in with their application passwords while access is open. Turn on “Only administrators” or delete the passwords from the profile.', 'ds-core' )
				);
				?>
			</p>
			<table class="widefat striped ds-ra-mini">
				<thead><tr><th scope="col"><?php esc_html_e( 'Username', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Role', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Application passwords', 'ds-core' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $utenti as $utente ) : ?>
					<tr>
						<td><a href="<?php echo esc_url( admin_url( 'user-edit.php?user_id=' . $utente['id'] ) . '#application-passwords-section' ); ?>"><?php echo esc_html( $utente['login'] ); ?></a></td>
						<td>
							<?php
							$ruoli = array();
							foreach ( $utente['ruoli'] as $ruolo ) {
								$ruoli[] = isset( $nomi[ $ruolo ] ) ? translate_user_role( $nomi[ $ruolo ] ) : $ruolo;
							}
							echo esc_html( $ruoli ? implode( ', ', $ruoli ) : '—' );
							?>
						</td>
						<td><?php echo (int) $utente['quante']; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
	<?php
}

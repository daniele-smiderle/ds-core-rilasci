<?php
/**
 * Modulo comments-closed (dalla 0.17.0, standard ST-27): commenti, trackback e pingback chiusi su tutto il sito.
 *
 * Perché anche i ping: i trackback entrano dall'indirizzo /trackback/ di ogni contenuto, passano da index.php e non
 * da xmlrpc.php, quindi né il blocco di XML-RPC né «solo utenti registrati possono commentare» li fermano; l'unico
 * controllo è pings_open() del contenuto, che segue default_ping_status (aperto in un'installazione nuova).
 *
 * Cosa fa, senza toccare il database (spento il modulo, ogni contenuto torna come era):
 * - comments_open() e pings_open() falsi per ogni contenuto, nuovo o vecchio, allegati compresi;
 * - wp-comments-post.php risponde 403 prima di WordPress («Sorry, comments are closed for this item.»);
 * - API REST: /wp/v2/comments tolto a chi non scrive contenuti (resta a chi ha edit_posts: l'editor a blocchi lo usa
 *   per le note);
 * - amministrazione: menu «Commenti», icona nella barra, colonna dei commenti e riquadro «Discussione» nascosti; il
 *   widget «Commenti recenti» non si può più aggiungere. La pagina dei commenti resta raggiungibile dal pannello,
 *   per moderare quelli in attesa.
 *
 * Commenti esistenti (decisione di Daniele del 27/11/2026): non si cancellano mai. Di base restano visibili; con la
 * scelta «Also hide existing comments» (spenta di base) escono dal sito pubblico senza essere cancellati: nelle
 * richieste pubbliche le query dei commenti (WP_Comment_Query: modelli, blocchi, widget, API REST per chi non scrive) e
 * il feed dei commenti non restituiscono commenti, ping e recensioni, e il numero dei commenti dei contenuti è 0. Le
 * note degli ordini WooCommerce e gli altri tipi interni non si toccano; la Bacheca vede tutto. Una query nascosta ha
 * un 'cache_domain' suo, così la cache degli oggetti non la scambia con quella della Bacheca.
 *
 * Commenti approvati: un attaccante potrebbe averne fatti approvare con link dannosi. Il pannello mostra quanti
 * commenti approvati ci sono, quanti con link e gli ultimi approvati con link (autore, data, domini, modifica; testo
 * senza HTML ed escapato). Con il modulo acceso non dovrebbero comparire commenti approvati nuovi: il modulo ricorda
 * l'ID più alto e il numero degli approvati all'accensione (opzione ds_core_cc_controllo) e, se ne compaiono
 * (approvati in Bacheca, scritti nel database da un altro plugin o da chi ha accesso al database), scrive un allarme
 * nel registro delle attività e lo segnala nel pannello finché un amministratore non preme «Mark as checked».
 * Controllo: subito quando WordPress inserisce o approva un commento, e dalle pagine di amministrazione al più una
 * volta l'ora.
 *
 * Moderazione dalla Bacheca (1.1.0, DS Core 0.18.0): un commento approvato, o una risposta scritta, dalla Bacheca da
 * un utente collegato che ha moderate_comments non è un allarme: entra nel punto di partenza e si registra come «da
 * notare» (livello 2) con chi l'ha fatto. Resta l'allarme (livello 3) per le approvazioni senza utente collegato, da
 * utenti senza quella capacità, via API REST (anche con password per le applicazioni), XML-RPC, cron, WP-CLI, e per i
 * commenti approvati scritti direttamente nel database (li trova il controllo orario).
 *
 * XSS (verificato sul codice di WordPress, 27/11/2026): il testo dei commenti di chi non ha unfiltered_html passa da
 * wp_filter_kses al salvataggio (pre_comment_content, kses_init_filters: pochi tag, niente script né attributi on*);
 * il nome dell'autore da sanitize_text_field e wp_filter_kses e si stampa con esc_html (filtro comment_author);
 * l'indirizzo dell'autore da sanitize_url e si stampa con esc_url. Sul sito pubblico comment_text() non rifà il kses
 * (lo fa solo in Bacheca, wp_kses_post): un commento scritto direttamente nel database non è ripulito. Per questo il
 * pannello di DS Core stampa il testo senza tag e con esc_html.
 *
 * Il pannello avvisa anche se ci sono commenti in attesa di moderazione.
 *
 * Negozi: con la scelta «Keep product reviews open» le recensioni dei prodotti WooCommerce (tipo 'product') restano
 * come le imposta WooCommerce; tutto il resto è chiuso (e, con «Also hide existing comments», nascosto).
 */

defined( 'ABSPATH' ) || exit;

/** Tipi di contenuto lasciati come sono (le recensioni dei prodotti, se scelto). */
function ds_core_cc_esclusi() {
	$valori = ds_core_opzioni_modulo( 'comments-closed' );
	return ! empty( $valori['recensioni'] ) && class_exists( 'WooCommerce' ) ? array( 'product' ) : array();
}

/** Il contenuto ($post o ID) è chiuso dal modulo. */
function ds_core_cc_chiuso( $post ) {
	$esclusi = ds_core_cc_esclusi();
	if ( ! $esclusi ) {
		return true;
	}
	$post = get_post( $post );
	return ! ( $post && in_array( $post->post_type, $esclusi, true ) );
}

/** Tipi di commento visibili ai visitatori: commenti, ping e recensioni (non le note degli ordini né altri usi interni). */
function ds_core_cc_tipi() {
	return array( '', 'comment', 'pingback', 'trackback', 'review' );
}

/* ---------- Sito ---------- */

add_filter( 'comments_open', 'ds_core_cc_aperto', PHP_INT_MAX, 2 );
add_filter( 'pings_open', 'ds_core_cc_aperto', PHP_INT_MAX, 2 );
function ds_core_cc_aperto( $aperto, $post_id ) {
	return ds_core_cc_chiuso( $post_id ) ? false : $aperto;
}

// wp-comments-post.php: 403 subito, salvo i contenuti esclusi (recensioni dei prodotti).
add_action( 'init', 'ds_core_cc_invio', 0 );
function ds_core_cc_invio() {
	$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( sanitize_text_field( wp_unslash( $_SERVER['SCRIPT_NAME'] ) ) ) : '';
	if ( 'wp-comments-post.php' !== $script ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- solo l'ID del contenuto, per le esclusioni.
	$post_id = isset( $_POST['comment_post_ID'] ) ? absint( $_POST['comment_post_ID'] ) : 0;
	if ( $post_id && ! ds_core_cc_chiuso( $post_id ) ) {
		return;
	}
	// Testo di WordPress (dominio predefinito, già tradotto).
	wp_die( esc_html__( 'Sorry, comments are closed for this item.' ), '', array( 'response' => 403 ) ); // phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- testo di WordPress.
}

// API REST: niente commenti per chi non scrive contenuti (vale anche per i clienti collegati).
add_filter( 'rest_endpoints', 'ds_core_cc_rest' );
function ds_core_cc_rest( $rotte ) {
	if ( current_user_can( 'edit_posts' ) || ds_core_cc_esclusi() ) {
		return $rotte;
	}
	foreach ( array_keys( $rotte ) as $rotta ) {
		if ( '/wp/v2/comments' === $rotta || 0 === strpos( $rotta, '/wp/v2/comments/' ) ) {
			unset( $rotte[ $rotta ] );
		}
	}
	return $rotte;
}

// Link al feed dei commenti tolto dall'<head>.
add_filter( 'feed_links_show_comments_feed', '__return_false' );

// Widget «Commenti recenti».
add_action( 'widgets_init', 'ds_core_cc_widget', 99 );
function ds_core_cc_widget() {
	unregister_widget( 'WP_Widget_Recent_Comments' );
}

/* ---------- Commenti esistenti nascosti (scelta) ---------- */

/** Scelta «Also hide existing comments». */
function ds_core_cc_nascondi() {
	$valori = ds_core_opzioni_modulo( 'comments-closed' );
	return ! empty( $valori['nascondi'] );
}

/**
 * I commenti esistenti vanno nascosti in questa richiesta: scelta accesa e richiesta pubblica. Bacheca: no. AJAX e
 * API REST: sì per chi non scrive contenuti (l'editor a blocchi usa l'API dei commenti per le note).
 */
function ds_core_cc_nascosti_qui() {
	if ( ! ds_core_cc_nascondi() ) {
		return false;
	}
	if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return ! current_user_can( 'edit_posts' );
	}
	return ! is_admin();
}

/** Elenco SQL di valori fra apici, preparati uno per uno. */
function ds_core_cc_sql_elenco( $valori ) {
	global $wpdb;
	$pezzi = array();
	foreach ( $valori as $valore ) {
		$pezzi[] = $wpdb->prepare( '%s', (string) $valore );
	}
	return implode( ',', $pezzi );
}

/** Condizione SQL che toglie commenti, ping e recensioni, salvo quelli dei contenuti esclusi (recensioni dei prodotti). */
function ds_core_cc_sql_nascosti() {
	global $wpdb;
	$dove    = "{$wpdb->comments}.comment_type NOT IN (" . ds_core_cc_sql_elenco( ds_core_cc_tipi() ) . ')';
	$esclusi = ds_core_cc_esclusi();
	if ( $esclusi ) {
		$dove = "( {$dove} OR {$wpdb->comments}.comment_post_ID IN ( SELECT ID FROM {$wpdb->posts} WHERE post_type IN (" . ds_core_cc_sql_elenco( $esclusi ) . ') ) )';
	}
	return $dove;
}

// Una chiave di cache propria per le query nascoste: la cache degli oggetti non le mescola con quelle della Bacheca.
add_action( 'pre_get_comments', 'ds_core_cc_query' );
function ds_core_cc_query( $query ) {
	if ( ds_core_cc_nascosti_qui() && is_object( $query ) ) {
		$query->query_vars['cache_domain'] = 'ds-core-comments-closed';
	}
}

add_filter( 'comments_clauses', 'ds_core_cc_clausole' );
function ds_core_cc_clausole( $clausole ) {
	if ( ! ds_core_cc_nascosti_qui() || ! is_array( $clausole ) ) {
		return $clausole;
	}
	$dove              = trim( (string) ( $clausole['where'] ?? '' ) );
	$clausole['where'] = ( '' !== $dove ? $dove . ' AND ' : '' ) . ds_core_cc_sql_nascosti();
	return $clausole;
}

// Feed dei commenti (query propria di WP_Query, non WP_Comment_Query): $dove comincia con «WHERE».
add_filter( 'comment_feed_where', 'ds_core_cc_feed' );
function ds_core_cc_feed( $dove ) {
	return ds_core_cc_nascosti_qui() ? $dove . ' AND ' . ds_core_cc_sql_nascosti() : $dove;
}

// Numero dei commenti dei contenuti (preso da comment_count, non da una query).
add_filter( 'get_comments_number', 'ds_core_cc_numero', PHP_INT_MAX, 2 );
function ds_core_cc_numero( $numero, $post_id = 0 ) {
	return ds_core_cc_nascosti_qui() && ds_core_cc_chiuso( $post_id ) ? 0 : $numero;
}

/* ---------- Amministrazione ---------- */

// Riquadro «Discussione», colonna dei commenti e campi dei ping: tolti togliendo il supporto ai commenti.
add_action( 'init', 'ds_core_cc_supporto', 100 );
function ds_core_cc_supporto() {
	$esclusi = ds_core_cc_esclusi();
	foreach ( get_post_types() as $tipo ) {
		if ( in_array( $tipo, $esclusi, true ) ) {
			continue;
		}
		remove_post_type_support( $tipo, 'comments' );
		remove_post_type_support( $tipo, 'trackbacks' );
	}
}

add_action( 'admin_menu', 'ds_core_cc_menu', 999 );
function ds_core_cc_menu() {
	if ( ! ds_core_cc_esclusi() ) {
		remove_menu_page( 'edit-comments.php' );
	}
}

add_action( 'admin_bar_menu', 'ds_core_cc_barra', 999 );
function ds_core_cc_barra( $barra ) {
	if ( ! ds_core_cc_esclusi() ) {
		$barra->remove_node( 'comments' );
	}
}

/* ---------- Commenti approvati: conteggi e controllo ---------- */

/** Condizione SQL «ha un link»: sito dell'autore, oppure un indirizzo o un href nel testo. */
function ds_core_cc_sql_link() {
	global $wpdb;
	return $wpdb->prepare(
		"(comment_author_url <> '' OR comment_content LIKE %s OR comment_content LIKE %s OR comment_content LIKE %s)",
		'%' . $wpdb->esc_like( '://' ) . '%',
		'%' . $wpdb->esc_like( 'www.' ) . '%',
		'%' . $wpdb->esc_like( 'href' ) . '%'
	);
}

/** Condizione SQL sui tipi di commento contati (commenti, ping, recensioni). */
function ds_core_cc_sql_tipi() {
	return 'comment_type IN (' . ds_core_cc_sql_elenco( ds_core_cc_tipi() ) . ')';
}

/**
 * Condizione SQL dei commenti controllati (allarme dei commenti approvati comparsi): come ds_core_cc_sql_tipi(), senza
 * i contenuti esclusi (le recensioni dei prodotti, se restano aperte, si approvano normalmente).
 */
function ds_core_cc_sql_controllati() {
	global $wpdb;
	$dove    = ds_core_cc_sql_tipi();
	$esclusi = ds_core_cc_esclusi();
	if ( $esclusi ) {
		$dove .= " AND comment_post_ID NOT IN ( SELECT ID FROM {$wpdb->posts} WHERE post_type IN (" . ds_core_cc_sql_elenco( $esclusi ) . ') )';
	}
	return $dove;
}

/** Commenti approvati e approvati con link: array( 'approvati' => n, 'con_link' => n ). Una volta per richiesta. */
function ds_core_cc_conteggi( $rifai = false ) {
	global $wpdb;
	static $conteggi = null;
	if ( null !== $conteggi && ! $rifai ) {
		return $conteggi;
	}
	$tipi = ds_core_cc_sql_tipi();
	$link = ds_core_cc_sql_link();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- condizioni già preparate.
	$riga     = $wpdb->get_row( "SELECT COUNT(*) AS approvati, SUM(CASE WHEN {$link} THEN 1 ELSE 0 END) AS con_link FROM {$wpdb->comments} WHERE comment_approved = '1' AND {$tipi}" );
	$conteggi = array(
		'approvati' => $riga ? (int) $riga->approvati : 0,
		'con_link'  => $riga ? (int) $riga->con_link : 0,
	);
	return $conteggi;
}

/** Ultimi commenti approvati con link (al più $quanti), dal più recente. */
function ds_core_cc_ultimi_con_link( $quanti = 10 ) {
	global $wpdb;
	$tipi = ds_core_cc_sql_tipi();
	$link = ds_core_cc_sql_link();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- condizioni già preparate.
	$righe = $wpdb->get_results( $wpdb->prepare( "SELECT comment_ID, comment_post_ID, comment_author, comment_author_url, comment_date_gmt, comment_content, comment_type FROM {$wpdb->comments} WHERE comment_approved = '1' AND {$tipi} AND {$link} ORDER BY comment_date_gmt DESC, comment_ID DESC LIMIT %d", max( 1, (int) $quanti ) ) );
	return is_array( $righe ) ? $righe : array();
}

/** Domini dei link di un commento (sito dell'autore e indirizzi nel testo), al più 5, minuscoli e senza doppioni. */
function ds_core_cc_domini( $commento ) {
	$domini = array();
	$testo  = (string) $commento->comment_author_url . ' ' . (string) $commento->comment_content;
	if ( preg_match_all( '~(?:[a-z][a-z0-9+.\-]*:)?//([^\s/?#"\'<>:@]+)|\bwww\.([^\s/?#"\'<>:@]+)~i', $testo, $trovati, PREG_SET_ORDER ) ) {
		foreach ( $trovati as $trovato ) {
			$host = strtolower( '' !== ( $trovato[1] ?? '' ) ? $trovato[1] : 'www.' . ( $trovato[2] ?? '' ) );
			$host = trim( $host, '.' );
			if ( '' !== $host && preg_match( '/^[a-z0-9.\-]+$/', $host ) ) {
				$domini[ $host ] = true;
			}
			if ( count( $domini ) >= 5 ) {
				break;
			}
		}
	}
	return array_keys( $domini );
}

/** Stato del controllo (ID più alto e approvati all'accensione, commenti approvati comparsi dopo), null prima del primo. */
function ds_core_cc_stato_controllo() {
	$stato = get_option( 'ds_core_cc_controllo', null );
	return is_array( $stato ) && isset( $stato['base_id'] ) ? $stato : null;
}

/** Punto di partenza: l'ID più alto e il numero degli approvati di adesso. */
function ds_core_cc_base() {
	global $wpdb;
	$tipi = ds_core_cc_sql_controllati();
	// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- condizioni già preparate.
	$base_id = (int) $wpdb->get_var( "SELECT MAX(comment_ID) FROM {$wpdb->comments}" );
	$vecchi  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = '1' AND {$tipi} AND comment_ID <= %d", $base_id ) );
	// phpcs:enable
	return array(
		'base_id'        => $base_id,
		'base_approvati' => $vecchi,
		'nuovi'          => array(),
		'vecchi'         => 0,
		'quando'         => time(),
	);
}

/**
 * Controllo dei commenti approvati comparsi dopo l'accensione. La prima volta fissa il punto di partenza. Commenti con
 * ID più alto: si sa quali. Commenti già presenti e approvati dopo (erano in attesa, nello spam o nel cestino): si sa
 * quanti, dal numero degli approvati con ID più basso. Allarme nel registro delle attività solo per le novità.
 */
function ds_core_cc_controlla() {
	global $wpdb;
	set_transient( 'ds_core_cc_controllato', 1, HOUR_IN_SECONDS );
	$stato = ds_core_cc_stato_controllo();
	if ( null === $stato ) {
		update_option( 'ds_core_cc_controllo', ds_core_cc_base(), false );
		return;
	}
	$tipi = ds_core_cc_sql_controllati();
	// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- condizioni già preparate.
	$nuovi  = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved = '1' AND {$tipi} AND comment_ID > %d ORDER BY comment_ID ASC LIMIT 250", (int) $stato['base_id'] ) ) );
	$vecchi = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = '1' AND {$tipi} AND comment_ID <= %d", (int) $stato['base_id'] ) );
	// phpcs:enable
	// Approvati o scritti dalla Bacheca da chi può moderare (1.1.0): non contano.
	$nuovi = array_slice( array_values( array_diff( $nuovi, array_map( 'intval', (array) ( $stato['visti'] ?? array() ) ) ) ), 0, 50 );

	$dopo = $stato;
	// Commenti tolti o non più approvati: il punto di partenza scende, così un'approvazione dopo non resta nascosta.
	if ( $vecchi < (int) $stato['base_approvati'] ) {
		$dopo['base_approvati'] = $vecchi;
	}
	$dopo['vecchi'] = max( 0, $vecchi - (int) $dopo['base_approvati'] );
	$dopo['nuovi']  = $nuovi;
	$comparsi       = array_values( array_diff( $nuovi, array_map( 'intval', (array) ( $stato['nuovi'] ?? array() ) ) ) );
	$piu_vecchi     = max( 0, $dopo['vecchi'] - (int) ( $stato['vecchi'] ?? 0 ) );
	if ( $dopo !== $stato ) {
		update_option( 'ds_core_cc_controllo', $dopo, false );
	}
	if ( $comparsi || $piu_vecchi ) {
		ds_core_registra_evento(
			'dscore.check',
			array(
				'livello' => 3,
				'origine' => 'comments-closed',
				'oggetto' => 'comments-closed',
				'dati'    => array(
					'azione'   => 'commenti-approvati',
					'nuovi'    => count( $comparsi ),
					'vecchi'   => $piu_vecchi,
					'commenti' => array_slice( $comparsi, 0, 10 ),
				),
			)
		);
	}
}

// Dalle pagine di amministrazione, al più una volta l'ora (la prima volta subito: fissa il punto di partenza).
add_action( 'admin_init', 'ds_core_cc_controllo_periodico' );
function ds_core_cc_controllo_periodico() {
	if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) || ( get_transient( 'ds_core_cc_controllato' ) && null !== ds_core_cc_stato_controllo() ) ) {
		return;
	}
	ds_core_cc_controlla();
}

/**
 * La richiesta è una moderazione dalla Bacheca: pagina di amministrazione (anche admin-ajax.php, che usa la pagina
 * dei commenti) di un utente collegato con moderate_comments. No per API REST, XML-RPC, cron e WP-CLI.
 */
function ds_core_cc_da_bacheca() {
	if ( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
		return false;
	}
	return is_admin() && is_user_logged_in() && current_user_can( 'moderate_comments' );
}

/**
 * Commento approvato (o risposta scritta) dalla Bacheca: entra nel punto di partenza, così il controllo non lo conta,
 * e si registra come «da notare» con chi l'ha fatto (l'utente collegato, scritto dal registro delle attività).
 */
function ds_core_cc_visto_da_bacheca( $commento, $risposta ) {
	$stato = ds_core_cc_stato_controllo();
	if ( null === $stato ) {
		return;
	}
	$id = (int) $commento->comment_ID;
	if ( $id > (int) $stato['base_id'] ) {
		$visti          = array_map( 'intval', (array) ( $stato['visti'] ?? array() ) );
		$visti[]        = $id;
		$stato['visti'] = array_slice( array_values( array_unique( $visti ) ), -200 );
	} else {
		$stato['base_approvati'] = (int) $stato['base_approvati'] + 1;
	}
	update_option( 'ds_core_cc_controllo', $stato, false );
	ds_core_registra_evento(
		'dscore.check',
		array(
			'livello' => 2,
			'origine' => 'comments-closed',
			'oggetto' => 'comments-closed',
			'dati'    => array(
				'azione'   => $risposta ? 'commento-risposta-bacheca' : 'commento-approvato-bacheca',
				'commento' => $id,
			),
		)
	);
}

// Subito quando WordPress inserisce un commento approvato o ne approva uno (l'evento dice chi l'ha fatto).
add_action( 'wp_insert_comment', 'ds_core_cc_inserito', 10, 2 );
function ds_core_cc_inserito( $id, $commento ) {
	if ( is_object( $commento ) && '1' === (string) $commento->comment_approved && in_array( (string) $commento->comment_type, ds_core_cc_tipi(), true ) && ds_core_cc_chiuso( (int) $commento->comment_post_ID ) && null !== ds_core_cc_stato_controllo() ) {
		if ( ds_core_cc_da_bacheca() ) {
			ds_core_cc_visto_da_bacheca( $commento, true );
			return;
		}
		ds_core_cc_controlla();
	}
}

add_action( 'transition_comment_status', 'ds_core_cc_approvato', 10, 3 );
function ds_core_cc_approvato( $nuovo, $prima, $commento ) {
	if ( 'approved' === $nuovo && 'approved' !== $prima && is_object( $commento ) && in_array( (string) $commento->comment_type, ds_core_cc_tipi(), true ) && ds_core_cc_chiuso( (int) $commento->comment_post_ID ) && null !== ds_core_cc_stato_controllo() ) {
		if ( ds_core_cc_da_bacheca() ) {
			ds_core_cc_visto_da_bacheca( $commento, false );
			return;
		}
		ds_core_cc_controlla();
	}
}

// Spegnendo il modulo si dimentica il punto di partenza: alla prossima accensione si riparte da quel momento.
add_action( 'ds_core_stato_cambiato', 'ds_core_cc_spento', 10, 3 );
function ds_core_cc_spento( $id, $prima, $dopo ) {
	if ( 'comments-closed' === $id && 'spento' === $dopo ) {
		delete_option( 'ds_core_cc_controllo' );
		delete_transient( 'ds_core_cc_controllato' );
	}
}

// «Mark as checked»: i commenti approvati di adesso diventano il nuovo punto di partenza.
add_action( 'admin_post_ds_core_cc_visti', 'ds_core_cc_visti' );
function ds_core_cc_visti() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_cc_visti' );
	$stato = ds_core_cc_stato_controllo();
	update_option( 'ds_core_cc_controllo', ds_core_cc_base(), false );
	if ( $stato && ( ! empty( $stato['nuovi'] ) || ! empty( $stato['vecchi'] ) ) ) {
		ds_core_registra_evento(
			'dscore.check',
			array(
				'livello' => 1,
				'origine' => 'comments-closed',
				'oggetto' => 'comments-closed',
				'dati'    => array( 'azione' => 'commenti-verificati', 'nuovi' => count( (array) $stato['nuovi'] ), 'vecchi' => (int) $stato['vecchi'] ),
			)
		);
	}
	wp_safe_redirect( ds_core_url_pannello( ds_core_scheda_dal_referer(), 'ds-impostazioni-comments-closed' ) );
	exit;
}

/** Numero dei commenti approvati comparsi dopo l'accensione (o dopo l'ultimo «Mark as checked»). */
function ds_core_cc_comparsi() {
	$stato = ds_core_cc_stato_controllo();
	return $stato ? count( (array) ( $stato['nuovi'] ?? array() ) ) + (int) ( $stato['vecchi'] ?? 0 ) : 0;
}

/* ---------- Pannello ---------- */

/** Commenti in attesa di moderazione (spam escluso). */
function ds_core_cc_in_attesa() {
	$conta = wp_count_comments();
	return isset( $conta->moderated ) ? (int) $conta->moderated : 0;
}

function ds_core_cc_problemi() {
	$problemi = array();
	$comparsi = ds_core_cc_comparsi();
	if ( $comparsi ) {
		/* translators: %d: number of comments. */
		$problemi[] = sprintf( _n( '%d approved comment appeared after comments were closed: check it.', '%d approved comments appeared after comments were closed: check them.', $comparsi, 'ds-core' ), $comparsi );
	}
	$quanti = ds_core_cc_in_attesa();
	if ( $quanti ) {
		/* translators: %d: number of comments. */
		$problemi[] = sprintf( _n( '%d comment is waiting for moderation.', '%d comments are waiting for moderation.', $quanti, 'ds-core' ), $quanti );
	}
	return $problemi;
}

/** Testo di un commento per il pannello: senza tag, su una riga, accorciato. Da stampare con esc_html. */
function ds_core_cc_estratto( $testo ) {
	$testo = trim( (string) preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $testo ) ) );
	return function_exists( 'mb_strlen' ) && mb_strlen( $testo ) > 160 ? mb_substr( $testo, 0, 160 ) . '…' : $testo;
}

function ds_core_cc_riquadro() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$quanti   = ds_core_cc_in_attesa();
	$conteggi = ds_core_cc_conteggi();
	$comparsi = ds_core_cc_comparsi();
	$formato  = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
	$si       = function_exists( 'ds_core_icona' ) ? ds_core_icona( 'acceso' ) : '';
	?>
	<div class="ds-comments-closed">
		<p class="ds-accesso-stato">
			<?php
			if ( ds_core_cc_nascondi() ) {
				printf(
					/* translators: %d: number of approved comments. */
					esc_html( _n( 'Comments, trackbacks and pingbacks are closed everywhere. %d approved comment is hidden from the public site, not deleted.', 'Comments, trackbacks and pingbacks are closed everywhere. %d approved comments are hidden from the public site, not deleted.', $conteggi['approvati'], 'ds-core' ) ),
					(int) $conteggi['approvati']
				);
			} else {
				printf(
					/* translators: %d: number of approved comments. */
					esc_html( _n( 'Comments, trackbacks and pingbacks are closed everywhere. %d approved comment is still shown, as before.', 'Comments, trackbacks and pingbacks are closed everywhere. %d approved comments are still shown, as before.', $conteggi['approvati'], 'ds-core' ) ),
					(int) $conteggi['approvati']
				);
			}
			?>
		</p>
		<p>
			<?php
			printf(
				/* translators: %d: number of approved comments with links. */
				esc_html( _n( '%d approved comment contains a link (website of the author or address in the text).', '%d approved comments contain a link (website of the author or address in the text).', $conteggi['con_link'], 'ds-core' ) ),
				(int) $conteggi['con_link']
			);
			?>
		</p>
		<?php if ( ds_core_cc_esclusi() ) : ?>
			<p class="ds-grigio"><?php esc_html_e( 'Product reviews follow the WooCommerce settings.', 'ds-core' ); ?></p>
		<?php endif; ?>
		<?php if ( $comparsi ) : ?>
			<div class="ds-avviso">
				<p>
					<?php
					printf(
						/* translators: %d: number of comments. */
						esc_html( _n( '%d approved comment appeared after comments were closed. It should not happen: check it and its links, then mark it as checked.', '%d approved comments appeared after comments were closed. It should not happen: check them and their links, then mark them as checked.', $comparsi, 'ds-core' ) ),
						(int) $comparsi
					);
					?>
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="ds_core_cc_visti">
					<?php wp_nonce_field( 'ds_core_cc_visti' ); ?>
					<button type="submit" class="button ds-con-icona"><?php echo $si; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Mark as checked', 'ds-core' ); ?></button>
				</form>
			</div>
		<?php endif; ?>
		<?php if ( $conteggi['con_link'] ) : ?>
			<h4><?php esc_html_e( 'Latest approved comments with links', 'ds-core' ); ?></h4>
			<table class="widefat striped ds-ra-mini">
				<thead><tr><th scope="col"><?php esc_html_e( 'Author', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Date', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Link domains', 'ds-core' ); ?></th><th scope="col"><?php esc_html_e( 'Text', 'ds-core' ); ?></th><th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Edit', 'ds-core' ); ?></span></th></tr></thead>
				<tbody>
				<?php foreach ( ds_core_cc_ultimi_con_link( 10 ) as $commento ) : ?>
					<tr>
						<td><?php echo esc_html( '' !== (string) $commento->comment_author ? (string) $commento->comment_author : '—' ); ?></td>
						<td><?php echo esc_html( wp_date( $formato, strtotime( $commento->comment_date_gmt . ' UTC' ) ) ); ?></td>
						<td><?php echo esc_html( implode( ', ', ds_core_cc_domini( $commento ) ) ); ?></td>
						<td><?php echo esc_html( ds_core_cc_estratto( $commento->comment_content ) ); ?></td>
						<td><a href="<?php echo esc_url( admin_url( 'comment.php?action=editcomment&c=' . (int) $commento->comment_ID ) ); ?>"><?php esc_html_e( 'Edit', 'ds-core' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="ds-grigio"><?php esc_html_e( 'Text without HTML. Links to unknown sites can be spam or worse: edit the comment, mark it as spam or move it to the trash.', 'ds-core' ); ?></p>
		<?php endif; ?>
		<?php if ( $quanti ) : ?>
			<p class="ds-avviso">
				<?php
				printf(
					/* translators: %d: number of comments. */
					esc_html( _n( '%d comment is waiting for moderation. Comments are closed: if it is spam, mark it as spam or move it to the trash.', '%d comments are waiting for moderation. Comments are closed: if they are spam, mark them as spam or move them to the trash.', $quanti, 'ds-core' ) ),
					(int) $quanti
				);
				?>
				<a href="<?php echo esc_url( admin_url( 'edit-comments.php?comment_status=moderated' ) ); ?>"><?php esc_html_e( 'Review', 'ds-core' ); ?></a>
			</p>
			<p class="ds-grigio"><?php esc_html_e( 'Approving or replying from the dashboard is recorded in the activity log with your name, not as an alarm.', 'ds-core' ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/** Stato a parole per la riga di riepilogo del pannello (0.18.0). */
function ds_core_cc_riepilogo() {
	$conteggi = ds_core_cc_conteggi();
	/* translators: %d: number of approved comments. */
	return sprintf( _n( 'Closed everywhere, %d approved comment', 'Closed everywhere, %d approved comments', $conteggi['approvati'], 'ds-core' ), $conteggi['approvati'] );
}

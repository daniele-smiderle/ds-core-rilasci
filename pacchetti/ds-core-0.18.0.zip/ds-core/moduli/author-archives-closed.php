<?php
/**
 * Modulo author-archives-closed.
 *
 * Gli archivi autore rivelano il nome utente: /?author=1 rimanda a /author/<nome-utente>/. Per chi non scrive
 * contenuti questo modulo:
 * - rimanda alla home ogni richiesta di archivio autore (?author=N, ?author_name=…, /author/…/), con la stessa
 *   risposta che l'utente esista o no, così non si può nemmeno sapere quali numeri corrispondono a un utente;
 * - sostituisce il link all'archivio autore con la home, così il nome utente non compare nelle pagine;
 * - toglie il link all'autore dalle risposte oEmbed;
 * - toglie gli autori dalla sitemap di WordPress (quelle dei plugin SEO si impostano nel plugin).
 *
 * Chi può modificare contenuti (edit_posts) continua a vedere gli archivi autore.
 * Non cambia il «nome pubblico» degli utenti: se coincide con il nome utente va cambiato nel profilo.
 */

defined( 'ABSPATH' ) || exit;

/** Vale per chi non scrive contenuti; mai in amministrazione. */
function ds_core_autori_chiusi_vale() {
	return ! is_admin() && ! current_user_can( 'edit_posts' );
}

add_action( 'template_redirect', 'ds_core_autori_chiusi_reindirizza', 0 );
function ds_core_autori_chiusi_reindirizza() {
	if ( ! ds_core_autori_chiusi_vale() ) {
		return;
	}
	// Si guardano i parametri della richiesta, non il risultato: /author/<nome-inesistente>/ non è is_author() ma
	// deve avere la stessa risposta di un autore vero, altrimenti la differenza 404/301 rivela chi esiste.
	global $wp;
	$richiesta = isset( $wp->query_vars ) && is_array( $wp->query_vars ) ? $wp->query_vars : array();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo lettura del parametro.
	if ( isset( $_GET['author'] ) || isset( $_GET['author_name'] ) || ! empty( $richiesta['author'] ) || ! empty( $richiesta['author_name'] ) || is_author() ) {
		wp_safe_redirect( home_url( '/' ), 301, 'DS Core' );
		exit;
	}
}

add_filter( 'author_link', 'ds_core_autori_chiusi_link', 99 );
function ds_core_autori_chiusi_link( $link ) {
	return ds_core_autori_chiusi_vale() ? home_url( '/' ) : $link;
}

add_filter( 'oembed_response_data', 'ds_core_autori_chiusi_oembed', 99 );
function ds_core_autori_chiusi_oembed( $dati ) {
	unset( $dati['author_url'] );
	return $dati;
}

add_filter( 'wp_sitemaps_add_provider', 'ds_core_autori_chiusi_sitemap', 10, 2 );
function ds_core_autori_chiusi_sitemap( $provider, $nome ) {
	return 'users' === $nome ? false : $provider;
}

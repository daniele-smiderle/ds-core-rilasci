<?php
/**
 * Modulo generic-login-errors (dalla 0.17.0): lo stesso messaggio d'errore per ogni accesso sbagliato.
 *
 * WordPress dice se il nome utente esiste («The username X is not registered on this site» / «The password you
 * entered for the username X is incorrect»), e lo stesso fa la reimpostazione della password («There is no account
 * with that username or email address»; in WooCommerce «Invalid username or email.»). Così da fuori si scopre quali
 * account esistono. Con il modulo acceso:
 *
 * - accesso (wp-login.php, login di WooCommerce «Il mio account», ogni modulo che usa wp_signon()): per utente
 *   inesistente, email inesistente o password errata un solo messaggio, «Incorrect username, email address or
 *   password», con il link «Lost your password?». Si cambia solo il testo dell'errore, alla fine del filtro
 *   'authenticate': i codici d'errore (invalid_username, invalid_email, incorrect_password) restano quelli di
 *   WordPress, quindi wp_login_failed, i limiti ai tentativi (Limit Login Attempts Reloaded e simili), l'accesso in due
 *   passaggi e gli accessi unici (SSO) che lavorano su wp_login vedono la stessa cosa di prima. Nessun altro errore
 *   cambia (campo vuoto, blocco per troppi tentativi, codice a due passaggi);
 * - reimpostazione della password (wp-login.php?action=lostpassword e «Password dimenticata» di WooCommerce): se
 *   l'account non esiste, la pagina fa quello che fa quando esiste, cioè «controlla la tua email» (WordPress:
 *   wp-login.php?checkemail=confirm o redirect_to; WooCommerce: ?reset-link-sent=true). Nessuna mail parte. Altri
 *   errori (campo vuoto, controlli di altri plugin come i captcha) restano visibili.
 *
 * Il tempo di risposta può ancora differire di poco (la mail si manda solo se l'account esiste). La registrazione
 * («email già registrata») non è toccata.
 */

defined( 'ABSPATH' ) || exit;

/** Codici d'errore che rivelano se l'account esiste. */
function ds_core_leg_codici() {
	return array( 'invalid_username', 'invalid_email', 'incorrect_password' );
}

/** Messaggio unico, con il link per reimpostare la password (wp_lostpassword_url: WooCommerce lo porta al suo). */
function ds_core_leg_messaggio() {
	return sprintf(
		/* translators: %s: link "Lost your password?". */
		__( '<strong>Error:</strong> Incorrect username, email address or password. %s', 'ds-core' ),
		'<a href="' . esc_url( wp_lostpassword_url() ) . '">' . __( 'Lost your password?', 'ds-core' ) . '</a>'
	);
}

/*
 * Ultimo filtro di 'authenticate' (WordPress lavora a 20 e 30): si sostituisce solo il testo, codici e dati restano.
 * Se lo stesso errore ha più codici che rivelano l'account, ne resta uno (il primo), con il messaggio unico.
 */
add_filter( 'authenticate', 'ds_core_leg_autentica', 9999, 1 );
function ds_core_leg_autentica( $utente ) {
	if ( ! is_wp_error( $utente ) ) {
		return $utente;
	}
	$codici = $utente->get_error_codes();
	if ( ! array_intersect( $codici, ds_core_leg_codici() ) ) {
		return $utente;
	}
	$nuovo = new WP_Error();
	$messo = false;
	foreach ( $codici as $codice ) {
		$dati = $utente->get_error_data( $codice );
		if ( in_array( $codice, ds_core_leg_codici(), true ) ) {
			if ( ! $messo ) {
				$nuovo->add( $codice, ds_core_leg_messaggio(), $dati );
				$messo = true;
			}
			continue;
		}
		foreach ( $utente->get_error_messages( $codice ) as $testo ) {
			$nuovo->add( $codice, $testo, $dati );
		}
	}
	return $nuovo;
}

/** Login scritto nel modulo di reimpostazione (vuoto se manca). */
function ds_core_leg_login_inviato() {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WordPress e WooCommerce hanno già controllato la richiesta.
	return isset( $_POST['user_login'] ) && is_string( $_POST['user_login'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) ) : '';
}

/** Gli unici errori sono quelli di un account inesistente (nessun altro plugin ha fermato la richiesta). */
function ds_core_leg_solo_inesistente( $errori ) {
	if ( ! is_wp_error( $errori ) ) {
		return true;
	}
	return ! array_diff( $errori->get_error_codes(), array( 'invalid_email', 'invalidcombo' ) );
}

/*
 * wp-login.php: retrieve_password() di WordPress filtra gli errori con 'lostpassword_errors' (dopo 'lostpassword_post',
 * dove lavorano i captcha). Account inesistente = $utente falso: stessa destinazione di quando la mail parte.
 */
add_filter( 'lostpassword_errors', 'ds_core_leg_password_persa_wp', PHP_INT_MAX, 2 );
function ds_core_leg_password_persa_wp( $errori, $utente ) {
	if ( $utente instanceof WP_User || 'wp-login.php' !== ( $GLOBALS['pagenow'] ?? '' ) || '' === ds_core_leg_login_inviato() || ! ds_core_leg_solo_inesistente( $errori ) ) {
		return $errori;
	}
	// Come wp-login.php quando retrieve_password() riesce.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- stessa lettura di wp-login.php.
	$destinazione = ! empty( $_REQUEST['redirect_to'] ) && is_string( $_REQUEST['redirect_to'] ) ? wp_unslash( $_REQUEST['redirect_to'] ) : 'wp-login.php?checkemail=confirm'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wp_safe_redirect controlla l'indirizzo.
	wp_safe_redirect( $destinazione );
	exit;
}

/*
 * WooCommerce («Password dimenticata» di Il mio account): WC_Shortcode_My_Account::retrieve_password() lancia
 * 'lostpassword_post' e poi, senza utente, scrive «Invalid username or email.». Qui si va dove va quando la mail parte.
 */
add_action( 'lostpassword_post', 'ds_core_leg_password_persa_wc', PHP_INT_MAX, 2 );
function ds_core_leg_password_persa_wc( $errori, $utente = false ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce ha già controllato il nonce.
	if ( $utente instanceof WP_User || ! isset( $_POST['wc_reset_password'] ) || ! function_exists( 'wc_get_account_endpoint_url' ) ) {
		return;
	}
	if ( '' === ds_core_leg_login_inviato() || ! ds_core_leg_solo_inesistente( $errori ) ) {
		return;
	}
	wp_safe_redirect( add_query_arg( 'reset-link-sent', 'true', wc_get_account_endpoint_url( 'lost-password' ) ) );
	exit;
}

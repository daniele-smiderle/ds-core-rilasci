<?php
/**
 * Modulo xmlrpc-closed (dalla 0.17.0): XML-RPC chiuso del tutto.
 *
 * XML-RPC (xmlrpc.php) è il vecchio ingresso remoto di WordPress: oggi lo usano quasi solo gli attacchi al login
 * (system.multicall prova centinaia di password in una richiesta) e i pingback di spam. Il filtro «xmlrpc_enabled»
 * da solo non basta: spegne i metodi con l'autenticazione, ma pingback.ping e system.multicall restano raggiungibili
 * (system.multicall lo aggiunge la libreria IXR dopo il filtro dei metodi, quindi non si toglie da «xmlrpc_methods»).
 * Per questo il modulo:
 * - risponde 403 a ogni richiesta a xmlrpc.php (anche «?rsd»), prima che WordPress prepari il server XML-RPC;
 * - per sicurezza, se un plugin crea il server XML-RPC per conto suo: «xmlrpc_enabled» falso con l'ultima parola,
 *   nessun metodo (pingback.*, system.*, demo.*, wp.*, metaWeblog.*…);
 * - toglie l'intestazione X-Pingback, il link RSD dall'<head> e l'indirizzo dei pingback (bloginfo 'pingback_url');
 * - non manda pingback ad altri siti (pre_ping).
 *
 * Password per le applicazioni (modulo claude-code-access): claude-code-access le spegne del tutto fuori dalle finestre di
 * apertura, per REST e XML-RPC, con il filtro wp_is_application_passwords_available; questo modulo non lo tocca.
 * Con xmlrpc-closed acceso XML-RPC resta chiuso anche a finestra aperta: Claude Code usa l'API REST (MCP), non
 * XML-RPC. Le password per le applicazioni sull'API REST non cambiano.
 *
 * Controllo: una volta ogni 12 ore, da una pagina di amministrazione aperta da un amministratore (o con «Check
 * again»), il sito chiama il proprio xmlrpc.php. Se risponde ancora con un elenco di metodi, un altro plugin o il
 * server lo serve prima di WordPress: problema nel pannello ed evento «da notare» nel registro delle attività.
 * Rompe l'app mobile di WordPress (vecchie versioni), Jetpack e i programmi di scrittura via XML-RPC: il pannello
 * avvisa se Jetpack è attivo.
 *
 * Base: modulo sicurezza-xmlrpc di un plugin di sito (solo il filtro), completato.
 */

defined( 'ABSPATH' ) || exit;

/* ---------- Chiusura ---------- */

// Richiesta a xmlrpc.php: il modulo si carica su plugins_loaded (priorità 5), prima che xmlrpc.php crei il server.
if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
	ds_core_xc_rifiuta();
}

/** Risposta 403 a una richiesta XML-RPC, con il testo di WordPress. Non torna. */
function ds_core_xc_rifiuta() {
	if ( ! headers_sent() ) {
		status_header( 403 );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=UTF-8' );
	}
	// Testo di WordPress (dominio predefinito): lo stesso che manda il server XML-RPC quando è spento.
	echo 'XML-RPC services are disabled on this site.';
	exit;
}

// Ultima parola, anche se un altro plugin lo riaccende.
add_filter( 'xmlrpc_enabled', '__return_false', PHP_INT_MAX );

// Nessun metodo, se un plugin crea il server XML-RPC fuori da xmlrpc.php.
add_filter( 'xmlrpc_methods', 'ds_core_xc_metodi', PHP_INT_MAX );
function ds_core_xc_metodi( $metodi ) {
	return array();
}

// Niente X-Pingback nelle risposte (WordPress lo manda sui contenuti con i ping aperti).
add_filter( 'wp_headers', 'ds_core_xc_intestazioni', PHP_INT_MAX );
function ds_core_xc_intestazioni( $intestazioni ) {
	if ( is_array( $intestazioni ) ) {
		unset( $intestazioni['X-Pingback'] );
	}
	return $intestazioni;
}

// Niente link RSD (EditURI) nell'<head>: indica xmlrpc.php.
remove_action( 'wp_head', 'rsd_link' );

// Indirizzo dei pingback vuoto: i temi che stampano <link rel="pingback"> non indicano più xmlrpc.php.
add_filter( 'bloginfo_url', 'ds_core_xc_bloginfo', PHP_INT_MAX, 2 );
function ds_core_xc_bloginfo( $valore, $cosa ) {
	return 'pingback_url' === $cosa ? '' : $valore;
}

// Nessun pingback in uscita verso altri siti.
add_action( 'pre_ping', 'ds_core_xc_niente_ping', PHP_INT_MAX, 1 );
function ds_core_xc_niente_ping( &$link ) {
	$link = array();
}

/* ---------- Controllo ---------- */

/** Jetpack attivo: usa XML-RPC per collegarsi a WordPress.com e smette di funzionare. */
function ds_core_xc_jetpack() {
	return defined( 'JETPACK__VERSION' ) || class_exists( 'Jetpack' );
}

/**
 * Chiama xmlrpc.php del sito con system.listMethods e salva l'esito in ds_core_xc_stato:
 * esito 'chiuso' (qualunque risposta senza elenco di metodi: 403 del modulo, blocco nel .htaccess, 404…),
 * 'aperto' (risponde con un methodResponse) o 'errore' (il sito non ha risposto: non è un problema del modulo).
 */
function ds_core_xc_controlla() {
	$corpo    = '<?xml version="1.0"?><methodCall><methodName>system.listMethods</methodName><params></params></methodCall>';
	$risposta = wp_remote_post(
		site_url( 'xmlrpc.php' ),
		array(
			'timeout'     => 10,
			'redirection' => 0,
			'sslverify'   => false,
			'headers'     => array( 'Content-Type' => 'text/xml' ),
			'body'        => $corpo,
		)
	);
	if ( is_wp_error( $risposta ) ) {
		$stato = array( 'esito' => 'errore', 'codice' => 0, 'quando' => time() );
	} else {
		$codice = (int) wp_remote_retrieve_response_code( $risposta );
		$aperto = 200 === $codice && false !== stripos( (string) wp_remote_retrieve_body( $risposta ), '<methodResponse' );
		$stato  = array( 'esito' => $aperto ? 'aperto' : 'chiuso', 'codice' => $codice, 'quando' => time() );
	}
	update_option( 'ds_core_xc_stato', $stato, false );
	set_transient( 'ds_core_xc_controllato', 1, 12 * HOUR_IN_SECONDS );
	if ( 'aperto' === $stato['esito'] ) {
		ds_core_registra_evento(
			'dscore.check',
			array(
				'livello' => 2,
				'origine' => 'xmlrpc-closed',
				'oggetto' => 'xmlrpc-closed',
				'utente'  => 'automatico',
				'ip'      => '',
				'ogni'    => DAY_IN_SECONDS,
				'dati'    => array( 'azione' => 'xmlrpc-aperto', 'codice' => $stato['codice'] ),
			)
		);
	}
	return $stato;
}

// Dalle pagine di amministrazione, al più ogni 12 ore.
add_action( 'admin_init', 'ds_core_xc_controllo_periodico' );
function ds_core_xc_controllo_periodico() {
	if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) || get_transient( 'ds_core_xc_controllato' ) ) {
		return;
	}
	ds_core_xc_controlla();
}

add_action( 'admin_post_ds_core_xc', 'ds_core_xc_ricontrolla' );
function ds_core_xc_ricontrolla() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_xc' );
	ds_core_xc_controlla();
	wp_safe_redirect( ds_core_url_pannello( ds_core_scheda_dal_referer(), 'ds-impostazioni-xmlrpc-closed' ) );
	exit;
}

/** Problemi per l'avviso in cima al pannello (campo 'problemi' del registro). */
function ds_core_xc_problemi() {
	$problemi = array();
	$stato    = get_option( 'ds_core_xc_stato', array() );
	if ( is_array( $stato ) && 'aperto' === ( $stato['esito'] ?? '' ) ) {
		$problemi[] = __( 'xmlrpc.php still answers with the list of methods: another plugin or the server handles it before WordPress.', 'ds-core' );
	}
	// Un altro filtro con l'ultima parola dopo questo modulo (stessa priorità, aggiunto dopo).
	if ( apply_filters( 'xmlrpc_enabled', true ) ) {
		$problemi[] = __( 'Another plugin turns XML-RPC back on.', 'ds-core' );
	}
	if ( ds_core_xc_jetpack() ) {
		$problemi[] = __( 'Jetpack is active and needs XML-RPC: its connection to WordPress.com stops working.', 'ds-core' );
	}
	return $problemi;
}

/** Stato nella riga del modulo (solo a modulo acceso). */
function ds_core_xc_riquadro() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$stato = get_option( 'ds_core_xc_stato', array() );
	$stato = is_array( $stato ) ? $stato : array();
	$esito = $stato['esito'] ?? '';
	$data  = isset( $stato['quando'] ) ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $stato['quando'] ) : '';
	?>
	<div class="ds-xmlrpc-closed">
		<p class="ds-accesso-stato">
			<?php
			if ( 'chiuso' === $esito ) {
				printf(
					/* translators: 1: date and time of the last check, 2: HTTP status code. */
					esc_html__( 'Closed: checked on %1$s, xmlrpc.php answered with code %2$d and no methods.', 'ds-core' ),
					esc_html( $data ),
					(int) $stato['codice']
				);
			} elseif ( 'aperto' === $esito ) {
				printf(
					/* translators: %s: date and time of the last check. */
					esc_html__( 'Still open: checked on %s, xmlrpc.php answered with the list of methods.', 'ds-core' ),
					esc_html( $data )
				);
			} elseif ( 'errore' === $esito ) {
				printf(
					/* translators: %s: date and time of the last check. */
					esc_html__( 'Not checked: on %s the site did not answer its own request. XML-RPC is closed by this module anyway.', 'ds-core' ),
					esc_html( $data )
				);
			} else {
				esc_html_e( 'Not checked yet: the check runs at the next page load of the dashboard.', 'ds-core' );
			}
			?>
		</p>
		<p class="ds-grigio"><?php esc_html_e( 'Every request to xmlrpc.php gets 403; pingback and system.multicall are gone with it. No X-Pingback header, no RSD link, no pingbacks sent to other sites. Application passwords on the REST API are not affected.', 'ds-core' ); ?></p>
		<?php if ( ds_core_xc_jetpack() ) : ?>
			<p class="ds-avviso"><?php esc_html_e( 'Jetpack is active and needs XML-RPC: its connection to WordPress.com stops working while this module is on.', 'ds-core' ); ?></p>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="ds_core_xc">
			<?php wp_nonce_field( 'ds_core_xc' ); ?>
			<button type="submit" class="button"><?php esc_html_e( 'Check again', 'ds-core' ); ?></button>
		</form>
	</div>
	<?php
}

/** Stato a parole per la riga di riepilogo del pannello (0.18.0). */
function ds_core_xc_riepilogo() {
	$stato = get_option( 'ds_core_xc_stato', array() );
	$stato = is_array( $stato ) ? $stato : array();
	$esito = $stato['esito'] ?? '';
	$data  = isset( $stato['quando'] ) ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $stato['quando'] ) : '';
	if ( 'chiuso' === $esito ) {
		/* translators: %s: date and time of the last check. */
		return sprintf( __( 'Closed, checked %s', 'ds-core' ), $data );
	}
	if ( 'aperto' === $esito ) {
		return __( 'Still answering: see the details', 'ds-core' );
	}
	return __( 'Closed, not checked yet', 'ds-core' );
}

<?php
/**
 * Modulo admin-branding («Brand colors», dalla 0.18.0; docs/ds-core-analisi-pannello-ux.md §3, decisioni di Daniele
 * del 27/11/2026). Solo aspetto, nessun dato cambiato: spento il modulo, tutto torna com'era.
 *
 * - Bacheca: schema colori di WordPress «Site brand» (wp_admin_css_color, slug ds-brand) con il colore del brand
 *   sulla voce di menu scelta, sui pulsanti principali, sui link e sul fuoco; menu laterale scuro come quello di
 *   WordPress. Il foglio assets/admin-branding.css usa variabili CSS, i valori li scrive qui un blocco in linea sul
 *   foglio 'colors' (quello degli schemi colori). Applicato come predefinito a tutti (filtro
 *   get_user_option_admin_color, la scelta nel profilo sparisce); con «Let each user keep…» chi ha scelto un altro
 *   schema nel profilo lo tiene. Nessuna modalità scura per il resto di WordPress (Daniele 27/11).
 * - Editor a blocchi: --wp-admin-theme-color (e le sue tonalità) nel colore del brand, per pulsanti e selezioni.
 * - Colori leggibili: testo bianco o scuro sul colore del brand, quello con il contrasto maggiore; sotto 4,5:1 (WCAG
 *   AA) il colore si scurisce o si schiarisce finché ci arriva (ds_core_colore_leggibile(), includes/opzioni.php). I
 *   link usano il colore portato a 4,5:1 sullo sfondo della Bacheca, le voci evidenziate del menu scuro lo stesso
 *   sul grigio del menu.
 * - Colore: quello scelto nel pannello; vuoto = il colore «Brand» dei colori globali di Breakdance, se c'è
 *   (ds_core_colore_dal_sito(), nessuna dipendenza da Breakdance); altrimenti il blu di WordPress.
 * - Scelta «Black text in the block editor» (riga 12 di docs/ds-core-analisi-mc-funzioni.md, era lo snippet 53 di un
 *   sito e il modulo editor-testo-nero di mc-funzioni): testo nero nell'area di scrittura, anche nell'editor in iframe
 *   (enqueue_block_assets, solo in amministrazione).
 * - Pagina di accesso (scelta spenta di base, versione leggera): solo CSS su login_enqueue_scripts, logo del sito
 *   (logo personalizzato del tema o icona del sito, altrimenti il titolo come testo) al posto di quello di WordPress,
 *   link del logo verso il sito (login_headerurl), pulsanti e link nel colore del brand. Nessun cambio a indirizzo,
 *   campi, passaggi o protezioni; nessuna risorsa esterna (le immagini sono quelle del sito).
 */

defined( 'ABSPATH' ) || exit;

const DS_CORE_AB_SCHEMA = 'ds-brand';

/** Scelte del modulo. */
function ds_core_ab_valori() {
	return ds_core_opzioni_modulo( 'admin-branding' );
}

/** Colore del brand: scelto nel pannello, altrimenti dal design del sito, altrimenti il blu di WordPress. */
function ds_core_ab_colore() {
	$valori = ds_core_ab_valori();
	$colore = sanitize_hex_color( (string) ( $valori['colore'] ?? '' ) );
	if ( ! $colore ) {
		$colore = ds_core_colore_dal_sito();
	}
	return $colore ? strtolower( $colore ) : '#2271b1';
}

/**
 * Colori derivati dal brand, tutti #rrggbb (sicuri da scrivere nel CSS): fondo e testo dei pulsanti e della voce di
 * menu scelta, le due tonalità più scure per hover e premuto, link sulla Bacheca, colore evidenziato sul menu scuro.
 */
function ds_core_ab_tavolozza() {
	static $tavolozza = null;
	if ( null !== $tavolozza ) {
		return $tavolozza;
	}
	$brand     = ds_core_ab_colore();
	$leggibile = ds_core_colore_leggibile( $brand );
	$link      = ds_core_colore_su( $brand, '#f0f0f1' );
	$tavolozza = array(
		'brand'    => $brand,
		'fondo'    => $leggibile['fondo'],
		'testo'    => $leggibile['testo'],
		'fondo_10' => ds_core_colore_mescola( $leggibile['fondo'], '#ffffff' === $leggibile['testo'] ? 'scuro' : 'chiaro', 0.1 ),
		'fondo_20' => ds_core_colore_mescola( $leggibile['fondo'], '#ffffff' === $leggibile['testo'] ? 'scuro' : 'chiaro', 0.2 ),
		'link'     => $link,
		'link_10'  => ds_core_colore_mescola( $link, 'scuro', 0.1 ),
		'link_20'  => ds_core_colore_mescola( $link, 'scuro', 0.2 ),
		'su_menu'  => ds_core_colore_su( $brand, '#2c3338' ),
	);
	return $tavolozza;
}

/* ---------- Schema colori della Bacheca ---------- */

add_action( 'admin_init', 'ds_core_ab_registra' );
function ds_core_ab_registra() {
	$t = ds_core_ab_tavolozza();
	wp_admin_css_color(
		DS_CORE_AB_SCHEMA,
		__( 'Site brand', 'ds-core' ),
		DS_CORE_URL . 'assets/admin-branding.css?ver=' . rawurlencode( DS_CORE_VERSIONE ),
		array( '#1d2327', '#2c3338', $t['fondo'], $t['su_menu'] ),
		array(
			'base'    => '#a7aaad',
			'focus'   => $t['su_menu'],
			'current' => $t['testo'],
		)
	);
	// Schema imposto a tutti: la scelta nel profilo non servirebbe, quindi non si mostra.
	if ( empty( ds_core_ab_valori()['propri'] ) ) {
		remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
	}
}

/**
 * Schema di ogni utente: «Site brand», salvo la scelta «Let each user keep…» e un altro schema scelto nel profilo
 * («fresh», il predefinito di WordPress, non conta come scelta).
 */
add_filter( 'get_user_option_admin_color', 'ds_core_ab_schema_utente', 10, 1 );
function ds_core_ab_schema_utente( $schema ) {
	if ( ! empty( ds_core_ab_valori()['propri'] ) && is_string( $schema ) && '' !== $schema && 'fresh' !== $schema ) {
		return $schema;
	}
	return DS_CORE_AB_SCHEMA;
}

/** Variabili CSS dei colori del brand (per lo schema e per l'editor a blocchi). Solo colori #rrggbb e numeri. */
function ds_core_ab_css_variabili() {
	$t   = ds_core_ab_tavolozza();
	$rgb = ds_core_colore_rgb( $t['link'] );
	$wp  = '--wp-admin-theme-color:' . $t['link'] . ';--wp-admin-theme-color--rgb:' . implode( ',', array_map( 'intval', (array) $rgb ) ) . ';--wp-admin-theme-color-darker-10:' . $t['link_10'] . ';--wp-admin-theme-color-darker-20:' . $t['link_20'] . ';';
	return ':root{--ds-ab-fondo:' . $t['fondo'] . ';--ds-ab-testo:' . $t['testo'] . ';--ds-ab-fondo-10:' . $t['fondo_10'] . ';--ds-ab-fondo-20:' . $t['fondo_20'] . ';--ds-ab-link:' . $t['link'] . ';--ds-ab-link-10:' . $t['link_10'] . ';--ds-ab-su-menu:' . $t['su_menu'] . ';' . $wp . '}'
		. 'body.admin-color-' . DS_CORE_AB_SCHEMA . '{' . $wp . '}';
}

add_action( 'admin_enqueue_scripts', 'ds_core_ab_variabili' );
function ds_core_ab_variabili() {
	if ( DS_CORE_AB_SCHEMA !== get_user_option( 'admin_color' ) ) {
		return;
	}
	wp_add_inline_style( 'colors', ds_core_ab_css_variabili() );
}

/* ---------- Editor a blocchi: testo nero (scelta) ---------- */

add_action( 'enqueue_block_assets', 'ds_core_ab_editor' );
function ds_core_ab_editor() {
	if ( ! is_admin() || empty( ds_core_ab_valori()['editor_nero'] ) ) {
		return;
	}
	// Nessun file: solo il blocco in linea, che WordPress porta anche dentro l'editor in iframe.
	wp_register_style( 'ds-core-ab-editor', false, array(), DS_CORE_VERSIONE );
	wp_enqueue_style( 'ds-core-ab-editor' );
	wp_add_inline_style( 'ds-core-ab-editor', '.editor-styles-wrapper,.editor-styles-wrapper.block-editor-writing-flow{color:#000 !important}' );
}

/* ---------- Pagina di accesso (scelta, spenta di base) ---------- */

/** La scelta «Show the site logo and brand color on the login page» è accesa. */
function ds_core_ab_login_acceso() {
	return ! empty( ds_core_ab_valori()['login'] );
}

/** Immagine del logo per la pagina di accesso: logo del tema, poi icona del sito; '' se nessuna. */
function ds_core_ab_logo() {
	$logo = (int) get_theme_mod( 'custom_logo' );
	if ( $logo ) {
		$immagine = wp_get_attachment_image_src( $logo, 'medium' );
		if ( is_array( $immagine ) && ! empty( $immagine[0] ) ) {
			return (string) $immagine[0];
		}
	}
	return (string) get_site_icon_url( 192 );
}

add_action( 'login_enqueue_scripts', 'ds_core_ab_login_stile' );
function ds_core_ab_login_stile() {
	if ( ! ds_core_ab_login_acceso() ) {
		return;
	}
	$t    = ds_core_ab_tavolozza();
	$logo = esc_url_raw( ds_core_ab_logo() );
	$css  = '';
	if ( '' !== $logo ) {
		// esc_url_raw toglie virgolette, barre rovesciate e parentesi angolari: l'indirizzo non può uscire da url("…").
		$css .= '.login h1 a{background-image:url("' . $logo . '");background-size:contain;background-position:center;width:100%;max-width:320px;height:84px}';
	} else {
		// Niente logo né icona: il titolo del sito come testo, al posto del logo di WordPress.
		$css .= '.login h1 a{background-image:none;text-indent:0;width:auto;height:auto;font-size:22px;line-height:1.3;font-weight:600;color:#1d2327;overflow:visible}';
	}
	$css .= '.login form{border-top:4px solid ' . $t['fondo'] . '}';
	$css .= '.wp-core-ui .button-primary{background:' . $t['fondo'] . ';border-color:' . $t['fondo'] . ';color:' . $t['testo'] . '}';
	$css .= '.wp-core-ui .button-primary:hover,.wp-core-ui .button-primary:focus{background:' . $t['fondo_10'] . ';border-color:' . $t['fondo_10'] . ';color:' . $t['testo'] . '}';
	$css .= '.wp-core-ui .button-primary:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px ' . $t['link'] . '}';
	$css .= '.wp-core-ui .button-secondary,.login .button.wp-hide-pw{color:' . $t['link'] . '}';
	$css .= '.login #nav a:hover,.login #backtoblog a:hover,.login h1 a:focus,.login a:focus{color:' . $t['link'] . '}';
	$css .= '.login input[type=text]:focus,.login input[type=password]:focus,.login input[type=email]:focus,.login input[type=checkbox]:focus{border-color:' . $t['link'] . ';box-shadow:0 0 0 1px ' . $t['link'] . '}';
	$css .= '.login .message,.login .notice-info{border-left-color:' . $t['link'] . '}';
	wp_add_inline_style( 'login', $css );
}

add_filter( 'login_headerurl', 'ds_core_ab_login_url' );
function ds_core_ab_login_url( $url ) {
	return ds_core_ab_login_acceso() ? home_url( '/' ) : $url;
}

add_filter( 'login_headertext', 'ds_core_ab_login_testo' );
function ds_core_ab_login_testo( $testo ) {
	return ds_core_ab_login_acceso() ? wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) : $testo;
}

/* ---------- Pannello ---------- */

/** Stato a parole per la riga di riepilogo. */
function ds_core_ab_riepilogo() {
	$t = ds_core_ab_tavolozza();
	if ( $t['fondo'] !== $t['brand'] ) {
		/* translators: %s: colour code. */
		return sprintf( __( '“Site brand” scheme on, with the readable shade %s', 'ds-core' ), $t['fondo'] );
	}
	return __( '“Site brand” scheme on', 'ds-core' );
}

<?php
/**
 * Modulo rest-protected-hidden (dalla 0.17.0): i contenuti protetti da password non escono dall'API REST.
 *
 * WordPress nasconde il testo di un contenuto con password, ma nell'API REST ne mostra titolo, indirizzo, date e
 * autore a chiunque: chi elenca /wp/v2/pages (o cerca con /wp/v2/search) legge i titoli di contratti e pagine
 * riservate. Per chi non scrive contenuti (senza edit_posts: visitatori, clienti collegati dei negozi, iscritti)
 * questo modulo:
 * - toglie i contenuti con password dagli elenchi di ogni tipo di contenuto pubblico (rest_{tipo}_query);
 * - li toglie dalla ricerca (/wp/v2/search, rest_post_search_query);
 * - risponde alla lettura diretta (/wp/v2/pages/<id>) con l'errore che WordPress dà per un ID inesistente
 *   (rest_post_invalid_id, «Invalid post ID.», 404): non si capisce nemmeno che il contenuto esiste;
 * - li toglie dall'oEmbed (/oembed/1.0/embed, che ne mostrerebbe il titolo): 404 come per un indirizzo sconosciuto.
 *
 * Chi può modificare contenuti (edit_posts) o quel contenuto continua a vederli: l'editor a blocchi li usa.
 * Le pagine del sito non cambiano: la richiesta della password resta quella di WordPress.
 *
 * Base: modulo sicurezza-rest-pagine-protette di un plugin di sito (solo pagine, solo non collegati), esteso agli
 * articoli e ai tipi di contenuto pubblici e ai clienti collegati.
 */

defined( 'ABSPATH' ) || exit;

/** Vale per chi non scrive contenuti. $post facoltativo: chi può modificare quel contenuto lo vede. */
function ds_core_rpc_vale( $post = null ) {
	if ( current_user_can( 'edit_posts' ) ) {
		return false;
	}
	if ( $post instanceof WP_Post && current_user_can( 'edit_post', $post->ID ) ) {
		return false;
	}
	return true;
}

/** Il contenuto ha una password. */
function ds_core_rpc_protetto( $post ) {
	return $post instanceof WP_Post && '' !== (string) $post->post_password;
}

// I tipi di contenuto sono tutti registrati quando parte l'API REST.
add_action( 'rest_api_init', 'ds_core_rpc_aggancia', 0 );
function ds_core_rpc_aggancia() {
	foreach ( get_post_types( array( 'public' => true, 'show_in_rest' => true ) ) as $tipo ) {
		if ( 'attachment' === $tipo ) {
			continue; // gli allegati non hanno password
		}
		add_filter( 'rest_' . $tipo . '_query', 'ds_core_rpc_senza_password', PHP_INT_MAX );
		add_filter( 'rest_prepare_' . $tipo, 'ds_core_rpc_nega_lettura', PHP_INT_MAX, 3 );
	}
}

add_filter( 'rest_post_search_query', 'ds_core_rpc_senza_password', PHP_INT_MAX );

/** Elenchi e ricerca: niente contenuti con password. */
function ds_core_rpc_senza_password( $argomenti ) {
	if ( is_array( $argomenti ) && ds_core_rpc_vale() ) {
		$argomenti['has_password'] = false;
	}
	return $argomenti;
}

/** Lettura diretta (e ogni altra risposta con quel contenuto): come un ID che non esiste. */
function ds_core_rpc_nega_lettura( $risposta, $post, $richiesta ) {
	if ( ! ds_core_rpc_protetto( $post ) || ! ds_core_rpc_vale( $post ) ) {
		return $risposta;
	}
	// Testo e codice di WordPress (dominio predefinito, già tradotto): gli stessi di un ID inesistente.
	return new WP_REST_Response(
		array(
			'code'    => 'rest_post_invalid_id',
			'message' => __( 'Invalid post ID.' ), // phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- testo di WordPress.
			'data'    => array( 'status' => 404 ),
		),
		404
	);
}

// oEmbed: un contenuto con password è come un indirizzo sconosciuto.
add_filter( 'oembed_request_post_id', 'ds_core_rpc_oembed', PHP_INT_MAX );
function ds_core_rpc_oembed( $id ) {
	$post = $id ? get_post( (int) $id ) : null;
	if ( ds_core_rpc_protetto( $post ) && ds_core_rpc_vale( $post ) ) {
		return 0;
	}
	return $id;
}

/** Stato nella riga del modulo: quanti contenuti pubblicati hanno una password. */
function ds_core_rpc_riquadro() {
	global $wpdb;
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- un conteggio solo nel pannello.
	$quanti = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_password <> '' AND post_status IN ('publish','private','future')" );
	?>
	<p class="ds-accesso-stato">
		<?php
		if ( $quanti ) {
			printf(
				/* translators: %d: number of password-protected contents. */
				esc_html( _n( '%d password-protected content is hidden from the REST API for people who do not write content.', '%d password-protected contents are hidden from the REST API for people who do not write content.', $quanti, 'ds-core' ) ),
				(int) $quanti
			);
		} else {
			esc_html_e( 'No content has a password at the moment: the module will hide any you protect from now on.', 'ds-core' );
		}
		?>
	</p>
	<?php
}

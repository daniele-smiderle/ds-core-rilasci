<?php
/**
 * Aggiornatore firmato di DS Core (dalla 0.16.0; kb ARCH-08, docs/ds-core-rilasci.md, «Aggiornatore firmato»).
 * Caricato sempre, anche con l'interruttore d'emergenza acceso: non è un modulo, perché deve poter portare la
 * correzione di un modulo guasto.
 *
 * Cosa fa, dentro il flusso standard di WordPress (nessun secondo aggiornatore):
 * - Controllo. Con «Update URI: ds-core» nell'intestazione WordPress non chiede DS Core a wordpress.org e passa dal
 *   filtro update_plugins_{host}: qui si legge il manifest del canale scelto (manifest-<canale>.json) all'indirizzo
 *   dei rilasci, si controlla e si offre la versione nuova. WordPress la mostra in Bacheca › Aggiornamenti e
 *   nell'elenco dei plugin, come per gli altri.
 * - Dettagli. plugins_api risponde per lo slug ds-core (finestra «Visualizza i dettagli»), senza chiedere a
 *   wordpress.org.
 * - Installazione. upgrader_pre_download: ogni aggiornamento di DS Core, chiunque lo avvii (clic, aggiornamento
 *   automatico, WP-CLI), scarica il pacchetto qui e lo consegna a WordPress solo se dimensione, SHA-256, firma Ed25519
 *   e versione dentro lo zip coincidono con il manifest. Altrimenti l'aggiornamento si ferma con un errore di
 *   WordPress, allarme nel registro delle attività e avviso di sicurezza (tipo aggiornatore.firma). Un pacchetto che
 *   non viene dal manifest firmato non si installa.
 * - Quando aggiornare lo decide il modulo aggiornamenti (DS Core in automatico anche sui negozi, kb ARCH-09). Senza il
 *   modulo vale solo il filtro qui sotto, che chiede a WordPress di aggiornare DS Core da solo.
 *
 * Firma: Ed25519 puro (RFC 8032) sui byte dello zip, 64 byte in base64, chiave pubblica qui sotto (non è un segreto;
 * la privata non lascia mai il PC di chi firma). Verifica con sodium_crypto_sign_verify_detached(), inclusa in PHP o
 * nella copia di libsodium di WordPress (sodium_compat).
 *
 * Indirizzo dei rilasci e canale: impostazioni generali di DS Core (opzione ds_core_generali, chiavi 'rilasci' e
 * 'canale'), salvate nel database del sito. L'indirizzo non sta nel codice: il pacchetto è pubblico e non nomina
 * account né persone (docs/ds-core-regole.md, «Pacchetto pubblico» e «Nome di Daniele»). Vuoto = nessun controllo.
 *
 * Opzioni: ds_core_rilasci_offerta (ultimo manifest valido, letto dalla verifica del pacchetto), ds_core_rilasci_stato
 * (ultimo controllo, per il pannello e per non ripetere eventi e mail). Transient ds_core_rilasci_<md5> (manifest per
 * un'ora, errori per 15 minuti; «Controlla di nuovo» in Bacheca › Aggiornamenti lo salta).
 */

defined( 'ABSPATH' ) || exit;

/** Chiave pubblica Ed25519 dei rilasci, base64 dei 32 byte (docs/ds-core-rilasci.md). */
const DS_CORE_RILASCI_CHIAVE = '52/kBYh4HgvL/bcbSXi2lDDx3CiYlYvFnhmKFkRyhig=';

/** Impronta della chiave: primi 16 caratteri esadecimali dello SHA-256 dei 32 byte. La scrive il manifest («chiave»). */
const DS_CORE_RILASCI_IMPRONTA = '09beb996dd47e680';

/** Valore di «Update URI» nell'intestazione di ds-core.php: serve solo a instradare il filtro update_plugins_{host}. */
const DS_CORE_RILASCI_URI = 'ds-core';

/** Dimensione massima accettata per un pacchetto: 20 MB. */
const DS_CORE_RILASCI_MAX = 20971520;

/** Durata della copia del manifest: un'ora (gli errori 15 minuti). */
const DS_CORE_RILASCI_CACHE = 3600;

/** Motivi di rifiuto che sono un problema di firma: allarme e avviso di sicurezza. */
function ds_core_rilasci_motivi_firma() {
	return array( 'senza-firma', 'algoritmo', 'chiave', 'prova', 'firma', 'sha256', 'dimensione', 'versione-zip', 'vecchia', 'pacchetto', 'sodium' );
}

/** File del plugin come lo vede WordPress (ds-core/ds-core.php). */
function ds_core_rilasci_file() {
	return plugin_basename( DS_CORE_FILE );
}

/** Host derivato da «Update URI» esattamente come fa WordPress in wp_update_plugins(). */
function ds_core_rilasci_host() {
	$host = wp_parse_url( sanitize_url( DS_CORE_RILASCI_URI ), PHP_URL_HOST );
	return is_string( $host ) && '' !== $host ? strtolower( $host ) : DS_CORE_RILASCI_URI;
}

/* ---------- Impostazioni ---------- */

/**
 * Indirizzo predefinito dei rilasci firmati (repository pubblico). Non è un segreto: i siti installano solo pacchetti
 * firmati con la chiave dei rilasci. Il campo «Release address» del pannello, se compilato, lo sostituisce.
 */
if ( ! defined( 'DS_CORE_RILASCI_PREDEFINITO' ) ) {
	define( 'DS_CORE_RILASCI_PREDEFINITO', 'https://raw.githubusercontent.com/daniele-smiderle/ds-core-rilasci/main/' );
}

/** Canale scelto nelle impostazioni generali: 'stabile' (predefinito) o 'test'. */
function ds_core_rilasci_canale() {
	$generali = ds_core_opzioni_modulo( 'ds-core' );
	return isset( $generali['canale'] ) && 'test' === $generali['canale'] ? 'test' : 'stabile';
}

/**
 * Indirizzo di base dei rilasci (https, con la barra finale) o '' se manca o non è valido. Il manifest e i pacchetti
 * con indirizzo relativo stanno sotto questo indirizzo.
 */
function ds_core_rilasci_base() {
	$generali = ds_core_opzioni_modulo( 'ds-core' );
	$scelto   = trim( (string) ( $generali['rilasci'] ?? '' ) );
	return ds_core_rilasci_url_base( '' !== $scelto ? $scelto : DS_CORE_RILASCI_PREDEFINITO );
}

/** Normalizza un indirizzo di base: solo https, con host, senza utente, query o frammento; barra finale aggiunta. */
function ds_core_rilasci_url_base( $url ) {
	$url   = trim( (string) $url );
	$parti = '' !== $url ? wp_parse_url( $url ) : false;
	if ( ! is_array( $parti ) || 'https' !== strtolower( (string) ( $parti['scheme'] ?? '' ) ) || empty( $parti['host'] )
		|| isset( $parti['user'] ) || isset( $parti['pass'] ) || isset( $parti['query'] ) || isset( $parti['fragment'] ) ) {
		return '';
	}
	return rtrim( $url, '/' ) . '/';
}

/* ---------- Firma ---------- */

/** Impronta (16 caratteri esadecimali) di una chiave pubblica base64. */
function ds_core_rilasci_impronta( $pubblica_b64 ) {
	$byte = base64_decode( (string) $pubblica_b64, true );
	return false === $byte ? '' : substr( hash( 'sha256', $byte ), 0, 16 );
}

/** La funzione di verifica Ed25519 c'è (PHP o sodium_compat di WordPress)? */
function ds_core_rilasci_sodium() {
	if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) && defined( 'WPINC' ) && file_exists( ABSPATH . WPINC . '/sodium_compat/autoload.php' ) ) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
	}
	return function_exists( 'sodium_crypto_sign_verify_detached' );
}

/** Verifica Ed25519 della firma (base64) sui byte dati, con la chiave pubblica dei rilasci. */
function ds_core_rilasci_firma_valida( $byte, $firma_b64 ) {
	$firma    = base64_decode( (string) $firma_b64, true );
	$pubblica = base64_decode( DS_CORE_RILASCI_CHIAVE, true );
	if ( false === $firma || 64 !== strlen( $firma ) || false === $pubblica || 32 !== strlen( $pubblica ) ) {
		return false;
	}
	try {
		return true === sodium_crypto_sign_verify_detached( $firma, (string) $byte, $pubblica );
	} catch ( \Throwable $e ) {
		return false;
	}
}

/* ---------- Manifest ---------- */

/**
 * Controlla un manifest decodificato. Restituisce il manifest pulito (con l'indirizzo completo del pacchetto) oppure
 * un WP_Error con il codice del motivo (ds_core_rilasci_motivo_testo()).
 */
function ds_core_rilasci_valida( $m, $canale, $base ) {
	if ( ! is_array( $m ) ) {
		return new WP_Error( 'formato' );
	}
	if ( 'ds-core' !== ( $m['plugin'] ?? '' ) ) {
		return new WP_Error( 'formato' );
	}
	if ( $canale !== ( $m['canale'] ?? '' ) ) {
		return new WP_Error( 'canale' );
	}
	$versione = (string) ( $m['versione'] ?? '' );
	if ( ! preg_match( '/^\d{1,4}\.\d{1,4}\.\d{1,4}(?:-[0-9A-Za-z.]{1,20})?$/', $versione ) ) {
		return new WP_Error( 'formato' );
	}
	if ( ! empty( $m['prova'] ) ) {
		return new WP_Error( 'prova', '', $versione );
	}
	if ( empty( $m['firma'] ) ) {
		return new WP_Error( 'senza-firma', '', $versione );
	}
	if ( 'ed25519' !== ( $m['algoritmo'] ?? '' ) ) {
		return new WP_Error( 'algoritmo', '', $versione );
	}
	if ( DS_CORE_RILASCI_IMPRONTA !== ( $m['chiave'] ?? '' ) ) {
		return new WP_Error( 'chiave', '', $versione );
	}
	$firma = base64_decode( (string) $m['firma'], true );
	if ( false === $firma || 64 !== strlen( $firma ) ) {
		return new WP_Error( 'senza-firma', '', $versione );
	}
	$sha256 = strtolower( (string) ( $m['sha256'] ?? '' ) );
	if ( ! preg_match( '/^[0-9a-f]{64}$/', $sha256 ) ) {
		return new WP_Error( 'formato' );
	}
	$dimensione = $m['dimensione'] ?? 0;
	if ( ! is_int( $dimensione ) || $dimensione < 1 || $dimensione > DS_CORE_RILASCI_MAX ) {
		return new WP_Error( 'formato' );
	}
	$pacchetto = ds_core_rilasci_url_pacchetto( (string) ( $m['pacchetto'] ?? '' ), $base );
	if ( '' === $pacchetto ) {
		return new WP_Error( 'pacchetto', '', $versione );
	}
	$pulito = array(
		'versione'   => $versione,
		'canale'     => $canale,
		'pacchetto'  => $pacchetto,
		'dimensione' => $dimensione,
		'sha256'     => $sha256,
		'firma'      => (string) $m['firma'],
		'firmato'    => is_string( $m['firmato'] ?? null ) ? substr( $m['firmato'], 0, 25 ) : '',
	);
	// Campi facoltativi per la schermata di WordPress (scritti a mano nel manifest, restano dopo la firma).
	foreach ( array( 'requires', 'tested', 'requires_php' ) as $campo ) {
		if ( isset( $m[ $campo ] ) && is_string( $m[ $campo ] ) && preg_match( '/^\d{1,2}(?:\.\d{1,2}){0,2}$/', $m[ $campo ] ) ) {
			$pulito[ $campo ] = $m[ $campo ];
		}
	}
	if ( isset( $m['note'] ) && is_string( $m['note'] ) ) {
		$pulito['note'] = substr( sanitize_textarea_field( $m['note'] ), 0, 2000 );
	}
	return $pulito;
}

/**
 * Indirizzo completo del pacchetto: un percorso relativo all'indirizzo dei rilasci (pacchetti/ds-core-0.16.0.zip),
 * senza «..», oppure un indirizzo https. Sempre un file .zip. '' se non va bene.
 */
function ds_core_rilasci_url_pacchetto( $pacchetto, $base ) {
	$pacchetto = trim( $pacchetto );
	if ( '' === $pacchetto || ! preg_match( '/\.zip$/i', $pacchetto ) ) {
		return '';
	}
	if ( preg_match( '#^https://#i', $pacchetto ) ) {
		$parti = wp_parse_url( $pacchetto );
		return is_array( $parti ) && ! empty( $parti['host'] ) && ! isset( $parti['user'] ) && ! isset( $parti['pass'] ) ? $pacchetto : '';
	}
	if ( '' === $base || ! preg_match( '#^[A-Za-z0-9_][A-Za-z0-9._-]*(?:/[A-Za-z0-9_][A-Za-z0-9._-]*)*$#', $pacchetto ) || str_contains( $pacchetto, '..' ) ) {
		return '';
	}
	return $base . $pacchetto;
}

/**
 * Manifest del canale scelto: array pulito oppure WP_Error (codice = motivo). Copia per un'ora (errori 15 minuti);
 * $fresco = true la salta.
 */
function ds_core_rilasci_manifest( $fresco = false ) {
	$base = ds_core_rilasci_base();
	if ( '' === $base ) {
		return new WP_Error( 'indirizzo' );
	}
	$canale = ds_core_rilasci_canale();
	$cache  = 'ds_core_rilasci_' . md5( $base . '|' . $canale );
	if ( ! $fresco ) {
		$copia = get_transient( $cache );
		if ( is_array( $copia ) && isset( $copia['esito'] ) ) {
			return is_array( $copia['esito'] ) ? $copia['esito'] : new WP_Error( (string) $copia['esito'], '', $copia['versione'] ?? '' );
		}
	}

	$risposta = wp_safe_remote_get(
		$base . 'manifest-' . $canale . '.json',
		array(
			'timeout'             => 10,
			'redirection'         => 3,
			'limit_response_size' => 65536,
			// Niente indirizzo del sito nell'agente (quello predefinito di WordPress lo contiene).
			'user-agent'          => 'DS Core/' . DS_CORE_VERSIONE . '; WordPress/' . get_bloginfo( 'version' ),
			'headers'             => array( 'Accept' => 'application/json' ),
		)
	);
	if ( is_wp_error( $risposta ) || 200 !== (int) wp_remote_retrieve_response_code( $risposta ) ) {
		$esito = new WP_Error( 'rete' );
	} else {
		$esito = ds_core_rilasci_valida( json_decode( (string) wp_remote_retrieve_body( $risposta ), true ), $canale, $base );
	}
	set_transient(
		$cache,
		array(
			'esito'    => is_wp_error( $esito ) ? $esito->get_error_code() : $esito,
			'versione' => is_wp_error( $esito ) ? (string) $esito->get_error_data() : '',
		),
		is_wp_error( $esito ) ? 15 * MINUTE_IN_SECONDS : DS_CORE_RILASCI_CACHE
	);
	return $esito;
}

/** Ultimo manifest valido (per la verifica del pacchetto e per i dettagli), o null. */
function ds_core_rilasci_offerta() {
	$offerta = get_option( 'ds_core_rilasci_offerta', false );
	return is_array( $offerta ) && ! empty( $offerta['pacchetto'] ) && ! empty( $offerta['firma'] ) ? $offerta : null;
}

/* ---------- Controllo: la versione nuova a WordPress ---------- */

add_filter( 'update_plugins_' . ds_core_rilasci_host(), 'ds_core_rilasci_offri', 10, 4 );

/**
 * Risposta per wp_update_plugins(): la versione del manifest con il pacchetto. WordPress la mette fra gli
 * aggiornamenti se è più nuova di quella installata. Con un errore nessuna offerta (resta la versione installata).
 */
function ds_core_rilasci_offri( $update, $plugin_data, $plugin_file, $locales = array() ) {
	if ( ds_core_rilasci_file() !== $plugin_file ) {
		return $update;
	}
	// «Controlla di nuovo» in Bacheca › Aggiornamenti: manifest fresco.
	$manifest = ds_core_rilasci_manifest( doing_action( 'load-update-core.php' ) );
	if ( is_wp_error( $manifest ) ) {
		ds_core_rilasci_esito( $manifest->get_error_code(), (string) $manifest->get_error_data() );
		return $update;
	}
	update_option( 'ds_core_rilasci_offerta', $manifest, false );
	$nuova = version_compare( $manifest['versione'], DS_CORE_VERSIONE, '>' );
	ds_core_rilasci_esito( $nuova ? 'nuova' : 'aggiornato', $manifest['versione'] );
	return ds_core_rilasci_dati_wordpress( $manifest );
}

/** Dati nel formato di update_plugins_{host}. */
function ds_core_rilasci_dati_wordpress( $manifest ) {
	$dati = array(
		'slug'    => 'ds-core',
		'version' => $manifest['versione'],
		'package' => $manifest['pacchetto'],
		'url'     => '',
		'icons'   => array(),
	);
	foreach ( array( 'requires', 'tested', 'requires_php' ) as $campo ) {
		if ( isset( $manifest[ $campo ] ) ) {
			$dati[ $campo ] = $manifest[ $campo ];
		}
	}
	return $dati;
}

/**
 * Annota l'esito di un controllo o di un'installazione. Evento nel registro solo quando l'esito cambia (stesso esito,
 * versione e canale: niente righe ripetute a ogni controllo); per i motivi di firma allarme e avviso di sicurezza.
 */
function ds_core_rilasci_esito( $esito, $versione = '', $fase = 'controllo' ) {
	$prima  = get_option( 'ds_core_rilasci_stato', array() );
	$prima  = is_array( $prima ) ? $prima : array();
	$canale = ds_core_rilasci_canale();
	$stato  = array(
		'quando'   => time(),
		'esito'    => (string) $esito,
		'versione' => (string) $versione,
		'canale'   => $canale,
		'fase'     => (string) $fase,
		'avvisato' => (string) ( $prima['avvisato'] ?? '' ),
	);
	$cambiato = ( $prima['esito'] ?? '' ) !== $stato['esito'] || ( $prima['versione'] ?? '' ) !== $stato['versione'] || ( $prima['canale'] ?? '' ) !== $canale;

	if ( in_array( $esito, ds_core_rilasci_motivi_firma(), true ) ) {
		// Mail al più una volta per motivo e versione ogni 7 giorni; registro a ogni rifiuto di un pacchetto.
		$chiave = $esito . '|' . $versione;
		if ( $cambiato || 'pacchetto' === $fase ) {
			ds_core_rilasci_evento( 'rifiutato', 3, array( 'motivo' => $esito, 'versione' => $versione, 'fase' => $fase ) );
		}
		if ( $chiave !== $stato['avvisato'] || (int) ( $prima['avvisato_quando'] ?? 0 ) < time() - 7 * DAY_IN_SECONDS ) {
			ds_core_rilasci_avviso( $esito, $versione, $fase );
			$stato['avvisato']        = $chiave;
			$stato['avvisato_quando'] = time();
		} else {
			$stato['avvisato_quando'] = (int) ( $prima['avvisato_quando'] ?? 0 );
		}
	} else {
		$stato['avvisato_quando'] = (int) ( $prima['avvisato_quando'] ?? 0 );
		if ( $cambiato ) {
			if ( 'nuova' === $esito ) {
				ds_core_rilasci_evento( 'disponibile', 1, array( 'versione' => $versione, 'canale' => $canale ) );
			} elseif ( 'verificato' === $esito ) {
				ds_core_rilasci_evento( 'verificato', 1, array( 'versione' => $versione ) );
			} elseif ( 'aggiornato' !== $esito ) {
				ds_core_rilasci_evento( 'errore', 2, array( 'motivo' => $esito, 'fase' => $fase ) );
			}
		}
	}
	update_option( 'ds_core_rilasci_stato', $stato, false );
}

/** Evento del registro delle attività (tipo dscore.update). */
function ds_core_rilasci_evento( $azione, $livello, $dati = array() ) {
	ds_core_registra_evento(
		'dscore.update',
		array(
			'livello' => $livello,
			'origine' => 'ds-core',
			'oggetto' => 'ds-core',
			'dati'    => array_merge( array( 'azione' => $azione ), $dati ),
		)
	);
}

/** Avviso di sicurezza: aggiornamento di DS Core rifiutato o non verificabile. Nella lingua del sito. */
function ds_core_rilasci_avviso( $motivo, $versione, $fase ) {
	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	/* translators: %s: site title. */
	$oggetto = sprintf( __( '[%s] DS Core update refused: signature check failed', 'ds-core' ), $sito );
	$righe   = array(
		/* translators: 1: version number, 2: site address. */
		sprintf( __( 'An update of DS Core to version %1$s has been refused on %2$s.', 'ds-core' ), '' !== $versione ? $versione : '?', home_url( '/' ) ),
		'',
		/* translators: %s: reason. */
		sprintf( __( 'Reason: %s', 'ds-core' ), ds_core_rilasci_motivo_testo( $motivo ) ),
		/* translators: %s: "update check" or "package download". */
		sprintf( __( 'When: %s', 'ds-core' ), 'pacchetto' === $fase ? __( 'while installing the package', 'ds-core' ) : __( 'while checking for updates', 'ds-core' ) ),
		/* translators: %s: update channel. */
		sprintf( __( 'Channel: %s', 'ds-core' ), ds_core_rilasci_canale_nome( ds_core_rilasci_canale() ) ),
		'',
		__( 'Nothing has been installed: DS Core stays at the current version.', 'ds-core' ),
		__( 'If no new release was expected, someone may have changed the release files: tell support before doing anything else.', 'ds-core' ),
		'',
		admin_url( 'admin.php?page=ds-core#ds-generali' ),
	);
	ds_core_manda_avviso( 'aggiornatore.firma', $oggetto, implode( "\n", $righe ) );
	if ( $cambiata ) {
		restore_previous_locale();
	}
}

/* ---------- Installazione: verifica del pacchetto ---------- */

// Priorità alta: decide l'aggiornatore anche se un altro filtro ha già scaricato il pacchetto di DS Core.
add_filter( 'upgrader_pre_download', 'ds_core_rilasci_scarica', 9999, 4 );

/**
 * Scarica e verifica il pacchetto di ogni aggiornamento di DS Core. Restituisce il file verificato (WordPress lo
 * estrae e poi lo cancella) oppure un WP_Error che ferma l'aggiornamento. Gli altri pacchetti passano invariati.
 * Il caricamento manuale di uno zip (Plugin › Aggiungi nuovo › Carica plugin) non passa da qui: è la strada del primo
 * ingresso, con l'impronta controllata a mano prima (docs/ds-core-rilasci.md).
 */
function ds_core_rilasci_scarica( $reply, $package, $upgrader = null, $hook_extra = array() ) {
	$offerta = ds_core_rilasci_offerta();
	$nostro  = ( is_array( $hook_extra ) && ds_core_rilasci_file() === ( $hook_extra['plugin'] ?? '' ) )
		|| ( $offerta && is_string( $package ) && $package === $offerta['pacchetto'] );
	if ( ! $nostro || is_wp_error( $reply ) ) {
		return $reply;
	}
	if ( is_string( $reply ) && '' !== $reply && file_exists( $reply ) && $reply !== $package ) {
		wp_delete_file( $reply ); // Scaricato da altri: si riscarica e si verifica qui.
	}
	if ( ! $offerta || ! is_string( $package ) || $package !== $offerta['pacchetto'] ) {
		ds_core_rilasci_esito( 'pacchetto', $offerta['versione'] ?? '', 'pacchetto' );
		return ds_core_rilasci_errore( 'pacchetto' );
	}
	if ( ! function_exists( 'download_url' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	if ( is_object( $upgrader ) && isset( $upgrader->skin ) && is_object( $upgrader->skin ) && method_exists( $upgrader->skin, 'feedback' ) ) {
		$upgrader->skin->feedback( 'downloading_package', $package );
	}
	$file = download_url( $package, 300 );
	if ( is_wp_error( $file ) ) {
		ds_core_rilasci_esito( 'scaricamento', $offerta['versione'], 'pacchetto' );
		return new WP_Error( 'download_failed', ds_core_rilasci_motivo_testo( 'scaricamento' ), $file->get_error_message() );
	}
	$esito = ds_core_rilasci_verifica_file( $file, $offerta );
	if ( true !== $esito ) {
		wp_delete_file( $file );
		ds_core_rilasci_esito( $esito, $offerta['versione'], 'pacchetto' );
		return ds_core_rilasci_errore( $esito );
	}
	ds_core_rilasci_esito( 'verificato', $offerta['versione'], 'pacchetto' );
	if ( is_object( $upgrader ) && isset( $upgrader->skin ) && is_object( $upgrader->skin ) && method_exists( $upgrader->skin, 'feedback' ) ) {
		$upgrader->skin->feedback( __( 'DS Core: package signature verified.', 'ds-core' ) );
	}
	return $file;
}

/** WP_Error che WordPress mostra come motivo dell'aggiornamento non riuscito. */
function ds_core_rilasci_errore( $motivo ) {
	return new WP_Error(
		'ds_core_firma',
		/* translators: %s: reason. */
		sprintf( __( 'DS Core update refused: %s Nothing was installed.', 'ds-core' ), ds_core_rilasci_motivo_testo( $motivo ) )
	);
}

/**
 * Controlli sul file scaricato, in ordine: dimensione, SHA-256, firma Ed25519 (il controllo vero), versione dentro lo
 * zip uguale a quella del manifest e più nuova di quella installata (niente ritorni a versioni vecchie firmate).
 * Restituisce true oppure il codice del motivo.
 */
function ds_core_rilasci_verifica_file( $file, $offerta ) {
	$dimensione = is_file( $file ) ? filesize( $file ) : false;
	if ( false === $dimensione || $dimensione !== (int) $offerta['dimensione'] || $dimensione > DS_CORE_RILASCI_MAX ) {
		return 'dimensione';
	}
	$byte = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- file locale appena scaricato.
	if ( false === $byte || ! hash_equals( (string) $offerta['sha256'], hash( 'sha256', $byte ) ) ) {
		return 'sha256';
	}
	if ( ! ds_core_rilasci_sodium() ) {
		return 'sodium';
	}
	if ( ! ds_core_rilasci_firma_valida( $byte, $offerta['firma'] ) ) {
		return 'firma';
	}
	unset( $byte );
	$versione = ds_core_rilasci_versione_zip( $file );
	if ( $versione !== (string) $offerta['versione'] ) {
		return 'versione-zip';
	}
	if ( ! version_compare( $versione, DS_CORE_VERSIONE, '>' ) ) {
		return 'vecchia';
	}
	return true;
}

/** Versione scritta in ds-core/ds-core.php dentro lo zip ('' se non si legge). ZipArchive o, senza, PclZip. */
function ds_core_rilasci_versione_zip( $file ) {
	$testo = false;
	if ( class_exists( 'ZipArchive' ) ) {
		$zip = new ZipArchive();
		if ( true === $zip->open( $file ) ) {
			$testo = $zip->getFromName( 'ds-core/ds-core.php' );
			$zip->close();
		}
	} else {
		if ( ! class_exists( 'PclZip' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		}
		$zip   = new PclZip( $file );
		$parti = $zip->extract( PCLZIP_OPT_BY_NAME, 'ds-core/ds-core.php', PCLZIP_OPT_EXTRACT_AS_STRING );
		$testo = is_array( $parti ) && isset( $parti[0]['content'] ) ? $parti[0]['content'] : false;
	}
	if ( ! is_string( $testo ) || ! preg_match( '/^[ \t\/*#@]*Version:\s*(\S+)/m', $testo, $m ) ) {
		return '';
	}
	return $m[1];
}

/* ---------- Dettagli della versione (finestra di WordPress) ---------- */

add_filter( 'plugins_api', 'ds_core_rilasci_dettagli', 10, 3 );

/** Risponde per lo slug ds-core senza chiedere a wordpress.org (dove un plugin con lo stesso slug non è il nostro). */
function ds_core_rilasci_dettagli( $risultato, $azione, $args ) {
	if ( 'plugin_information' !== $azione || ! is_object( $args ) || 'ds-core' !== ( $args->slug ?? '' ) ) {
		return $risultato;
	}
	$offerta = ds_core_rilasci_offerta();
	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$intestazione = get_plugin_data( DS_CORE_FILE, false, true );
	$note         = $offerta && ! empty( $offerta['note'] ) ? $offerta['note'] : __( 'Improvements and fixes.', 'ds-core' );
	$info         = array(
		'name'          => 'DS Core',
		'slug'          => 'ds-core',
		'version'       => $offerta ? $offerta['versione'] : DS_CORE_VERSIONE,
		'author'        => (string) ( $intestazione['Author'] ?? '' ),
		'requires'      => $offerta['requires'] ?? (string) ( $intestazione['RequiresWP'] ?? '' ),
		'tested'        => $offerta['tested'] ?? '',
		'requires_php'  => $offerta['requires_php'] ?? (string) ( $intestazione['RequiresPHP'] ?? '' ),
		'last_updated'  => $offerta ? $offerta['firmato'] : '',
		'download_link' => $offerta ? $offerta['pacchetto'] : '',
		'sections'      => array(
			'description' => wpautop( esc_html( (string) ( $intestazione['Description'] ?? '' ) ) ),
			'changelog'   => wpautop( esc_html( $note ) ),
		),
	);
	return (object) $info;
}

/* ---------- Aggiornamento automatico ---------- */

/*
 * kb ARCH-09: DS Core si aggiorna da solo su tutti i siti, negozi compresi. Priorità normale: il modulo aggiornamenti
 * (priorità 9999) può decidere diversamente con le scelte del sito. Se l'aggiornatore automatico di WordPress è spento
 * (per esempio da un sistema di aggiornamento dell'hosting) serve il modulo aggiornamenti, che lo riaccende.
 */
add_filter( 'auto_update_plugin', 'ds_core_rilasci_automatico', 10, 2 );
function ds_core_rilasci_automatico( $aggiorna, $elemento ) {
	return is_object( $elemento ) && ds_core_rilasci_file() === ( $elemento->plugin ?? '' ) ? true : $aggiorna;
}

/* ---------- Impostazioni salvate ---------- */

add_action( 'ds_core_impostazioni_salvate', 'ds_core_rilasci_impostazioni', 10, 3 );

/** Canale o indirizzo cambiati: evento nel registro, si dimentica l'offerta e WordPress ricontrolla. */
function ds_core_rilasci_impostazioni( $id, $prima, $dopo ) {
	if ( 'ds-core' !== $id ) {
		return;
	}
	$canale_prima    = ( $prima['canale'] ?? 'stabile' ) === 'test' ? 'test' : 'stabile';
	$canale_dopo     = ( $dopo['canale'] ?? 'stabile' ) === 'test' ? 'test' : 'stabile';
	$indirizzo_prima = ds_core_rilasci_url_base( (string) ( $prima['rilasci'] ?? '' ) );
	$indirizzo_dopo  = ds_core_rilasci_url_base( (string) ( $dopo['rilasci'] ?? '' ) );
	if ( $canale_prima === $canale_dopo && $indirizzo_prima === $indirizzo_dopo ) {
		return;
	}
	if ( $canale_prima !== $canale_dopo ) {
		ds_core_rilasci_evento( 'canale', 2, array( 'da' => $canale_prima, 'a' => $canale_dopo ) );
	}
	if ( $indirizzo_prima !== $indirizzo_dopo ) {
		ds_core_rilasci_evento( 'indirizzo', 2, array( 'da' => $indirizzo_prima, 'a' => $indirizzo_dopo ) );
	}
	ds_core_rilasci_dimentica();
}

/** Toglie offerta e stato e chiede a WordPress un controllo nuovo dei plugin. */
function ds_core_rilasci_dimentica() {
	delete_option( 'ds_core_rilasci_offerta' );
	delete_option( 'ds_core_rilasci_stato' );
	delete_site_transient( 'update_plugins' );
}

/* ---------- Testi ---------- */

/** Nome del canale, tradotto. */
function ds_core_rilasci_canale_nome( $canale ) {
	return 'test' === $canale ? _x( 'test', 'update channel', 'ds-core' ) : _x( 'stable', 'update channel', 'ds-core' );
}

/** Testo di un motivo (rifiuto o errore), tradotto. */
function ds_core_rilasci_motivo_testo( $motivo ) {
	$testi = array(
		'senza-firma'  => __( 'the release has no valid signature.', 'ds-core' ),
		'algoritmo'    => __( 'the release is signed with an unknown method.', 'ds-core' ),
		'chiave'       => __( 'the release is signed with a different key from the one built into DS Core.', 'ds-core' ),
		'prova'        => __( 'the release is marked as a signing test.', 'ds-core' ),
		'firma'        => __( 'the package signature does not match: the package has been altered or is not the signed one.', 'ds-core' ),
		'sha256'       => __( 'the package fingerprint (SHA-256) does not match the release.', 'ds-core' ),
		'dimensione'   => __( 'the package size does not match the release.', 'ds-core' ),
		'versione-zip' => __( 'the version inside the package is not the announced one.', 'ds-core' ),
		'vecchia'      => __( 'the package is not newer than the installed version.', 'ds-core' ),
		'pacchetto'    => __( 'the package does not come from the signed release.', 'ds-core' ),
		'sodium'       => __( 'this server cannot check Ed25519 signatures (sodium is missing).', 'ds-core' ),
		'scaricamento' => __( 'the package could not be downloaded.', 'ds-core' ),
		'rete'         => __( 'the release file could not be read.', 'ds-core' ),
		'formato'      => __( 'the release file is not valid.', 'ds-core' ),
		'canale'       => __( 'the release file belongs to another channel.', 'ds-core' ),
		'indirizzo'    => __( 'no release address is set.', 'ds-core' ),
	);
	return $testi[ $motivo ] ?? (string) $motivo;
}

/** Stato per il pannello, sotto l'indirizzo dei rilasci nelle impostazioni generali. HTML già escapato. */
function ds_core_rilasci_stato_html() {
	$base  = ds_core_rilasci_base();
	$stato = get_option( 'ds_core_rilasci_stato', array() );
	$stato = is_array( $stato ) ? $stato : array();
	$html  = '';
	if ( '' === $base ) {
		return '<p class="ds-avvisi-errata">' . ds_core_icona( 'attenzione' ) . '<span>' . esc_html__( 'No release address: DS Core does not look for its own updates on this site.', 'ds-core' ) . '</span></p>';
	}
	if ( ! empty( $stato['quando'] ) ) {
		$esito = (string) ( $stato['esito'] ?? '' );
		if ( 'nuova' === $esito ) {
			/* translators: %s: version number. */
			$testo = sprintf( __( 'version %s available', 'ds-core' ), $stato['versione'] );
		} elseif ( 'aggiornato' === $esito ) {
			$testo = __( 'DS Core is up to date', 'ds-core' );
		} elseif ( 'verificato' === $esito ) {
			/* translators: %s: version number. */
			$testo = sprintf( __( 'package %s verified and handed to WordPress', 'ds-core' ), $stato['versione'] );
		} else {
			$testo = ds_core_rilasci_motivo_testo( $esito );
		}
		$allarme = in_array( $esito, ds_core_rilasci_motivi_firma(), true );
		$html   .= '<p class="' . ( $allarme ? 'ds-avvisi-errata' : 'ds-avvisi-rotta' ) . '">' . ds_core_icona( $allarme ? 'attenzione' : 'attesa' ) . '<span>' . esc_html(
			sprintf(
				/* translators: 1: date and time, 2: update channel, 3: result. */
				__( 'Last check %1$s, %2$s channel: %3$s', 'ds-core' ),
				wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $stato['quando'] ),
				ds_core_rilasci_canale_nome( (string) ( $stato['canale'] ?? ds_core_rilasci_canale() ) ),
				$testo
			)
		) . '</span></p>';
	}
	$html .= '<p class="ds-campo-aiuto">' . esc_html(
		sprintf(
			/* translators: %s: key fingerprint. */
			__( 'A new version is installed only if its signature matches the key built into DS Core (fingerprint %s). To check now: Dashboard › Updates › Check again.', 'ds-core' ),
			DS_CORE_RILASCI_IMPRONTA
		)
	) . '</p>';
	return $html;
}

<?php
/**
 * Disinstallazione di DS Core: toglie le impostazioni del pannello, le scelte dei moduli di DS Core e la tabella del
 * registro delle attività.
 * I moduli che creano file o opzioni proprie li tolgono quando vengono spenti (vedi la loro voce nel registro).
 * Le scelte dei moduli di DS Woo e dei plugin dei siti restano: le cancella il loro plugin.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$ds_core_opzioni = array( 'ds_core_stati', 'ds_core_errori', 'ds_core_storia', 'ds_core_generali', 'ds_core_db', 'ds_core_accesso_fino', 'ds_core_accesso_nonce', 'ds_core_agg', 'ds_core_agg_visti', 'ds_core_agg_registro', 'ds_core_hd_stato', 'ds_core_ra_db', 'ds_core_avvisi_attesa', 'ds_core_emergenza_vista', 'ds_core_rilasci_offerta', 'ds_core_rilasci_stato' );

// Opzioni dichiarate dai moduli di DS Core nel registro (campo 'opzione', dalla 0.13.0).
if ( ! function_exists( 'ds_core_registro_core' ) ) {
	require_once __DIR__ . '/includes/registro.php';
}
foreach ( ds_core_registro_core() as $ds_core_modulo ) {
	if ( ! empty( $ds_core_modulo['opzione'] ) && is_string( $ds_core_modulo['opzione'] ) ) {
		$ds_core_opzioni[] = $ds_core_modulo['opzione'];
	}
}

foreach ( array_unique( $ds_core_opzioni ) as $ds_core_opzione ) {
	delete_option( $ds_core_opzione );
}
// Aspetto del pannello scelto da ogni amministratore.
delete_metadata( 'user', 0, 'ds_core_tema', '', true );
// Riepilogo giornaliero del modulo aggiornamenti.
wp_clear_scheduled_hook( 'ds_core_agg_riepilogo' );
// Scadenza di una richiesta di cambio dell'indirizzo degli avvisi (0.15.0).
wp_clear_scheduled_hook( 'ds_core_avvisi_scadenza' );

// Registro delle attività (0.14.0): tabella propria, pulizia e riepilogo settimanale, tentativo di creazione fallito.
global $wpdb;
$ds_core_tabella = $wpdb->prefix . 'ds_core_eventi';
// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabella propria, nome fisso.
$wpdb->query( "DROP TABLE IF EXISTS {$ds_core_tabella}" );
delete_transient( 'ds_core_ra_db_errore' );
wp_clear_scheduled_hook( 'ds_core_ra_pulizia' );
wp_clear_scheduled_hook( 'ds_core_ra_riepilogo' );

<?php
/**
 * Blocchi di DS Core nel .htaccess della radice, con il sistema di WordPress (insert_with_markers): ogni modulo ha il
 * suo blocco «# BEGIN DS Core <id>» … «# END DS Core <id>» e non tocca il resto del file.
 *
 * Regole:
 * - si scrive solo da una richiesta di amministrazione e solo se il contenuto cambia;
 * - dopo ogni scrittura si controllano la home e un file statico: se non rispondono 200, si rimette il file di prima;
 * - il blocco di un modulo si toglie quando il modulo si spegne e quando DS Core si disattiva (tutti i blocchi);
 * - l'interruttore d'emergenza DS_CORE_SPENTI non tocca il file: i blocchi restano finché il modulo non si spegne dal
 *   pannello o non si cancellano a mano (sono righe con i marcatori, facili da riconoscere).
 */

defined( 'ABSPATH' ) || exit;

/** Percorso del .htaccess della radice di WordPress. */
function ds_core_htaccess_file() {
	if ( ! function_exists( 'get_home_path' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	return get_home_path() . '.htaccess';
}

/** Il server legge il .htaccess? (Apache o LiteSpeed; Nginx no). */
function ds_core_htaccess_supportato() {
	$server = isset( $_SERVER['SERVER_SOFTWARE'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) ) : '';
	return false !== strpos( $server, 'apache' ) || false !== strpos( $server, 'litespeed' );
}

/**
 * Righe attuali del blocco di un modulo, senza i commenti (array vuoto se non c'è). I commenti si tolgono perché
 * insert_with_markers aggiunge in cima al blocco le sue righe di istruzioni.
 */
function ds_core_htaccess_leggi( $id ) {
	if ( ! function_exists( 'extract_from_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}
	$file = ds_core_htaccess_file();
	return file_exists( $file ) ? ds_core_htaccess_senza_commenti( extract_from_markers( $file, 'DS Core ' . $id ) ) : array();
}

/** Righe senza commenti e righe vuote, per confrontare due blocchi. */
function ds_core_htaccess_senza_commenti( $righe ) {
	return array_values(
		array_filter(
			array_map( 'trim', (array) $righe ),
			function ( $riga ) {
				return '' !== $riga && 0 !== strpos( $riga, '#' );
			}
		)
	);
}

/** Risposta della home e di un file statico di WordPress: true se entrambe 200. */
function ds_core_htaccess_sito_ok() {
	$prove = array(
		add_query_arg( 'ds_core_prova', time(), home_url( '/' ) ),
		includes_url( 'css/dashicons.min.css' ),
	);
	foreach ( $prove as $url ) {
		$risposta = wp_remote_get( $url, array( 'timeout' => 20, 'redirection' => 3, 'sslverify' => false ) );
		if ( is_wp_error( $risposta ) || 200 !== (int) wp_remote_retrieve_response_code( $risposta ) ) {
			return false;
		}
	}
	return true;
}

/**
 * Scrive il blocco di un modulo e controlla il sito. $righe vuoto = toglie il blocco.
 * Restituisce true, oppure un codice: 'non-supportato', 'non-scrivibile', 'sito-ko' (file di prima rimesso).
 */
function ds_core_htaccess_scrivi( $id, $righe ) {
	if ( ! ds_core_htaccess_supportato() ) {
		return 'non-supportato';
	}
	if ( ! function_exists( 'insert_with_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}
	$file = ds_core_htaccess_file();
	if ( ( file_exists( $file ) && ! wp_is_writable( $file ) ) || ( ! file_exists( $file ) && ! wp_is_writable( dirname( $file ) ) ) ) {
		ds_core_htaccess_evento( $id, 'non-scrivibile' );
		return 'non-scrivibile';
	}
	if ( ds_core_htaccess_senza_commenti( $righe ) === ds_core_htaccess_leggi( $id ) ) {
		return true;
	}
	$prima = file_exists( $file ) ? file_get_contents( $file ) : null;
	if ( ! $righe ) {
		// Togliere: via il blocco intero, marcatori compresi (insert_with_markers lascerebbe i marcatori vuoti).
		if ( null !== $prima ) {
			$pulito = preg_replace( '/^# BEGIN DS Core ' . preg_quote( $id, '/' ) . '\R.*?^# END DS Core ' . preg_quote( $id, '/' ) . '\R?/ms', '', $prima );
			if ( is_string( $pulito ) && $pulito !== $prima ) {
				file_put_contents( $file, $pulito );
				ds_core_htaccess_evento( $id, 'tolto' );
			}
		}
		return true;
	}
	if ( ! insert_with_markers( $file, 'DS Core ' . $id, (array) $righe ) ) {
		ds_core_htaccess_evento( $id, 'non-scrivibile' );
		return 'non-scrivibile';
	}
	if ( $righe && ! ds_core_htaccess_sito_ok() ) {
		if ( null === $prima ) {
			wp_delete_file( $file );
		} else {
			file_put_contents( $file, $prima );
		}
		ds_core_htaccess_evento( $id, 'ripristinato' );
		return 'sito-ko';
	}
	ds_core_htaccess_evento( $id, 'scritto' );
	return true;
}

/**
 * Registro delle attività (0.14.0): blocco scritto, tolto, file rimesso com'era, file non scrivibile (al più una
 * riga al giorno per modulo, perché il controllo si ripete ogni ora).
 */
function ds_core_htaccess_evento( $id, $azione ) {
	$livelli = array( 'scritto' => 2, 'tolto' => 2, 'ripristinato' => 3, 'non-scrivibile' => 2 );
	ds_core_registra_evento(
		'dscore.htaccess',
		array(
			'livello' => $livelli[ $azione ] ?? 2,
			'origine' => $id,
			'oggetto' => $id,
			'dati'    => array( 'azione' => $azione ),
			'ogni'    => 'non-scrivibile' === $azione ? DAY_IN_SECONDS : 0,
		)
	);
}

// Un modulo spento perde il suo blocco (se ne aveva uno).
add_action( 'ds_core_stato_cambiato', 'ds_core_htaccess_modulo_spento', 10, 3 );
function ds_core_htaccess_modulo_spento( $id, $prima, $dopo ) {
	if ( 'spento' === $dopo && ds_core_htaccess_leggi( $id ) ) {
		ds_core_htaccess_scrivi( $id, array() );
	}
}

/** Toglie tutti i blocchi di DS Core (disattivazione del plugin): «disattivare DS Core non lascia modifiche». */
function ds_core_htaccess_togli_tutti() {
	$file = ds_core_htaccess_file();
	if ( ! file_exists( $file ) || ! wp_is_writable( $file ) ) {
		return;
	}
	$testo = file_get_contents( $file );
	if ( false === $testo || false === strpos( $testo, '# BEGIN DS Core ' ) ) {
		return;
	}
	$pulito = preg_replace( '/^# BEGIN DS Core [a-z0-9-]+\R.*?^# END DS Core [a-z0-9-]+\R?/ms', '', $testo );
	if ( is_string( $pulito ) && $pulito !== $testo ) {
		file_put_contents( $file, $pulito );
	}
}

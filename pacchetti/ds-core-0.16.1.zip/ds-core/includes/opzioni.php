<?php
/**
 * Opzioni dei moduli e di DS Core (dalla 0.13.0). Caricato sempre, anche sul sito pubblico: poche funzioni, nessun
 * disegno. Il disegno e il salvataggio dei campi stanno in includes/impostazioni.php (solo amministrazione).
 *
 * Un modulo dichiara le sue scelte nel registro (includes/registro.php) con 'opzione' (nome dell'opzione nel
 * database) e 'campi' (elenco dei campi: tipo, predefinito, limiti, valori ammessi). DS Core le mostra e le salva
 * anche a modulo spento, senza eseguire codice del modulo; il modulo acceso le legge con:
 *
 *   $valori = ds_core_opzioni_modulo( 'my-module' );   // valori salvati, puliti, con i predefiniti
 *
 * Le scelte di DS Core stesso (l'indirizzo degli avvisi; il canale dell'aggiornatore, nascosto) sono il gruppo
 * riservato 'ds-core', opzione ds_core_generali: ds_core_opzioni_modulo( 'ds-core' ); l'indirizzo degli avvisi si
 * legge con ds_core_indirizzo_avvisi() (includes/avvisi.php, dalla 0.15.0 con la conferma del cambio).
 *
 * Tipi di campo (ds_core_tipi_campo()) e chiavi di ogni campo:
 * - tipo         text, email, url (solo https, dalla 0.16.0), number, checkbox, radio, select, checkboxes, plugins, color
 * - predefinito  valore quando il campo non è mai stato salvato (o il valore salvato non è valido)
 * - predefinito_da  facoltativo: funzione (nome o closure) che calcola il predefinito. Deve esistere anche a modulo
 *                spento, quindi sta nel file principale del plugin, non nel file del modulo
 * - min, max     number: limiti (i valori fuori si riconducono al limite); passo: 1 = numeri interi (predefinito)
 * - scelte       radio, select, checkboxes: valori ammessi (array di chiavi); i nomi visibili stanno nei testi
 * - lunghezza    text: lunghezza massima (predefinita 200)
 * - gruppo       facoltativo: chiave del gruppo, per un titolo sopra i campi dello stesso gruppo (testi 'gruppi')
 * - mostra_se    facoltativo: array( chiave di un altro campo, valore ): il campo si mostra solo con quel valore
 *                (JavaScript); senza JavaScript resta visibile e conta il modulo, che lo ignora con l'altro valore
 * - nascosto     facoltativo (dalla 0.16.1): true = il campo non si mostra e non si cambia dal pannello; il valore
 *                salvato resta com'è a ogni salvataggio (si legge come gli altri con ds_core_opzioni_modulo())
 *
 * I testi (etichetta, aiuto, unità, nomi delle scelte, titoli dei gruppi) stanno nella funzione 'testi' del modulo,
 * come titolo e descrizione, perché si traducono solo dopo init:
 *
 *   'campi'  => array( 'chiave' => array( 'etichetta' => …, 'aiuto' => …, 'unita' => …, 'scelte' => array( valore => nome ),
 *                                        'testo' => frase accanto a una casella (checkbox) ) ),
 *   'gruppi' => array( 'gruppo' => titolo ),
 *
 * Salvare non applica niente da solo: DS Core lancia l'azione 'ds_core_impostazioni_salvate' ( $id, $prima, $dopo )
 * e il modulo, se è acceso, la ascolta e applica.
 */

defined( 'ABSPATH' ) || exit;

/** Tipi di campo che DS Core sa disegnare, controllare e salvare. */
function ds_core_tipi_campo() {
	return array( 'text', 'email', 'url', 'number', 'checkbox', 'radio', 'select', 'checkboxes', 'plugins', 'color' );
}

/** Opzioni di DS Core che nessun modulo può usare per le sue scelte. */
function ds_core_opzioni_riservate() {
	return array( 'ds_core_stati', 'ds_core_errori', 'ds_core_storia', 'ds_core_generali', 'ds_core_db', 'ds_core_accesso_fino', 'ds_core_accesso_nonce', 'ds_core_ra_db', 'ds_core_avvisi_attesa', 'ds_core_emergenza_vista', 'ds_core_rilasci_offerta', 'ds_core_rilasci_stato' );
}

/** Campi delle impostazioni generali di DS Core (gruppo 'ds-core'). */
function ds_core_campi_generali() {
	return array(
		// Indirizzo confermato: si cambia solo con la conferma dal nuovo indirizzo (includes/avvisi.php).
		'avvisi'      => array(
			'tipo'        => 'email',
			'predefinito' => '',
		),
		'anche_admin' => array(
			'tipo'        => 'checkbox',
			'predefinito' => false,
		),
		/*
		 * Canale dell'aggiornatore firmato (includes/aggiornatore.php). Dalla 0.16.1 non si mostra e non si cambia dal
		 * pannello ('nascosto'): resta nello schema solo perché il valore 'test' salvato con la 0.16.0 continui a
		 * valere e non si perda quando si salvano le impostazioni generali. Il canale si sceglie con DS_CORE_CANALE in
		 * wp-config.php. L'indirizzo dei rilasci ('rilasci' della 0.16.0) non è più un'impostazione: solo la costante
		 * DS_CORE_RILASCI_URL; il valore rimasto nel database si ignora e si toglie al primo salvataggio.
		 */
		'canale'      => array(
			'tipo'        => 'radio',
			'scelte'      => array( 'stabile', 'test' ),
			'predefinito' => 'stabile',
			'nascosto'    => true,
		),
	);
}

/** Testi delle impostazioni generali, tradotti. Solo dopo init (pannello). */
function ds_core_testi_generali() {
	return array(
		'campi' => array(
			'avvisi' => array(
				'etichetta' => __( 'Notification address', 'ds-core' ),
				'aiuto'     => __( 'All DS Core emails go here: update notices, Claude Code access openings, the weekly activity log summary and security notices. Empty = the site administrator email. A new address takes effect only after it is confirmed from the link sent to it; until then the emails keep going to the current one.', 'ds-core' ),
			),
			'anche_admin' => array(
				'etichetta' => __( 'Site administrator', 'ds-core' ),
				/* translators: %s: site administrator email address. */
				'testo'     => sprintf( __( 'Also send every DS Core email to the site administrator email (%s)', 'ds-core' ), (string) get_option( 'admin_email' ) ),
				'aiuto'     => __( 'Security notices always go there too, whatever you choose here: Claude Code access openings and closings before time is up, requests and confirmations of a new notification address, the emergency switch. Each address gets its own email, WordPress update emails included: nobody sees the other address.', 'ds-core' ),
			),
		),
	);
}

/**
 * Controlla un elenco di campi dichiarato nel registro e lo restituisce pulito: chiave => campo con tutte le chiavi.
 * I campi sbagliati si saltano e finiscono in $problemi (testi brevi, per la riga del modulo): un errore nello schema
 * non ferma né il pannello né il sito.
 */
function ds_core_schema( $campi, &$problemi = array() ) {
	$problemi = array();
	$schema   = array();
	if ( ! is_array( $campi ) ) {
		return $schema;
	}
	$tipi = ds_core_tipi_campo();
	foreach ( $campi as $chiave => $campo ) {
		$chiave = (string) $chiave;
		if ( '' === $chiave || sanitize_key( $chiave ) !== $chiave || ! is_array( $campo ) ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: invalid name or definition.';
			continue;
		}
		$tipo = isset( $campo['tipo'] ) ? (string) $campo['tipo'] : '';
		if ( ! in_array( $tipo, $tipi, true ) ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: unknown type "' . $tipo . '".';
			continue;
		}
		$pulito = array(
			'tipo'           => $tipo,
			'predefinito'    => $campo['predefinito'] ?? null,
			'predefinito_da' => isset( $campo['predefinito_da'] ) && is_callable( $campo['predefinito_da'] ) ? $campo['predefinito_da'] : null,
			'min'            => isset( $campo['min'] ) && is_numeric( $campo['min'] ) ? 0 + $campo['min'] : null,
			'max'            => isset( $campo['max'] ) && is_numeric( $campo['max'] ) ? 0 + $campo['max'] : null,
			'passo'          => isset( $campo['passo'] ) && is_numeric( $campo['passo'] ) && $campo['passo'] > 0 ? 0 + $campo['passo'] : 1,
			'scelte'         => array(),
			'lunghezza'      => isset( $campo['lunghezza'] ) ? max( 1, (int) $campo['lunghezza'] ) : 200,
			'gruppo'         => isset( $campo['gruppo'] ) ? sanitize_key( (string) $campo['gruppo'] ) : '',
			'nascosto'       => ! empty( $campo['nascosto'] ),
			'mostra_se'      => isset( $campo['mostra_se'] ) && is_array( $campo['mostra_se'] ) && 2 === count( $campo['mostra_se'] ) ? array( sanitize_key( (string) reset( $campo['mostra_se'] ) ), (string) end( $campo['mostra_se'] ) ) : array(),
		);
		if ( in_array( $tipo, array( 'radio', 'select', 'checkboxes' ), true ) ) {
			$scelte = isset( $campo['scelte'] ) && is_array( $campo['scelte'] ) ? array_values( array_unique( array_map( 'strval', array_filter( $campo['scelte'], 'is_scalar' ) ) ) ) : array();
			if ( ! $scelte ) {
				$problemi[] = 'Field "' . $chiave . '" skipped: no choices.';
				continue;
			}
			$pulito['scelte'] = $scelte;
		}
		if ( null !== $pulito['min'] && null !== $pulito['max'] && $pulito['min'] > $pulito['max'] ) {
			$problemi[] = 'Field "' . $chiave . '" skipped: min is greater than max.';
			continue;
		}
		// Il predefinito dichiarato passa dalla stessa pulizia dei valori salvati: se non è valido diventa neutro.
		$errore                = '';
		$valore                = ds_core_valore_campo( $pulito, $pulito['predefinito'], false, $errore );
		$pulito['predefinito'] = '' === $errore ? $valore : ds_core_valore_neutro( $pulito );
		$schema[ $chiave ]     = $pulito;
	}
	return $schema;
}

/** Valore «vuoto» di un tipo di campo. */
function ds_core_valore_neutro( $campo ) {
	switch ( $campo['tipo'] ) {
		case 'number':
			return null !== $campo['min'] ? $campo['min'] : 0;
		case 'checkbox':
			return false;
		case 'checkboxes':
		case 'plugins':
			return array();
		case 'radio':
		case 'select':
			return $campo['scelte'][0] ?? '';
	}
	return '';
}

/** Predefinito di un campo, calcolato se il campo ha 'predefinito_da'. Un errore nella funzione dà il predefinito fisso. */
function ds_core_predefinito( $campo ) {
	if ( $campo['predefinito_da'] ) {
		try {
			$errore = '';
			$valore = ds_core_valore_campo( $campo, call_user_func( $campo['predefinito_da'] ), false, $errore );
			if ( '' === $errore ) {
				return $valore;
			}
		} catch ( \Throwable $e ) {
			error_log( '[DS Core] default value not computed: ' . $e->getMessage() );
		}
	}
	return $campo['predefinito'];
}

/**
 * Pulisce un valore secondo il tipo del campo. Restituisce il valore pulito; se il valore non si può accettare,
 * $errore contiene il motivo (tradotto se le traduzioni sono già caricate) e il valore restituito non va usato.
 * $severo = true nel salvataggio dal pannello: i plugin si confrontano con quelli installati (lettura dei file, solo
 * in amministrazione). I numeri fuori dai limiti si riconducono al limite, senza errore.
 */
function ds_core_valore_campo( $campo, $grezzo, $severo, &$errore ) {
	$errore = '';
	switch ( $campo['tipo'] ) {
		case 'text':
			if ( ! is_scalar( $grezzo ) && null !== $grezzo ) {
				$errore = ds_core_testo_errore( 'testo' );
				return '';
			}
			$valore = sanitize_text_field( (string) $grezzo );
			return function_exists( 'mb_substr' ) ? mb_substr( $valore, 0, $campo['lunghezza'] ) : substr( $valore, 0, $campo['lunghezza'] );

		case 'email':
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = sanitize_email( $valore );
			if ( ! is_email( $valore ) ) {
				$errore = ds_core_testo_errore( 'email' );
				return '';
			}
			return $valore;

		case 'url':
			// Solo https, con host, senza utente e password (dalla 0.16.0).
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = esc_url_raw( $valore, array( 'https' ) );
			$parti  = '' !== $valore ? wp_parse_url( $valore ) : false;
			if ( ! is_array( $parti ) || 'https' !== strtolower( (string) ( $parti['scheme'] ?? '' ) ) || empty( $parti['host'] ) || isset( $parti['user'] ) || isset( $parti['pass'] ) ) {
				$errore = ds_core_testo_errore( 'url' );
				return '';
			}
			return function_exists( 'mb_substr' ) ? mb_substr( $valore, 0, $campo['lunghezza'] ) : substr( $valore, 0, $campo['lunghezza'] );

		case 'number':
			if ( ! is_scalar( $grezzo ) || '' === trim( (string) $grezzo ) || ! is_numeric( trim( (string) $grezzo ) ) ) {
				$errore = ds_core_testo_errore( 'numero' );
				return 0;
			}
			$valore = 0 + trim( (string) $grezzo );
			if ( floor( $campo['passo'] ) == $campo['passo'] ) { // phpcs:ignore Universal.Operators.StrictComparisons -- 1 e 1.0 sono lo stesso passo.
				$valore = (int) round( $valore );
			}
			if ( null !== $campo['min'] && $valore < $campo['min'] ) {
				$valore = $campo['min'];
			}
			if ( null !== $campo['max'] && $valore > $campo['max'] ) {
				$valore = $campo['max'];
			}
			return $valore;

		case 'checkbox':
			return true === $grezzo || 1 === $grezzo || ( is_string( $grezzo ) && in_array( strtolower( $grezzo ), array( '1', 'on', 'yes', 'true' ), true ) );

		case 'radio':
		case 'select':
			$valore = is_scalar( $grezzo ) ? (string) $grezzo : '';
			if ( ! in_array( $valore, $campo['scelte'], true ) ) {
				$errore = ds_core_testo_errore( 'scelta' );
				return '';
			}
			return $valore;

		case 'checkboxes':
			$valori = is_array( $grezzo ) ? array_map( 'strval', array_filter( $grezzo, 'is_scalar' ) ) : array();
			return array_values( array_intersect( $campo['scelte'], $valori ) );

		case 'plugins':
			$valori = is_array( $grezzo ) ? array_values( array_unique( array_map( 'sanitize_text_field', array_map( 'strval', array_filter( $grezzo, 'is_scalar' ) ) ) ) ) : array();
			if ( $severo ) {
				if ( ! function_exists( 'get_plugins' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}
				$valori = array_values( array_intersect( $valori, array_keys( get_plugins() ) ) );
			}
			return $valori;

		case 'color':
			$valore = is_scalar( $grezzo ) ? trim( (string) $grezzo ) : '';
			if ( '' === $valore ) {
				return '';
			}
			$valore = sanitize_hex_color( $valore );
			if ( ! $valore ) {
				$errore = ds_core_testo_errore( 'colore' );
				return '';
			}
			return strtolower( $valore );
	}
	$errore = ds_core_testo_errore( 'testo' );
	return '';
}

/** Motivi per cui un valore non si accetta. Tradotti solo dopo init; prima (sito pubblico, cron) servono solo da segnale. */
function ds_core_testo_errore( $codice ) {
	if ( ! did_action( 'init' ) ) {
		return $codice;
	}
	$testi = array(
		'email'  => __( 'Enter a valid email address, or leave the field empty.', 'ds-core' ),
		'url'    => __( 'Enter an address that starts with https://, or leave the field empty.', 'ds-core' ),
		'numero' => __( 'Enter a number.', 'ds-core' ),
		'scelta' => __( 'Choose one of the options.', 'ds-core' ),
		'colore' => __( 'Enter a colour as #rrggbb, or leave the field empty.', 'ds-core' ),
		'testo'  => __( 'This value cannot be saved.', 'ds-core' ),
	);
	return $testi[ $codice ] ?? $testi['testo'];
}

/**
 * Gruppo di impostazioni: array( 'opzione' => nome, 'schema' => campi puliti, 'problemi' => errori dello schema ),
 * oppure null se l'ID non ha scelte. 'ds-core' è il gruppo riservato alle impostazioni generali.
 */
function ds_core_gruppo_impostazioni( $id ) {
	$problemi = array();
	if ( 'ds-core' === $id ) {
		$schema = ds_core_schema( ds_core_campi_generali(), $problemi );
		return array( 'opzione' => 'ds_core_generali', 'schema' => $schema, 'problemi' => $problemi );
	}
	$registro = ds_core_registro();
	if ( ! isset( $registro[ $id ] ) || '' === $registro[ $id ]['opzione'] || ! $registro[ $id ]['campi'] ) {
		return null;
	}
	// Anche con lo schema tutto sbagliato il gruppo esiste: il pannello mostra i problemi nella riga del modulo.
	$schema = ds_core_schema( $registro[ $id ]['campi'], $problemi );
	return array( 'opzione' => $registro[ $id ]['opzione'], 'schema' => $schema, 'problemi' => $problemi );
}

/**
 * Valori puliti di un elenco di campi a partire da quelli salvati. $severo come in ds_core_valore_campo(). Un campo
 * mai salvato o con un valore non valido prende il predefinito.
 */
function ds_core_valori_da_salvati( $schema, $salvati, $severo = false ) {
	$salvati = is_array( $salvati ) ? $salvati : array();
	$valori  = array();
	foreach ( $schema as $chiave => $campo ) {
		if ( array_key_exists( $chiave, $salvati ) ) {
			$errore = '';
			$valore = ds_core_valore_campo( $campo, $salvati[ $chiave ], $severo, $errore );
			if ( '' === $errore ) {
				$valori[ $chiave ] = $valore;
				continue;
			}
		}
		$valori[ $chiave ] = ds_core_predefinito( $campo );
	}
	return $valori;
}

/**
 * Scelte di un modulo (o di DS Core con 'ds-core'): valori salvati, puliti, con i predefiniti per quelli mai
 * salvati. Una volta per richiesta; ds_core_opzioni_svuota() dopo un salvataggio. Array vuoto se il modulo non ha
 * scelte.
 */
function ds_core_opzioni_modulo( $id, $svuota = false ) {
	static $cache = array();
	if ( $svuota ) {
		$cache = array();
		return array();
	}
	$id = (string) $id;
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	$gruppo = ds_core_gruppo_impostazioni( $id );
	if ( ! $gruppo || ! $gruppo['schema'] ) {
		return array();
	}
	$valori = ds_core_valori_da_salvati( $gruppo['schema'], get_option( $gruppo['opzione'], array() ) );
	if ( did_action( 'plugins_loaded' ) ) {
		$cache[ $id ] = $valori;
	}
	return $valori;
}

/** Dimentica i valori letti in questa richiesta (dopo un salvataggio). */
function ds_core_opzioni_svuota() {
	ds_core_opzioni_modulo( '', true );
}

/*
 * Predefiniti calcolati dei moduli di DS Core: stanno qui e non nel file del modulo, perché servono anche a modulo
 * spento (il pannello mostra le scelte prima dell'accensione).
 */

/** aggiornamenti: plugin da aggiornare a mano finché non si sceglie diversamente, quelli che toccano le vendite. */
function ds_core_agg_manuali_predefiniti() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$manuali = array();
	foreach ( array_keys( get_plugins() ) as $file ) {
		$cartella = strtolower( dirname( $file ) );
		if ( 'woocommerce' === $cartella || 'ds-woo' === $cartella || preg_match( '/-site$/', $cartella )
			|| preg_match( '/(gateway|payment|pagament|stripe|paypal|satispay|klarna|scalapay|nexi|braintree|mollie|square)/', $cartella ) ) {
			$manuali[] = $file;
		}
	}
	return $manuali;
}

/*
 * Migrazioni dei dati salvati: una volta per versione, alla prima richiesta dopo l'aggiornamento dei file (i siti
 * ricevono i file senza riattivare il plugin, quindi niente register_activation_hook). Non cancellano nulla: le
 * vecchie chiavi restano finché il pannello non salva di nuovo quel gruppo, così si può tornare indietro.
 */
add_action( 'plugins_loaded', 'ds_core_migra', 1 );
function ds_core_migra() {
	$db = (string) get_option( 'ds_core_db', '' );
	if ( '' !== $db && version_compare( $db, DS_CORE_VERSIONE, '>=' ) ) {
		return;
	}

	// 0.13.0: l'indirizzo degli avvisi del modulo aggiornamenti diventa l'indirizzo unico di DS Core.
	if ( '' === $db || version_compare( $db, '0.13.0', '<' ) ) {
		$generali = get_option( 'ds_core_generali', array() );
		$generali = is_array( $generali ) ? $generali : array();
		$agg      = get_option( 'ds_core_agg', array() );
		if ( empty( $generali['avvisi'] ) && is_array( $agg ) && ! empty( $agg['avvisi'] ) && is_email( $agg['avvisi'] ) ) {
			// Indirizzo già scelto da un amministratore: vale come confermato (dalla 0.15.0 passa dalla guardia).
			ds_core_avvisi_scrivi_confermato( $agg['avvisi'] );
		}
	}

	/*
	 * 0.15.0: l'indirizzo degli avvisi salvato con la 0.13/0.14 resta valido senza conferma (è già in
	 * ds_core_generali['avvisi'], niente da copiare). Registro delle attività: la conservazione passa da numero libero
	 * a scelta 30 / 90 / 365 / personalizzato; un numero salvato diverso dai tre diventa «personalizzato» (7-730).
	 */
	if ( '' === $db || version_compare( $db, '0.15.0', '<' ) ) {
		$ra = get_option( 'ds_core_ra', false );
		if ( is_array( $ra ) && isset( $ra['giorni'] ) && ! isset( $ra['conserva'] ) ) {
			$ra = array_merge( $ra, ds_core_eventi_conserva_da_giorni( $ra['giorni'] ) );
			update_option( 'ds_core_ra', $ra, false );
		}
	}

	update_option( 'ds_core_db', DS_CORE_VERSIONE, true );
}

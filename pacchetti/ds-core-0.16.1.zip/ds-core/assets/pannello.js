/*
 * Pannello DS Core, scritto a mano senza dipendenze.
 * - Levetta (role="switch") per i moduli a due stati, pulsanti Spento | Prova | Attivo per quelli a tre stati:
 *   un clic salva subito (azione AJAX ds_core_imposta); in caso d'errore il controllo torna com'era.
 * - Filtri lato client: stato, categoria, origine, tag (anche cliccando un tag nella riga) e ricerca, combinati.
 * - Azioni su un'intera categoria (nella testata della categoria), con conferma che dice quanti moduli cambiano.
 * - Aspetto Automatico | Chiaro | Scuro: cambia subito la pagina e si salva per l'utente (azione ds_core_tema).
 * - Testi tradotti con wp.i18n (dipendenza 'wp-i18n', file JSON in languages/): testi in inglese nel codice.
 * - Azioni in blocco via AJAX (ds_core_blocco) sui moduli selezionati e visibili; senza JavaScript il modulo
 *   HTML fa lo stesso con la ricarica della pagina.
 * - Impostazioni nella riga del modulo (0.12.0): il pulsante «Settings» (aria-expanded, aria-controls) apre e chiude
 *   la riga sotto; le righe aperte si ricordano nel browser (localStorage) e si apre quella dell'indirizzo
 *   (#ds-impostazioni-<id>, dopo un salvataggio). I link dell'avviso in cima aprono la riga del modulo con problemi,
 *   togliendo prima i filtri se la nascondono. Senza JavaScript le righe restano aperte (classe ds-js assente).
 * - Scelte dichiarate nel registro (0.13.0): ogni modulo di scelte ha il suo «Save settings», salvato via AJAX
 *   (ds_core_impostazioni, nonce del modulo già nel modulo HTML); modifiche non salvate segnalate accanto al
 *   pulsante; errori campo per campo; dopo il salvataggio i campi mostrano i valori puliti dal server (per esempio
 *   un numero ricondotto al limite). Senza JavaScript il modulo HTML salva con la ricarica della pagina.
 * - Dopo un cambio di stato (levetta, azioni in blocco) la parte «stato» della riga si chiede di nuovo
 *   (ds_core_riga): accendendo compare lo stato vero senza ricaricare, spegnendo torna la frase d'attesa.
 * - Campi che dipendono da un altro (0.15.0, data-ds-mostra-se): si mostrano e si mandano solo con il valore giusto
 *   dell'altro campo; senza JavaScript restano visibili e il server guarda solo la scelta.
 * - Indirizzo degli avvisi (0.15.0): se il salvataggio crea una richiesta di cambio la pagina si ricarica (il server
 *   tiene il messaggio); pulsante «Copy» per la riga da mettere in wp-config.php.
 */
( function () {
	'use strict';

	var pagina = document.querySelector( '.ds-core' );
	if ( ! pagina || typeof dsCore === 'undefined' || ! window.wp || ! wp.i18n ) {
		return;
	}

	pagina.classList.add( 'ds-js' );

	var __ = wp.i18n.__;
	var _n = wp.i18n._n;
	var sprintf = wp.i18n.sprintf;

	var messaggio = pagina.querySelector( '.ds-messaggio' );
	var righe = Array.prototype.slice.call( pagina.querySelectorAll( 'tr[data-ds-id]' ) );
	var sezioni = Array.prototype.slice.call( pagina.querySelectorAll( '.ds-categoria' ) );
	var perId = {};
	righe.forEach( function ( riga ) {
		perId[ riga.getAttribute( 'data-ds-id' ) ] = riga;
	} );

	var campoCategoria = pagina.querySelector( '#ds-categoria' );
	var campoOrigine = pagina.querySelector( '#ds-origine' );
	var campoTag = pagina.querySelector( '#ds-tag' );
	var campoCerca = pagina.querySelector( '#ds-cerca' );
	var azzera = pagina.querySelector( '.ds-azzera' );
	var nessuno = pagina.querySelector( '.ds-nessuno' );
	var tuttiVisibili = pagina.querySelector( '#ds-seleziona-visibili' );
	var contaScelti = pagina.querySelector( '.ds-blocco-conta' );
	var barra = pagina.querySelector( '.ds-blocco' );

	var filtri = { stato: 'tutti', categoria: '', origine: '', tag: '', testo: '' };

	/* ---------- Messaggi ---------- */

	function mostra( testo, errore ) {
		if ( ! messaggio ) {
			return;
		}
		messaggio.textContent = testo;
		messaggio.className = 'ds-messaggio notice ' + ( errore ? 'notice-error' : 'notice-success' );
	}

	function messaggioRiga( riga, testo, tipo ) {
		var spazio = riga.querySelector( '.ds-riga-messaggio' );
		if ( ! spazio ) {
			return;
		}
		spazio.textContent = testo || '';
		spazio.className = 'ds-riga-messaggio' + ( tipo ? ' ds-riga-messaggio--' + tipo : '' );
	}

	function titolo( riga ) {
		var t = riga.querySelector( '.ds-titolo' );
		return t ? t.textContent : riga.getAttribute( 'data-ds-id' );
	}

	/* ---------- Richieste ---------- */

	function richiesta( campi ) {
		var dati = new FormData();
		dati.append( 'nonce', dsCore.nonce );
		Object.keys( campi ).forEach( function ( chiave ) {
			var valore = campi[ chiave ];
			if ( Array.isArray( valore ) ) {
				valore.forEach( function ( v ) {
					dati.append( chiave + '[]', v );
				} );
			} else {
				dati.append( chiave, valore );
			}
		} );
		return fetch( dsCore.ajax, { method: 'POST', credentials: 'same-origin', body: dati } ).then( function ( risposta ) {
			return risposta.json().catch( function () {
				return null;
			} );
		} );
	}

	// WordPress risponde -1 o 0 (non un oggetto) se il nonce è scaduto o l'azione non esiste.
	function testoErrore( esito ) {
		if ( esito && typeof esito === 'object' && esito.data && esito.data.messaggio ) {
			return esito.data.messaggio;
		}
		if ( esito === -1 || esito === 0 ) {
			return __( 'Session expired: reload the page and try again.', 'ds-core' );
		}
		return __( 'Not saved.', 'ds-core' );
	}

	/* ---------- Stato delle righe ---------- */

	function impostaControllo( riga, scelto ) {
		var levetta = riga.querySelector( '.ds-levetta' );
		if ( levetta ) {
			levetta.setAttribute( 'aria-checked', scelto !== 'spento' ? 'true' : 'false' );
		}
		riga.querySelectorAll( '.ds-segmento' ).forEach( function ( pulsante ) {
			pulsante.setAttribute( 'aria-pressed', pulsante.getAttribute( 'data-ds-valore' ) === scelto ? 'true' : 'false' );
		} );
	}

	function applicaRiga( riga, dati ) {
		riga.setAttribute( 'data-ds-stato', dati.stato );
		riga.setAttribute( 'data-ds-scelto', dati.scelto );
		impostaControllo( riga, dati.scelto );
		var badge = riga.querySelector( '.ds-stato' );
		if ( badge ) {
			badge.textContent = dati.etichetta;
			badge.className = 'ds-stato ds-stato--' + dati.stato;
		}
	}

	// Durante il salvataggio i controlli restano focalizzabili (aria-disabled, non disabled): chi usa la tastiera
	// non perde la posizione.
	function inSalvataggio( riga, si ) {
		riga.classList.toggle( 'is-salvataggio', si );
		riga.querySelectorAll( '.ds-levetta, .ds-segmento' ).forEach( function ( c ) {
			if ( si ) {
				c.setAttribute( 'aria-disabled', 'true' );
			} else {
				c.removeAttribute( 'aria-disabled' );
			}
		} );
		var cella = riga.querySelector( '.ds-col-stato' );
		if ( cella ) {
			cella.setAttribute( 'aria-busy', si ? 'true' : 'false' );
		}
		if ( si ) {
			riga.classList.remove( 'is-errore' );
			messaggioRiga( riga, __( 'saving…', 'ds-core' ), 'attesa' );
		}
	}

	function segnaErrore( riga, testo ) {
		riga.classList.add( 'is-errore' );
		messaggioRiga( riga, testo, 'errore' );
	}

	function cambia( riga, nuovo ) {
		if ( riga.classList.contains( 'is-salvataggio' ) ) {
			return;
		}
		var prima = riga.getAttribute( 'data-ds-scelto' );
		if ( nuovo === prima ) {
			return;
		}
		impostaControllo( riga, nuovo );
		inSalvataggio( riga, true );

		richiesta( { action: 'ds_core_imposta', id: riga.getAttribute( 'data-ds-id' ), stato: nuovo } )
			.then( function ( esito ) {
				inSalvataggio( riga, false );
				if ( esito && esito.success ) {
					applicaRiga( riga, esito.data );
					aggiornaDettagli( riga.getAttribute( 'data-ds-id' ) );
					messaggioRiga( riga, esito.data.stato === 'dipendenze' ? esito.data.messaggio : '', esito.data.stato === 'dipendenze' ? 'avviso' : '' );
					/* translators: 1: module title, 2: message. */
					mostra( sprintf( __( '%1$s: %2$s', 'ds-core' ), titolo( riga ), esito.data.messaggio ), false );
				} else {
					impostaControllo( riga, prima );
					segnaErrore( riga, testoErrore( esito ) );
					/* translators: 1: module title, 2: message. */
					mostra( sprintf( __( '%1$s: %2$s', 'ds-core' ), titolo( riga ), testoErrore( esito ) ), true );
				}
				aggiornaConteggi();
			} )
			.catch( function () {
				inSalvataggio( riga, false );
				impostaControllo( riga, prima );
				segnaErrore( riga, __( 'Not saved: network error.', 'ds-core' ) );
				/* translators: %s: module title. */
				mostra( sprintf( __( '%s: not saved, network error. Reload the page and try again.', 'ds-core' ), titolo( riga ) ), true );
			} );
	}

	righe.forEach( function ( riga ) {
		var levetta = riga.querySelector( '.ds-levetta' );
		if ( levetta ) {
			// Un <button> si attiva già con spazio e invio.
			levetta.addEventListener( 'click', function () {
				if ( levetta.disabled || levetta.getAttribute( 'aria-disabled' ) === 'true' ) {
					return;
				}
				cambia( riga, levetta.getAttribute( 'aria-checked' ) === 'true' ? 'spento' : 'attivo' );
			} );
		}
		riga.querySelectorAll( '.ds-segmento' ).forEach( function ( pulsante ) {
			pulsante.addEventListener( 'click', function () {
				if ( pulsante.disabled || pulsante.getAttribute( 'aria-disabled' ) === 'true' ) {
					return;
				}
				cambia( riga, pulsante.getAttribute( 'data-ds-valore' ) );
			} );
		} );
	} );

	/* ---------- Conteggi e filtri ---------- */

	function gruppo( stato ) {
		return ( stato === 'attivo' || stato === 'prova' || stato === 'errore' ) ? stato : 'spento';
	}

	function aggiornaConteggi() {
		var conta = { tutti: righe.length, attivo: 0, prova: 0, spento: 0, errore: 0 };
		righe.forEach( function ( riga ) {
			conta[ gruppo( riga.getAttribute( 'data-ds-stato' ) ) ]++;
		} );
		Object.keys( conta ).forEach( function ( chiave ) {
			var posto = pagina.querySelector( '[data-ds-conta="' + chiave + '"]' );
			if ( posto ) {
				posto.textContent = conta[ chiave ];
			}
		} );
		sezioni.forEach( function ( sezione ) {
			var tutte = sezione.querySelectorAll( 'tr[data-ds-id]' );
			var accese = 0;
			tutte.forEach( function ( riga ) {
				if ( riga.getAttribute( 'data-ds-scelto' ) !== 'spento' ) {
					accese++;
				}
			} );
			var posto = sezione.querySelector( '[data-ds-categoria-conta]' );
			if ( posto ) {
				/* translators: 1: number of modules on, 2: number of modules in the category. */
				posto.textContent = sprintf( __( '%1$d of %2$d on', 'ds-core' ), accese, tutte.length );
			}
			sezione.querySelectorAll( '.ds-categoria-azione' ).forEach( function ( pulsante ) {
				var accendi = pulsante.getAttribute( 'data-ds-categoria-azione' ) === 'attivo';
				var inutile = accendi ? accese === tutte.length : accese === 0;
				pulsante.disabled = inutile;
				pulsante.title = inutile ? ( accendi ? __( 'They are all on already', 'ds-core' ) : __( 'They are all off already', 'ds-core' ) ) : '';
			} );
		} );
	}

	function tagDi( riga ) {
		var valore = riga.getAttribute( 'data-ds-tag' ) || '';
		return valore ? valore.split( '|' ) : [];
	}

	// Dopo un cambio di stato la riga resta dov'è anche se non corrisponde più al filtro: sparirebbe sotto il
	// cursore. Il filtro si riapplica alla prossima scelta di filtro.
	function filtra() {
		var vuoto = true;
		sezioni.forEach( function ( sezione ) {
			var visibili = 0;
			var categoriaOk = ! filtri.categoria || sezione.getAttribute( 'data-ds-categoria' ) === filtri.categoria;
			sezione.querySelectorAll( 'tr[data-ds-id]' ).forEach( function ( riga ) {
				var ok = categoriaOk && ( filtri.stato === 'tutti' || filtri.stato === gruppo( riga.getAttribute( 'data-ds-stato' ) ) ) &&
					( ! filtri.origine || riga.getAttribute( 'data-ds-origine' ) === filtri.origine ) &&
					( ! filtri.tag || tagDi( riga ).indexOf( filtri.tag ) !== -1 ) &&
					( ! filtri.testo || ( riga.getAttribute( 'data-ds-testo' ) || '' ).indexOf( filtri.testo ) !== -1 );
				riga.hidden = ! ok;
				// La riga delle impostazioni sta nello stesso <tbody> e sparisce con il suo modulo.
				var corpo = riga.parentNode;
				if ( corpo && corpo.classList && corpo.classList.contains( 'ds-modulo' ) ) {
					corpo.hidden = ! ok;
				}
				if ( ok ) {
					visibili++;
				}
			} );
			sezione.hidden = visibili === 0;
			if ( visibili ) {
				vuoto = false;
			}
		} );
		if ( nessuno ) {
			nessuno.hidden = ! vuoto;
		}
		if ( azzera ) {
			azzera.hidden = filtri.stato === 'tutti' && ! filtri.categoria && ! filtri.origine && ! filtri.tag && ! filtri.testo;
		}
		pagina.querySelectorAll( '.ds-tag' ).forEach( function ( pulsante ) {
			pulsante.setAttribute( 'aria-pressed', filtri.tag && pulsante.getAttribute( 'data-ds-tag' ) === filtri.tag ? 'true' : 'false' );
		} );
		aggiornaSelezione();
	}

	function scegliStato( chiave ) {
		filtri.stato = chiave;
		pagina.querySelectorAll( '[data-ds-filtro]' ).forEach( function ( link ) {
			var attivo = link.getAttribute( 'data-ds-filtro' ) === chiave;
			link.classList.toggle( 'current', attivo );
			if ( attivo ) {
				link.setAttribute( 'aria-current', 'true' );
			} else {
				link.removeAttribute( 'aria-current' );
			}
		} );
	}

	pagina.querySelectorAll( '[data-ds-filtro]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function ( evento ) {
			evento.preventDefault();
			scegliStato( link.getAttribute( 'data-ds-filtro' ) );
			filtra();
		} );
	} );

	if ( campoCategoria ) {
		campoCategoria.addEventListener( 'change', function () {
			filtri.categoria = campoCategoria.value;
			filtra();
		} );
	}

	if ( campoOrigine ) {
		campoOrigine.addEventListener( 'change', function () {
			filtri.origine = campoOrigine.value;
			filtra();
		} );
	}

	function scegliTag( tag ) {
		filtri.tag = tag;
		if ( campoTag ) {
			campoTag.value = tag;
		}
		filtra();
	}

	if ( campoTag ) {
		campoTag.addEventListener( 'change', function () {
			scegliTag( campoTag.value );
		} );
	}

	// Un tag nella riga filtra; cliccato di nuovo toglie il filtro.
	pagina.querySelectorAll( '.ds-tag' ).forEach( function ( pulsante ) {
		pulsante.addEventListener( 'click', function () {
			var tag = pulsante.getAttribute( 'data-ds-tag' );
			scegliTag( filtri.tag === tag ? '' : tag );
		} );
	} );

	if ( campoCerca ) {
		campoCerca.addEventListener( 'input', function () {
			filtri.testo = campoCerca.value.trim().toLowerCase();
			filtra();
		} );
	}

	function togliFiltri() {
		scegliStato( 'tutti' );
		filtri.categoria = '';
		filtri.origine = '';
		if ( campoCategoria ) {
			campoCategoria.value = '';
		}
		filtri.testo = '';
		if ( campoOrigine ) {
			campoOrigine.value = '';
		}
		if ( campoCerca ) {
			campoCerca.value = '';
		}
		scegliTag( '' );
	}

	if ( azzera ) {
		azzera.addEventListener( 'click', togliFiltri );
	}

	/* ---------- Selezione e azioni in blocco ---------- */

	function visibile( riga ) {
		var sezione = riga.closest( '.ds-categoria' );
		return ! riga.hidden && ! ( sezione && sezione.hidden );
	}

	function casella( riga ) {
		return riga.querySelector( 'input[name="ds_scelti[]"]' );
	}

	function sceltiVisibili() {
		return righe.filter( function ( riga ) {
			var c = casella( riga );
			return c && c.checked && visibile( riga );
		} );
	}

	function statoCasella( casellaTutti, elenco ) {
		var scelte = elenco.filter( function ( riga ) {
			return casella( riga ) && casella( riga ).checked;
		} ).length;
		casellaTutti.checked = elenco.length > 0 && scelte === elenco.length;
		casellaTutti.indeterminate = scelte > 0 && scelte < elenco.length;
	}

	function aggiornaSelezione() {
		var visibiliTutte = righe.filter( visibile );
		var scelte = sceltiVisibili().length;
		if ( contaScelti ) {
			/* translators: %d: number of selected modules. */
			contaScelti.textContent = scelte === 0 ? __( 'No modules selected', 'ds-core' ) : sprintf( _n( '%d module selected', '%d modules selected', scelte, 'ds-core' ), scelte );
		}
		if ( tuttiVisibili ) {
			statoCasella( tuttiVisibili, visibiliTutte );
		}
		sezioni.forEach( function ( sezione ) {
			var c = sezione.querySelector( '.ds-seleziona-tutti' );
			if ( c ) {
				statoCasella( c, visibiliTutte.filter( function ( riga ) {
					return sezione.contains( riga );
				} ) );
			}
		} );
		pagina.querySelectorAll( '.ds-blocco-azioni button' ).forEach( function ( pulsante ) {
			pulsante.disabled = scelte === 0;
		} );
		if ( barra ) {
			barra.classList.toggle( 'ds-blocco--attivo', scelte > 0 );
		}
	}

	if ( tuttiVisibili ) {
		tuttiVisibili.addEventListener( 'change', function () {
			righe.filter( visibile ).forEach( function ( riga ) {
				casella( riga ).checked = tuttiVisibili.checked;
			} );
			aggiornaSelezione();
		} );
	}

	pagina.querySelectorAll( '.ds-seleziona-tutti' ).forEach( function ( c ) {
		c.addEventListener( 'change', function () {
			var sezione = c.closest( '.ds-categoria' );
			righe.filter( function ( riga ) {
				return sezione.contains( riga ) && visibile( riga );
			} ).forEach( function ( riga ) {
				casella( riga ).checked = c.checked;
			} );
			aggiornaSelezione();
		} );
	} );

	righe.forEach( function ( riga ) {
		var c = casella( riga );
		if ( c ) {
			c.addEventListener( 'change', aggiornaSelezione );
		}
	} );

	// Applica uno stato a più righe insieme (azioni in blocco e azioni di categoria): una richiesta, esito riga per riga.
	function eseguiBlocco( scelte, stato, fatto ) {
		var ids = scelte.map( function ( riga ) {
			return riga.getAttribute( 'data-ds-id' );
		} );
		scelte.forEach( function ( riga ) {
			inSalvataggio( riga, true );
		} );

		richiesta( { action: 'ds_core_blocco', stato: stato, ids: ids } )
			.then( function ( esito ) {
				scelte.forEach( function ( riga ) {
					inSalvataggio( riga, false );
					messaggioRiga( riga, '', '' );
				} );
				if ( ! esito || ! esito.success ) {
					mostra( testoErrore( esito ), true );
					return;
				}
				Object.keys( esito.data.righe ).forEach( function ( id ) {
					var riga = perId[ id ];
					var dati = esito.data.righe[ id ];
					if ( ! riga ) {
						return;
					}
					applicaRiga( riga, dati );
					aggiornaDettagli( id );
					if ( dati.errore ) {
						segnaErrore( riga, dati.errore );
					} else if ( dati.stato === 'dipendenze' ) {
						messaggioRiga( riga, dati.messaggio, 'avviso' );
					} else {
						casella( riga ).checked = false;
					}
				} );
				mostra( esito.data.messaggio, false );
				aggiornaConteggi();
				aggiornaSelezione();
				if ( fatto ) {
					fatto();
				}
			} )
			.catch( function () {
				scelte.forEach( function ( riga ) {
					inSalvataggio( riga, false );
					messaggioRiga( riga, '', '' );
				} );
				mostra( __( 'Not saved: network error. Reload the page and try again.', 'ds-core' ), true );
			} );
	}

	pagina.querySelectorAll( '.ds-blocco-azioni button' ).forEach( function ( pulsante ) {
		pulsante.addEventListener( 'click', function ( evento ) {
			evento.preventDefault();
			var scelte = sceltiVisibili();
			if ( ! scelte.length ) {
				mostra( __( 'Select at least one module.', 'ds-core' ), true );
				return;
			}
			eseguiBlocco( scelte, pulsante.value );
		} );
	} );

	/* ---------- Azioni su tutta la categoria ---------- */

	// Primo clic: al posto dei due pulsanti compare la domanda con il numero di moduli; secondo clic su «Conferma».
	// Esc o «Annulla» tornano indietro. Valgono per tutti i moduli della categoria, anche quelli nascosti dai filtri.
	sezioni.forEach( function ( sezione ) {
		var azioni = sezione.querySelector( '.ds-categoria-azioni' );
		var conferma = sezione.querySelector( '.ds-categoria-conferma' );
		if ( ! azioni || ! conferma ) {
			return;
		}
		var domanda = conferma.querySelector( '.ds-categoria-domanda' );
		var si = conferma.querySelector( '.ds-categoria-si' );
		var no = conferma.querySelector( '.ds-categoria-no' );
		var scelto = '';
		var origine = null;

		function chiudi( rimettiFuoco ) {
			conferma.hidden = true;
			azioni.hidden = false;
			sezione.classList.remove( 'is-conferma' );
			scelto = '';
			if ( rimettiFuoco && origine ) {
				origine.focus();
			}
		}

		azioni.querySelectorAll( '.ds-categoria-azione' ).forEach( function ( pulsante ) {
			pulsante.addEventListener( 'click', function () {
				scelto = pulsante.getAttribute( 'data-ds-categoria-azione' );
				origine = pulsante;
				domanda.textContent = pulsante.getAttribute( 'data-ds-domanda' );
				si.textContent = scelto === 'spento' ? __( 'Yes, turn off', 'ds-core' ) : __( 'Yes, turn on', 'ds-core' );
				azioni.hidden = true;
				conferma.hidden = false;
				sezione.classList.add( 'is-conferma' );
				si.focus();
			} );
		} );
		no.addEventListener( 'click', function () {
			chiudi( true );
		} );
		conferma.addEventListener( 'keydown', function ( evento ) {
			if ( evento.key === 'Escape' ) {
				chiudi( true );
			}
		} );
		si.addEventListener( 'click', function () {
			var stato = scelto;
			var righeCategoria = Array.prototype.slice.call( sezione.querySelectorAll( 'tr[data-ds-id]' ) ).filter( function ( riga ) {
				return riga.getAttribute( 'data-ds-scelto' ) !== stato;
			} );
			chiudi( true );
			if ( righeCategoria.length ) {
				eseguiBlocco( righeCategoria, stato );
			}
		} );
	} );

	/* ---------- Aspetto ---------- */

	// La classe sul <body> cambia subito; se il salvataggio fallisce torna quella di prima.
	function applicaTema( tema ) {
		document.body.classList.remove( 'ds-tema-auto', 'ds-tema-chiaro', 'ds-tema-scuro' );
		document.body.classList.add( 'ds-tema-' + tema );
		pagina.querySelectorAll( '.ds-tema-scelta' ).forEach( function ( pulsante ) {
			pulsante.setAttribute( 'aria-pressed', pulsante.getAttribute( 'data-ds-tema' ) === tema ? 'true' : 'false' );
		} );
	}

	pagina.querySelectorAll( '.ds-tema-scelta' ).forEach( function ( pulsante ) {
		pulsante.addEventListener( 'click', function () {
			var corrente = pagina.querySelector( '.ds-tema-scelta[aria-pressed="true"]' );
			var prima = corrente ? corrente.getAttribute( 'data-ds-tema' ) : 'auto';
			var tema = pulsante.getAttribute( 'data-ds-tema' );
			if ( tema === prima ) {
				return;
			}
			applicaTema( tema );
			richiesta( { action: 'ds_core_tema', tema: tema } )
				.then( function ( esito ) {
					if ( ! esito || ! esito.success ) {
						applicaTema( prima );
						/* translators: %s: error message. */
						mostra( sprintf( __( 'Appearance not saved: %s', 'ds-core' ), testoErrore( esito ) ), true );
					}
				} )
				.catch( function () {
					applicaTema( prima );
					mostra( __( 'Appearance not saved: network error.', 'ds-core' ), true );
				} );
		} );
	} );

	/* ---------- Stato del modulo nella riga sotto, dopo un cambio ---------- */

	// La parte «stato» esiste solo per i moduli con scelte o stato. La richiesta parte dopo il salvataggio dello
	// stato: in quella richiesta il modulo appena acceso è già caricato e la sua funzione 'stato' esiste.
	function aggiornaDettagli( id ) {
		var area = pagina.querySelector( '[data-ds-stato-area="' + id + '"]' );
		if ( ! area ) {
			return;
		}
		area.setAttribute( 'aria-busy', 'true' );
		richiesta( { action: 'ds_core_riga', id: id } )
			.then( function ( esito ) {
				area.removeAttribute( 'aria-busy' );
				if ( ! esito || ! esito.success ) {
					return;
				}
				// HTML preparato dal server (escape fatto in PHP), come al caricamento della pagina.
				area.innerHTML = esito.data.html;
				var conProblemi = esito.data.problemi > 0;
				var riga = perId[ id ];
				if ( riga ) {
					riga.classList.toggle( 'ds-riga--problema', conProblemi );
					var segno = riga.querySelector( '.ds-riga-azioni .ds-apri + .ds-attenzione' );
					if ( segno ) {
						segno.hidden = ! conProblemi;
					}
				}
				var dettagli = document.getElementById( 'ds-impostazioni-' + id );
				if ( dettagli ) {
					dettagli.classList.toggle( 'ds-dettagli--problema', conProblemi );
					var spento = dettagli.querySelector( '.ds-salva-spento' );
					if ( spento ) {
						spento.hidden = esito.data.acceso;
					}
				}
			} )
			.catch( function () {
				area.removeAttribute( 'aria-busy' );
			} );
	}

	/* ---------- Scelte dei moduli e impostazioni generali ---------- */

	// Spunta come ds_core_icona( 'spunta' ): markup fisso, nessun dato esterno.
	var SPUNTA = '<svg class="ds-icona" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false"><path d="M3 8.5 6.5 12 13 4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

	function esitoForm( form, testo, tipo ) {
		var posto = form.querySelector( '.ds-salva-esito' );
		if ( ! posto ) {
			return;
		}
		posto.className = 'ds-salva-esito' + ( tipo ? ' ds-salva-esito--' + tipo : '' );
		posto.textContent = '';
		if ( ! testo ) {
			return;
		}
		if ( tipo === 'ok' ) {
			posto.innerHTML = SPUNTA;
		}
		var span = document.createElement( 'span' );
		span.textContent = testo;
		posto.appendChild( span );
	}

	function campiDi( form, chiave ) {
		return Array.prototype.slice.call( form.querySelectorAll( '[name="ds_campi[' + chiave + ']"], [name="ds_campi[' + chiave + '][]"]' ) );
	}

	function mostraErrori( form, errori ) {
		var primo = null;
		form.querySelectorAll( '.ds-campo[data-ds-campo]' ).forEach( function ( blocco ) {
			var chiave = blocco.getAttribute( 'data-ds-campo' );
			var testo = errori && errori[ chiave ] ? errori[ chiave ] : '';
			var posto = blocco.querySelector( '.ds-campo-errore' );
			blocco.classList.toggle( 'is-invalido', !! testo );
			if ( posto ) {
				posto.hidden = ! testo;
				var span = posto.querySelector( 'span' );
				if ( span ) {
					span.textContent = testo;
				}
			}
			campiDi( form, chiave ).forEach( function ( campo ) {
				if ( testo ) {
					campo.setAttribute( 'aria-invalid', 'true' );
				} else {
					campo.removeAttribute( 'aria-invalid' );
				}
			} );
			if ( testo && ! primo ) {
				primo = campiDi( form, chiave )[ 0 ] || null;
			}
		} );
		if ( primo ) {
			primo.focus();
		}
	}

	// Colore: il selettore del browser e il testo #rrggbb si seguono; il testo è il valore che si salva.
	function sincronizzaColore( testo ) {
		var gruppo = testo.closest ? testo.closest( '.ds-campo-colore' ) : null;
		var scelta = gruppo ? gruppo.querySelector( '.ds-campo-colore-scelta' ) : null;
		if ( scelta && /^#[0-9a-f]{6}$/i.test( testo.value ) ) {
			scelta.value = testo.value.toLowerCase();
		}
	}

	// Rimette nei campi i valori salvati e puliti dal server.
	function applicaValori( form, valori ) {
		Object.keys( valori || {} ).forEach( function ( chiave ) {
			var valore = valori[ chiave ];
			campiDi( form, chiave ).forEach( function ( campo ) {
				if ( campo.type === 'radio' ) {
					campo.checked = String( valore ) === campo.value;
				} else if ( campo.type === 'checkbox' ) {
					campo.checked = Array.isArray( valore ) ? valore.indexOf( campo.value ) !== -1 : !! valore;
				} else {
					campo.value = valore === null || valore === undefined ? '' : String( valore );
					sincronizzaColore( campo );
				}
			} );
		} );
	}

	pagina.querySelectorAll( '.ds-campo-colore' ).forEach( function ( gruppo ) {
		var scelta = gruppo.querySelector( '.ds-campo-colore-scelta' );
		var testo = gruppo.querySelector( 'input[type="text"]' );
		if ( ! scelta || ! testo ) {
			return;
		}
		scelta.addEventListener( 'input', function () {
			testo.value = scelta.value;
			testo.dispatchEvent( new Event( 'input', { bubbles: true } ) );
		} );
		testo.addEventListener( 'input', function () {
			sincronizzaColore( testo );
		} );
	} );

	pagina.querySelectorAll( 'form.ds-impostazioni' ).forEach( function ( form ) {
		var pulsante = form.querySelector( '.ds-salva-pulsante' );

		function modificato() {
			if ( form.classList.contains( 'is-salvataggio' ) ) {
				return;
			}
			form.classList.add( 'is-modificato' );
			esitoForm( form, __( 'Unsaved changes', 'ds-core' ), 'modificato' );
		}
		form.addEventListener( 'input', modificato );
		form.addEventListener( 'change', modificato );

		function fine() {
			form.classList.remove( 'is-salvataggio' );
			if ( pulsante ) {
				pulsante.removeAttribute( 'aria-disabled' );
			}
		}

		form.addEventListener( 'submit', function ( evento ) {
			evento.preventDefault();
			if ( form.classList.contains( 'is-salvataggio' ) ) {
				return;
			}
			form.classList.add( 'is-salvataggio' );
			if ( pulsante ) {
				pulsante.setAttribute( 'aria-disabled', 'true' );
			}
			esitoForm( form, __( 'saving…', 'ds-core' ), 'attesa' );

			// FormData del modulo HTML: contiene già action=ds_core_impostazioni, l'ID e il nonce del modulo.
			fetch( dsCore.ajax, { method: 'POST', credentials: 'same-origin', body: new FormData( form ) } )
				.then( function ( risposta ) {
					return risposta.json().catch( function () {
						return null;
					} );
				} )
				.then( function ( esito ) {
					fine();
					if ( esito && esito.success && esito.data.ricarica ) {
						// Richiesta di cambio dell'indirizzo creata: la pagina nuova la mostra con il messaggio.
						form.classList.remove( 'is-modificato' );
						esitoForm( form, esito.data.messaggio, 'ok' );
						window.location.reload();
						return;
					}
					if ( esito && esito.success ) {
						form.classList.remove( 'is-modificato' );
						mostraErrori( form, {} );
						applicaValori( form, esito.data.valori );
						esitoForm( form, esito.data.messaggio, 'ok' );
						return;
					}
					var dati = esito && esito.data ? esito.data : null;
					mostraErrori( form, dati && dati.errori ? dati.errori : {} );
					esitoForm( form, testoErrore( esito ), 'errore' );
				} )
				.catch( function () {
					fine();
					esitoForm( form, __( 'Not saved: network error.', 'ds-core' ), 'errore' );
				} );
		} );
	} );

	/* ---------- Campi che dipendono da un altro campo ---------- */

	pagina.querySelectorAll( '.ds-campo[data-ds-mostra-se]' ).forEach( function ( blocco ) {
		var form = blocco.closest( 'form' );
		var chiave = blocco.getAttribute( 'data-ds-mostra-se' );
		var valore = blocco.getAttribute( 'data-ds-mostra-valore' );
		if ( ! form ) {
			return;
		}
		function aggiorna() {
			var scelto = campiDi( form, chiave ).filter( function ( campo ) {
				return ( campo.type !== 'radio' && campo.type !== 'checkbox' ) || campo.checked;
			} )[ 0 ];
			var mostra = !! scelto && scelto.value === valore;
			blocco.hidden = ! mostra;
			// Nascosto = non si manda: il server tiene il numero effettivo.
			blocco.querySelectorAll( 'input, select, textarea' ).forEach( function ( campo ) {
				campo.disabled = ! mostra;
			} );
		}
		campiDi( form, chiave ).forEach( function ( campo ) {
			campo.addEventListener( 'change', aggiorna );
		} );
		aggiorna();
	} );

	/* ---------- Copia della riga per wp-config.php ---------- */

	pagina.querySelectorAll( '[data-ds-copia]' ).forEach( function ( pulsante ) {
		var sorgente = document.getElementById( pulsante.getAttribute( 'data-ds-copia' ) );
		var esito = pulsante.parentNode.querySelector( '.ds-copia-esito' );
		if ( ! sorgente ) {
			return;
		}
		pulsante.hidden = false;
		function scrivi( testo, errore ) {
			if ( esito ) {
				esito.textContent = testo;
				esito.classList.toggle( 'is-errore', !! errore );
			}
		}
		function seleziona() {
			var intervallo = document.createRange();
			intervallo.selectNodeContents( sorgente );
			var selezione = window.getSelection();
			selezione.removeAllRanges();
			selezione.addRange( intervallo );
		}
		pulsante.addEventListener( 'click', function () {
			var testo = sorgente.textContent;
			if ( navigator.clipboard && window.isSecureContext ) {
				navigator.clipboard.writeText( testo ).then( function () {
					scrivi( __( 'Copied.', 'ds-core' ) );
				}, function () {
					seleziona();
					scrivi( __( 'Selected: press Ctrl+C to copy.', 'ds-core' ), true );
				} );
				return;
			}
			seleziona();
			scrivi( __( 'Selected: press Ctrl+C to copy.', 'ds-core' ), true );
		} );
	} );

	/* ---------- Impostazioni nella riga del modulo ---------- */

	var CHIAVE_APERTI = 'ds-core-aperti';

	// localStorage può mancare o dare errore (navigazione privata, dati bloccati): allora non si ricorda nulla.
	function apertiSalvati() {
		try {
			var valore = JSON.parse( window.localStorage.getItem( CHIAVE_APERTI ) || '[]' );
			return Array.isArray( valore ) ? valore : [];
		} catch ( e ) {
			return [];
		}
	}

	function ricordaAperto( id, aperto ) {
		var elenco = apertiSalvati().filter( function ( voce ) {
			return voce !== id;
		} );
		if ( aperto ) {
			elenco.push( id );
		}
		try {
			window.localStorage.setItem( CHIAVE_APERTI, JSON.stringify( elenco ) );
		} catch ( e ) {
			// Niente da fare: la riga resta aperta solo fino alla ricarica.
		}
	}

	function pulsanteDi( id ) {
		return document.getElementById( 'ds-apri-' + id );
	}

	function impostaAperto( id, aperto, ricorda ) {
		var pulsante = pulsanteDi( id );
		var dettagli = document.getElementById( 'ds-impostazioni-' + id );
		if ( ! pulsante || ! dettagli ) {
			return false;
		}
		pulsante.setAttribute( 'aria-expanded', aperto ? 'true' : 'false' );
		dettagli.hidden = ! aperto;
		if ( perId[ id ] ) {
			perId[ id ].classList.toggle( 'is-aperto', aperto );
		}
		if ( ricorda ) {
			ricordaAperto( id, aperto );
		}
		return true;
	}

	function scorriA( elemento ) {
		var calmo = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		elemento.scrollIntoView( { behavior: calmo ? 'auto' : 'smooth', block: 'start' } );
	}

	// Apre la riga di un modulo dall'avviso in cima o dall'indirizzo: toglie i filtri se la nascondono, la porta in
	// vista e mette il fuoco sul suo pulsante «Settings», così chi usa la tastiera continua da lì.
	function mostraModulo( id ) {
		var riga = perId[ id ];
		if ( ! riga || ! pulsanteDi( id ) ) {
			return false;
		}
		if ( ! visibile( riga ) ) {
			togliFiltri();
		}
		impostaAperto( id, true, true );
		scorriA( riga );
		pulsanteDi( id ).focus( { preventScroll: true } );
		return true;
	}

	pagina.querySelectorAll( '.ds-apri' ).forEach( function ( pulsante ) {
		var id = pulsante.id.replace( /^ds-apri-/, '' );
		pulsante.addEventListener( 'click', function () {
			impostaAperto( id, pulsante.getAttribute( 'aria-expanded' ) !== 'true', true );
		} );
	} );

	pagina.querySelectorAll( '[data-ds-apri]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function ( evento ) {
			if ( mostraModulo( link.getAttribute( 'data-ds-apri' ) ) ) {
				evento.preventDefault();
			}
		} );
	} );

	apertiSalvati().forEach( function ( id ) {
		impostaAperto( id, true, false );
	} );
	var dallIndirizzo = /^#ds-impostazioni-([a-z0-9_-]+)$/.exec( window.location.hash );
	if ( dallIndirizzo ) {
		mostraModulo( dallIndirizzo[ 1 ] );
	}

	aggiornaConteggi();
	aggiornaSelezione();
}() );

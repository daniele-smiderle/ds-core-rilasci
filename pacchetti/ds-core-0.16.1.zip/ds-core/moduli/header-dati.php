<?php
/**
 * Modulo header-dati: intestazioni di sicurezza e meno dati esposti, nel .htaccess della radice (blocco
 * «DS Core header-dati», includes/htaccess.php).
 *
 * - Intestazioni: X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy e, se il sito è in
 *   https, Strict-Transport-Security. Nel .htaccess valgono anche per immagini, font e fogli di stile (da PHP no).
 * - Niente elenco dei file delle cartelle senza index (Options -Indexes). Alcuni hosting non lo permettono: se il sito
 *   non risponde con quella riga, il blocco si riscrive senza (e il pannello lo dice).
 * - readme.html, license.txt e wp-config-sample.php negati (dicono la versione di WordPress o sono inutili sul sito).
 * - Se le stesse intestazioni arrivano già da PHP o da un altro blocco, escono doppie (su alcuni server Header set non
 *   sostituisce quelle di PHP): il modulo lo controlla e lo segnala, senza toccare gli altri.
 * - Server senza .htaccess (Nginx): le intestazioni si mandano da PHP, solo sulle pagine di WordPress.
 *
 * Il blocco si scrive da una richiesta di amministrazione (al più una volta l'ora o con «Check again» nel riquadro),
 * si controlla il sito dopo la scrittura e si toglie quando il modulo si spegne.
 */

defined( 'ABSPATH' ) || exit;

/** Intestazioni di sicurezza: nome => valore. */
function ds_core_hd_intestazioni() {
	$intestazioni = array(
		'X-Content-Type-Options' => 'nosniff',
		'X-Frame-Options'        => 'SAMEORIGIN',
		'Referrer-Policy'        => 'strict-origin-when-cross-origin',
		'Permissions-Policy'     => 'camera=(), microphone=(), geolocation=()',
	);
	if ( 0 === strpos( home_url( '/' ), 'https://' ) ) {
		$intestazioni['Strict-Transport-Security'] = 'max-age=31536000';
	}
	return $intestazioni;
}

/** Righe del blocco. $con_indexes = false per gli hosting che non permettono Options. */
function ds_core_hd_righe( $con_indexes ) {
	$righe = array( '<IfModule mod_headers.c>' );
	foreach ( ds_core_hd_intestazioni() as $nome => $valore ) {
		$righe[] = 'Header set ' . $nome . ' "' . $valore . '"';
	}
	$righe[] = '</IfModule>';
	if ( $con_indexes ) {
		$righe[] = 'Options -Indexes';
	}
	$righe = array_merge(
		$righe,
		array(
			'<FilesMatch "^(readme\.html|license\.txt|wp-config-sample\.php)$">',
			'<IfModule mod_authz_core.c>',
			'Require all denied',
			'</IfModule>',
			'<IfModule !mod_authz_core.c>',
			'Order allow,deny',
			'Deny from all',
			'</IfModule>',
			'</FilesMatch>',
		)
	);
	return $righe;
}

/**
 * Scrive o controlla il blocco e salva l'esito in ds_core_hd_stato:
 * esito (true | 'non-supportato' | 'non-scrivibile' | 'sito-ko'), quando, senza_indexes, doppie (nomi), mancanti.
 */
function ds_core_hd_applica() {
	$stato = get_option( 'ds_core_hd_stato', array() );
	$stato = is_array( $stato ) ? $stato : array();
	$senza = ! empty( $stato['senza_indexes'] );

	$esito = ds_core_htaccess_scrivi( 'header-dati', ds_core_hd_righe( ! $senza ) );
	if ( 'sito-ko' === $esito && ! $senza ) {
		$senza = true;
		$esito = ds_core_htaccess_scrivi( 'header-dati', ds_core_hd_righe( false ) );
	}

	// Controllo delle intestazioni sulla home e su un file statico: mancanti e doppie.
	$doppie   = array();
	$mancanti = array();
	if ( true === $esito || 'non-supportato' === $esito ) {
		foreach ( array( add_query_arg( 'ds_core_prova', time(), home_url( '/' ) ), includes_url( 'css/dashicons.min.css' ) ) as $url ) {
			$risposta = wp_remote_get( $url, array( 'timeout' => 20, 'redirection' => 3, 'sslverify' => false ) );
			if ( is_wp_error( $risposta ) ) {
				continue;
			}
			$statico = false !== strpos( $url, 'dashicons' );
			foreach ( array_keys( ds_core_hd_intestazioni() ) as $nome ) {
				$valore = wp_remote_retrieve_header( $risposta, $nome );
				$valori = is_array( $valore ) ? $valore : ( '' === $valore ? array() : array_map( 'trim', explode( ',', $valore ) ) );
				// Permissions-Policy contiene virgole proprie: conta solo i doppioni identici.
				if ( 'Permissions-Policy' === $nome && ! is_array( $valore ) ) {
					$valori = '' === $valore ? array() : array( $valore );
				}
				if ( ! $valori ) {
					if ( ! ( $statico && 'non-supportato' === $esito ) ) {
						$mancanti[ $nome ] = true;
					}
				} elseif ( count( $valori ) > 1 ) {
					$doppie[ $nome ] = true;
				}
			}
		}
	}

	$stato = array(
		'esito'         => $esito,
		'quando'        => time(),
		'senza_indexes' => $senza,
		'doppie'        => array_keys( $doppie ),
		'mancanti'      => array_keys( $mancanti ),
	);
	update_option( 'ds_core_hd_stato', $stato, false );
	set_transient( 'ds_core_hd_controllato', 1, HOUR_IN_SECONDS );
	return $stato;
}

// Scrittura e controllo dalle richieste di amministrazione, al più una volta l'ora.
add_action( 'admin_init', 'ds_core_hd_controlla' );
function ds_core_hd_controlla() {
	if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) || get_transient( 'ds_core_hd_controllato' ) ) {
		return;
	}
	ds_core_hd_applica();
}

// Server senza .htaccess: intestazioni da PHP sulle pagine di WordPress.
add_action( 'send_headers', 'ds_core_hd_php' );
function ds_core_hd_php() {
	if ( ds_core_htaccess_supportato() || headers_sent() ) {
		return;
	}
	foreach ( ds_core_hd_intestazioni() as $nome => $valore ) {
		header( $nome . ': ' . $valore );
	}
}

add_action( 'admin_post_ds_core_hd', 'ds_core_hd_ricontrolla' );
function ds_core_hd_ricontrolla() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_hd' );
	ds_core_hd_applica();
	wp_safe_redirect( admin_url( 'admin.php?page=ds-core' ) . '#ds-impostazioni-header-dati' );
	exit;
}

/**
 * Problemi da mostrare nell'avviso in cima al pannello (campo 'problemi' del registro). «Non ancora controllato» e
 * «server senza .htaccess» non sono problemi: il modulo fa quello che può e lo spiega nel suo stato.
 */
function ds_core_hd_problemi() {
	$stato    = get_option( 'ds_core_hd_stato', array() );
	$stato    = is_array( $stato ) ? $stato : array();
	$esito    = $stato['esito'] ?? null;
	$problemi = array();
	if ( 'non-scrivibile' === $esito ) {
		$problemi[] = __( 'The .htaccess file cannot be written: the headers are not active.', 'ds-core' );
	} elseif ( 'sito-ko' === $esito ) {
		$problemi[] = __( 'The site did not respond with the new rules, so the previous .htaccess file has been put back.', 'ds-core' );
	}
	if ( ! empty( $stato['doppie'] ) ) {
		$problemi[] = __( 'Some headers are sent twice.', 'ds-core' );
	}
	if ( ! empty( $stato['mancanti'] ) ) {
		$problemi[] = __( 'Some headers are missing from the responses.', 'ds-core' );
	}
	return $problemi;
}

/**
 * Stato e controllo, dentro la riga del modulo nel pannello (campo 'stato' del registro, dalla 0.13.0; solo a modulo
 * acceso). Le scelte future (HSTS, X-Frame-Options, Content-Security-Policy di prova) andranno nei campi del registro,
 * applicate ascoltando 'ds_core_impostazioni_salvate'.
 */
function ds_core_hd_riquadro() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$stato = get_option( 'ds_core_hd_stato', array() );
	$stato = is_array( $stato ) ? $stato : array();
	$esito = $stato['esito'] ?? null;
	?>
	<div class="ds-header-dati">
		<p class="ds-accesso-stato">
			<?php
			if ( null === $esito ) {
				esc_html_e( 'Not checked yet: the check runs at the next page load of the dashboard.', 'ds-core' );
			} elseif ( true === $esito ) {
				printf(
					/* translators: %s: date and time of the last check. */
					esc_html__( 'Written in the .htaccess file and checked on %s.', 'ds-core' ),
					esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $stato['quando'] ) )
				);
			} elseif ( 'non-supportato' === $esito ) {
				esc_html_e( 'This server does not read .htaccess files: the headers are sent by WordPress, only on its own pages.', 'ds-core' );
			} elseif ( 'non-scrivibile' === $esito ) {
				esc_html_e( 'The .htaccess file cannot be written: nothing has been changed.', 'ds-core' );
			} else {
				esc_html_e( 'The site did not respond with the new rules, so the previous .htaccess file has been put back.', 'ds-core' );
			}
			?>
		</p>
		<?php if ( ! empty( $stato['senza_indexes'] ) ) : ?>
			<p class="ds-avviso"><?php esc_html_e( 'This hosting does not allow “Options -Indexes”: the block has been written without it. Folder listing depends on the hosting settings.', 'ds-core' ); ?></p>
		<?php endif; ?>
		<?php if ( ! empty( $stato['doppie'] ) ) : ?>
			<?php /* translators: %s: list of header names. */ ?>
			<p class="ds-avviso"><?php echo esc_html( sprintf( __( 'These headers are sent twice (also by PHP, a plugin or another .htaccess block): %s. Remove the other source.', 'ds-core' ), implode( ', ', $stato['doppie'] ) ) ); ?></p>
		<?php endif; ?>
		<?php if ( ! empty( $stato['mancanti'] ) ) : ?>
			<?php /* translators: %s: list of header names. */ ?>
			<p class="ds-avviso"><?php echo esc_html( sprintf( __( 'These headers are missing from the responses: %s. The hosting may not have the headers module.', 'ds-core' ), implode( ', ', $stato['mancanti'] ) ) ); ?></p>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="ds_core_hd">
			<?php wp_nonce_field( 'ds_core_hd' ); ?>
			<button type="submit" class="button"><?php esc_html_e( 'Check again', 'ds-core' ); ?></button>
		</form>
	</div>
	<?php
}

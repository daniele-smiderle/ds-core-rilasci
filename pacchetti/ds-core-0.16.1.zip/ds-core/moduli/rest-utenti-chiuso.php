<?php
/**
 * Modulo rest-utenti-chiuso.
 *
 * Toglie dall'API REST l'elenco degli utenti (/wp/v2/users) e la scheda del singolo utente (/wp/v2/users/<id>) a
 * chi non scrive contenuti: visitatori, clienti dei negozi, abbonati. Così dall'esterno non si leggono i nomi utente
 * da usare per gli attacchi al login.
 *
 * Perché serve anche con l'opzione «REST API disabilitata» di Breakdance: quella risponde 403 ma lascia l'elenco
 * nel corpo della risposta, e su ?rest_route=/wp/v2/users risponde 200 (verificato il 24/11/2026).
 *
 * Restano disponibili:
 * - /wp/v2/users/me per chi è collegato (lo usano l'editor e le app);
 * - tutto l'endpoint per chi può modificare contenuti (edit_posts) o gestire utenti (list_users): l'editor a
 *   blocchi lo usa per scegliere l'autore.
 *
 * Base: modulo sicurezza-rest-utenti di un plugin di sito, generalizzato.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'rest_endpoints', 'ds_core_rest_utenti_chiuso' );

function ds_core_rest_utenti_chiuso( $endpoints ) {
	if ( current_user_can( 'edit_posts' ) || current_user_can( 'list_users' ) ) {
		return $endpoints;
	}
	foreach ( array_keys( $endpoints ) as $rotta ) {
		// /wp/v2/users e /wp/v2/users/(?P<id>[\d]+); non /wp/v2/users/me né le password per le applicazioni.
		if ( '/wp/v2/users' === $rotta || preg_match( '#^/wp/v2/users/\(\?P<id>[^/]*\)$#', $rotta ) ) {
			unset( $endpoints[ $rotta ] );
		}
	}
	return $endpoints;
}

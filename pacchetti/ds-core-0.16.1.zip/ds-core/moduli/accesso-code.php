<?php
/**
 * Modulo accesso-code.
 *
 * Gli ingressi usati da Claude Code restano chiusi finché un amministratore non li apre a tempo dal pannello di
 * DS Core (1, 4 o 8 ore). Alla scadenza si richiudono da soli: l'ora si controlla a ogni richiesta, senza cron.
 * Non esiste «aperto per sempre». I plugin (Agent Connector, Universal Abilities, Breakdance) restano attivi e
 * aggiornabili: si chiudono solo gli ingressi.
 *
 * Da chiuso:
 * - le password per le applicazioni non funzionano (wp_is_application_passwords_available → false): non entrano
 *   né nell'API REST né in XML-RPC. Le password salvate non si cancellano e tornano valide all'apertura;
 * - l'API REST risponde 403 a /mcp/*, /acfw-auth/v1/*, /agent-connector-for-wp/v1/* e
 *   /wp-abilities/v1/abilities/agent-connector-for-wp/*, anche agli amministratori collegati dal browser: un
 *   account rubato non diventa esecuzione di codice. Stessa risposta per tutti i casi, senza dire perché.
 *
 * Restano sempre raggiungibili: il login dal browser (cookie, non usa le password per le applicazioni), il
 * pannello di DS Core (admin-post e admin-ajax, non REST), il builder di Breakdance e tutte le altre rotte REST.
 *
 * Fallisce chiuso: opzione mancante, illeggibile, scaduta o con una scadenza oltre la durata massima = chiuso.
 *
 * Ogni apertura e chiusura va nella storia del pannello (ds_core_storia) come codice ('accesso:aperto:<fino>:<ore>:
 * <origine>', 'accesso:chiuso[:<origine>]', 'accesso:scaduto', 'accesso:non-valido'), tradotto dal pannello quando
 * lo mostra; ogni apertura manda una mail all'indirizzo unico degli avvisi di DS Core (dalla 1.2.0; vuoto =
 * amministratore del sito), nella lingua del sito. Dalla 1.4.0 (DS Core 0.15.1, decisione di Daniele del 27/11/2026)
 * anche la chiusura prima della scadenza («Chiudi ora», in futuro la firma) e la chiusura per una scadenza non valida
 * mandano l'avviso di sicurezza, con chi, quando e IP; la chiusura alla scadenza naturale no.
 *
 * Emergenza: define( 'DS_CORE_SPENTI', 'accesso-code' ); in wp-config.php spegne il modulo, quindi apre tutto.
 *
 * Opzioni: ds_core_accesso_fino (timestamp di chiusura; assente = chiuso). Riservata alla fase 2:
 * ds_core_accesso_nonce (numeri unici delle aperture firmate dal PC, rotta /ds-core/v1/accesso). La rotta della
 * fase 2 non rientra fra quelle chiuse qui sotto e dovrà aprire con ds_core_accesso_apri( $ore, 'firma' ).
 */

defined( 'ABSPATH' ) || exit;

const DS_CORE_ACCESSO_OPZIONE = 'ds_core_accesso_fino';

/** Durate ammesse, in ore. Niente filtro: l'elenco non si allarga dall'esterno. */
function ds_core_accesso_durate() {
	return array( 1, 4, 8 );
}

/** Durata massima in secondi: una scadenza più lontana di così non è valida. */
function ds_core_accesso_massimo() {
	return max( ds_core_accesso_durate() ) * HOUR_IN_SECONDS;
}

/**
 * Scadenza dell'apertura in corso (timestamp) oppure 0 = chiuso.
 * Una scadenza passata o non valida viene tolta e la chiusura scritta nella storia, una volta sola.
 */
function ds_core_accesso_fino() {
	$valore = get_option( DS_CORE_ACCESSO_OPZIONE, '' );
	if ( empty( $valore ) ) {
		return 0;
	}
	if ( is_int( $valore ) ) {
		$valore = (string) $valore;
	}
	if ( ! is_string( $valore ) || ! ctype_digit( $valore ) ) {
		ds_core_accesso_scaduto( 0 );
		return 0;
	}
	$fino = (int) $valore;
	$ora  = time();
	if ( $fino <= $ora ) {
		ds_core_accesso_scaduto( $fino );
		return 0;
	}
	if ( $fino > $ora + ds_core_accesso_massimo() + MINUTE_IN_SECONDS ) {
		ds_core_accesso_scaduto( 0 );
		return 0;
	}
	return $fino;
}

function ds_core_accesso_aperto() {
	return ds_core_accesso_fino() > 0;
}

/**
 * Chiusura automatica (scadenza raggiunta, $fino > 0) o per valore non valido ($fino = 0).
 * Può girare durante l'autenticazione: niente funzioni dell'utente corrente, utente 'automatico'.
 */
function ds_core_accesso_scaduto( $fino ) {
	static $fatto = false;
	if ( $fatto ) {
		return;
	}
	$fatto = true;
	// Solo la richiesta che cancella davvero l'opzione scrive la storia (niente righe doppie fra richieste parallele).
	if ( delete_option( DS_CORE_ACCESSO_OPZIONE ) ) {
		if ( $fino ) {
			// Scadenza naturale: solo la storia e il registro, nessuna mail (Daniele, 27/11/2026).
			ds_core_storia_aggiungi( 'accesso-code', ds_core_accesso_descrivi( $fino ), 'accesso:scaduto', 'automatico', $fino );
		} else {
			// Scadenza illeggibile o troppo lontana: l'opzione è stata scritta senza passare dal pannello.
			ds_core_storia_aggiungi( 'accesso-code', 'accesso:non-valido', 'accesso:chiuso', 'automatico' );
			ds_core_accesso_avviso_chiusura( 0, 'non-valido' );
		}
	}
}

/** Codice per la storia: 'accesso:aperto:<fino>' o 'accesso:chiuso'. */
function ds_core_accesso_descrivi( $fino ) {
	return $fino ? 'accesso:aperto:' . (int) $fino : 'accesso:chiuso';
}

/**
 * Apre per $ore ore da adesso (sostituisce un'apertura in corso: si può allungare o accorciare).
 * $origine: 'pannello' (fase 1) o, in futuro, 'firma'. Restituisce true se la mail è partita, false se no,
 * WP_Error se la durata non è ammessa.
 */
function ds_core_accesso_apri( $ore, $origine ) {
	$ore = (int) $ore;
	if ( ! in_array( $ore, ds_core_accesso_durate(), true ) ) {
		return new WP_Error( 'ds_core_accesso_durata', __( 'Duration not allowed.', 'ds-core' ) );
	}
	$prima = ds_core_accesso_fino();
	$fino  = time() + $ore * HOUR_IN_SECONDS;
	update_option( DS_CORE_ACCESSO_OPZIONE, (string) $fino, true );
	ds_core_storia_aggiungi( 'accesso-code', ds_core_accesso_descrivi( $prima ), 'accesso:aperto:' . $fino . ':' . $ore . ':' . sanitize_key( $origine ) );
	do_action( 'ds_core_accesso_aperto', $fino, $origine );
	return ds_core_accesso_mail( $fino, $ore, $origine );
}

/**
 * Chiude subito. $origine: 'pannello' o, in futuro, 'firma'. Se l'accesso era aperto è una chiusura prima della
 * scadenza: storia, registro delle attività e avviso di sicurezza (dalla 1.4.0). Restituisce true se la mail è
 * partita, false se no, null se l'accesso era già chiuso (niente da avvisare).
 */
function ds_core_accesso_chiudi( $origine ) {
	$prima = ds_core_accesso_fino();
	delete_option( DS_CORE_ACCESSO_OPZIONE );
	if ( ! $prima ) {
		return null;
	}
	ds_core_storia_aggiungi( 'accesso-code', ds_core_accesso_descrivi( $prima ), 'accesso:chiuso:' . sanitize_key( $origine ) );
	do_action( 'ds_core_accesso_chiuso', $origine );
	return ds_core_accesso_avviso_chiusura( $prima, $origine );
}

/**
 * Avviso di sicurezza per una chiusura prima della scadenza ($fino = scadenza che aveva, $origine 'pannello' o
 * 'firma') o per una scadenza non valida ($fino = 0, $origine 'non-valido'). Va all'indirizzo degli avvisi e sempre
 * anche all'email dell'amministratore del sito (tipo 'accesso.chiusura', includes/avvisi.php), nella lingua del sito.
 * La chiusura per scadenza non valida può avvenire durante l'autenticazione, prima di 'init': allora la mail parte
 * su 'init' (traduzioni pronte). Restituisce true se è partita, false se no, null se rimandata.
 */
function ds_core_accesso_avviso_chiusura( $fino, $origine ) {
	$utente = did_action( 'set_current_user' ) ? wp_get_current_user() : null;
	$dati   = array(
		'fino'    => (int) $fino,
		'origine' => sanitize_key( $origine ),
		'quando'  => time(),
		'chi'     => $utente && $utente->exists() ? $utente->user_login : '',
		'ip'      => 'non-valido' === $origine ? '' : ds_core_eventi_ip(),
	);
	if ( ! did_action( 'init' ) ) {
		add_action(
			'init',
			function () use ( $dati ) {
				ds_core_accesso_mail_chiusura( $dati );
			},
			99,
			0
		);
		return null;
	}
	return ds_core_accesso_mail_chiusura( $dati );
}

/** Testo e invio dell'avviso di chiusura (dati preparati da ds_core_accesso_avviso_chiusura()). */
function ds_core_accesso_mail_chiusura( $dati ) {
	$cambiata = switch_to_locale( get_locale() );
	$sito     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$formato  = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
	if ( 'non-valido' === $dati['origine'] ) {
		/* translators: %s: site title. */
		$oggetto = sprintf( __( '[%s] Claude Code access closed: invalid expiry', 'ds-core' ), $sito );
		$righe   = array(
			/* translators: %s: site address. */
			sprintf( __( 'Claude Code access on %s has been closed because its stored expiry was not valid.', 'ds-core' ), home_url( '/' ) ),
			'',
			/* translators: %s: date and time. */
			sprintf( __( 'When: %s', 'ds-core' ), wp_date( $formato, $dati['quando'] ) ),
			'',
			__( 'Only the DS Core panel writes the expiry. If nobody changed the database by hand, someone with access to it may have tried to keep access open: check the administrator accounts and the hosting account.', 'ds-core' ),
		);
	} else {
		/* translators: %s: site title. */
		$oggetto = sprintf( __( '[%s] Claude Code access closed before time', 'ds-core' ), $sito );
		$righe   = array(
			/* translators: %s: site address. */
			sprintf( __( 'Claude Code access on %s has been closed before its expiry.', 'ds-core' ), home_url( '/' ) ),
			'',
			/* translators: 1: username, 2: where it was closed from (panel). */
			sprintf( __( 'Closed by: %1$s (%2$s)', 'ds-core' ), '' !== $dati['chi'] ? $dati['chi'] : __( 'unknown', 'ds-core' ), $dati['origine'] ),
			/* translators: %s: date and time. */
			sprintf( __( 'When: %s', 'ds-core' ), wp_date( $formato, $dati['quando'] ) ),
			/* translators: %s: IP address. */
			sprintf( __( 'IP address: %s', 'ds-core' ), '' !== $dati['ip'] ? $dati['ip'] : __( 'unknown', 'ds-core' ) ),
			/* translators: %s: date and time when access would have closed by itself. */
			sprintf( __( 'It was open until: %s', 'ds-core' ), wp_date( $formato, $dati['fino'] ) ),
			'',
			__( 'If you did not close it, someone else with an administrator account did: check the administrator accounts.', 'ds-core' ),
		);
	}
	$righe[] = admin_url( 'admin.php?page=ds-core' );
	$inviata = ds_core_manda_avviso( 'accesso.chiusura', $oggetto, implode( "\n", $righe ) );
	if ( $cambiata ) {
		restore_previous_locale();
	}
	return $inviata;
}

/**
 * Mail di apertura all'indirizzo unico degli avvisi di DS Core (impostazioni generali; vuoto = amministratore del
 * sito, dalla 1.2.0), nella lingua del sito (non di chi apre). Dalla 1.3.0 (DS Core 0.15.0) è un avviso di
 * sicurezza: va sempre anche all'email dell'amministratore del sito.
 */
function ds_core_accesso_mail( $fino, $ore, $origine ) {
	$cambiata = switch_to_locale( get_locale() );

	$sito    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$utente  = wp_get_current_user();
	$chi     = $utente->exists() ? $utente->user_login : $origine;
	$ip      = isset( $_SERVER['REMOTE_ADDR'] ) ? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP ) : false;
	$quando  = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $fino );
	/* translators: 1: site title, 2: time when access closes. */
	$oggetto = sprintf( __( '[%1$s] Claude Code access open until %2$s', 'ds-core' ), $sito, wp_date( get_option( 'time_format' ), $fino ) );
	$testo   = implode(
		"\n",
		array(
			/* translators: %s: site address. */
			sprintf( __( 'Claude Code access has been opened on %s.', 'ds-core' ), home_url( '/' ) ),
			'',
			/* translators: 1: username, 2: where it was opened from (panel). */
			sprintf( __( 'Opened by: %1$s (%2$s)', 'ds-core' ), $chi, $origine ),
			/* translators: %s: IP address. */
			sprintf( __( 'IP address: %s', 'ds-core' ), $ip ? $ip : __( 'unknown', 'ds-core' ) ),
			/* translators: 1: number of hours, 2: date and time when access closes. */
			sprintf( __( 'Duration: %1$d h, until %2$s. Then it closes by itself.', 'ds-core' ), $ore, $quando ),
			'',
			__( 'If you did not open it: go to the panel and press “Close now”, then change the password of the account above.', 'ds-core' ),
			admin_url( 'admin.php?page=ds-core' ),
		)
	);
	// Avviso di sicurezza (0.15.0): va anche all'email dell'amministratore del sito (includes/avvisi.php).
	$inviata = ds_core_manda_avviso( 'accesso.apertura', $oggetto, $testo );

	if ( $cambiata ) {
		restore_previous_locale();
	}
	return $inviata;
}

/* ---------- Chiusura ---------- */

// Controllo della scadenza a ogni richiesta (un'opzione caricata in memoria, nessuna query in più): la chiusura
// automatica finisce nella storia alla prima richiesta dopo la scadenza, con l'ora della scadenza.
add_action( 'init', 'ds_core_accesso_fino', 1, 0 );

// Priorità alta: ha l'ultima parola anche se un altro plugin riaccende le password per le applicazioni.
add_filter( 'wp_is_application_passwords_available', 'ds_core_accesso_password_app', 9999 );
function ds_core_accesso_password_app( $disponibili ) {
	return ds_core_accesso_aperto() ? $disponibili : false;
}

/**
 * Rotte chiuse. WordPress confronta le rotte senza distinguere maiuscole e minuscole: qui si normalizza allo
 * stesso modo (minuscole, barre doppie, codifica %).
 */
function ds_core_accesso_rotta_chiusa( $rotta ) {
	$rotta = strtolower( rawurldecode( (string) $rotta ) );
	$rotta = '/' . ltrim( (string) preg_replace( '#/+#', '/', $rotta ), '/' );
	return (bool) preg_match( '#^/(?:mcp|acfw-auth/v1|agent-connector-for-wp/v1|wp-abilities/v1/abilities/agent-connector-for-wp)(?:/|$)#', $rotta );
}

// Priorità alta: vale anche se un filtro precedente ha già preparato una risposta. Vale anche per le richieste
// interne (rest_do_request) e per quelle dentro /batch/v1, che passano dallo stesso filtro.
add_filter( 'rest_pre_dispatch', 'ds_core_accesso_rest', 9999, 3 );
function ds_core_accesso_rest( $risultato, $server, $richiesta ) {
	if ( ! ( $richiesta instanceof WP_REST_Request ) || ! ds_core_accesso_rotta_chiusa( $richiesta->get_route() ) ) {
		return $risultato;
	}
	if ( ds_core_accesso_aperto() ) {
		return $risultato;
	}
	// La stessa risposta standard di WordPress per ogni caso chiuso.
	return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to do that.' ), array( 'status' => 403 ) );
}

/* ---------- Pannello ---------- */

add_action( 'admin_post_ds_core_accesso', 'ds_core_accesso_pulsante' );
function ds_core_accesso_pulsante() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to do this.', 'ds-core' ), 403 );
	}
	check_admin_referer( 'ds_core_accesso' );

	$scelta = isset( $_POST['ds_accesso'] ) ? sanitize_key( wp_unslash( $_POST['ds_accesso'] ) ) : '';
	if ( 'chiudi' === $scelta ) {
		$mail  = ds_core_accesso_chiudi( 'pannello' );
		$esito = false === $mail ? 'chiuso-senza-mail' : 'chiuso';
	} elseif ( ctype_digit( $scelta ) && in_array( (int) $scelta, ds_core_accesso_durate(), true ) ) {
		$mail  = ds_core_accesso_apri( (int) $scelta, 'pannello' );
		$esito = true === $mail ? 'aperto' : 'aperto-senza-mail';
	} else {
		$esito = 'errore';
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'ds-core', 'ds_accesso' => $esito ), admin_url( 'admin.php' ) ) );
	exit;
}

add_action( 'ds_core_pannello_riquadri', 'ds_core_accesso_riquadro' );
function ds_core_accesso_riquadro() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$fino = ds_core_accesso_fino();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo il messaggio dopo il reindirizzamento.
	$esito    = isset( $_GET['ds_accesso'] ) ? sanitize_key( wp_unslash( $_GET['ds_accesso'] ) ) : '';
	$messaggi = array(
		'aperto'            => array( 'success', __( 'Access opened. The notification email has been sent.', 'ds-core' ) ),
		'aperto-senza-mail' => array( 'warning', __( 'Access opened, but the notification email was not sent: check that the site can send email.', 'ds-core' ) ),
		'chiuso'            => array( 'success', __( 'Access closed.', 'ds-core' ) ),
		'chiuso-senza-mail' => array( 'warning', __( 'Access closed, but the notification email was not sent: check that the site can send email.', 'ds-core' ) ),
		'errore'            => array( 'error', __( 'Invalid choice: nothing has changed.', 'ds-core' ) ),
	);
	// Icone del pannello (includes/pannello.php): lucchetto aperto e chiuso.
	$icona = function ( $nome ) {
		return function_exists( 'ds_core_icona' ) ? ds_core_icona( $nome ) : '';
	};
	?>
	<div class="ds-accesso ds-accesso--<?php echo $fino ? 'aperto' : 'chiuso'; ?>">
		<h2><?php esc_html_e( 'Claude Code access', 'ds-core' ); ?></h2>
		<?php if ( isset( $messaggi[ $esito ] ) ) : ?>
			<div class="notice notice-<?php echo esc_attr( $messaggi[ $esito ][0] ); ?> inline"><p><?php echo esc_html( $messaggi[ $esito ][1] ); ?></p></div>
		<?php endif; ?>
		<p class="ds-accesso-stato">
			<?php if ( $fino ) : ?>
				<?php
				echo $icona( 'aperto' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso.
				printf(
					/* translators: 1: date and time when access closes, 2: time left (e.g. "2 hours"). */
					esc_html__( 'Open until %1$s (%2$s left). Then it closes by itself.', 'ds-core' ),
					esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $fino ) ),
					esc_html( human_time_diff( time(), $fino ) )
				);
				?>
			<?php else : ?>
				<?php echo $icona( 'chiuso' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?>
				<?php esc_html_e( 'Closed. Application passwords are off; MCP and the Agent Connector features answer 403.', 'ds-core' ); ?>
			<?php endif; ?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="ds_core_accesso">
			<?php wp_nonce_field( 'ds_core_accesso' ); ?>
			<?php foreach ( ds_core_accesso_durate() as $ore ) : ?>
				<button type="submit" name="ds_accesso" value="<?php echo (int) $ore; ?>" class="button ds-con-icona"><?php echo $icona( 'aperto' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php
				/* translators: %d: number of hours. */
				echo esc_html( sprintf( __( 'Open for %d h', 'ds-core' ), $ore ) );
				?></button>
			<?php endforeach; ?>
			<button type="submit" name="ds_accesso" value="chiudi" class="button ds-con-icona ds-pulsante-stop" <?php disabled( ! $fino ); ?>><?php echo $icona( 'chiuso' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso. ?><?php esc_html_e( 'Close now', 'ds-core' ); ?></button>
		</form>
		<p class="ds-grigio">
			<?php
			printf(
				/* translators: %s: email address, or a list of addresses. */
				esc_html__( 'Opening while access is already open starts again from now with the new duration. Every opening, and every closing before time is up, sends an email to %s (General settings at the bottom of the page); closing when time is up does not. Browser login, this panel and the builder also work while closed.', 'ds-core' ),
				ds_core_avvisi_destinatari_html( 'accesso.apertura' ) // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato.
			);
			?>
		</p>
	</div>
	<?php
}

// Promemoria nella barra di amministrazione finché l'accesso è aperto.
add_action( 'admin_bar_menu', 'ds_core_accesso_barra', 100 );
function ds_core_accesso_barra( $barra ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$fino = ds_core_accesso_fino();
	if ( ! $fino ) {
		return;
	}
	$barra->add_node(
		array(
			'id'    => 'ds-core-accesso',
			/* translators: %s: time when access closes. */
			'title' => esc_html( sprintf( __( 'Code open until %s', 'ds-core' ), wp_date( get_option( 'time_format' ), $fino ) ) ),
			'href'  => admin_url( 'admin.php?page=ds-core' ),
		)
	);
}

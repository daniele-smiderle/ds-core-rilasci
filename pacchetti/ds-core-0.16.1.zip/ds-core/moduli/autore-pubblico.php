<?php
/**
 * Modulo autore-pubblico.
 *
 * Nelle pagine pubbliche l'autore dei contenuti si chiama come il sito (Impostazioni → Generali → Titolo del sito),
 * qualunque sia l'account che li ha pubblicati. Così non compaiono né il nome di chi gestisce il sito né il nome
 * utente (login), che altrimenti escono dal tema, dal feed, da oEmbed e dai plugin SEO (es. «Scritto da» e schema
 * Person di Rank Math).
 *
 * Non modifica gli utenti: cambia solo ciò che viene mostrato fuori dall'amministrazione. Spento il modulo, torna
 * tutto come prima.
 *
 * Il nome si può cambiare dal plugin del sito con il filtro 'ds_core_nome_pubblico'.
 * Con il modulo autori-chiusi, anche i link all'autore puntano alla home.
 */

defined( 'ABSPATH' ) || exit;

/** Nome pubblico dell'autore: il titolo del sito, salvo diversa scelta del plugin del sito. */
function ds_core_autore_pubblico_nome() {
	static $nome = null;
	if ( null === $nome ) {
		$nome = (string) apply_filters( 'ds_core_nome_pubblico', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
	}
	return $nome;
}

/** Vale fuori dall'amministrazione. */
function ds_core_autore_pubblico_vale() {
	return ! is_admin() && '' !== ds_core_autore_pubblico_nome();
}

add_filter( 'the_author', 'ds_core_autore_pubblico_testo', 99 );
add_filter( 'get_the_author_display_name', 'ds_core_autore_pubblico_testo', 99 );
add_filter( 'get_the_author_nickname', 'ds_core_autore_pubblico_testo', 99 );
function ds_core_autore_pubblico_testo( $valore ) {
	return ds_core_autore_pubblico_vale() ? ds_core_autore_pubblico_nome() : $valore;
}

// Login e abbreviazione dell'utente letti da temi e plugin con get_the_author_meta().
add_filter( 'get_the_author_user_login', 'ds_core_autore_pubblico_slug', 99 );
add_filter( 'get_the_author_user_nicename', 'ds_core_autore_pubblico_slug', 99 );
function ds_core_autore_pubblico_slug( $valore ) {
	return ds_core_autore_pubblico_vale() ? sanitize_title( ds_core_autore_pubblico_nome() ) : $valore;
}

// Nome e cognome dell'account non si mostrano: restano vuoti fuori dall'amministrazione.
add_filter( 'get_the_author_first_name', 'ds_core_autore_pubblico_vuoto', 99 );
add_filter( 'get_the_author_last_name', 'ds_core_autore_pubblico_vuoto', 99 );
function ds_core_autore_pubblico_vuoto( $valore ) {
	return ds_core_autore_pubblico_vale() ? '' : $valore;
}

add_filter( 'oembed_response_data', 'ds_core_autore_pubblico_oembed', 99 );
function ds_core_autore_pubblico_oembed( $dati ) {
	if ( isset( $dati['author_name'] ) && '' !== ds_core_autore_pubblico_nome() ) {
		$dati['author_name'] = ds_core_autore_pubblico_nome();
	}
	return $dati;
}
